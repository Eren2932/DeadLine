import math, random
from core import *

STEEL = (108, 112, 124, 255)
STEEL_D = (62, 66, 78, 255)
WOOD = (122, 76, 44, 255)
POLY = (54, 56, 62, 255)

def gun(L=22, H=14, body=POLY, barrel=STEEL, stock=None, mag=3, scope=False,
        drum=False, tube=False, muzzle_w=0, foregrip=False, accent=None):
    """generic side-view gun facing right. Returns (img, muzzle_xy, grip_xy)"""
    im = new(L + 4, H)
    cy = H // 2
    bx0, bx1 = 4, L - 2
    # receiver / body
    rect(im, bx0, cy - 2, bx1 - 6, cy + 2, body)
    rect(im, bx0, cy - 2, bx1 - 6, cy - 2, light(body, 0.22))
    # barrel
    rect(im, bx1 - 8, cy - 1, bx1, cy, barrel)
    if muzzle_w:
        rect(im, bx1 - muzzle_w, cy - 2, bx1, cy + 1, STEEL_D)
    if tube:
        rect(im, bx1 - 12, cy - 3, bx1, cy - 2, dark(barrel, 0.1))
    if drum:
        disc(im, bx0 + 6, cy + 5, 4, STEEL_D)
        disc(im, bx0 + 6, cy + 5, 2, dark(STEEL_D, 0.3))
    # magazine
    if mag:
        rect(im, bx0 + 5, cy + 3, bx0 + 5 + max(1, mag - 1), cy + 5, dark(body, 0.2))
    # grip
    rect(im, bx0 + 2, cy + 3, bx0 + 4, cy + 6, dark(body, 0.35))
    if stock:
        rect(im, 0, cy - 1, bx0 + 1, cy + 3, stock)
        rect(im, 0, cy - 1, bx0 + 1, cy - 1, light(stock, 0.2))
    if scope:
        rect(im, bx0 + 4, cy - 5, bx0 + 11, cy - 3, STEEL_D)
        rect(im, bx0 + 5, cy - 4, bx0 + 6, cy - 4, (150, 220, 255, 255))
    if foregrip:
        rect(im, bx1 - 10, cy + 3, bx1 - 9, cy + 5, dark(body, 0.4))
    if accent:
        rect(im, bx0 + 1, cy - 1, bx0 + 4, cy, accent)
    volumize(im, 0.2, 0.24)
    outline(im)
    return im, (im.width - 2, cy), (bx0 + 3, cy + 3)

def chainsaw():
    im = new(30, 14)
    rect(im, 2, 4, 12, 10, (168, 32, 30, 255))
    rect(im, 2, 4, 12, 4, (214, 66, 60, 255))
    rect(im, 4, 2, 9, 3, (60, 60, 66, 255))
    rect(im, 12, 6, 27, 8, STEEL_D)
    for x in range(13, 28, 2):
        px(im, x, 5, (222, 226, 235, 255))
        px(im, x + 1, 9, (222, 226, 235, 255))
    volumize(im, 0.2, 0.2); outline(im)
    return im, (28, 7), (5, 9)

def katana():
    im = new(28, 12)
    rect(im, 2, 6, 8, 8, (48, 40, 44, 255))
    rect(im, 8, 5, 9, 9, (198, 160, 60, 255))
    rect(im, 9, 6, 26, 7, (226, 232, 244, 255))
    rect(im, 9, 7, 24, 7, (150, 160, 180, 255))
    volumize(im, 0.25, 0.2); outline(im)
    return im, (26, 6), (4, 8)

def turret_parts():
    base = new(20, 14)
    rect(base, 2, 8, 17, 12, (74, 78, 86, 255))
    rect(base, 2, 8, 17, 8, (110, 116, 126, 255))
    rect(base, 4, 5, 15, 8, (58, 62, 70, 255))
    rect(base, 7, 3, 12, 5, (86, 92, 100, 255))
    volumize(base); outline(base)
    gunp = new(22, 10)
    rect(gunp, 2, 3, 12, 7, (60, 64, 72, 255))
    rect(gunp, 12, 4, 20, 5, STEEL)
    rect(gunp, 12, 5, 20, 6, STEEL_D)
    rect(gunp, 4, 1, 9, 2, (44, 48, 54, 255))
    volumize(gunp); outline(gunp)
    return base, gunp

def barricade(dmg=0):
    im = new(22, 24)
    c = (146, 150, 158, 255)
    rect(im, 2, 6, 19, 22, c)
    rect(im, 2, 6, 19, 7, light(c, 0.25))
    for i in range(0, 18, 6):
        rect(im, 3 + i, 8, 6 + i, 11, (226, 200, 60, 255))
        rect(im, 3 + i, 12, 6 + i, 15, (36, 34, 38, 255))
    rect(im, 2, 20, 19, 22, dark(c, 0.3))
    rnd = random.Random(dmg + 3)
    for _ in range(dmg * 22):
        x = rnd.randint(2, 19); y = rnd.randint(6, 22)
        px(im, x, y, (0, 0, 0, 0) if rnd.random() < 0.5 else dark(c, 0.5))
    volumize(im); outline(im)
    return im

def sandbag():
    im = new(22, 16)
    c = (146, 132, 96, 255)
    for row, y in enumerate((11, 6)):
        for i in range(3 - row):
            x = 2 + i * 6 + row * 3
            rect(im, x, y, x + 5, y + 4, c if (i + row) % 2 == 0 else dark(c, 0.12))
    volumize(im); outline(im)
    return im

def spikes():
    im = new(24, 14)
    for i in range(4):
        x = 2 + i * 5
        for k in range(5):
            rect(im, x + k, 13 - (4 - abs(k - 2)) * 2, x + k, 13, (206, 210, 220, 255))
    rect(im, 1, 12, 22, 13, (70, 66, 62, 255))
    volumize(im); outline(im)
    return im

def tesla():
    im = new(18, 26)
    rect(im, 6, 14, 11, 24, (72, 68, 78, 255))
    disc(im, 8, 9, 5, (150, 156, 170, 255))
    disc(im, 8, 9, 3, (96, 210, 255, 255))
    disc(im, 8, 9, 1, (240, 255, 255, 255))
    volumize(im); outline(im)
    return im

def mine():
    im = new(14, 8)
    rect(im, 2, 4, 11, 6, (86, 92, 72, 255))
    rect(im, 5, 2, 8, 3, (200, 60, 50, 255))
    volumize(im); outline(im)
    return im

def crate():
    im = new(20, 18)
    c = (132, 92, 52, 255)
    rect(im, 2, 3, 17, 16, c)
    rect(im, 2, 3, 17, 4, light(c, 0.25))
    rect(im, 2, 9, 17, 10, dark(c, 0.25))
    limb(im, 3, 4, 16, 15, 1, dark(c, 0.3))
    volumize(im); outline(im)
    return im

def barrel_prop():
    im = new(16, 20)
    c = (168, 62, 46, 255)
    rect(im, 3, 2, 12, 18, c)
    rect(im, 3, 2, 12, 3, light(c, 0.3))
    rect(im, 3, 7, 12, 8, dark(c, 0.3))
    rect(im, 3, 13, 12, 14, dark(c, 0.3))
    volumize(im); outline(im)
    return im

def gravestone():
    im = new(16, 20)
    c = (128, 128, 134, 255)
    rect(im, 3, 5, 12, 19, c)
    disc(im, 7, 6, 4, c)
    rect(im, 6, 9, 9, 10, dark(c, 0.35))
    rect(im, 7, 8, 8, 13, dark(c, 0.35))
    volumize(im); outline(im)
    return im
