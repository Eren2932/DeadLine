"""Procedural soundtrack generator for Dead Line.
Renders three seamless looping tracks (menu / battle / boss) as 22050 Hz mono WAV.
Run:  python3 tools/music.py      (output -> <project>/music/*.wav)
"""
import numpy as np, wave, os, math
from scipy import signal

SR = 22050
OUT = os.environ.get("MUSIC_OUT", os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "music"))
os.makedirs(OUT, exist_ok=True)
rng = np.random.default_rng(1337)

# ------------------------------------------------------------------ helpers
def n_of(sec):
    return int(round(SR * sec))

def zeros(sec):
    return np.zeros(n_of(sec))

def add(buf, pos_sec, data, gain=1.0):
    i = int(round(pos_sec * SR))
    if i < 0:
        data = data[-i:]
        i = 0
    if i >= len(buf):
        return
    end = min(len(buf), i + len(data))
    buf[i:end] += data[:end - i] * gain

def env_ad(n, a=0.002, p=2.0, hold=0.0):
    e = np.ones(n)
    at = max(1, int(n * a)) if a < 1 else int(a)
    at = min(at, n - 1) if n > 1 else 1
    e[:at] = np.linspace(0.0, 1.0, at)
    h = int(hold * n)
    dec_len = n - at - h
    if dec_len > 0:
        e[at + h:] = np.linspace(1.0, 0.0, dec_len) ** p
    return e

def noise(n):
    return rng.normal(0.0, 1.0, n)

def lp(x, cut, order=2):
    cut = min(cut, SR * 0.45)
    b, a = signal.butter(order, cut / (SR * 0.5), btype="low")
    return signal.lfilter(b, a, x)

def hp(x, cut, order=2):
    b, a = signal.butter(order, max(20.0, cut) / (SR * 0.5), btype="high")
    return signal.lfilter(b, a, x)

def bp(x, lo, hi, order=2):
    b, a = signal.butter(order, [max(20.0, lo) / (SR * 0.5), min(hi, SR * 0.45) / (SR * 0.5)],
                         btype="band")
    return signal.lfilter(b, a, x)

def saw(freq, n, phase=0.0):
    ph = (np.arange(n) * freq / SR + phase) % 1.0
    return 2.0 * ph - 1.0

def square(freq, n, duty=0.5, phase=0.0):
    ph = (np.arange(n) * freq / SR + phase) % 1.0
    return np.where(ph < duty, 1.0, -1.0)

def sine(freq, n, phase=0.0):
    return np.sin(2.0 * np.pi * (np.arange(n) * freq / SR + phase))

def dist(x, drive=8.0):
    return np.tanh(x * drive)

def note(semi, base=82.41):
    """Frequency of a note given in semitones above E2 (drop-E metal root)."""
    return base * (2.0 ** (semi / 12.0))

# ------------------------------------------------------------------ instruments
def kick(dur=0.30, f0=150.0, f1=44.0, punch=1.0):
    n = n_of(dur)
    f = np.linspace(f0, f1, n)
    body = np.sin(2.0 * np.pi * np.cumsum(f) / SR) * env_ad(n, 0.0008, 2.2)
    click = hp(noise(n), 2200) * env_ad(n, 0.0005, 9.0) * 0.35 * punch
    return dist(body * 1.4, 1.6) * 0.9 + click

def snare(dur=0.22, bright=1.0):
    n = n_of(dur)
    body = (sine(190, n) + 0.7 * sine(268, n)) * env_ad(n, 0.001, 4.0) * 0.5
    rattle = bp(noise(n), 900, 6500 * bright) * env_ad(n, 0.001, 2.4)
    return dist(body + rattle * 1.2, 1.4)

def hat(dur=0.07, open_=False):
    n = n_of(dur if not open_ else dur * 4)
    return hp(noise(n), 6500) * env_ad(n, 0.0004, 5.0 if not open_ else 1.6) * 0.5

def crash(dur=1.6):
    n = n_of(dur)
    c = hp(noise(n), 3200) * env_ad(n, 0.001, 1.3)
    c += bp(noise(n), 1200, 4200) * env_ad(n, 0.002, 1.0) * 0.6
    return c * 0.55

def tom(f=120.0, dur=0.25):
    n = n_of(dur)
    return np.sin(2.0 * np.pi * np.cumsum(np.linspace(f, f * 0.7, n)) / SR) * env_ad(n, 0.001, 2.4)

def guitar(semi, dur, mute=False, power=True, drive=11.0, detune=0.008):
    """Palm-muted / ringing distorted power chord."""
    n = n_of(dur)
    f = note(semi)
    voices = [f, f * (1.0 + detune), f * 0.5]
    if power:
        voices += [f * 1.4983, f * 1.4983 * (1.0 - detune), f * 2.0]
    x = np.zeros(n)
    for i, vf in enumerate(voices):
        x += saw(vf, n, phase=rng.random()) * (1.0 / (1.0 + i * 0.35))
    e = env_ad(n, 0.0015, 6.0 if mute else 1.5, 0.0 if mute else 0.25)
    x = dist(x * e * 1.4, drive)
    x = lp(x, 3600)
    x = hp(x, 95)
    # speaker cabinet bump
    x += lp(x, 240) * 0.5
    return x * e

def bass(semi, dur, drive=5.0):
    n = n_of(dur)
    f = note(semi) * 0.5
    x = saw(f, n) * 0.8 + sine(f, n) * 0.9 + square(f * 2.0, n, 0.35) * 0.18
    x = dist(x, drive)
    x = lp(x, 900)
    return x * env_ad(n, 0.004, 2.0, 0.55)

def lead(semi, dur, kind="square"):
    n = n_of(dur)
    f = note(semi) * 2.0
    vib = 1.0 + 0.012 * np.sin(2.0 * np.pi * 5.5 * np.arange(n) / SR)
    ph = np.cumsum(f * vib) / SR
    x = (2.0 * ((ph % 1.0)) - 1.0) if kind == "saw" else np.where((ph % 1.0) < 0.5, 1.0, -1.0)
    x = dist(x * 0.7, 4.0)
    x = lp(x, 5200)
    return x * env_ad(n, 0.01, 1.6, 0.35) * 0.5

def pad(semi, dur, voices=5):
    n = n_of(dur)
    f = note(semi)
    x = np.zeros(n)
    for i in range(voices):
        det = 1.0 + (i - voices * 0.5) * 0.004
        x += saw(f * det, n, rng.random()) * 0.5
        x += saw(f * 2.0 * det, n, rng.random()) * 0.18
    x = lp(x, 1400)
    e = np.minimum(1.0, np.linspace(0, 3, n)) * np.minimum(1.0, np.linspace(3, 0, n))
    return x * e * 0.4

def bell(semi, dur=2.4):
    n = n_of(dur)
    f = note(semi) * 2.0
    x = np.zeros(n)
    for k, g in [(1.0, 1.0), (2.01, 0.5), (2.98, 0.3), (4.2, 0.16), (5.4, 0.1)]:
        x += sine(f * k, n) * g * env_ad(n, 0.001, 1.6 + k * 0.4)
    return x * 0.4

def wind(dur):
    n = n_of(dur)
    x = lp(noise(n), 420) * 1.4
    mod = 0.5 + 0.5 * np.sin(2.0 * np.pi * 0.08 * np.arange(n) / SR + rng.random() * 6.0)
    return x * mod * 0.25

def reverb(x, decay=0.32, mix=0.28):
    out = np.copy(x)
    for d, g in [(0.031, 0.7), (0.047, 0.6), (0.071, 0.5), (0.113, 0.42)]:
        di = n_of(d)
        tail = np.zeros(len(x))
        tail[di:] = x[:-di] * g * decay
        out += tail * mix
    return out

def master(buf, tail_sec, gain=0.92, loud=1.0):
    """Fold the reverb tail back to the head so the loop is seamless, then limit."""
    tail_n = n_of(tail_sec)
    if tail_n > 0 and len(buf) > tail_n * 2:
        buf[:tail_n] += buf[-tail_n:]
        buf = buf[:-tail_n]
    buf = dist(buf * loud, 1.05)
    m = np.max(np.abs(buf)) or 1.0
    return buf / m * gain

def write(name, data):
    """Writes a temp WAV then encodes to OGG Vorbis (small, loops cleanly in Godot)."""
    pcm = (np.clip(data, -1.0, 1.0) * 32000).astype("<i2")
    wav_path = os.path.join(OUT, name + ".wav")
    f = wave.open(wav_path, "wb")
    f.setnchannels(1)
    f.setsampwidth(2)
    f.setframerate(SR)
    f.writeframes(pcm.tobytes())
    f.close()
    ogg_path = os.path.join(OUT, name + ".ogg")
    rc = os.system('ffmpeg -y -loglevel error -i "%s" -c:a libvorbis -q:a 3 -ar %d -ac 1 "%s"'
                   % (wav_path, SR, ogg_path))
    if rc == 0 and os.path.exists(ogg_path):
        os.remove(wav_path)
        size = os.path.getsize(ogg_path) / 1024.0
        print("  %-12s %5.1f s  %6.1f KB (ogg)" % (name, len(data) / SR, size))
    else:
        print("  %-12s %5.1f s  WAV fallback (ffmpeg missing)" % (name, len(data) / SR))

# ------------------------------------------------------------------ BATTLE
def build_battle():
    bpm = 150.0
    beat = 60.0 / bpm
    bar = beat * 4.0
    sixteenth = beat * 0.25
    bars = 40
    tail = 1.2
    total = bars * bar + tail
    dr = zeros(total)
    gt = zeros(total)
    bs = zeros(total)
    ld = zeros(total)

    # riff root per bar (E phrygian-ish: 0=E, 1=F, 3=G, 5=A, 8=C, 10=D)
    riff_a = [0, 0, 3, 1, 0, 0, 5, 3]
    riff_b = [8, 8, 5, 5, 3, 3, 1, 0]
    riff_c = [0, 3, 5, 8, 10, 8, 5, 3]
    lead_mel = [12, 15, 19, 15, 17, 15, 12, 10, 12, 15, 19, 22, 19, 17, 15, 12]

    def drum_bar(pos, style="main"):
        for b in range(4):
            t0 = pos + b * beat
            if style == "half":
                if b % 2 == 0:
                    add(dr, t0, kick(0.34), 1.0)
                if b == 2:
                    add(dr, t0, snare(0.3), 0.9)
                add(dr, t0 + beat * 0.5, hat(), 0.35)
                continue
            add(dr, t0, kick(), 1.0 if b % 2 == 0 else 0.75)
            if style == "main" and b in (1, 3):
                add(dr, t0, snare(), 0.85)
            if style == "drive":
                add(dr, t0 + beat * 0.5, kick(0.22), 0.6)
                if b in (1, 3):
                    add(dr, t0, snare(), 0.9)
            for s in range(4):
                add(dr, t0 + s * sixteenth, hat(open_=(s == 2 and b == 3)), 0.28)

    for bar_i in range(bars):
        pos = bar_i * bar
        section = "intro" if bar_i < 4 else (
            "verse" if bar_i < 12 else (
            "chorus" if bar_i < 20 else (
            "verse2" if bar_i < 28 else (
            "break" if bar_i < 32 else "chorus2"))))

        if section == "intro":
            drum_bar(pos, "main" if bar_i >= 2 else "half")
            root = riff_a[bar_i % len(riff_a)]
            add(bs, pos, bass(root, bar * 0.95), 0.9)
            if bar_i >= 2:
                for s in range(8):
                    add(gt, pos + s * beat * 0.5, guitar(root, beat * 0.45, mute=True), 0.5)
        elif section in ("verse", "verse2"):
            drum_bar(pos, "main")
            pat = riff_a if section == "verse" else riff_c
            root = pat[bar_i % len(pat)]
            add(bs, pos, bass(root, bar * 0.98), 1.0)
            # 16th chug with accents
            for s in range(16):
                if s in (0, 3, 6, 8, 11, 14):
                    add(gt, pos + s * sixteenth, guitar(root, sixteenth * 2.1, mute=True), 0.72)
                elif s % 2 == 0:
                    add(gt, pos + s * sixteenth, guitar(root, sixteenth * 1.1, mute=True), 0.42)
            if section == "verse2":
                for s in range(4):
                    add(ld, pos + s * beat, lead(lead_mel[(bar_i * 4 + s) % len(lead_mel)],
                                                 beat * 0.9), 0.5)
        elif section.startswith("chorus"):
            drum_bar(pos, "drive")
            pat = riff_b
            root = pat[bar_i % len(pat)]
            add(bs, pos, bass(root, bar), 1.0)
            add(gt, pos, guitar(root, bar * 0.55, mute=False), 0.75)
            add(gt, pos + bar * 0.5, guitar(root + 3, bar * 0.5, mute=False), 0.6)
            for s in range(4):
                add(ld, pos + s * beat, lead(lead_mel[(bar_i * 4 + s) % len(lead_mel)],
                                             beat * 0.95, "saw"), 0.62)
            if bar_i % 4 == 0:
                add(dr, pos, crash(), 0.5)
        else:  # break
            drum_bar(pos, "half")
            root = [0, 0, 1, 3][bar_i % 4]
            add(bs, pos, bass(root, bar), 0.9)
            add(gt, pos, guitar(root, bar * 0.9, mute=False, drive=8.0), 0.55)
            add(dr, pos + beat * 3, tom(140), 0.5)
            add(dr, pos + beat * 3.5, tom(110), 0.5)

    mixed = dr * 0.95 + reverb(gt, 0.28, 0.22) * 0.85 + bs * 0.95 + reverb(ld, 0.4, 0.3) * 0.5
    return master(mixed, tail, 0.93, 1.15)

# ------------------------------------------------------------------ BOSS
def build_boss():
    bpm = 176.0
    beat = 60.0 / bpm
    bar = beat * 4.0
    six = beat * 0.25
    bars = 32
    tail = 1.2
    buf = zeros(bars * bar + tail)
    gt = zeros(bars * bar + tail)
    ld = zeros(bars * bar + tail)

    roots = [0, 0, 1, 0, 3, 1, 0, -1]
    for bar_i in range(bars):
        pos = bar_i * bar
        root = roots[bar_i % len(roots)]
        # double kick
        for s in range(16):
            add(buf, pos + s * six, kick(0.16, 160, 50, 0.7), 0.7)
        for b in range(4):
            t0 = pos + b * beat
            if b in (1, 3):
                add(buf, t0, snare(0.2, 1.2), 0.95)
            add(buf, t0 + beat * 0.5, hat(), 0.3)
        if bar_i % 4 == 0:
            add(buf, pos, crash(1.4), 0.6)
        # tremolo picked guitar
        for s in range(32):
            add(gt, pos + s * six * 0.5, guitar(root + (12 if bar_i % 8 >= 4 else 0),
                                                six * 0.6, mute=True, drive=13.0), 0.5)
        add(gt, pos, bass(root, bar), 1.0)
        if bar_i % 8 >= 4:
            for s in range(8):
                add(ld, pos + s * beat * 0.5, lead([12, 13, 15, 13, 12, 10, 8, 10][s],
                                                   beat * 0.5, "saw"), 0.55)
        if bar_i % 8 == 7:
            add(ld, pos + beat * 3, bell(12, 1.2), 0.5)

    mixed = buf * 0.9 + reverb(gt, 0.3, 0.24) * 0.9 + reverb(ld, 0.45, 0.34) * 0.55
    return master(mixed, tail, 0.94, 1.2)

# ------------------------------------------------------------------ MENU
def build_menu():
    bpm = 84.0
    beat = 60.0 / bpm
    bar = beat * 4.0
    bars = 16
    tail = 2.4
    total = bars * bar + tail
    amb = wind(total)
    mus = zeros(total)
    drums = zeros(total)

    chords = [0, 0, -4, -2, 0, 3, -4, -5]
    for bar_i in range(bars):
        pos = bar_i * bar
        c = chords[bar_i % len(chords)]
        add(mus, pos, pad(c, bar * 1.15), 0.75)
        add(mus, pos, bass(c, bar * 0.9, drive=3.0), 0.55)
        if bar_i % 4 == 0:
            add(mus, pos, bell(c + 12, 2.6), 0.45)
        if bar_i >= 4:
            add(drums, pos, kick(0.36), 0.75)
            add(drums, pos + beat * 1.5, kick(0.28), 0.45)
            add(drums, pos + beat * 2, snare(0.24, 0.7), 0.35)
            add(drums, pos + beat * 3.5, hat(open_=True), 0.18)
        if bar_i >= 8 and bar_i % 2 == 0:
            add(mus, pos + beat * 3, guitar(c, beat * 1.4, mute=False, drive=7.0), 0.4)
        if bar_i == 12:
            add(mus, pos, guitar(c, bar * 0.8, mute=False, drive=9.0), 0.5)

    mixed = reverb(mus, 0.5, 0.4) + drums * 0.8 + amb
    return master(mixed, tail, 0.85, 1.0)

# ------------------------------------------------------------------ main
if __name__ == "__main__":
    print("music ->", OUT)
    write("menu", build_menu())
    write("battle", build_battle())
    write("boss", build_boss())
