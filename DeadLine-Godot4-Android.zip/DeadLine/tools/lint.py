"""Deep static lint for the GDScript layer: unknown identifiers, undefined
locals, bad indentation, unbalanced brackets, suspicious type inference.
Run:  python3 tools/lint.py
"""
import os, re, sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
S = os.path.join(ROOT, "scripts")

KEYWORDS = set("""if elif else for while match break continue pass return func var const
class class_name extends enum signal static await yield super self true false null and or not
in is as void breakpoint assert preload load range print push_error push_warning when
tool onready export setget PI TAU INF NAN""".split())

GLOBAL_FUNCS = set("""abs absf absi acos asin atan atan2 bytes_to_var ceil ceilf ceili clamp
clampf clampi cos cosh db_to_linear deg_to_rad ease error_string exp floor floorf floori fmod
fposmod hash instance_from_id inverse_lerp is_equal_approx is_finite is_inf is_instance_id_valid
is_instance_valid is_nan is_zero_approx lerp lerpf lerp_angle linear_to_db log max maxf maxi min
minf mini move_toward nearest_po2 pingpong posmod pow print printerr print_rich prints printt
push_error push_warning rad_to_deg rand_from_seed randf randf_range randfn randi randi_range
randomize remap rid_allocate_id round roundf roundi seed sign signf signi sin sinh smoothstep
snapped snappedf snappedi sqrt step_decimals str str_to_var tan tanh type_convert type_exists
typeof var_to_bytes var_to_str weakref wrap wrapf wrapi range len bool int float""".split())

GLOBAL_CLASSES = set("""Node Node2D Control CanvasLayer CanvasItem CanvasModulate Camera2D Sprite2D
AnimatedSprite2D SpriteFrames Texture2D ImageTexture Image Label Button ColorRect Line2D Timer
CPUParticles2D CharacterBody2D StaticBody2D RigidBody2D Area2D CollisionShape2D CircleShape2D
RectangleShape2D CapsuleShape2D PhysicsRayQueryParameters2D Vector2 Vector2i Vector3 Rect2 Rect2i
Color Transform2D Basis Quaternion Plane AABB Dictionary Array PackedByteArray PackedInt32Array
PackedFloat32Array PackedVector2Array PackedStringArray PackedColorArray String StringName NodePath
RID Callable Signal Variant Object RefCounted Resource Engine OS Time Input InputEvent
InputEventScreenTouch InputEventScreenDrag InputEventMouseButton InputEventMouseMotion InputEventKey
InputMap ProjectSettings DisplayServer RenderingServer AudioServer AudioStreamPlayer
AudioStreamPlayer2D AudioStream AudioStreamWAV AudioStreamOggVorbis AudioStreamPlaybackPolyphonic
AudioStreamRandomizer FileAccess DirAccess JSON ResourceLoader ResourceSaver SceneTree Tween
StyleBoxFlat StyleBoxEmpty StyleBox Font FontFile SystemFont FontVariation Theme HBoxContainer VBoxContainer GridContainer
PanelContainer ScrollContainer MarginContainer CenterContainer TextureRect TextureButton
ProgressBar HSlider VSlider CheckButton OptionButton RichTextLabel NinePatchRect ShaderMaterial
Shader CanvasItemMaterial Performance Viewport SubViewport Window Marker2D PhysicsBody2D
GPUParticles2D Curve Gradient GradientTexture1D Geometry2D Mutex Thread Semaphore
TileMap TileSet Script GDScript PackedScene SceneTreeTimer PhysicsDirectSpaceState2D
KinematicCollision2D PhysicsPointQueryParameters2D PhysicsShapeQueryParameters2D
BaseButton Container Range TranslationServer AudioEffect AudioBusLayout MainLoop""".split())

ENGINE_MEMBERS = set("""global_position global_rotation global_scale position rotation scale visible
modulate self_modulate name z_index z_as_relative queue_free free add_child remove_child get_parent
get_children get_child get_child_count get_node get_node_or_null has_node find_child owner
add_to_group remove_from_group is_in_group get_tree get_viewport get_viewport_rect get_window
set_process set_physics_process set_process_input set_process_unhandled_input is_processing
process_mode create_tween queue_redraw request_ready is_node_ready duplicate get_instance_id
set_meta get_meta has_meta remove_meta call call_deferred callv connect disconnect emit_signal
is_connected notification propagate_call move_child get_index get_path get_script set_script
velocity move_and_slide move_and_collide is_on_floor is_on_wall get_slide_collision_count
get_slide_collision get_last_slide_collision motion_mode floor_stop_on_slope up_direction
collision_layer collision_mask set_collision_layer_value set_collision_mask_value
shape input_pickable monitoring monitorable get_overlapping_bodies get_overlapping_areas
texture centered offset flip_h flip_v region_enabled region_rect hframes vframes frame
frame_coords sprite_frames animation autoplay play stop pause is_playing speed_scale
text label_settings horizontal_alignment vertical_alignment autowrap_mode clip_text
size custom_minimum_size anchor_left anchor_top anchor_right anchor_bottom
offset_left offset_top offset_right offset_bottom set_anchors_preset set_offsets_preset
set_anchors_and_offsets_preset grow_horizontal grow_vertical mouse_filter mouse_default_cursor_shape
focus_mode disabled toggle_mode button_pressed pressed_no_signal pressed released
tooltip_text add_theme_color_override add_theme_font_size_override add_theme_stylebox_override
add_theme_constant_override add_theme_font_override get_theme_font get_theme_default_font
get_global_rect get_rect has_point encloses intersects grow abs
size_flags_horizontal size_flags_vertical alignment add_spacer columns
color points width default_color closed antialiased add_point clear_points
emitting amount lifetime one_shot explosiveness randomness direction spread gravity
initial_velocity_min initial_velocity_max scale_amount_min scale_amount_max damping_min
damping_max angular_velocity_min angular_velocity_max color_ramp restart
layer follow_viewport_enabled
draw draw_line draw_rect draw_circle draw_arc draw_texture draw_texture_rect draw_string
draw_polyline draw_colored_polygon draw_set_transform draw_multiline
stream volume_db pitch_scale bus playing finished autostart wait_time timeout start
zoom limit_left limit_right limit_top limit_bottom position_smoothing_enabled
position_smoothing_speed make_current enabled ignore_rotation
is_queued_for_deletion is_inside_tree ready tree_exiting
material light_mask use_parent_material show_behind_parent top_level clip_children
set_deferred get set_indexed tween_property tween_callback tween_interval set_ease set_trans
set_loops kill is_valid chain parallel
_ready _process _physics_process _draw _input _unhandled_input _notification _init _enter_tree
_exit_tree _gui_input""".split())

TYPE_CONSTS = set(["TYPE_NIL","TYPE_BOOL","TYPE_INT","TYPE_FLOAT","TYPE_STRING","TYPE_VECTOR2",
"TYPE_VECTOR2I","TYPE_RECT2","TYPE_COLOR","TYPE_ARRAY","TYPE_DICTIONARY","TYPE_OBJECT",
"TYPE_CALLABLE","TYPE_STRING_NAME","TYPE_PACKED_BYTE_ARRAY","NOTIFICATION_WM_GO_BACK_REQUEST",
"NOTIFICATION_APPLICATION_FOCUS_OUT","NOTIFICATION_WM_CLOSE_REQUEST","MOUSE_BUTTON_LEFT",
"NOTIFICATION_APPLICATION_PAUSED","NOTIFICATION_APPLICATION_RESUMED",
"NOTIFICATION_APPLICATION_FOCUS_IN","NOTIFICATION_WM_WINDOW_FOCUS_OUT",
"NOTIFICATION_WM_WINDOW_FOCUS_IN","NOTIFICATION_EXIT_TREE","NOTIFICATION_ENTER_TREE",
"NOTIFICATION_OS_MEMORY_WARNING",
"MOUSE_BUTTON_RIGHT","HORIZONTAL_ALIGNMENT_LEFT","HORIZONTAL_ALIGNMENT_CENTER",
"HORIZONTAL_ALIGNMENT_RIGHT","HORIZONTAL_ALIGNMENT_FILL","VERTICAL_ALIGNMENT_TOP",
"VERTICAL_ALIGNMENT_CENTER","VERTICAL_ALIGNMENT_BOTTOM","AtlasTexture","TextServer","ThemeDB",
"OK","FAILED","ERR_FILE_NOT_FOUND","SIDE_LEFT","SIDE_TOP","SIDE_RIGHT","SIDE_BOTTOM"])
KEY_CONSTS = set(re.findall(r"KEY_\w+", " ".join(["KEY_%s" % c for c in
    list("ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789")]) +
    " KEY_ESCAPE KEY_ENTER KEY_SPACE KEY_SHIFT KEY_CTRL KEY_ALT KEY_TAB KEY_LEFT KEY_RIGHT KEY_UP KEY_DOWN KEY_P KEY_F1"))

# member sets per script file
def members(src):
    m = set(re.findall(r"^\s*func ([a-zA-Z_]\w*)", src, re.M))
    m |= set(re.findall(r"^\s*static func ([a-zA-Z_]\w*)", src, re.M))
    m |= set(re.findall(r"^var ([a-zA-Z_]\w*)", src, re.M))
    m |= set(re.findall(r"^@onready var ([a-zA-Z_]\w*)", src, re.M))
    m |= set(re.findall(r"^const ([A-Za-z_]\w*)", src, re.M))
    m |= set(re.findall(r"^signal ([a-zA-Z_]\w*)", src, re.M))
    m |= set(re.findall(r"^enum ([A-Za-z_]\w*)", src, re.M))
    return m

def strip_code(line):
    """remove strings and trailing comment"""
    out, i, n = [], 0, len(line)
    while i < n:
        c = line[i]
        if c == "#":
            break
        if c in "\"'":
            q = c
            i += 1
            while i < n and line[i] != q:
                if line[i] == "\\":
                    i += 1
                i += 1
            i += 1
            out.append('""')
            continue
        out.append(c)
        i += 1
    return "".join(out)

files = {f: open(os.path.join(S, f)).read() for f in sorted(os.listdir(S)) if f.endswith(".gd")}
class_names = set(re.findall(r"^class_name (\w+)", "\n".join(files.values()), re.M))
proj = open(os.path.join(ROOT, "project.godot")).read()
autoloads = set(re.findall(r'^(\w+)="\*res://', proj, re.M))

errors, warns = [], []
KNOWN = (GLOBAL_FUNCS | GLOBAL_CLASSES | KEYWORDS | class_names | autoloads
         | ENGINE_MEMBERS | TYPE_CONSTS | KEY_CONSTS | {"_"})

for fname, src in files.items():
    lines = src.split("\n")
    mem = members(src)
    scope = set()          # locals of the current function
    depth_ok = True
    in_func = None
    open_br = 0
    for i, raw in enumerate(lines, 1):
        code = strip_code(raw)
        if raw.strip() and raw.startswith(" ") and open_br == 0:
            errors.append("%s:%d space indentation" % (fname, i))
        # bracket balance (per logical line, continuation aware)
        open_br += code.count("(") + code.count("[") + code.count("{")
        open_br -= code.count(")") + code.count("]") + code.count("}")
        m = re.match(r"^(?:static )?func ([a-zA-Z_]\w*)\((.*)", code)
        if m:
            in_func = m.group(1)
            scope = set()
            sig = m.group(2)
            j = i
            while sig.count("(") + 1 > sig.count(")") + 0 and j < len(lines):
                j += 1
                sig += strip_code(lines[j - 1])
            sig_inner = sig[:sig.rfind(")")] if ")" in sig else sig
            for part in sig_inner.split(","):
                mm = re.match(r"\s*([a-zA-Z_]\w*)", part)
                if mm:
                    scope.add(mm.group(1))
            sig_skip = j
            continue
        if in_func is None:
            continue
        # collect declarations on this line
        for d in re.findall(r"\bvar ([a-zA-Z_]\w*)", code):
            scope.add(d)
        for d in re.findall(r"\bfor ([a-zA-Z_]\w*) in\b", code):
            scope.add(d)
        for d in re.findall(r"func\s*\(([^)]*)\)", code):   # lambda params
            for p in re.findall(r"([a-zA-Z_]\w*)", d):
                scope.add(p)
        # identifier usage check
        body = re.sub(r"\bvar ([a-zA-Z_]\w*)", "", code)
        for m2 in re.finditer(r"(?<![\w.$\"])([a-zA-Z_]\w*)", body):
            name = m2.group(1)
            if name in KNOWN or name in mem or name in scope:
                continue
            # type hints after ':' are class names, already covered
            errors.append("%s:%d unknown identifier '%s'  |%s" % (fname, i, name, raw.strip()[:70]))
    if open_br != 0:
        errors.append("%s: unbalanced brackets (%d)" % (fname, open_br))

# type inference: var x := <call on untyped>
for fname, src in files.items():
    for i, raw in enumerate(src.split("\n"), 1):
        if re.search(r"\bvar \w+ :=", raw):
            warns.append("%s:%d inferred type: %s" % (fname, i, raw.strip()[:80]))

# =====================================================================
# Duplicate dictionary keys.
# GDScript treats a repeated key in a dictionary LITERAL as a parse error, so
# one accidental repeat silently kills the whole script - and if that script is
# an autoload, it takes the game's UI down with it. This is the check whose
# absence cost us a full build (two "Incendiary" rows in Loc.gd).
# =====================================================================
def dict_key_dupes(src):
    """Returns [(line, key)] for string keys repeated inside one dict literal."""
    out, stack, i, n = [], [], 0, len(src)
    line = 1
    while i < n:
        c = src[i]
        if c == "\n":
            line += 1; i += 1; continue
        if c == "#":
            while i < n and src[i] != "\n":
                i += 1
            continue
        if c in "\"'":
            quote, j = c, i + 1
            buf = []
            while j < n:
                if src[j] == "\\":
                    buf.append(src[j:j + 2]); j += 2; continue
                if src[j] == quote:
                    break
                if src[j] == "\n":
                    break
                buf.append(src[j]); j += 1
            key = "".join(buf)
            i = j + 1
            # a string is a dict key only when the innermost bracket is '{'
            # and the next non-space character is ':'
            k = i
            while k < n and src[k] in " \t":
                k += 1
            if stack and stack[-1][0] == "{" and k < n and src[k] == ":" \
                    and (k + 1 >= n or src[k + 1] != "="):
                seen = stack[-1][1]
                if key in seen:
                    out.append((line, key))
                else:
                    seen.add(key)
            continue
        if c in "{[(":
            stack.append((c, set()))
        elif c in "}])":
            if stack:
                stack.pop()
        i += 1
    return out


for fname, src in files.items():
    for line, key in dict_key_dupes(src):
        errors.append("%s:%d DUPLICATE dictionary key \"%s\" - this is a PARSE ERROR "
                      "in GDScript and disables the whole script" % (fname, line, key))

# =====================================================================
# Localization table: row width and printf placeholders.
# A row with the wrong number of "%d"/"%s" used to be a hard runtime error at
# format time; UI.tr_f() now degrades gracefully, but it is still a bug.
# =====================================================================
loc_src = files.get("Loc.gd", "")
if loc_src:
    m = re.search(r"const LANGS\s*:?=\s*\[(.*?)\]", loc_src, re.S)
    n_langs = len(re.findall(r'"[^"]*"', m.group(1))) if m else 0
    want = max(0, n_langs - 1)
    body = loc_src[loc_src.find("const TABLE"):]

    def slots(t):
        out, i = 0, 0
        while i < len(t):
            if t[i] == "%":
                if i + 1 < len(t) and t[i + 1] == "%":
                    i += 2; continue
                out += 1
            i += 1
        return out

    for mm in re.finditer(r'^\t"((?:[^"\\]|\\.)*)":\s*\[(.*?)\],\s*$', body, re.M):
        key, inner = mm.group(1), mm.group(2)
        line = loc_src[:loc_src.find("const TABLE")].count("\n") + body[:mm.start()].count("\n") + 1
        vals = re.findall(r'"((?:[^"\\]|\\.)*)"', inner)
        if want and len(vals) != want:
            errors.append("Loc.gd:%d row \"%s\" has %d translations, expected %d"
                          % (line, key, len(vals), want))
        for v in vals:
            if slots(v) != slots(key):
                errors.append("Loc.gd:%d row \"%s\": translation \"%s\" has %d placeholders, "
                              "source has %d" % (line, key, v, slots(v), slots(key)))

# =====================================================================
# Android project settings that we depend on at runtime.
# =====================================================================
proj = open(os.path.join(ROOT, "project.godot"), encoding="utf-8").read()
for need, why in [("config/quit_on_go_back=false",
                   "back gesture would quit the app and kill the run"),
                  ("window/energy_saving/keep_screen_on=true",
                   "screen would sleep mid wave")]:
    if need not in proj:
        errors.append("project.godot: missing %s (%s)" % (need, why))

print("files:", len(files))
print("ERRORS: %d" % len(errors))
for e in errors:
    print("  !", e)
print("WARNINGS: %d" % len(warns))
for w in warns[:40]:
    print("  -", w)
sys.exit(1 if errors else 0)
