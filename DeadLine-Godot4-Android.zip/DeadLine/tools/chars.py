import math, random
from core import *

CW, CH = 26, 38          # cell for normal humans
FEET = 36

def pal(skin, shirt, pants, hair, boots=(40, 34, 40), gear=None, blood=(150, 18, 22),
        bare_arms=False, glove=None, hand=None):
    skin = tuple(list(skin)[:3] + [255])
    return {"skin": skin, "shirt": shirt, "pants": pants, "hair": hair,
            "boots": boots, "gear": gear or dark(shirt, 0.35), "blood": blood,
            "bare_arms": bare_arms, "glove": glove or (46, 42, 44, 255),
            "hand": hand or dark(skin, 0.25)}

def draw_char(P, phase=0.0, hunch=0.0, cw=CW, ch=CH, feet=FEET, walk=1.0,
              helmet=False, vest=False, torn=0.0, gore=0.0, arm_reach=1.0,
              fat=0.0, dead=None, rnd=None, backpack=False):
    """Returns RGBA image of a side-view (facing right) character."""
    rnd = rnd or random.Random(7)
    im = new(cw, ch)
    a = phase * math.tau
    bob = abs(math.sin(a)) * walk
    swing = math.sin(a) * 0.62 * walk
    swing2 = math.sin(a + math.pi) * 0.62 * walk

    hip_x = cw * 0.5
    hip_y = feet - 14 - bob
    sh_x = hip_x + hunch * 2.2
    sh_y = hip_y - 9 + hunch * 2.4 - 0
    hd_x = sh_x + 0.6 + hunch * 1.8
    hd_y = sh_y - 4.6 - fat * 0.5
    head_r = 3.4 + fat * 0.7

    skin, skin_d = P["skin"], dark(P["skin"], 0.28)
    pants, pants_d = P["pants"], dark(P["pants"], 0.30)
    shirt = P["shirt"]

    def leg(ang, col, w=4):
        fx = hip_x + math.sin(ang) * 7.0
        lift = max(0.0, math.sin(ang) * 2.6) if walk > 0 else 0.0
        fy = feet - lift
        kx = hip_x + math.sin(ang) * 3.4
        ky = (hip_y + fy) * 0.5
        limb(im, hip_x, hip_y, kx, ky, w, col)
        limb(im, kx, ky, fx, fy, w - 1, col)
        # boot
        rect(im, fx - 2, fy - 1, fx + 2, fy, P["boots"])
        rect(im, fx - 1, fy - 2, fx + 2, fy - 2, dark(P["boots"], 0.15))

    def arm(ang, col, w=3, reach=1.0, fore=None):
        ex = sh_x + math.sin(ang) * 6.0 * reach + reach * (4.0 + fat * 1.2)
        ey = sh_y + 6.0 - reach * 4.0 + math.cos(ang) * 1.5
        mx = (sh_x + ex) / 2 + 1
        my = (sh_y + ey) / 2 + 2
        limb(im, sh_x, sh_y + 1, mx, my, w, col)
        limb(im, mx, my, ex, ey, max(2, w - 1), fore if fore else col)
        disc(im, ex, ey, 1.3, P.get("hand", skin_d))
        return ex, ey

    bare = P.get("bare_arms", False)
    fore_back = dark(P["skin"], 0.42) if bare else dark(shirt, 0.5)
    fore_front = P["skin"] if bare else P.get("glove", dark(shirt, 0.25))

    # ---- back leg / arm (darker) ----
    leg(swing2, pants_d, 4 + int(fat))
    arm(swing2 * 0.7, dark(shirt, 0.45), 3 + int(fat), arm_reach * 0.92, fore_back)

    # ---- torso ----
    top_w = 4 + fat * 2
    bot_w = 3.5 + fat * 2
    steps = 14
    for i in range(steps + 1):
        t = i / steps
        x = sh_x + (hip_x - sh_x) * t
        y = sh_y + (hip_y - sh_y) * t
        w = top_w + (bot_w - top_w) * t
        col = shirt if t < 0.72 else pants
        rect(im, x - w, y, x + w - 1, y, col)
    # jacket details
    rect(im, sh_x - top_w, sh_y + 1, sh_x + top_w - 1, sh_y + 1, light(shirt, 0.18))
    rect(im, hip_x - bot_w, hip_y - 3, hip_x + bot_w - 1, hip_y - 3, dark(P["boots"], 0.0))  # belt
    px(im, hip_x + 1, hip_y - 3, (214, 178, 66, 255))
    if vest:
        rect(im, sh_x - top_w + 1, sh_y + 2, sh_x + top_w - 2, sh_y + 7, P["gear"])
        rect(im, sh_x - 1, sh_y + 3, sh_x, sh_y + 4, dark(P["gear"], 0.4))
        rect(im, sh_x + 1, sh_y + 5, sh_x + 2, sh_y + 6, dark(P["gear"], 0.4))
        rect(im, sh_x - top_w + 1, sh_y + 3, sh_x - top_w + 1, sh_y + 6, light(P["gear"], 0.2))
    if backpack:
        rect(im, sh_x - top_w - 2, sh_y + 2, sh_x - top_w, sh_y + 8, P["gear"])
    if torn > 0:
        for _ in range(int(10 * torn)):
            x = rnd.randint(int(sh_x - top_w), int(sh_x + top_w))
            y = rnd.randint(int(sh_y + 2), int(hip_y - 1))
            px(im, x, y, skin_d if rnd.random() < 0.6 else (0, 0, 0, 0))

    # ---- front leg ----
    leg(swing, pants, 4 + int(fat))

    # ---- neck + head ----
    rect(im, hd_x - 1, hd_y + 2, hd_x + 1, sh_y + 1, dark(skin, 0.2))
    disc(im, hd_x, hd_y, head_r, skin)
    rect(im, hd_x - head_r + 0.5, hd_y + 2, hd_x + head_r - 1.5, hd_y + 3, skin)   # jaw
    px(im, hd_x + 2, hd_y - 1, (24, 18, 22, 255))                    # eye
    px(im, hd_x + 1, hd_y - 1, (238, 238, 230, 255))
    rect(im, hd_x - 1, hd_y + 2, hd_x + 1, hd_y + 2, dark(skin, 0.35))  # mouth line
    if helmet:
        for x in range(int(hd_x - head_r - 0.5), int(hd_x + head_r + 0.5)):
            rect(im, x, hd_y - head_r - 1.6, x, hd_y - 2 - abs(x - hd_x) * 0.2, P["gear"])
        rect(im, hd_x - 4, hd_y - 2, hd_x + 3, hd_y - 2, dark(P["gear"], 0.25))
        rect(im, hd_x - 4, hd_y - 5, hd_x + 3, hd_y - 5, light(P["gear"], 0.25))
    else:
        for x in range(int(hd_x - head_r - 0.5), int(hd_x + head_r - 0.5)):
            rect(im, x, hd_y - head_r - 0.6, x, hd_y - 1 - abs(x - hd_x) * 0.35, P["hair"])
        rect(im, hd_x - 4, hd_y - 3, hd_x - 4, hd_y + 1, P["hair"])
    # ---- front arm ----
    hx, hy = arm(swing * 0.6, shirt, 3 + int(fat), arm_reach, fore_front)

    if gore > 0:
        b = P["blood"]
        for _ in range(int(16 * gore)):
            x = rnd.randint(2, cw - 3); y = rnd.randint(int(sh_y - 4), feet - 1)
            if get(im, x, y)[3] != 0:
                px(im, x, y, b if rnd.random() < 0.7 else dark(b, 0.35))

    volumize(im)
    outline(im)
    return im, (hx, hy)

def anim(P, frames, **kw):
    out = []
    hands = []
    for i in range(frames):
        im, h = draw_char(P, phase=i / float(frames), **kw)
        out.append(im); hands.append(h)
    return out, hands

def death_frames(P, n=5, **kw):
    """falls forward and collapses into a bloody heap"""
    out = []
    for i in range(n):
        t = i / float(n - 1)
        im = new(kw.get("cw", CW), kw.get("ch", CH))
        base, _ = draw_char(P, phase=0.0, walk=0.0, **kw)
        ang = -t * 82.0
        r = base.rotate(ang, resample=Image.NEAREST, center=(base.width / 2, kw.get("feet", FEET)))
        im.alpha_composite(r)
        if t > 0.35:
            b = P["blood"]
            rnd = random.Random(int(t * 100))
            for _ in range(int(t * 26)):
                x = rnd.randint(1, im.width - 2)
                y = kw.get("feet", FEET) - rnd.randint(0, 2)
                px(im, x, y, b if rnd.random() < 0.6 else dark(b, 0.4))
        out.append(im)
    return out
