extends CanvasLayer
class_name HUD
## All on-screen UI: stats, boss bar, weapon strip, shop, build bar, upgrade
## cards, pause menu (with full settings) and the game over screen.

var game = null

var root: Control
var touch = null

# ---- top
var hp_fill: ColorRect
var hp_label: Label
var xp_fill: ColorRect
var wave_label: Label
var cash_label: Label
var kills_label: Label
var score_label: Label
var combo_label: Label
var left_label: Label
var event_label: Label
var fps_label: Label

# ---- boss
var boss_box: Control
var boss_fill: ColorRect
var boss_label: Label

# ---- center
var banner: Label
var vignette: ColorRect
var arrow_l: Label
var arrow_r: Label

# ---- bottom
var weapon_strip: HBoxContainer
var slot_buttons: Array = []
var ammo_label: Label
var reload_fill: ColorRect
var nade_label: Label
var prep_box: VBoxContainer
var prep_timer_label: Label
var build_bar: PanelContainer
var build_row: HBoxContainer

# ---- overlays
var overlay_dim: ColorRect
var shop_panel: Control
var up_panel: Control
var pause_panel: Control
var over_panel: Control

var build_mode = false
var _banner_tw: Tween = null


func _ready() -> void:
	layer = 10
	# stays interactive while the tree is paused (pause menu / upgrade cards)
	process_mode = Node.PROCESS_MODE_ALWAYS
	root = Control.new()
	root.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(root)

	_build_top()
	_build_boss()
	_build_center()
	_build_bottom()
	_build_overlays()

	touch = TouchPad.new()
	touch.game = game
	touch.set_anchors_preset(Control.PRESET_FULL_RECT)
	touch.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(touch)
	root.move_child(touch, 0)


# ================================================================ build UI
func _bar(parent: Control, pos: Vector2, size: Vector2, color: Color) -> ColorRect:
	var bg = ColorRect.new()
	bg.color = Color(0, 0, 0, 0.72)
	bg.position = pos - Vector2(1, 1)
	bg.size = size + Vector2(2, 2)
	parent.add_child(bg)
	var fill = ColorRect.new()
	fill.color = color
	fill.position = pos
	fill.size = size
	parent.add_child(fill)
	return fill


func _build_top() -> void:
	var top = Control.new()
	top.set_anchors_preset(Control.PRESET_TOP_WIDE)
	top.offset_bottom = 46
	top.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(top)

	var bg = ColorRect.new()
	bg.color = Color(0.05, 0.05, 0.06, 0.55)
	bg.set_anchors_preset(Control.PRESET_FULL_RECT)
	bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
	top.add_child(bg)

	hp_fill = _bar(top, Vector2(6, 6), Vector2(118, 8), Color(0.80, 0.18, 0.18))
	hp_label = UI.label("120/120", 7, UI.BONE)
	hp_label.position = Vector2(8, 4)
	top.add_child(hp_label)

	xp_fill = _bar(top, Vector2(6, 18), Vector2(118, 4), Color(0.35, 0.72, 1.0))

	wave_label = UI.label("WAVE 1", 11, UI.RED)
	wave_label.position = Vector2(150, 2)
	top.add_child(wave_label)

	cash_label = UI.label("$0", 9, UI.GOLD)
	cash_label.position = Vector2(150, 16)
	top.add_child(cash_label)

	kills_label = UI.label("0 kills", 7, UI.DIM)
	kills_label.position = Vector2(150, 28)
	top.add_child(kills_label)

	score_label = UI.label("0", 7, UI.BONE)
	score_label.position = Vector2(6, 26)
	top.add_child(score_label)

	combo_label = UI.label("", 9, UI.GOLD)
	combo_label.position = Vector2(62, 26)
	top.add_child(combo_label)

	left_label = UI.label("", 7, UI.BONE)
	left_label.position = Vector2(6, 36)
	top.add_child(left_label)

	event_label = UI.label("", 7, UI.BLUE)
	event_label.position = Vector2(90, 36)
	top.add_child(event_label)

	var pause_btn = UI.button("II", 10, UI.DIM, 20.0)
	pause_btn.custom_minimum_size = Vector2(24, 20)
	pause_btn.set_anchors_preset(Control.PRESET_TOP_RIGHT)
	pause_btn.offset_left = -30
	pause_btn.offset_top = 4
	pause_btn.offset_right = -4
	pause_btn.offset_bottom = 24
	pause_btn.pressed.connect(func() -> void: game.toggle_pause())
	top.add_child(pause_btn)

	fps_label = UI.label("", 7, UI.GREEN)
	fps_label.set_anchors_preset(Control.PRESET_TOP_RIGHT)
	fps_label.offset_left = -60
	fps_label.offset_top = 26
	fps_label.offset_right = -6
	fps_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	top.add_child(fps_label)


func _build_boss() -> void:
	boss_box = Control.new()
	boss_box.set_anchors_preset(Control.PRESET_TOP_WIDE)
	boss_box.offset_top = 48
	boss_box.offset_bottom = 66
	boss_box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	boss_box.visible = false
	root.add_child(boss_box)

	boss_label = UI.label("BRUTE", 8, UI.RED, HORIZONTAL_ALIGNMENT_CENTER)
	boss_label.set_anchors_preset(Control.PRESET_TOP_WIDE)
	boss_label.offset_bottom = 10
	boss_box.add_child(boss_label)

	var holder = Control.new()
	holder.set_anchors_preset(Control.PRESET_TOP_WIDE)
	holder.offset_top = 10
	holder.mouse_filter = Control.MOUSE_FILTER_IGNORE
	boss_box.add_child(holder)

	var bg = ColorRect.new()
	bg.color = Color(0, 0, 0, 0.8)
	bg.set_anchors_preset(Control.PRESET_TOP_WIDE)
	bg.offset_left = 30
	bg.offset_right = -30
	bg.offset_bottom = 7
	holder.add_child(bg)

	boss_fill = ColorRect.new()
	boss_fill.color = Color(0.85, 0.15, 0.15)
	boss_fill.set_anchors_preset(Control.PRESET_TOP_LEFT)
	boss_fill.position = Vector2(31, 1)
	boss_fill.size = Vector2(100, 5)
	holder.add_child(boss_fill)


func _build_center() -> void:
	vignette = ColorRect.new()
	vignette.color = Color(0.75, 0.05, 0.05, 0.0)
	vignette.set_anchors_preset(Control.PRESET_FULL_RECT)
	vignette.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(vignette)

	banner = UI.label("", 15, UI.RED, HORIZONTAL_ALIGNMENT_CENTER)
	banner.set_anchors_preset(Control.PRESET_CENTER_TOP)
	banner.offset_top = 92
	banner.offset_left = -140
	banner.offset_right = 140
	banner.offset_bottom = 120
	banner.modulate.a = 0.0
	banner.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(banner)

	arrow_l = UI.label("", 12, UI.RED)
	arrow_l.set_anchors_preset(Control.PRESET_CENTER_LEFT)
	arrow_l.offset_left = 2
	arrow_l.offset_right = 40
	root.add_child(arrow_l)

	arrow_r = UI.label("", 12, UI.RED, HORIZONTAL_ALIGNMENT_RIGHT)
	arrow_r.set_anchors_preset(Control.PRESET_CENTER_RIGHT)
	arrow_r.offset_left = -40
	arrow_r.offset_right = -2
	root.add_child(arrow_r)


func _build_bottom() -> void:
	# ---- weapon strip (tap a slot to switch)
	var strip_holder = Control.new()
	strip_holder.set_anchors_preset(Control.PRESET_BOTTOM_WIDE)
	strip_holder.offset_top = -128
	strip_holder.offset_bottom = -100
	root.add_child(strip_holder)

	weapon_strip = HBoxContainer.new()
	weapon_strip.set_anchors_preset(Control.PRESET_FULL_RECT)
	weapon_strip.offset_left = 4
	weapon_strip.offset_right = -4
	weapon_strip.add_theme_constant_override("separation", 3)
	strip_holder.add_child(weapon_strip)

	# ---- ammo + reload
	var info = Control.new()
	info.set_anchors_preset(Control.PRESET_BOTTOM_WIDE)
	info.offset_top = -100
	info.offset_bottom = -84
	info.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(info)

	ammo_label = UI.label("", 8, UI.BONE)
	ammo_label.position = Vector2(6, 0)
	info.add_child(ammo_label)

	nade_label = UI.label("", 8, UI.GREEN, HORIZONTAL_ALIGNMENT_RIGHT)
	nade_label.set_anchors_preset(Control.PRESET_TOP_RIGHT)
	nade_label.offset_left = -70
	nade_label.offset_right = -6
	info.add_child(nade_label)

	reload_fill = _bar(info, Vector2(6, 12), Vector2(110, 3), Color(1.0, 0.8, 0.3))
	reload_fill.size.x = 0.0

	# ---- prep controls
	prep_box = VBoxContainer.new()
	prep_box.set_anchors_preset(Control.PRESET_CENTER_BOTTOM)
	prep_box.offset_left = -78
	prep_box.offset_right = 78
	prep_box.offset_top = -196
	prep_box.offset_bottom = -130
	prep_box.add_theme_constant_override("separation", 3)
	root.add_child(prep_box)

	prep_timer_label = UI.label("", 8, UI.DIM, HORIZONTAL_ALIGNMENT_CENTER)
	prep_box.add_child(prep_timer_label)

	var start_btn = UI.big_button("START WAVE", UI.GREEN)
	start_btn.pressed.connect(func() -> void:
		hide_overlays()
		game.start_wave())
	prep_box.add_child(start_btn)

	var row = HBoxContainer.new()
	row.add_theme_constant_override("separation", 4)
	prep_box.add_child(row)
	var shop_btn = UI.button("SHOP", 10, UI.GOLD, 24.0)
	shop_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	shop_btn.pressed.connect(toggle_shop)
	row.add_child(shop_btn)
	var build_btn = UI.button("BUILD", 10, UI.BLUE, 24.0)
	build_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	build_btn.pressed.connect(toggle_build)
	row.add_child(build_btn)

	# ---- build bar
	build_bar = UI.panel(UI.PANEL, UI.BLUE.darkened(0.5))
	build_bar.set_anchors_preset(Control.PRESET_BOTTOM_WIDE)
	build_bar.offset_top = -168
	build_bar.offset_bottom = -130
	build_bar.offset_left = 2
	build_bar.offset_right = -2
	build_bar.visible = false
	root.add_child(build_bar)

	build_row = HBoxContainer.new()
	build_row.add_theme_constant_override("separation", 2)
	build_bar.add_child(build_row)
	for kind in GameData.BUILD_ORDER:
		var d: Dictionary = GameData.BUILDINGS[kind]
		var b = UI.button("%s\n$%d" % [String(d.get("name", kind)), int(d.get("price", 0))], 7,
				UI.BLUE, 30.0)
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		b.pressed.connect(func() -> void:
			game.select_build(kind)
			flash_banner("TAP THE GROUND", UI.BLUE)
			Audio.play("click", -12.0))
		build_row.add_child(b)
	var cancel = UI.button("X", 9, UI.RED, 30.0)
	cancel.custom_minimum_size = Vector2(22, 30)
	cancel.pressed.connect(func() -> void: set_build_mode(false))
	build_row.add_child(cancel)


func _build_overlays() -> void:
	overlay_dim = ColorRect.new()
	overlay_dim.color = Color(0, 0, 0, 0.72)
	overlay_dim.set_anchors_preset(Control.PRESET_FULL_RECT)
	overlay_dim.visible = false
	root.add_child(overlay_dim)

	shop_panel = _make_shop()
	up_panel = _make_upgrades()
	pause_panel = _make_pause()
	over_panel = _make_over()
	for p in [shop_panel, up_panel, pause_panel, over_panel]:
		p.visible = false
		root.add_child(p)


func _center_panel(title: String, top: float = 30.0, bottom: float = -30.0) -> VBoxContainer:
	var holder = PanelContainer.new()
	holder.add_theme_stylebox_override("panel", UI.style(Color(0.08, 0.08, 0.09, 0.98),
			UI.RED_DARK, 2, 3))
	holder.set_anchors_preset(Control.PRESET_FULL_RECT)
	holder.offset_left = 8
	holder.offset_right = -8
	holder.offset_top = top
	holder.offset_bottom = bottom
	var vb = VBoxContainer.new()
	vb.add_theme_constant_override("separation", 4)
	holder.add_child(vb)
	var t = UI.label(title, 13, UI.RED, HORIZONTAL_ALIGNMENT_CENTER)
	vb.add_child(t)
	holder.set_meta("body", vb)
	return vb


func _make_shop() -> Control:
	var vb = _center_panel("BLACK MARKET", 26.0, -110.0)
	var panel: Control = vb.get_parent()
	var scroll = ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	vb.add_child(scroll)
	var list = VBoxContainer.new()
	list.add_theme_constant_override("separation", 2)
	list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.add_child(list)

	for id in GameData.SHOP_ORDER:
		var w: Dictionary = GameData.WEAPONS[id]
		var row = HBoxContainer.new()
		row.add_theme_constant_override("separation", 3)
		row.add_child(UI.sprite_rect(Art.weapon_tex(id), Vector2(34, 16)))
		var col = VBoxContainer.new()
		col.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		col.add_theme_constant_override("separation", 0)
		col.add_child(UI.label(String(w.get("name", id)), 8, UI.BONE))
		col.add_child(UI.label("DMG %d  %s" % [int(w.get("dmg", 0)), String(w.get("desc", ""))],
				6, UI.DIM))
		row.add_child(col)
		var buy = UI.button("$%d" % int(w.get("price", 0)), 8, UI.GOLD, 20.0)
		buy.custom_minimum_size = Vector2(48, 20)
		buy.pressed.connect(func() -> void:
			if game.buy_weapon(id):
				_rebuild_slots())
		row.add_child(buy)
		list.add_child(row)

	var tools = HBoxContainer.new()
	tools.add_theme_constant_override("separation", 3)
	var ammo_btn = UI.button("REFILL AMMO", 8, UI.BLUE, 22.0)
	ammo_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	ammo_btn.pressed.connect(func() -> void: game.buy_ammo())
	tools.add_child(ammo_btn)
	var heal_btn = UI.button("MEDKIT $90", 8, UI.GREEN, 22.0)
	heal_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	heal_btn.pressed.connect(func() -> void: game.buy_heal())
	tools.add_child(heal_btn)
	vb.add_child(tools)

	var close = UI.button("CLOSE", 10, UI.RED, 26.0)
	close.pressed.connect(func() -> void: hide_overlays())
	vb.add_child(close)
	return panel


func _make_upgrades() -> Control:
	var vb = _center_panel("LEVEL UP - PICK ONE", 40.0, -60.0)
	var panel: Control = vb.get_parent()
	var box = VBoxContainer.new()
	box.name = "Cards"
	box.add_theme_constant_override("separation", 4)
	box.size_flags_vertical = Control.SIZE_EXPAND_FILL
	vb.add_child(box)
	panel.set_meta("cards", box)
	return panel


func _make_pause() -> Control:
	var vb = _center_panel("PAUSED", 20.0, -20.0)
	var panel: Control = vb.get_parent()
	var scroll = ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	vb.add_child(scroll)
	var sp = SettingsPanel.new()
	sp.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.add_child(sp)

	var resume = UI.big_button("RESUME", UI.GREEN)
	resume.pressed.connect(func() -> void: game.toggle_pause())
	vb.add_child(resume)
	var row = HBoxContainer.new()
	row.add_theme_constant_override("separation", 4)
	var restart = UI.button("RESTART", 9, UI.GOLD, 24.0)
	restart.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	restart.pressed.connect(func() -> void: game.restart())
	row.add_child(restart)
	var menu = UI.button("MENU", 9, UI.RED, 24.0)
	menu.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	menu.pressed.connect(func() -> void: game.return_to_menu())
	row.add_child(menu)
	vb.add_child(row)
	return panel


func _make_over() -> Control:
	var vb = _center_panel("YOU DIED", 60.0, -70.0)
	var panel: Control = vb.get_parent()
	var stats = VBoxContainer.new()
	stats.add_theme_constant_override("separation", 2)
	vb.add_child(stats)
	panel.set_meta("stats", stats)
	var retry = UI.big_button("RETRY", UI.GREEN)
	retry.pressed.connect(func() -> void: game.restart())
	vb.add_child(retry)
	var menu = UI.button("MAIN MENU", 10, UI.RED, 26.0)
	menu.pressed.connect(func() -> void: game.return_to_menu())
	vb.add_child(menu)
	return panel


# ================================================================ weapon slots
func _rebuild_slots() -> void:
	for c in weapon_strip.get_children():
		c.queue_free()
	slot_buttons.clear()
	var pl = game.player
	if pl == null:
		return
	for i in range(pl.weapons.size()):
		var id = String(pl.weapons[i])
		var w: Dictionary = GameData.WEAPONS.get(id, {})
		var b = UI.button("", 7, UI.DIM, 26.0)
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		b.tooltip_text = String(w.get("name", id))
		var icon = UI.sprite_rect(Art.weapon_tex(id), Vector2(30, 14))
		icon.mouse_filter = Control.MOUSE_FILTER_IGNORE
		icon.set_anchors_preset(Control.PRESET_CENTER)
		icon.offset_left = -15
		icon.offset_right = 15
		icon.offset_top = -9
		icon.offset_bottom = 5
		b.add_child(icon)
		var tag = UI.label(str(i + 1), 6, UI.DIM)
		tag.mouse_filter = Control.MOUSE_FILTER_IGNORE
		tag.position = Vector2(2, 0)
		b.add_child(tag)
		var slot_i = i
		b.pressed.connect(func() -> void: pl.select_slot(slot_i))
		weapon_strip.add_child(b)
		slot_buttons.append(b)


# ================================================================ refresh
func refresh() -> void:
	var pl = game.player
	if pl == null or not is_instance_valid(pl):
		return
	if slot_buttons.size() != pl.weapons.size():
		_rebuild_slots()

	hp_fill.size.x = 118.0 * clampf(pl.hp / pl.max_hp, 0.0, 1.0)
	hp_label.text = "%d/%d" % [int(ceil(maxf(pl.hp, 0.0))), int(pl.max_hp)]
	xp_fill.size.x = 118.0 * clampf(float(pl.xp) / float(maxi(1, pl.xp_next)), 0.0, 1.0)
	wave_label.text = "WAVE %d" % maxi(1, game.wave)
	cash_label.text = "$%d" % game.cash
	kills_label.text = "%d kills  LV%d" % [game.kills, pl.level]
	score_label.text = "SCORE %d" % game.score
	combo_label.text = ("x%d" % game.combo) if game.combo >= 5 else ""
	left_label.text = ("LEFT %d" % game.zombies_left()) if game.state == "fight" else ""

	# weapon info
	var id = pl.weapon_id()
	var wname = String(GameData.WEAPONS.get(id, {}).get("name", id))
	if pl.is_melee():
		ammo_label.text = "%s  MELEE" % wname
	elif pl.reloading:
		ammo_label.text = "%s  RELOADING" % wname
	else:
		ammo_label.text = "%s  %d/%d" % [wname, pl.ammo_in_mag(), pl.mag_size(id)]
	reload_fill.size.x = 110.0 * pl.reload_progress()
	nade_label.text = "NADES %d" % pl.grenades

	for i in range(slot_buttons.size()):
		var b: Button = slot_buttons[i]
		b.modulate = Color(1, 1, 1) if i == pl.slot else Color(0.6, 0.6, 0.6)

	# boss bar
	if game.boss != null and is_instance_valid(game.boss) and not game.boss.dead:
		boss_box.visible = true
		var bw = root.size.x - 62.0
		boss_fill.size.x = maxf(0.0, bw * clampf(game.boss.hp / game.boss.max_hp, 0.0, 1.0))
		boss_label.text = "%s  %d%%" % [String(game.boss.d.get("name", "BOSS")),
				int(round(game.boss.hp / game.boss.max_hp * 100.0))]
	else:
		boss_box.visible = false

	# off-screen threat arrows
	var lc = 0
	var rc = 0
	var half = root.size.x * 0.5 / Settings.zoom()
	for z in game.get_zombies():
		if z == null or not is_instance_valid(z) or z.dead:
			continue
		var dx: float = z.global_position.x - pl.global_position.x
		if dx < -half:
			lc += 1
		elif dx > half:
			rc += 1
	arrow_l.text = ("<< %d" % lc) if lc > 0 else ""
	arrow_r.text = ("%d >>" % rc) if rc > 0 else ""

	# low HP vignette
	var frac = pl.hp / pl.max_hp
	if frac < 0.35 and not pl.dead:
		vignette.color.a = maxf(vignette.color.a, 0.10 + 0.10 * sin(Time.get_ticks_msec() * 0.006))
	else:
		vignette.color.a = maxf(0.0, vignette.color.a - 0.02)

	fps_label.visible = Settings.on("show_fps")
	if fps_label.visible:
		fps_label.text = "%d FPS  %d Z" % [Engine.get_frames_per_second(), game.get_zombies().size()]

	prep_box.visible = game.state == "prep" and not overlay_dim.visible
	build_bar.visible = build_mode and not overlay_dim.visible


func update_prep(time_left: float) -> void:
	prep_timer_label.text = "PREPARE - %ds" % int(ceil(maxf(time_left, 0.0)))


func show_prep(time_left: float) -> void:
	update_prep(time_left)
	prep_box.visible = true
	event_label.text = ""
	_rebuild_slots()


func on_wave_start(wave_no: int, event_id: String) -> void:
	prep_box.visible = false
	set_build_mode(false)
	var ev_name = ""
	for e in GameData.EVENTS:
		if String(e.get("id", "")) == event_id:
			ev_name = String(e.get("name", ""))
	if ev_name != "":
		flash_banner("%s!" % ev_name, UI.BLUE)
		event_label.text = ev_name
	else:
		flash_banner("WAVE %d" % wave_no, UI.RED)
		event_label.text = ""


func flash_banner(text: String, color: Color = UI.RED) -> void:
	banner.text = text
	banner.add_theme_color_override("font_color", color)
	if _banner_tw != null and _banner_tw.is_valid():
		_banner_tw.kill()
	banner.modulate.a = 0.0
	banner.scale = Vector2(0.9, 0.9)
	_banner_tw = create_tween()
	_banner_tw.set_parallel(true)
	_banner_tw.tween_property(banner, "modulate:a", 1.0, 0.15)
	_banner_tw.tween_property(banner, "scale", Vector2.ONE, 0.25)
	_banner_tw.chain().tween_interval(1.1)
	_banner_tw.chain().tween_property(banner, "modulate:a", 0.0, 0.5)


func hurt_pulse() -> void:
	vignette.color.a = 0.42
	var tw = create_tween()
	tw.tween_property(vignette, "color:a", 0.0, 0.45)


func flash_screen(color: Color = Color(1, 1, 1), strength: float = 0.35) -> void:
	vignette.color = Color(color.r, color.g, color.b, strength)
	var tw = create_tween()
	tw.tween_property(vignette, "color:a", 0.0, 0.25)
	tw.tween_callback(func() -> void: vignette.color = Color(0.75, 0.05, 0.05, 0.0))


# ================================================================ overlays
func hide_overlays() -> void:
	overlay_dim.visible = false
	shop_panel.visible = false
	up_panel.visible = false
	pause_panel.visible = false
	over_panel.visible = false


func toggle_shop() -> void:
	var showing = not shop_panel.visible
	hide_overlays()
	if showing:
		set_build_mode(false)
		overlay_dim.visible = true
		shop_panel.visible = true
	Audio.play("click", -12.0)


func toggle_build() -> void:
	set_build_mode(not build_mode)


func set_build_mode(v: bool) -> void:
	build_mode = v
	build_bar.visible = v
	if v:
		hide_overlays()
		game.select_build("wall")
		flash_banner("PICK A STRUCTURE", UI.BLUE)
	else:
		game.select_build("")


func show_upgrades(picks: Array) -> void:
	hide_overlays()
	overlay_dim.visible = true
	up_panel.visible = true
	var box: VBoxContainer = up_panel.get_meta("cards")
	for c in box.get_children():
		c.queue_free()
	for u in picks:
		var id = String(u["id"])
		var lvl = int(game.player.lvl(id))
		var card = UI.button("", 9, UI.GOLD, 46.0)
		card.size_flags_vertical = Control.SIZE_EXPAND_FILL
		var col = VBoxContainer.new()
		col.mouse_filter = Control.MOUSE_FILTER_IGNORE
		col.set_anchors_preset(Control.PRESET_FULL_RECT)
		col.offset_left = 6
		col.offset_top = 4
		col.add_theme_constant_override("separation", 0)
		col.add_child(UI.label("%s  [%d/%d]" % [String(u.get("name", id)), lvl,
				int(u.get("max", 5))], 9, UI.GOLD))
		col.add_child(UI.label(String(u.get("desc", "")), 7, UI.BONE))
		card.add_child(col)
		card.pressed.connect(func() -> void: game.pick_upgrade(id))
		box.add_child(card)


func show_pause() -> void:
	hide_overlays()
	overlay_dim.visible = true
	pause_panel.visible = true


func show_game_over(wave_no: int, kill_count: int, final_score: int, cores: int) -> void:
	hide_overlays()
	overlay_dim.visible = true
	over_panel.visible = true
	var stats: VBoxContainer = over_panel.get_meta("stats")
	for c in stats.get_children():
		c.queue_free()
	stats.add_child(UI.label("WAVE REACHED     %d" % wave_no, 9, UI.BONE))
	stats.add_child(UI.label("ZOMBIES KILLED   %d" % kill_count, 9, UI.BONE))
	stats.add_child(UI.label("SCORE            %d" % final_score, 9, UI.BONE))
	stats.add_child(UI.label("CORES EARNED     +%d" % cores, 10, UI.GOLD))
	stats.add_child(UI.label("BEST WAVE        %d" % Save.stat("best_wave"), 8, UI.DIM))
	stats.add_child(UI.label("TOTAL CORES      %d" % Save.cores(), 8, UI.DIM))


# ================================================================ touch helpers
func blocks_touch() -> bool:
	return overlay_dim.visible


func point_blocked(screen_pos: Vector2) -> bool:
	## True when the point is over UI, so the world must ignore that tap.
	if overlay_dim.visible:
		return true
	if screen_pos.y < 48.0:
		return true
	if build_bar.visible and build_bar.get_global_rect().has_point(screen_pos):
		return true
	if prep_box.visible and prep_box.get_global_rect().has_point(screen_pos):
		return true
	if weapon_strip.get_parent() != null:
		var r: Rect2 = (weapon_strip.get_parent() as Control).get_global_rect()
		if r.has_point(screen_pos):
			return true
	return false
