extends Node2D
class_name Game
## The run itself: world, camera, waves, spawning, combat helpers, economy,
## building, upgrades, crates, events, pause and game over.
##
## Everything is built from code so nothing can break in the editor.

const BULLET_POOL := 240
const GRID_CELL := 48.0
const PREP_TIME := 26.0
const SPAWN_MARGIN := 46.0
const COMBO_TIME := 3.2

# ---------------------------------------------------------------- state
var state = "prep"                 # "prep" | "fight" | "over"
var wave = 0
var cash = 220
var kills = 0
var score = 0
var combo = 0
var combo_t = 0.0
var prep_time = PREP_TIME
var to_spawn = 0
var spawn_t = 0.0
var wave_hp = 1.0
var wave_spd = 1.0
var event_id = "none"
var boss = null
var build_kind = ""
var run_time = 0.0
var paused = false

# ---------------------------------------------------------------- nodes
var world: Node2D
var parallax: Array = []            # [{"node": Node2D, "factor": float}]
var entities: Node2D
var cam: Camera2D
var fx = null
var hud = null
var player = null
var night: CanvasModulate

var zombies: Array = []
var structures: Array = []
var allies: Array = []
var crates: Array = []
var _bullets: Array = []            # free pool
var _grid: Dictionary = {}
var _beams: Array = []
var _shake = 0.0
var _hitstop_until = 0


# ================================================================ setup
func _ready() -> void:
	randomize()
	Engine.time_scale = 1.0
	get_tree().paused = false
	_build_world()
	_build_bullets()
	fx = Fx.new()
	fx.z_index = 10
	add_child(fx)
	hud = HUD.new()
	hud.game = self
	add_child(hud)
	_spawn_player()
	_build_camera()
	var pet = Save.loadout_get("pet")
	if pet != "none":
		spawn_ally(pet)
	state = "prep"
	prep_time = 12.0
	hud.show_prep(prep_time)
	hud.flash_banner("HOLD THE LINE", UI.RED)
	Music.play("battle", 1.5)


func _exit_tree() -> void:
	Engine.time_scale = 1.0
	get_tree().paused = false


func _build_world() -> void:
	world = Node2D.new()
	add_child(world)

	var sky = _layer(Art.env_tex("sky"), 0.0, -170.0, 3.2)
	var mountains = _layer(Art.env_tex("mountains"), 0.15, -96.0, 1.0)
	var city = _layer(Art.env_tex("city"), 0.35, -104.0, 1.0)
	var fence = _layer(Art.env_tex("fence"), 0.62, -54.0, 1.0)
	var ground = _layer(Art.env_tex("ground"), 1.0, -6.0, 1.0)
	var road = _layer(Art.env_tex("road"), 1.0, -4.0, 1.0)
	if sky != null:
		sky.z_index = -40
	if mountains != null:
		mountains.z_index = -30
	if city != null:
		city.z_index = -25
	if fence != null:
		fence.z_index = -20
	if ground != null:
		ground.z_index = -12
	if road != null:
		road.z_index = -10

	entities = Node2D.new()
	entities.y_sort_enabled = true
	world.add_child(entities)

	# scenery props along the band
	var props: Array = Art.env_props()
	if not props.is_empty():
		for i in range(26):
			var s = Sprite2D.new()
			s.texture = Art.tex(String(props[randi() % props.size()]))
			s.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
			s.position = Vector2(randf_range(40.0, GameData.ARENA_W - 40.0),
					randf_range(GameData.BAND_TOP - 16.0, GameData.BAND_TOP - 4.0))
			s.z_index = -8
			world.add_child(s)

	night = CanvasModulate.new()
	night.color = Color(1, 1, 1)
	add_child(night)


func _layer(tex: Texture2D, factor: float, y: float, v_scale: float = 1.0) -> Node2D:
	## A scrolling background band. The strip is only as wide as the screen plus
	## two spare tiles and is re-wrapped every frame with fposmod, so the layer
	## can never run out, drift away or "slide off" the level like it used to.
	if tex == null:
		return null
	var holder = Node2D.new()
	holder.position.y = y
	var tw = maxf(8.0, float(tex.get_width()))
	var span = max_visible_w() + tw * 2.0
	var tiles = int(ceil(span / tw)) + 1
	for i in range(tiles):
		var s = Sprite2D.new()
		s.texture = tex
		s.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
		s.centered = false
		s.position = Vector2(float(i) * tw, 0.0)
		s.scale = Vector2(1.0, v_scale)
		holder.add_child(s)
	world.add_child(holder)
	parallax.append({"node": holder, "factor": factor, "base_y": y, "tile_w": tw})
	return holder


# ================================================================ view helpers
func visible_half_w() -> float:
	## Half of what the player actually sees, in world pixels.
	return get_viewport_rect().size.x * 0.5 / maxf(0.1, Settings.zoom())


func visible_half_h() -> float:
	return get_viewport_rect().size.y * 0.5 / maxf(0.1, Settings.zoom())


func max_visible_w() -> float:
	## Widest possible view over every zoom setting (used to size the parallax).
	var z = 99.0
	for v in Settings.ZOOM_VALUES:
		z = minf(z, float(v))
	return get_viewport_rect().size.x / maxf(0.1, z)


func on_screen(pos: Vector2, margin: float = 0.0) -> bool:
	return absf(pos.x - cam.global_position.x) < visible_half_w() + margin


func _build_camera() -> void:
	cam = Camera2D.new()
	cam.zoom = Vector2.ONE * Settings.zoom()
	cam.position_smoothing_enabled = true
	cam.position_smoothing_speed = 7.0
	cam.limit_left = 0
	cam.limit_right = int(GameData.ARENA_W)
	cam.limit_top = -600
	cam.limit_bottom = 400
	cam.ignore_rotation = true
	add_child(cam)
	cam.make_current()
	cam.global_position = player.global_position + Vector2(0, -14)


func _build_bullets() -> void:
	for i in range(BULLET_POOL):
		var b = Bullet.new()
		add_child(b)
		_bullets.append(b)
	for i in range(6):
		var l = Line2D.new()
		l.width = 2.0
		l.visible = false
		l.z_index = 9
		l.default_color = Color(0.7, 0.95, 1.0)
		add_child(l)
		_beams.append(l)


func _spawn_player() -> void:
	player = Player.new()
	entities.add_child(player)
	player.global_position = Vector2(GameData.ARENA_W * 0.5, (GameData.BAND_TOP + GameData.BAND_BOT) * 0.5)
	player.setup(self, Save.loadout())


# ================================================================ loop
func _process(delta: float) -> void:
	run_time += delta
	_keyboard(delta)

	if Engine.time_scale < 1.0 and Time.get_ticks_msec() > _hitstop_until:
		Engine.time_scale = 1.0

	# camera follow + shake
	if player != null and is_instance_valid(player):
		# look ahead in the direction the survivor faces so the horde is on
		# screen long before it can reach him
		var lead = clampf(player.aim_dir.x, -1.0, 1.0) * visible_half_w() * 0.18
		var target = player.global_position + Vector2(lead, -16.0)
		cam.global_position = cam.global_position.lerp(target, clampf(delta * 5.0, 0.0, 1.0))
	cam.zoom = Vector2.ONE * Settings.zoom()
	if _shake > 0.01:
		_shake = maxf(0.0, _shake - delta * 26.0)
		var m = Settings.shake_mul()
		cam.offset = Vector2(randf_range(-_shake, _shake), randf_range(-_shake, _shake) * 0.6) * m
	else:
		cam.offset = cam.offset.lerp(Vector2.ZERO, 0.4)

	# parallax: wrap each band around the camera, seamless and drift free
	var cx = cam.global_position.x
	var edge = visible_half_w() + 2.0
	for l in parallax:
		var n: Node2D = l["node"]
		var f: float = float(l["factor"])
		var tw: float = float(l["tile_w"])
		n.position.x = cx - edge - tw - fposmod(cx * f, tw)

	if combo_t > 0.0:
		combo_t -= delta
		if combo_t <= 0.0:
			combo = 0

	match state:
		"prep":
			prep_time -= delta
			hud.update_prep(prep_time)
			if prep_time <= 0.0:
				start_wave()
		"fight":
			_spawn_step(delta)
		_:
			pass

	hud.refresh()


func _physics_process(_delta: float) -> void:
	_rebuild_grid()
	_cleanup()


func _cleanup() -> void:
	for i in range(zombies.size() - 1, -1, -1):
		var z = zombies[i]
		if z == null or not is_instance_valid(z) or z.dead:
			zombies.remove_at(i)
	for i in range(structures.size() - 1, -1, -1):
		var s = structures[i]
		if s == null or not is_instance_valid(s) or s.dead:
			structures.remove_at(i)
	for i in range(allies.size() - 1, -1, -1):
		if allies[i] == null or not is_instance_valid(allies[i]):
			allies.remove_at(i)
	for i in range(crates.size() - 1, -1, -1):
		if crates[i] == null or not is_instance_valid(crates[i]):
			crates.remove_at(i)


func _keyboard(_delta: float) -> void:
	if player == null or not is_instance_valid(player) or player.dead:
		return
	var kb = Vector2.ZERO
	if Input.is_key_pressed(KEY_A) or Input.is_key_pressed(KEY_LEFT):
		kb.x -= 1.0
	if Input.is_key_pressed(KEY_D) or Input.is_key_pressed(KEY_RIGHT):
		kb.x += 1.0
	if Input.is_key_pressed(KEY_W) or Input.is_key_pressed(KEY_UP):
		kb.y -= 1.0
	if Input.is_key_pressed(KEY_S) or Input.is_key_pressed(KEY_DOWN):
		kb.y += 1.0
	if kb.length() > 0.05:
		player.move_input = kb.normalized()
	if Input.is_key_pressed(KEY_CTRL):
		player.fire_held = true


func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo:
		var k = (event as InputEventKey).keycode
		match k:
			KEY_ESCAPE:
				toggle_pause()
			KEY_E:
				player.dash()
			KEY_Q:
				player.next_weapon()
			KEY_G:
				player.throw_grenade()
			KEY_R:
				player.start_reload()
			KEY_B:
				hud.toggle_build()
			KEY_SPACE:
				if state == "prep":
					start_wave()
			KEY_1, KEY_2, KEY_3, KEY_4:
				player.select_slot(k - KEY_1)
			_:
				pass


# ================================================================ waves
func start_wave() -> void:
	if state == "fight" or state == "over":
		return
	wave += 1
	state = "fight"
	wave_hp = GameData.wave_hp_mul(wave) * Settings.diff_hp()
	wave_spd = GameData.wave_speed_mul(wave) * Settings.diff_speed()
	to_spawn = int(round(float(GameData.wave_count(wave)) * Settings.diff_count()))
	spawn_t = 0.35
	event_id = _roll_event()
	_apply_event_visuals()
	player.grenades += player.lvl("grenades")
	hud.hide_overlays()
	hud.on_wave_start(wave, event_id)
	Audio.play("siren", -12.0)
	if GameData.is_boss_wave(wave):
		Music.play("boss", 1.0)
		_spawn_boss()
	else:
		Music.play("battle", 1.0)
	if wave % 2 == 0:
		_schedule_airdrop()


func _roll_event() -> String:
	if wave < 3:
		return "none"
	var total = 0
	for e in GameData.EVENTS:
		total += int(e.get("weight", 1))
	var pick = randi() % maxi(1, total)
	for e in GameData.EVENTS:
		pick -= int(e.get("weight", 1))
		if pick < 0:
			return String(e.get("id", "none"))
	return "none"


func _apply_event_visuals() -> void:
	match event_id:
		"night":
			night.color = Color(0.42, 0.46, 0.62)
		"fog":
			night.color = Color(0.72, 0.85, 0.7)
		_:
			night.color = Color(1, 1, 1)


func _spawn_step(delta: float) -> void:
	spawn_t -= delta
	if to_spawn > 0 and spawn_t <= 0.0:
		if zombies.size() < Settings.max_alive():
			_spawn_zombie()
			to_spawn -= 1
			var rate = clampf(1.15 - float(wave) * 0.03, 0.22, 1.15)
			if event_id == "horde":
				rate *= 0.45
			spawn_t = rate * randf_range(0.7, 1.25)
		else:
			spawn_t = 0.25
	if to_spawn <= 0 and zombies.is_empty():
		_end_wave()


func _end_wave() -> void:
	state = "prep"
	boss = null
	night.color = Color(1, 1, 1)
	var reward = int(round(float(GameData.wave_reward(wave)) * Settings.diff_cash()))
	cash += reward
	score += wave * 120
	prep_time = PREP_TIME
	hud.show_prep(prep_time)
	hud.flash_banner("WAVE %d CLEARED  +$%d" % [wave, reward], UI.GOLD)
	Audio.play("levelup", -6.0)
	Music.play("battle", 2.0)
	for s in structures:
		s.repair(0.25)


func _pick_type() -> String:
	var pool: Array = []
	var total = 0
	for id in GameData.ZOMBIES.keys():
		var d: Dictionary = GameData.ZOMBIES[id]
		if wave < int(d.get("min_wave", 1)):
			continue
		if id == GameData.BOSS_TYPE and not GameData.is_boss_wave(wave):
			if wave < 12:
				continue
		var w = int(d.get("weight", 10))
		if event_id == "runners" and String(d.get("behavior", "walk")) == "walk":
			w = int(float(w) * 0.5)
		if event_id == "runners" and id == "z_runner":
			w *= 4
		if event_id == "fog" and String(d.get("behavior", "")) == "spit":
			w *= 3
		if w <= 0:
			continue
		pool.append({"id": id, "w": w})
		total += w
	if pool.is_empty():
		return "z_walker"
	var pick = randi() % maxi(1, total)
	for p in pool:
		pick -= int(p["w"])
		if pick < 0:
			return String(p["id"])
	return "z_walker"


func _spawn_zombie() -> void:
	var type = _pick_type()
	var elite = ""
	var chance = GameData.elite_chance(wave) + (0.35 if event_id == "elites" else 0.0)
	if randf() < chance:
		elite = String(GameData.ELITE_ORDER[randi() % GameData.ELITE_ORDER.size()])
	var hp_mul = wave_hp * (0.65 if event_id == "horde" else 1.0)
	var spd = wave_spd * (1.35 if event_id == "runners" else 1.0)
	var z = Zombie.new()
	entities.add_child(z)
	z.global_position = _spawn_pos()
	z.setup(self, type, hp_mul, spd, elite, false)
	zombies.append(z)


func _spawn_boss() -> void:
	var z = Zombie.new()
	entities.add_child(z)
	z.global_position = _spawn_pos()
	z.setup(self, GameData.BOSS_TYPE, wave_hp * 1.1, wave_spd * 0.85, "", true)
	zombies.append(z)
	boss = z
	hud.flash_banner("BOSS INCOMING", UI.RED)
	Audio.play("roar", -2.0)
	Music.duck(-6.0, 0.5)
	shake(6.0)


func _spawn_pos() -> Vector2:
	var half = visible_half_w() + SPAWN_MARGIN
	var side = 1.0 if randf() < 0.5 else -1.0
	var x = player.global_position.x + side * (half + randf_range(0.0, 90.0))
	if x < 20.0 or x > GameData.ARENA_W - 20.0:
		x = player.global_position.x - side * (half + randf_range(0.0, 90.0))
	x = clampf(x, 16.0, GameData.ARENA_W - 16.0)
	return Vector2(x, randf_range(GameData.BAND_TOP + 4.0, GameData.BAND_BOT - 2.0))


# ================================================================ rewards
func on_zombie_died(z, overkill: float) -> void:
	kills += 1
	combo += 1
	combo_t = COMBO_TIME
	var mul = combo_mul()
	var money = int(round(float(z.cash) * mul * cash_mul() * Settings.diff_cash()))
	if event_id == "bounty":
		money *= 2
	cash += money
	score += int(round(float(z.cash) * 12.0 * mul))
	add_xp(int(round(float(z.xp) * xp_mul() * Settings.diff_xp())))
	player.on_kill(z)
	if z == boss:
		boss = null
		hitstop(0.16)
		shake(7.0)
		hud.flash_banner("BOSS DOWN", UI.GOLD)
		fx.big_text(z.hit_center(), "+$%d" % money, UI.GOLD)
		Music.play("battle", 1.5)
	elif combo > 0 and combo % 15 == 0:
		fx.big_text(z.hit_center(), "x%d COMBO" % combo, UI.GOLD)
	if randf() < 0.035:
		_drop_pickup(z.global_position)


func combo_mul() -> float:
	return clampf(1.0 + float(combo) * 0.015, 1.0, 2.0)


func cash_mul() -> float:
	return 1.0 + 0.25 * float(player.lvl("greed")) + 0.1 * float(player.lvl("magnet"))


func xp_mul() -> float:
	return 1.0 + 0.25 * float(player.lvl("xp"))


func add_xp(amount: int) -> void:
	player.xp += amount
	while player.xp >= player.xp_next:
		player.xp -= player.xp_next
		player.level += 1
		player.xp_next = int(round(float(player.xp_next) * 1.28 + 8.0))
		offer_upgrades()


func offer_upgrades() -> void:
	var pool: Array = []
	for u in GameData.UPGRADES:
		var id = String(u["id"])
		if player.lvl(id) >= int(u.get("max", 5)):
			continue
		pool.append(u)
	pool.shuffle()
	var picks: Array = []
	for i in range(mini(3, pool.size())):
		picks.append(pool[i])
	if picks.is_empty():
		return
	Audio.play("levelup", -6.0)
	Engine.time_scale = 1.0
	hud.show_upgrades(picks)
	get_tree().paused = true


func pick_upgrade(id: String) -> void:
	player.add_upgrade(id)
	get_tree().paused = false
	hud.hide_overlays()
	Audio.play("coin", -8.0)


# ================================================================ pickups / crates
func _drop_pickup(pos: Vector2) -> void:
	var kind = "medkit" if randf() < 0.45 else "cash"
	var s = Sprite2D.new()
	s.texture = Art.fx_tex(kind)
	s.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	s.position = pos + Vector2(0, -4)
	s.z_index = 3
	world.add_child(s)
	crates.append(s)
	s.set_meta("loot", kind)
	s.set_meta("crate", false)
	var tw = create_tween()
	tw.tween_property(s, "position", s.position + Vector2(0, -5), 0.4)
	tw.tween_property(s, "position", s.position, 0.4)
	tw.set_loops(20)


func _schedule_airdrop() -> void:
	var tmr = get_tree().create_timer(randf_range(8.0, 18.0))
	tmr.timeout.connect(_spawn_airdrop)


func _spawn_airdrop() -> void:
	if state != "fight":
		return
	var x = clampf(player.global_position.x + randf_range(-140.0, 140.0), 30.0, GameData.ARENA_W - 30.0)
	var target = Vector2(x, randf_range(GameData.BAND_TOP + 10.0, GameData.BAND_BOT - 6.0))
	var s = Sprite2D.new()
	s.texture = Art.fx_tex("crate")
	s.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	s.position = target - Vector2(0, 220.0)
	s.scale = Vector2.ONE * 1.4
	s.z_index = 7
	world.add_child(s)
	crates.append(s)
	s.set_meta("crate", true)
	s.set_meta("loot", _roll_loot())
	Audio.play("horn", -8.0)
	hud.flash_banner("AIRDROP INBOUND", UI.BLUE)
	var tw = create_tween()
	tw.tween_property(s, "position", target, 1.9).set_ease(Tween.EASE_IN)
	tw.tween_callback(func() -> void:
		if is_instance_valid(s):
			fx.smoke(s.position, 8, Color(0.55, 0.5, 0.45, 0.7))
			shake(2.0)
			Audio.play("thud", -8.0))


func _roll_loot() -> String:
	var total = 0
	for l in GameData.CRATE_LOOT:
		total += int(l.get("weight", 1))
	var pick = randi() % maxi(1, total)
	for l in GameData.CRATE_LOOT:
		pick -= int(l.get("weight", 1))
		if pick < 0:
			return String(l.get("id", "cash"))
	return "cash"


func _collect(node: Sprite2D) -> void:
	var loot = String(node.get_meta("loot", "cash"))
	match loot:
		"cash":
			var money = 60 + wave * 18
			cash += money
			fx.float_text(node.position, "+$%d" % money, UI.GOLD)
			Audio.play("coin", -8.0)
		"ammo":
			player.refill_ammo()
			fx.float_text(node.position, "AMMO FULL", UI.BLUE)
			Audio.play("reload", -8.0)
		"heal", "medkit":
			player.heal(45.0)
			fx.float_text(node.position, "+45 HP", UI.GREEN)
			Audio.play("heal", -8.0)
		"nades":
			player.add_grenades(3)
			fx.float_text(node.position, "+3 GRENADES", UI.BONE)
			Audio.play("click", -8.0)
		"rage":
			player.give_rage(9.0)
			Audio.play("levelup", -8.0)
		"weapon":
			var order: Array = GameData.SHOP_ORDER
			var pool: Array = []
			for cand in order:
				if weapon_unlocked(String(cand)) and not player.owns(String(cand)):
					pool.append(cand)
			if pool.is_empty():
				pool = order.duplicate()
			var id = String(pool[randi() % pool.size()])
			if player.add_weapon(id):
				fx.big_text(node.position, String(GameData.WEAPONS[id].get("name", id)), UI.BLUE)
			Audio.play("coin", -6.0)
		_:
			cash += 40
	if node.get_meta("crate", false):
		Audio.play("crate", -8.0)
		fx.smoke(node.position, 6, Color(0.6, 0.55, 0.5, 0.7))
	node.queue_free()


# ================================================================ combat helpers
func _rebuild_grid() -> void:
	_grid.clear()
	for z in zombies:
		if z == null or not is_instance_valid(z) or z.dead:
			continue
		var key = int(floor(z.global_position.x / GRID_CELL))
		if not _grid.has(key):
			_grid[key] = []
		(_grid[key] as Array).append(z)
	# pickup magnet / collection
	if player != null and is_instance_valid(player) and not player.dead:
		var reach = 30.0 if player.lvl("magnet") > 0 else 13.0
		for c in crates:
			if c == null or not is_instance_valid(c):
				continue
			if c.position.distance_to(player.global_position + Vector2(0, -8)) < reach:
				_collect(c)


func get_zombies() -> Array:
	return zombies


func get_structures() -> Array:
	return structures


func zombies_near(pos: Vector2, r: float) -> Array:
	var out: Array = []
	var c0 = int(floor((pos.x - r) / GRID_CELL))
	var c1 = int(floor((pos.x + r) / GRID_CELL))
	for c in range(c0, c1 + 1):
		if not _grid.has(c):
			continue
		for z in (_grid[c] as Array):
			if z == null or not is_instance_valid(z) or z.dead:
				continue
			if absf(z.global_position.y - pos.y) > r + 44.0:
				continue
			out.append(z)
	return out


func nearest_zombie(pos: Vector2, max_range: float = 400.0):
	var best = null
	var best_d = max_range * max_range
	for z in zombies:
		if z == null or not is_instance_valid(z) or z.dead:
			continue
		var d: float = pos.distance_squared_to(z.hit_center())
		if d < best_d:
			best_d = d
			best = z
	return best


func structure_in_front(pos: Vector2, dir_x: float, reach: float) -> Structure:
	if dir_x == 0.0:
		return null
	var best = null
	var best_dx = reach
	for s in structures:
		if s == null or not is_instance_valid(s) or s.dead:
			continue
		if String(s.kind) == "mine" or String(s.kind) == "spikes":
			continue
		var dx: float = (s.global_position.x - pos.x) * dir_x
		if dx < 0.0 or dx > reach:
			continue
		if absf(s.global_position.y - pos.y) > 15.0:
			continue
		if dx < best_dx:
			best_dx = dx
			best = s
	return best


func structure_power() -> float:
	if player == null or not is_instance_valid(player):
		return 1.0
	return 1.0 + 0.3 * float(player.lvl("turretdmg"))


func spawn_bullet(pos: Vector2, dir: Vector2, cfg: Dictionary) -> void:
	if _bullets.is_empty():
		return
	var b = _bullets.pop_back()
	b.launch(self, pos, dir, cfg)


func recycle_bullet(b) -> void:
	if not _bullets.has(b):
		_bullets.append(b)


func hitscan(from: Vector2, dir: Vector2, max_range: float, dmg: float, pierce: int,
		knock: float, crit_chance: float, crit_mul: float,
		color: Color = Color(0.7, 0.95, 1.0)) -> void:
	var d = dir.normalized()
	var hits: Array = []
	for z in zombies:
		if z == null or not is_instance_valid(z) or z.dead:
			continue
		var c: Vector2 = z.hit_center()
		var to: Vector2 = c - from
		var along: float = to.dot(d)
		if along < 0.0 or along > max_range:
			continue
		var perp: float = absf(to.cross(d))
		if perp > z.radius + 7.0:
			continue
		hits.append({"z": z, "t": along})
	hits.sort_custom(func(a, b): return float(a["t"]) < float(b["t"]))
	var end = from + d * max_range
	var used = 0
	for h in hits:
		if used > pierce:
			break
		var z = h["z"]
		var at: Vector2 = from + d * float(h["t"])
		var crit = randf() < crit_chance
		z.take_hit(dmg * (crit_mul if crit else 1.0), d * knock, crit, at)
		if used == pierce:
			end = at
		used += 1
	_beam(from, end, color)
	fx.sparks(end, -d)


func _beam(a: Vector2, b: Vector2, color: Color) -> void:
	if _beams.is_empty():
		return
	var l: Line2D = _beams.pop_front()
	_beams.append(l)
	l.points = PackedVector2Array([a, b])
	l.default_color = color
	l.width = 2.6
	l.visible = true
	l.modulate = Color(1, 1, 1, 1)
	var tw = create_tween()
	tw.tween_property(l, "modulate:a", 0.0, 0.12)
	tw.tween_callback(func() -> void: l.visible = false)


func chain_lightning(from: Vector2, count: int, dmg: float, max_range: float,
		from_player: bool = true) -> void:
	var pos = from
	var hit_ids: Dictionary = {}
	for i in range(count):
		var best = null
		var best_d = max_range * max_range
		for z in zombies:
			if z == null or not is_instance_valid(z) or z.dead:
				continue
			if hit_ids.has(z.get_instance_id()):
				continue
			var d: float = pos.distance_squared_to(z.hit_center())
			if d < best_d:
				best_d = d
				best = z
		if best == null:
			break
		hit_ids[best.get_instance_id()] = true
		var at: Vector2 = best.hit_center()
		_beam(pos, at, Color(0.6, 0.85, 1.0))
		best.take_hit(dmg, (at - pos).normalized() * 40.0, false, at)
		best.stagger(0.25)
		fx.sparks(at, Vector2.UP)
		pos = at
	Audio.play("zap", -10.0, randf_range(0.95, 1.1), 0.02)


func explode(pos: Vector2, radius: float, dmg: float, from_player: bool = true,
		scale: float = 1.0) -> void:
	fx.explosion(pos, scale)
	fx.shockwave(pos, radius, Color(1.0, 0.8, 0.45, 0.55))
	shake(3.5 * scale)
	hitstop(0.05)
	Audio.play("explosion", -4.0, randf_range(0.92, 1.08))
	Music.duck(-4.0, 0.3)
	for z in zombies_near(pos, radius + 20.0):
		if z.dead:
			continue
		var dist: float = pos.distance_to(z.hit_center())
		if dist > radius:
			continue
		var falloff: float = 1.0 - clampf(dist / radius, 0.0, 1.0) * 0.55
		z.take_hit(dmg * falloff, (z.hit_center() - pos).normalized() * 120.0, false, z.hit_center())
	if not from_player and player != null and is_instance_valid(player):
		var pd: float = pos.distance_to(player.global_position + Vector2(0, -10))
		if pd < radius:
			player.take_damage(dmg * 0.5 * (1.0 - pd / radius), pos)
	for s in structures:
		if s == null or not is_instance_valid(s) or s.dead:
			continue
		if pos.distance_to(s.global_position) < radius and not from_player:
			s.take_structure_damage(dmg * 0.4)


func shake(amount: float) -> void:
	_shake = minf(_shake + amount, 12.0)


func hitstop(seconds: float) -> void:
	if Settings.quality() == 0:
		return
	_hitstop_until = maxi(_hitstop_until, Time.get_ticks_msec() + int(seconds * 1000.0))
	Engine.time_scale = 0.32


# ================================================================ building / shop
func can_build(kind: String) -> bool:
	return cash >= int(GameData.BUILDINGS.get(kind, {}).get("price", 99999))


func select_build(kind: String) -> void:
	build_kind = kind


func place_build(world_pos: Vector2) -> bool:
	if build_kind == "" or not GameData.BUILDINGS.has(build_kind):
		return false
	var price = int(GameData.BUILDINGS[build_kind].get("price", 100))
	if cash < price:
		hud.flash_banner("NOT ENOUGH CASH", UI.RED)
		Audio.play("empty", -10.0)
		return false
	var pos = Vector2(clampf(world_pos.x, 16.0, GameData.ARENA_W - 16.0),
			clampf(world_pos.y, GameData.BAND_TOP + 4.0, GameData.BAND_BOT))
	for s in structures:
		if s != null and is_instance_valid(s) and s.global_position.distance_to(pos) < 14.0:
			hud.flash_banner("TOO CLOSE", UI.RED)
			return false
	cash -= price
	var st = Structure.new()
	entities.add_child(st)
	st.global_position = pos
	st.setup(self, build_kind, 1.0 + 0.4 * float(player.lvl("structhp")))
	structures.append(st)
	fx.smoke(pos, 5, Color(0.6, 0.55, 0.5, 0.6))
	Audio.play("build", -8.0)
	return true


func weapon_unlocked(id: String) -> bool:
	## Guns show up in the market as the run gets deeper, so wave 1 cash can
	## never buy a railgun.
	return maxi(1, wave) >= int(GameData.WEAPONS.get(id, {}).get("unlock", 1))


func weapon_price(id: String) -> int:
	return int(GameData.WEAPONS.get(id, {}).get("price", 99999))


func sell_price(id: String) -> int:
	return int(round(float(weapon_price(id)) * GameData.SELL_REFUND))


func ammo_price(id: String) -> int:
	## Only pay for the rounds that are actually missing.
	var full = player.max_reserve(id)
	if full <= 0:
		return 0
	var missing = float(full - player.reserve_ammo(id)) / float(full)
	if missing <= 0.001:
		return 0
	return maxi(10, int(round(float(GameData.WEAPONS[id].get("ammo_price", 100)) * missing)))


func refill_all_price() -> int:
	var total = 0
	for w in player.weapons:
		total += ammo_price(String(w))
	return total


func heal_price() -> int:
	var missing = clampf(1.0 - player.hp / maxf(1.0, player.max_hp), 0.0, 1.0)
	return maxi(0, int(round(float(GameData.MEDKIT_PRICE) * missing)))


func _deny(reason: String) -> bool:
	hud.flash_banner(reason, UI.RED)
	Audio.play("empty", -10.0)
	return false


func buy_weapon(id: String) -> bool:
	var w: Dictionary = GameData.WEAPONS.get(id, {})
	if w.is_empty():
		return false
	if player.owns(id):
		return _deny("ALREADY OWNED")
	if not weapon_unlocked(id):
		return _deny("LOCKED UNTIL WAVE %d" % int(w.get("unlock", 1)))
	if player.weapons.size() >= Player.MAX_WEAPONS:
		return _deny("SELL A WEAPON FIRST")
	var price = weapon_price(id)
	if cash < price:
		return _deny("NOT ENOUGH CASH")
	cash -= price
	player.add_weapon(id)
	Audio.play("coin", -6.0)
	hud.flash_banner("%s ACQUIRED" % String(w.get("name", id)), UI.GOLD)
	return true


func sell_weapon(id: String) -> bool:
	if not player.owns(id):
		return false
	var refund = sell_price(id)
	if not player.drop_weapon(id):
		return _deny("YOU NEED A GUN")
	cash += refund
	Audio.play("coin", -8.0)
	hud.flash_banner("SOLD  +$%d" % refund, UI.GOLD)
	return true


func buy_ammo(id: String) -> bool:
	var price = ammo_price(id)
	if price <= 0:
		return _deny("AMMO IS FULL")
	if cash < price:
		return _deny("NOT ENOUGH CASH")
	cash -= price
	player.fill_reserve(id)
	Audio.play("reload", -8.0)
	return true


func buy_ammo_all() -> bool:
	var price = refill_all_price()
	if price <= 0:
		return _deny("AMMO IS FULL")
	if cash < price:
		return _deny("NOT ENOUGH CASH")
	cash -= price
	player.refill_ammo()
	Audio.play("reload", -8.0)
	return true


func buy_grenade() -> bool:
	var price = int(GameData.GRENADE_PRICE)
	if cash < price:
		return _deny("NOT ENOUGH CASH")
	cash -= price
	player.add_grenades(1)
	Audio.play("coin", -8.0)
	return true


func buy_heal() -> bool:
	var price = heal_price()
	if price <= 0:
		return _deny("ALREADY AT FULL HP")
	if cash < price:
		return _deny("NOT ENOUGH CASH")
	cash -= price
	player.heal(player.max_hp)
	Audio.play("heal", -8.0)
	return true


func spawn_ally(kind: String) -> void:
	var a = Ally.new()
	entities.add_child(a)
	a.global_position = player.global_position + Vector2(randf_range(-20, 20), 0)
	a.setup(self, kind, 1.0 + 0.25 * float(player.level))
	allies.append(a)


# ================================================================ flow
func in_prep() -> bool:
	return state == "prep"


func is_over() -> bool:
	return state == "over"


func zombies_left() -> int:
	return to_spawn + zombies.size()


func toggle_pause() -> void:
	if state == "over":
		return
	paused = not paused
	Engine.time_scale = 1.0
	get_tree().paused = paused
	if paused:
		hud.show_pause()
	else:
		hud.hide_overlays()


func on_player_died() -> void:
	if state == "over":
		return
	state = "over"
	Engine.time_scale = 1.0
	var earned = Save.report_run(wave, kills, score)
	Music.play("menu", 2.0)
	shake(8.0)
	hud.show_game_over(wave, kills, score, earned)


func restart() -> void:
	Engine.time_scale = 1.0
	get_tree().paused = false
	get_tree().change_scene_to_file("res://Game.tscn")


func return_to_menu() -> void:
	Engine.time_scale = 1.0
	get_tree().paused = false
	get_tree().change_scene_to_file("res://Main.tscn")
