extends Node
## Persistent profile: records, meta currency (Cores), unlocks, loadout and settings.
## Stored as JSON in user://deadline_save.json - safe to delete, regenerates with defaults.

const PATH := "user://deadline_save.json"
const VERSION := 2

const DEFAULT_LOADOUT := {
	"primary": "ak47",
	"sidearm": "pistol",
	"melee": "none",
	"suit": "player_soldier",
	"pet": "none",
}

var data: Dictionary = {
	"version": VERSION,
	"best_wave": 0,
	"best_kills": 0,
	"best_score": 0,
	"total_kills": 0,
	"total_cores": 0,
	"cores": 0,
	"runs": 0,
	"settings": {},
	"unlocked": ["ak47", "shotgun", "pistol", "none", "player_soldier"],
	"loadout": DEFAULT_LOADOUT.duplicate(true),
	"seen_intro": false,
}


func _ready() -> void:
	load_game()


func load_game() -> void:
	if not FileAccess.file_exists(PATH):
		return
	var f = FileAccess.open(PATH, FileAccess.READ)
	if f == null:
		return
	var txt = f.get_as_text()
	f.close()
	var parsed: Variant = JSON.parse_string(txt)
	if typeof(parsed) != TYPE_DICTIONARY:
		return
	for k in (parsed as Dictionary).keys():
		if data.has(k):
			data[k] = (parsed as Dictionary)[k]
	# make sure nested structures always have every key
	var lo: Dictionary = data.get("loadout", {}) if typeof(data.get("loadout")) == TYPE_DICTIONARY else {}
	for k in DEFAULT_LOADOUT.keys():
		if not lo.has(k):
			lo[k] = DEFAULT_LOADOUT[k]
	data["loadout"] = lo
	if typeof(data.get("unlocked")) != TYPE_ARRAY:
		data["unlocked"] = ["ak47", "shotgun", "pistol", "none", "player_soldier"]
	data["version"] = VERSION


func save_game() -> void:
	var f = FileAccess.open(PATH, FileAccess.WRITE)
	if f == null:
		push_warning("Save: cannot write " + PATH)
		return
	f.store_string(JSON.stringify(data))
	f.close()


# ------------------------------------------------------------------ records
func report_run(wave: int, kills: int, score: int = 0) -> int:
	## Records a finished run and returns how many Cores were earned.
	data["runs"] = int(data.get("runs", 0)) + 1
	data["total_kills"] = int(data.get("total_kills", 0)) + kills
	if wave > int(data.get("best_wave", 0)):
		data["best_wave"] = wave
	if kills > int(data.get("best_kills", 0)):
		data["best_kills"] = kills
	if score > int(data.get("best_score", 0)):
		data["best_score"] = score
	var earned: int = GameData.cores_for_run(wave, kills)
	add_cores(earned)
	save_game()
	return earned


func stat(key: String) -> int:
	return int(data.get(key, 0))


# ------------------------------------------------------------------ cores / unlocks
func cores() -> int:
	return int(data.get("cores", 0))


func add_cores(amount: int) -> void:
	data["cores"] = maxi(0, cores() + amount)
	data["total_cores"] = int(data.get("total_cores", 0)) + maxi(0, amount)
	save_game()


func spend_cores(amount: int) -> bool:
	if cores() < amount:
		return false
	data["cores"] = cores() - amount
	save_game()
	return true


func unlocked_list() -> Array:
	var v: Variant = data.get("unlocked", [])
	return v if typeof(v) == TYPE_ARRAY else []


func is_unlocked(id: String) -> bool:
	if id == "none":
		return true
	return unlocked_list().has(id)


func unlock(id: String) -> void:
	var list = unlocked_list()
	if not list.has(id):
		list.append(id)
	data["unlocked"] = list
	save_game()


func try_buy(id: String, price: int) -> bool:
	if is_unlocked(id):
		return true
	if price <= 0:
		unlock(id)
		return true
	if not spend_cores(price):
		return false
	unlock(id)
	return true


# ------------------------------------------------------------------ loadout
func loadout() -> Dictionary:
	var v: Variant = data.get("loadout", {})
	if typeof(v) != TYPE_DICTIONARY:
		v = DEFAULT_LOADOUT.duplicate(true)
		data["loadout"] = v
	return v


func loadout_get(slot: String) -> String:
	return String(loadout().get(slot, DEFAULT_LOADOUT.get(slot, "none")))


func loadout_set(slot: String, id: String) -> void:
	var lo = loadout()
	lo[slot] = id
	data["loadout"] = lo
	save_game()


# ------------------------------------------------------------------ legacy flags
func get_flag(key: String, def: bool = true) -> bool:
	return bool(data.get(key, def))


func set_flag(key: String, value: bool) -> void:
	data[key] = value
	save_game()
