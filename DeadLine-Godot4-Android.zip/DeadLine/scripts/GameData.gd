extends Node
## All static balance data of the game. Pure data, no logic.

# ---------------------------------------------------------------- WEAPONS
# kind: bullet | pellet | rocket | grenade | flame | laser | tesla | melee
const WEAPONS := {
	"pistol": {
		"name": "M1911", "kind": "bullet", "dmg": 13.0, "rate": 4.5, "mag": 12, "reload": 0.9,
		"spread": 1.5, "count": 1, "speed": 620.0, "pierce": 0, "knock": 30.0, "price": 0,
		"aoe": 0.0, "range": 320.0, "auto": true, "shake": 0.6, "desc": "Reliable sidearm.",
		"reserve": -1, "ammo_price": 0, "unlock": 1
	},
	"magnum": {
		"name": ".44 Magnum", "kind": "bullet", "dmg": 44.0, "rate": 1.9, "mag": 6, "reload": 1.4,
		"spread": 1.0, "count": 1, "speed": 720.0, "pierce": 1, "knock": 120.0, "price": 820,
		"aoe": 0.0, "range": 360.0, "auto": true, "shake": 1.6, "desc": "Punches through skulls.",
		"reserve": 60, "ammo_price": 105, "unlock": 2
	},
	"uzi": {
		"name": "Uzi", "kind": "bullet", "dmg": 8.0, "rate": 12.0, "mag": 32, "reload": 1.2,
		"spread": 7.0, "count": 1, "speed": 560.0, "pierce": 0, "knock": 18.0, "price": 620,
		"aoe": 0.0, "range": 260.0, "auto": true, "shake": 0.4, "desc": "Spray and pray.",
		"reserve": 320, "ammo_price": 85, "unlock": 1
	},
	"mp5": {
		"name": "MP5", "kind": "bullet", "dmg": 12.0, "rate": 10.0, "mag": 30, "reload": 1.4,
		"spread": 4.0, "count": 1, "speed": 640.0, "pierce": 0, "knock": 24.0, "price": 1250,
		"aoe": 0.0, "range": 320.0, "auto": true, "shake": 0.5, "desc": "Controlled bursts.",
		"reserve": 300, "ammo_price": 115, "unlock": 3
	},
	"ak47": {
		"name": "AK-47", "kind": "bullet", "dmg": 21.0, "rate": 8.0, "mag": 30, "reload": 1.7,
		"spread": 5.0, "count": 1, "speed": 700.0, "pierce": 1, "knock": 40.0, "price": 2100,
		"aoe": 0.0, "range": 360.0, "auto": true, "shake": 0.9, "desc": "Loud, brutal, perfect.",
		"reserve": 300, "ammo_price": 145, "unlock": 4
	},
	"m4": {
		"name": "M4A1", "kind": "bullet", "dmg": 18.0, "rate": 10.5, "mag": 30, "reload": 1.5,
		"spread": 2.5, "count": 1, "speed": 760.0, "pierce": 1, "knock": 32.0, "price": 2600,
		"aoe": 0.0, "range": 400.0, "auto": true, "shake": 0.7, "desc": "Accurate full auto.",
		"reserve": 300, "ammo_price": 155, "unlock": 5
	},
	"shotgun": {
		"name": "Pump Shotgun", "kind": "pellet", "dmg": 12.0, "rate": 1.4, "mag": 6, "reload": 2.0,
		"spread": 15.0, "count": 7, "speed": 520.0, "pierce": 0, "knock": 190.0, "price": 1500,
		"aoe": 0.0, "range": 170.0, "auto": true, "shake": 2.2, "desc": "Turns a crowd into paste.",
		"reserve": 72, "ammo_price": 125, "unlock": 2
	},
	"autoshotgun": {
		"name": "AA-12", "kind": "pellet", "dmg": 10.0, "rate": 3.2, "mag": 12, "reload": 2.4,
		"spread": 17.0, "count": 6, "speed": 520.0, "pierce": 0, "knock": 150.0, "price": 3800,
		"aoe": 0.0, "range": 180.0, "auto": true, "shake": 1.8, "desc": "Automatic meat grinder.",
		"reserve": 144, "ammo_price": 200, "unlock": 8
	},
	"sniper": {
		"name": "Barrett", "kind": "bullet", "dmg": 140.0, "rate": 1.1, "mag": 5, "reload": 1.9,
		"spread": 0.3, "count": 1, "speed": 1500.0, "pierce": 4, "knock": 220.0, "price": 3400,
		"aoe": 0.0, "range": 640.0, "auto": true, "shake": 2.6, "desc": "Line them up.",
		"reserve": 60, "ammo_price": 210, "unlock": 6
	},
	"railgun": {
		"name": "Railgun", "kind": "laser", "dmg": 230.0, "rate": 0.75, "mag": 4, "reload": 2.2,
		"spread": 0.0, "count": 1, "speed": 0.0, "pierce": 99, "knock": 260.0, "price": 8500,
		"aoe": 0.0, "range": 700.0, "auto": true, "shake": 3.4, "desc": "Deletes a whole row.",
		"reserve": 32, "ammo_price": 370, "unlock": 15
	},
	"minigun": {
		"name": "Minigun", "kind": "bullet", "dmg": 13.0, "rate": 20.0, "mag": 200, "reload": 4.0,
		"spread": 8.0, "count": 1, "speed": 720.0, "pierce": 1, "knock": 26.0, "price": 6200,
		"aoe": 0.0, "range": 380.0, "auto": true, "shake": 0.6, "desc": "Never stops screaming.",
		"reserve": 1200, "ammo_price": 290, "unlock": 12
	},
	"rpg": {
		"name": "RPG-7", "kind": "rocket", "dmg": 70.0, "rate": 0.7, "mag": 1, "reload": 2.1,
		"spread": 0.5, "count": 1, "speed": 360.0, "pierce": 0, "knock": 260.0, "price": 5600,
		"aoe": 74.0, "range": 460.0, "auto": true, "shake": 3.6, "desc": "Body parts everywhere.",
		"reserve": 18, "ammo_price": 340, "unlock": 11
	},
	"grenadier": {
		"name": "Grenade MGL", "kind": "grenade", "dmg": 46.0, "rate": 1.3, "mag": 6, "reload": 2.6,
		"spread": 2.0, "count": 1, "speed": 300.0, "pierce": 0, "knock": 200.0, "price": 4600,
		"aoe": 62.0, "range": 380.0, "auto": true, "shake": 2.8, "desc": "Lobs death over the wall.",
		"reserve": 42, "ammo_price": 300, "unlock": 9
	},
	"flamer": {
		"name": "Flamethrower", "kind": "flame", "dmg": 6.0, "rate": 18.0, "mag": 220, "reload": 2.6,
		"spread": 11.0, "count": 1, "speed": 190.0, "pierce": 99, "knock": 4.0, "price": 3200,
		"aoe": 0.0, "range": 96.0, "auto": true, "shake": 0.3, "desc": "Burns the whole horde.",
		"reserve": 1320, "ammo_price": 190, "unlock": 6
	},
	"laser": {
		"name": "Laser Rifle", "kind": "laser", "dmg": 27.0, "rate": 6.5, "mag": 60, "reload": 1.8,
		"spread": 0.8, "count": 1, "speed": 0.0, "pierce": 2, "knock": 20.0, "price": 5000,
		"aoe": 0.0, "range": 460.0, "auto": true, "shake": 0.5, "desc": "Instant hit beams.",
		"reserve": 420, "ammo_price": 250, "unlock": 10
	},
	"tesla": {
		"name": "Tesla Gun", "kind": "tesla", "dmg": 32.0, "rate": 3.2, "mag": 40, "reload": 2.0,
		"spread": 0.0, "count": 4, "speed": 0.0, "pierce": 0, "knock": 40.0, "price": 5800,
		"aoe": 0.0, "range": 240.0, "auto": true, "shake": 1.0, "desc": "Chains between bodies.",
		"reserve": 280, "ammo_price": 290, "unlock": 12
	},
	"chainsaw": {
		"name": "Chainsaw", "kind": "melee", "dmg": 24.0, "rate": 9.0, "mag": 0, "reload": 0.0,
		"spread": 0.0, "count": 1, "speed": 0.0, "pierce": 99, "knock": 60.0, "price": 1350,
		"aoe": 0.0, "range": 34.0, "auto": true, "shake": 0.7, "desc": "Infinite fuel, infinite gore.",
		"reserve": 0, "ammo_price": 0, "unlock": 2
	},
	"lmg": {
		"name": "M249 SAW", "kind": "bullet", "dmg": 17.0, "rate": 13.0, "mag": 100, "reload": 3.6,
		"spread": 6.0, "count": 1, "speed": 720.0, "pierce": 2, "knock": 34.0, "price": 4200,
		"aoe": 0.0, "range": 380.0, "auto": true, "shake": 0.8, "desc": "Belt-fed wall of lead.",
		"reserve": 600, "ammo_price": 230, "unlock": 7
	},
	"gauss": {
		"name": "Gauss Rifle", "kind": "laser", "dmg": 95.0, "rate": 2.4, "mag": 8, "reload": 2.1,
		"spread": 0.2, "count": 1, "speed": 0.0, "pierce": 3, "knock": 190.0, "price": 7000,
		"aoe": 0.0, "range": 620.0, "auto": true, "shake": 2.4, "desc": "Magnetic slug, punches rows.",
		"reserve": 64, "ammo_price": 330, "unlock": 13
	},
	"katana": {
		"name": "Katana", "kind": "melee", "dmg": 62.0, "rate": 3.4, "mag": 0, "reload": 0.0,
		"spread": 0.0, "count": 1, "speed": 0.0, "pierce": 99, "knock": 130.0, "price": 1000,
		"aoe": 0.0, "range": 40.0, "auto": true, "shake": 1.2, "desc": "Clean decapitations.",
		"reserve": 0, "ammo_price": 0, "unlock": 1
	},
}

const SELL_REFUND := 0.5
## Cash cost of one full medkit and of a single grenade in the black market.
const MEDKIT_PRICE := 120
const GRENADE_PRICE := 45

const SHOP_ORDER := ["uzi", "magnum", "katana", "chainsaw", "shotgun", "mp5", "ak47", "m4",
	"flamer", "lmg", "sniper", "autoshotgun", "grenadier", "laser", "rpg", "tesla", "gauss",
	"minigun", "railgun"]

# ---------------------------------------------------------------- ZOMBIES
# behavior: walk | run | crawl | tank | spit | boom
const ZOMBIES := {
	"z_walker": {"name": "Walker", "hp": 36.0, "speed": 27.0, "dmg": 8.0, "rate": 1.1,
		"cash": 6, "xp": 2, "radius": 6.0, "behavior": "walk", "weight": 40, "min_wave": 1},
	"z_nurse": {"name": "Nurse", "hp": 30.0, "speed": 33.0, "dmg": 7.0, "rate": 1.3,
		"cash": 7, "xp": 2, "radius": 6.0, "behavior": "walk", "weight": 18, "min_wave": 2},
	"z_worker": {"name": "Worker", "hp": 52.0, "speed": 24.0, "dmg": 11.0, "rate": 1.0,
		"cash": 9, "xp": 3, "radius": 7.0, "behavior": "walk", "weight": 20, "min_wave": 3},
	"z_runner": {"name": "Runner", "hp": 28.0, "speed": 68.0, "dmg": 10.0, "rate": 1.6,
		"cash": 11, "xp": 4, "radius": 6.0, "behavior": "run", "weight": 22, "min_wave": 4},
	"z_crawler": {"name": "Crawler", "hp": 22.0, "speed": 52.0, "dmg": 7.0, "rate": 1.8,
		"cash": 9, "xp": 3, "radius": 6.0, "behavior": "crawl", "weight": 16, "min_wave": 5},
	"z_spitter": {"name": "Spitter", "hp": 44.0, "speed": 21.0, "dmg": 12.0, "rate": 1.9,
		"cash": 16, "xp": 6, "radius": 7.0, "behavior": "spit", "weight": 12, "min_wave": 7},
	"z_bloater": {"name": "Bloater", "hp": 110.0, "speed": 18.0, "dmg": 14.0, "rate": 1.0,
		"cash": 22, "xp": 8, "radius": 9.0, "behavior": "boom", "weight": 10, "min_wave": 8},
	"z_cop": {"name": "Riot Cop", "hp": 130.0, "speed": 25.0, "dmg": 17.0, "rate": 1.0,
		"cash": 20, "xp": 7, "radius": 7.0, "behavior": "walk", "weight": 13, "min_wave": 6,
		"armor": 0.32},
	"z_hazmat": {"name": "Hazmat", "hp": 96.0, "speed": 30.0, "dmg": 13.0, "rate": 1.5,
		"cash": 19, "xp": 7, "radius": 7.0, "behavior": "spit", "weight": 11, "min_wave": 9,
		"armor": 0.12, "toxic": true},
	"z_brute": {"name": "Brute", "hp": 380.0, "speed": 21.0, "dmg": 30.0, "rate": 0.9,
		"cash": 70, "xp": 26, "radius": 12.0, "behavior": "tank", "weight": 5, "min_wave": 10},
}

const BOSS_TYPE := "z_brute"

# ---------------------------------------------------------------- BUILDINGS
const BUILDINGS := {
	"wall": {"name": "Barricade", "price": 90, "hp": 320.0, "desc": "Blocks the horde."},
	"sandbag": {"name": "Sandbags", "price": 60, "hp": 200.0, "desc": "Cheap cover."},
	"spikes": {"name": "Spikes", "price": 130, "hp": 180.0, "dps": 26.0, "desc": "Shreds anything walking over."},
	"turret": {"name": "Sentry", "price": 420, "hp": 220.0, "dmg": 15.0, "rate": 4.5, "range": 210.0,
		"desc": "Auto-guns down zombies."},
	"tesla": {"name": "Tesla Coil", "price": 560, "hp": 180.0, "dmg": 26.0, "rate": 1.4, "range": 120.0,
		"desc": "Zaps 4 targets at once."},
	"mine": {"name": "Mine", "price": 70, "hp": 20.0, "dmg": 190.0, "aoe": 70.0, "desc": "One big red splash."},
}

const BUILD_ORDER := ["wall", "sandbag", "spikes", "mine", "turret", "tesla"]

# ---------------------------------------------------------------- UPGRADES
const UPGRADES := [
	{"id": "dmg", "name": "Hollow Points", "desc": "+15% weapon damage", "max": 12},
	{"id": "rate", "name": "Trigger Finger", "desc": "+12% fire rate", "max": 10},
	{"id": "speed", "name": "Combat Boots", "desc": "+8% move speed", "max": 8},
	{"id": "hp", "name": "Field Rations", "desc": "+25 max HP (and heal)", "max": 12},
	{"id": "armor", "name": "Kevlar Plate", "desc": "-8% damage taken", "max": 8},
	{"id": "reload", "name": "Quick Hands", "desc": "-15% reload time", "max": 6},
	{"id": "mag", "name": "Extended Mags", "desc": "+30% magazine size", "max": 6},
	{"id": "crit", "name": "Weak Spots", "desc": "+8% crit chance", "max": 8},
	{"id": "critdmg", "name": "Skull Cracker", "desc": "+50% crit damage", "max": 6},
	{"id": "pierce", "name": "AP Rounds", "desc": "+1 pierce", "max": 4},
	{"id": "knock", "name": "Stopping Power", "desc": "+50% knockback", "max": 4},
	{"id": "lifesteal", "name": "Adrenaline", "desc": "+1 HP per kill", "max": 5},
	{"id": "regen", "name": "Field Medic", "desc": "+1 HP / sec regen", "max": 5},
	{"id": "greed", "name": "Looter", "desc": "+25% cash from kills", "max": 6},
	{"id": "xp", "name": "Fast Learner", "desc": "+25% XP gained", "max": 6},
	{"id": "explosive", "name": "Explosive Rounds", "desc": "+12% chance of small blast", "max": 5},
	{"id": "burn", "name": "Incendiary", "desc": "Bullets set zombies on fire", "max": 4},
	{"id": "dash", "name": "Sprint Boost", "desc": "-25% dash cooldown", "max": 4},
	{"id": "dashkill", "name": "Bulldozer", "desc": "Dash deals 60 damage", "max": 4},
	{"id": "turretdmg", "name": "Gun Nut", "desc": "+30% structure damage", "max": 6},
	{"id": "structhp", "name": "Reinforced Steel", "desc": "+40% structure HP", "max": 5},
	{"id": "spikedmg", "name": "Rusty Spikes", "desc": "+60% spike damage", "max": 5},
	{"id": "multishot", "name": "Double Tap", "desc": "+1 projectile per shot", "max": 3},
	{"id": "slow", "name": "Cryo Rounds", "desc": "Hits slow zombies by 25%", "max": 3},
	{"id": "grenades", "name": "Bandolier", "desc": "+2 grenades per wave", "max": 5},
	{"id": "dog", "name": "Loyal Dog", "desc": "A dog fights beside you", "max": 3},
	{"id": "tiger", "name": "War Tiger", "desc": "A tiger mauls the horde", "max": 2},
	{"id": "magnet", "name": "Magnet", "desc": "Auto-collect drops, +10% cash", "max": 2},
]

# ---------------------------------------------------------------- WAVES
const ARENA_W := 2600.0
const BAND_TOP := -44.0
const BAND_BOT := 34.0


func wave_count(w: int) -> int:
	return int(round(7.0 + float(w) * 2.4 + pow(float(w), 1.35) * 0.5))


func wave_hp_mul(w: int) -> float:
	return 1.0 + float(w - 1) * 0.16 + pow(float(w), 1.5) * 0.006


func wave_speed_mul(w: int) -> float:
	return min(1.0 + float(w - 1) * 0.015, 1.7)


func wave_reward(w: int) -> int:
	return 110 + w * 34


func is_boss_wave(w: int) -> bool:
	return w % 5 == 0


# ---------------------------------------------------------------- LOADOUT / META
## Suits change the base body: HP, speed, armour, regen. Prices are in Cores (meta currency).
const SUITS := {
	"player_soldier": {"name": "Soldier", "hp": 0.0, "speed": 1.0, "armor": 0.0, "regen": 0.0,
		"price": 0, "desc": "Balanced army standard."},
	"player_swat": {"name": "SWAT", "hp": 25.0, "speed": 1.0, "armor": 0.10, "regen": 0.0,
		"price": 20, "desc": "Extra plates, same speed."},
	"player_survivor": {"name": "Survivor", "hp": -15.0, "speed": 1.14, "armor": 0.0, "regen": 0.0,
		"price": 12, "desc": "Fragile but fast."},
	"player_medic": {"name": "Medic", "hp": 10.0, "speed": 1.04, "armor": 0.0, "regen": 1.5,
		"price": 26, "desc": "Regenerates health slowly."},
	"player_juggernaut": {"name": "Juggernaut", "hp": 70.0, "speed": 0.87, "armor": 0.20,
		"regen": 0.0, "price": 40, "desc": "A walking bunker."},
}

const SUIT_ORDER := ["player_soldier", "player_swat", "player_survivor", "player_medic",
	"player_juggernaut"]

const PETS := {
	"none": {"name": "No Pet", "price": 0, "desc": "Fight alone."},
	"pet_dog": {"name": "Guard Dog", "price": 18, "desc": "Fast, bites nonstop."},
	"pet_tiger": {"name": "War Tiger", "price": 45, "desc": "Mauls whole groups."},
}

const PET_ORDER := ["none", "pet_dog", "pet_tiger"]

## Weapons you can start a run with, and their Core price (0 = unlocked from the start).
const LOADOUT_PRIMARY := {
	"ak47": 0, "shotgun": 0, "mp5": 8, "m4": 14, "lmg": 22, "flamer": 20, "autoshotgun": 26,
	"sniper": 24, "minigun": 34, "rpg": 36, "grenadier": 30, "laser": 32, "tesla": 34,
	"gauss": 44, "railgun": 55,
}
const LOADOUT_PRIMARY_ORDER := ["ak47", "shotgun", "mp5", "m4", "lmg", "flamer", "autoshotgun",
	"sniper", "grenadier", "laser", "tesla", "minigun", "rpg", "gauss", "railgun"]

const LOADOUT_SIDEARM := {"pistol": 0, "uzi": 6, "magnum": 12, "mp5": 16}
const LOADOUT_SIDEARM_ORDER := ["pistol", "uzi", "magnum", "mp5"]

const LOADOUT_MELEE := {"none": 0, "katana": 10, "chainsaw": 16}
const LOADOUT_MELEE_ORDER := ["none", "katana", "chainsaw"]

## Cores awarded at the end of a run.
func cores_for_run(wave: int, kills: int) -> int:
	return int(floor(float(wave) * 1.6 + float(kills) / 18.0))


# ---------------------------------------------------------------- WAVE EVENTS
## Random modifiers that make waves feel different. Rolled from wave 3 on.
const EVENTS := [
	{"id": "none", "name": "", "weight": 42},
	{"id": "horde", "name": "HORDE RUSH", "desc": "Twice the bodies, weaker skulls", "weight": 12},
	{"id": "runners", "name": "RUNNER PACK", "desc": "Everything sprints", "weight": 12},
	{"id": "elites", "name": "ELITE SQUAD", "desc": "Armoured mutations everywhere", "weight": 10},
	{"id": "fog", "name": "TOXIC FOG", "desc": "Low visibility, spitters hunt you", "weight": 8},
	{"id": "night", "name": "BLACKOUT", "desc": "Lights out. Muzzle flash only", "weight": 8},
	{"id": "bounty", "name": "BOUNTY RUN", "desc": "Double cash from every kill", "weight": 8},
]

## Elite mutations rolled per zombie in later waves.
const ELITES := {
	"armored": {"name": "Armoured", "hp": 2.2, "speed": 0.85, "armor": 0.4, "cash": 2.0,
		"tint": Color(0.62, 0.72, 1.0)},
	"frenzied": {"name": "Frenzied", "hp": 1.2, "speed": 1.55, "armor": 0.0, "cash": 1.8,
		"tint": Color(1.0, 0.55, 0.45)},
	"toxic": {"name": "Toxic", "hp": 1.5, "speed": 1.0, "armor": 0.1, "cash": 2.0,
		"tint": Color(0.6, 1.0, 0.55)},
}
const ELITE_ORDER := ["armored", "frenzied", "toxic"]


func elite_chance(w: int) -> float:
	if w < 6:
		return 0.0
	return minf(0.05 + float(w - 6) * 0.015, 0.3)


# ---------------------------------------------------------------- AIRDROPS
const CRATE_LOOT := [
	{"id": "cash", "name": "CASH STASH", "weight": 26},
	{"id": "ammo", "name": "AMMO REFILL", "weight": 22},
	{"id": "heal", "name": "MEDKIT", "weight": 20},
	{"id": "nades", "name": "GRENADES", "weight": 16},
	{"id": "weapon", "name": "WEAPON CRATE", "weight": 12},
	{"id": "rage", "name": "ADRENALINE", "weight": 10},
]
