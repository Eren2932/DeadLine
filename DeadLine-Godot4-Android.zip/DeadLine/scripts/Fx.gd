extends Node2D
class_name Fx
## Pooled gore / particle / decal system. Lives inside the world node.

const PARTICLE_POOL := 28
const TEXT_POOL := 20
const EXPLO_POOL := 10
const RING_POOL := 6

var _particles: Array[CPUParticles2D] = []
var _p_next = 0
var _texts: Array[Label] = []
var _t_next = 0
var _explosions: Array[AnimatedSprite2D] = []
var _e_next = 0

var decals: Node2D
var _decal_list: Array[Node2D] = []

var _rings: Array[Sprite2D] = []
var _r_next = 0
var _casing_tex: Texture2D
var _acid_tex: Texture2D
var _splat_tex: Array = []
var _gib_tex: Array = []
var _blood_tex: Texture2D
var _smoke_tex: Texture2D
var _spark_tex: Texture2D
var _explo_frames: SpriteFrames


func _ready() -> void:
	z_index = 0
	decals = Node2D.new()
	decals.name = "Decals"
	decals.z_index = -5
	add_child(decals)

	_splat_tex = Art.fx_list("splats")
	_gib_tex = Art.fx_list("gibs")
	_blood_tex = Art.fx_tex("blood")
	_smoke_tex = Art.fx_tex("smoke")
	_spark_tex = Art.fx_tex("spark")
	_casing_tex = Art.fx_tex("casing")
	_acid_tex = Art.fx_tex("acid")

	for i in range(PARTICLE_POOL):
		var p = CPUParticles2D.new()
		p.emitting = false
		p.one_shot = true
		p.local_coords = false
		p.z_index = 4
		add_child(p)
		_particles.append(p)

	for i in range(TEXT_POOL):
		var l = Label.new()
		l.add_theme_font_size_override("font_size", 9)
		l.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.9))
		l.add_theme_constant_override("outline_size", 3)
		l.visible = false
		l.z_index = 20
		add_child(l)
		_texts.append(l)

	for i in range(RING_POOL):
		var r = Sprite2D.new()
		r.texture = _smoke_tex
		r.visible = false
		r.z_index = 16
		r.modulate = Color(1, 1, 1, 0.0)
		add_child(r)
		_rings.append(r)

	var frames = Art.fx_strip("explosion")
	_explo_frames = SpriteFrames.new()
	if not _explo_frames.has_animation("boom"):
		_explo_frames.add_animation("boom")
	_explo_frames.set_animation_speed("boom", 22.0)
	_explo_frames.set_animation_loop("boom", false)
	for t in frames:
		_explo_frames.add_frame("boom", t)
	if _explo_frames.has_animation("default"):
		_explo_frames.remove_animation("default")

	for i in range(EXPLO_POOL):
		var a = AnimatedSprite2D.new()
		a.sprite_frames = _explo_frames
		a.visible = false
		a.z_index = 18
		add_child(a)
		a.animation_finished.connect(_on_explosion_done.bind(a))
		_explosions.append(a)


func _next_particles() -> CPUParticles2D:
	var p: CPUParticles2D = _particles[_p_next]
	_p_next = (_p_next + 1) % _particles.size()
	return p


func blood(pos: Vector2, amount: int = 10, color: Color = Color(0.62, 0.07, 0.09),
		dir: Vector2 = Vector2.ZERO, power: float = 70.0) -> void:
	if not Settings.blood_on():
		return
	var p = _next_particles()
	p.texture = _blood_tex
	p.position = pos
	p.amount = maxi(2, int(round(float(amount) * Settings.particle_mul())))
	p.lifetime = 0.55
	p.explosiveness = 1.0
	p.direction = dir if dir.length() > 0.01 else Vector2(0, -1)
	p.spread = 55.0 if dir.length() > 0.01 else 180.0
	p.initial_velocity_min = power * 0.3
	p.initial_velocity_max = power
	p.gravity = Vector2(0, 260)
	p.damping_min = 20.0
	p.damping_max = 60.0
	p.scale_amount_min = 0.7
	p.scale_amount_max = 1.6
	p.color = color
	p.restart()
	p.emitting = true


func gore(pos: Vector2, color: Color = Color(0.62, 0.07, 0.09)) -> void:
	blood(pos, 24, color, Vector2.ZERO, 120.0)
	if _gib_tex.is_empty() or not Settings.blood_on():
		return
	var p = _next_particles()
	p.texture = _gib_tex[randi() % _gib_tex.size()]
	p.position = pos
	p.amount = 7
	p.lifetime = 0.9
	p.explosiveness = 1.0
	p.direction = Vector2(0, -1)
	p.spread = 180.0
	p.initial_velocity_min = 60.0
	p.initial_velocity_max = 170.0
	p.gravity = Vector2(0, 420)
	p.damping_min = 0.0
	p.damping_max = 10.0
	p.scale_amount_min = 1.0
	p.scale_amount_max = 1.0
	p.angular_velocity_min = -420.0
	p.angular_velocity_max = 420.0
	p.color = Color(1, 1, 1)
	p.restart()
	p.emitting = true
	splat(pos + Vector2(0, 2))


func sparks(pos: Vector2, dir: Vector2 = Vector2.ZERO) -> void:
	var p = _next_particles()
	p.texture = _spark_tex
	p.position = pos
	p.amount = 6
	p.lifetime = 0.25
	p.explosiveness = 1.0
	p.direction = dir if dir.length() > 0.01 else Vector2(0, -1)
	p.spread = 70.0
	p.initial_velocity_min = 40.0
	p.initial_velocity_max = 150.0
	p.gravity = Vector2(0, 300)
	p.scale_amount_min = 0.6
	p.scale_amount_max = 1.2
	p.color = Color(1, 0.9, 0.5)
	p.restart()
	p.emitting = true


func smoke(pos: Vector2, amount: int = 8, color: Color = Color(0.35, 0.33, 0.32, 0.8)) -> void:
	var p = _next_particles()
	p.texture = _smoke_tex
	p.position = pos
	p.amount = amount
	p.lifetime = 0.9
	p.explosiveness = 0.8
	p.direction = Vector2(0, -1)
	p.spread = 40.0
	p.initial_velocity_min = 10.0
	p.initial_velocity_max = 40.0
	p.gravity = Vector2(0, -20)
	p.scale_amount_min = 1.0
	p.scale_amount_max = 2.4
	p.color = color
	p.restart()
	p.emitting = true


func splat(pos: Vector2) -> void:
	if _splat_tex.is_empty() or not Settings.blood_on():
		return
	var s = Sprite2D.new()
	s.texture = _splat_tex[randi() % _splat_tex.size()]
	s.position = pos + Vector2(randf_range(-4, 4), randf_range(-1, 3))
	s.rotation = randf_range(-0.25, 0.25)
	s.scale = Vector2.ONE * randf_range(0.8, 1.7)
	s.modulate = Color(1, 1, 1, randf_range(0.65, 0.95))
	decals.add_child(s)
	_decal_list.append(s)
	while _decal_list.size() > Settings.max_decals():
		var old: Node2D = _decal_list.pop_front()
		if is_instance_valid(old):
			old.queue_free()


func explosion(pos: Vector2, scale: float = 1.0) -> void:
	var a: AnimatedSprite2D = _explosions[_e_next]
	_e_next = (_e_next + 1) % _explosions.size()
	a.position = pos
	a.scale = Vector2.ONE * scale
	a.visible = true
	a.frame = 0
	a.play("boom")
	smoke(pos, 10)


func _on_explosion_done(a: AnimatedSprite2D) -> void:
	a.visible = false
	a.stop()


func float_text(pos: Vector2, text: String, color: Color = Color(1, 1, 1)) -> void:
	var l: Label = _texts[_t_next]
	_t_next = (_t_next + 1) % _texts.size()
	l.text = text
	l.add_theme_color_override("font_color", color)
	l.position = pos + Vector2(-6, -10)
	l.modulate = Color(1, 1, 1, 1)
	l.scale = Vector2.ONE
	l.visible = true
	var tw = create_tween()
	tw.set_parallel(true)
	tw.tween_property(l, "position", l.position + Vector2(randf_range(-6, 6), -16), 0.7)
	tw.tween_property(l, "modulate:a", 0.0, 0.7).set_delay(0.15)
	tw.chain().tween_callback(func() -> void: l.visible = false)


func clear_decals() -> void:
	for d in _decal_list:
		if is_instance_valid(d):
			d.queue_free()
	_decal_list.clear()


# ------------------------------------------------------------------ extra effects
func casing(pos: Vector2, dir: Vector2) -> void:
	## Ejected shell, purely cosmetic. Skipped on low quality.
	if _casing_tex == null or Settings.quality() == 0:
		return
	var p = _next_particles()
	p.texture = _casing_tex
	p.position = pos
	p.amount = 1
	p.lifetime = 0.7
	p.explosiveness = 1.0
	p.direction = Vector2(-dir.x * 0.4, -1.0)
	p.spread = 25.0
	p.initial_velocity_min = 45.0
	p.initial_velocity_max = 90.0
	p.gravity = Vector2(0, 460)
	p.damping_min = 0.0
	p.damping_max = 4.0
	p.angular_velocity_min = -720.0
	p.angular_velocity_max = 720.0
	p.scale_amount_min = 1.0
	p.scale_amount_max = 1.0
	p.color = Color(1, 1, 1)
	p.restart()
	p.emitting = true


func impact(pos: Vector2, dir: Vector2 = Vector2.ZERO) -> void:
	## Dust puff + sparks when a bullet hits the ground or a wall.
	sparks(pos, dir)
	smoke(pos, 3, Color(0.42, 0.38, 0.34, 0.55))


func blood_mist(pos: Vector2, dir: Vector2, power: float = 90.0,
		color: Color = Color(0.62, 0.07, 0.09)) -> void:
	blood(pos, 6, color, dir, power)


func acid_pool(pos: Vector2) -> void:
	if _acid_tex == null:
		return
	var s = Sprite2D.new()
	s.texture = _acid_tex
	s.position = pos
	s.scale = Vector2.ONE * randf_range(1.6, 2.6)
	s.modulate = Color(0.65, 1.0, 0.45, 0.75)
	decals.add_child(s)
	_decal_list.append(s)
	var tw = create_tween()
	tw.tween_property(s, "modulate:a", 0.0, 6.0)
	while _decal_list.size() > maxi(6, Settings.max_decals()):
		var old: Node2D = _decal_list.pop_front()
		if is_instance_valid(old):
			old.queue_free()


func shockwave(pos: Vector2, radius: float = 60.0, color: Color = Color(1.0, 0.75, 0.4, 0.6)) -> void:
	## Expanding ring, drawn as a scaled smoke sprite (cheap, works on any GPU).
	if _rings.is_empty() or Settings.quality() == 0:
		return
	var r: Sprite2D = _rings[_r_next]
	_r_next = (_r_next + 1) % _rings.size()
	r.position = pos
	r.visible = true
	r.scale = Vector2.ONE * 0.6
	r.modulate = color
	var tw = create_tween()
	tw.set_parallel(true)
	tw.tween_property(r, "scale", Vector2.ONE * (radius / 6.0), 0.32)
	tw.tween_property(r, "modulate:a", 0.0, 0.32)
	tw.chain().tween_callback(func() -> void: r.visible = false)


func damage_number(pos: Vector2, amount: float, crit: bool = false) -> void:
	if not Settings.on("dmg_numbers"):
		return
	var txt = str(int(round(amount)))
	if crit:
		float_text(pos, txt + "!", Color(1.0, 0.86, 0.28))
	else:
		float_text(pos, txt, Color(1.0, 0.95, 0.92, 0.95))


func big_text(pos: Vector2, text: String, color: Color = Color(1, 0.85, 0.3)) -> void:
	var l: Label = _texts[_t_next]
	_t_next = (_t_next + 1) % _texts.size()
	l.text = text
	l.add_theme_color_override("font_color", color)
	l.add_theme_font_size_override("font_size", 14)
	l.position = pos + Vector2(-16, -22)
	l.modulate = Color(1, 1, 1, 1)
	l.scale = Vector2.ONE
	l.visible = true
	var tw = create_tween()
	tw.set_parallel(true)
	tw.tween_property(l, "position", l.position + Vector2(0, -22), 1.0)
	tw.tween_property(l, "modulate:a", 0.0, 1.0).set_delay(0.35)
	tw.chain().tween_callback(func() -> void:
		l.visible = false
		l.add_theme_font_size_override("font_size", 9))


func flame_puff(pos: Vector2) -> void:
	## Tiny fire tick used by the burning status.
	if Settings.quality() == 0:
		return
	var p = _next_particles()
	p.texture = Art.fx_tex("flame")
	p.position = pos
	p.amount = 2
	p.lifetime = 0.35
	p.explosiveness = 1.0
	p.direction = Vector2(0, -1)
	p.spread = 30.0
	p.initial_velocity_min = 20.0
	p.initial_velocity_max = 50.0
	p.gravity = Vector2(0, -40)
	p.damping_min = 0.0
	p.damping_max = 2.0
	p.scale_amount_min = 0.7
	p.scale_amount_max = 1.3
	p.angular_velocity_min = 0.0
	p.angular_velocity_max = 0.0
	p.color = Color(1.0, 0.75, 0.35, 0.9)
	p.restart()
	p.emitting = true


func gibs(pos: Vector2, amount: int = 7, color: Color = Color(0.62, 0.07, 0.09)) -> void:
	## Alias kept for readability at call sites; heavy gore burst.
	gore(pos, color)
	blood(pos, amount * 2, color, Vector2.UP, 140.0)
