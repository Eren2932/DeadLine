extends VBoxContainer
class_name SettingsPanel
## Reusable options screen: used by the main menu and by the in-game pause menu.

var _rows: Array = []


func _ready() -> void:
	add_theme_constant_override("separation", 3)
	_build()


func _build() -> void:
	_header("AUDIO")
	_slider_row("MASTER", "vol_master")
	_slider_row("MUSIC", "vol_music")
	_slider_row("SFX", "vol_sfx")
	_toggle_row("MUSIC ON", "music_on")
	_toggle_row("SOUND FX", "sfx_on")
	_header("GRAPHICS")
	_cycle_row("CAMERA", "zoom", Settings.ZOOM_NAMES)
	_cycle_row("BLOOD", "gore", Settings.GORE_NAMES)
	_cycle_row("SCREEN SHAKE", "shake", Settings.SHAKE_NAMES)
	_cycle_row("QUALITY", "quality", Settings.QUALITY_NAMES)
	_toggle_row("DAMAGE NUMBERS", "dmg_numbers")
	_toggle_row("SHOW FPS", "show_fps")
	_header("CONTROLS & GAME")
	_cycle_row("STICK SIDE", "joy_side", Settings.SIDE_NAMES)
	_toggle_row("AUTO FIRE", "autofire")
	_toggle_row("VIBRATION", "vibration")
	_cycle_row("DIFFICULTY", "difficulty", Settings.DIFF_NAMES)


func _header(text: String) -> void:
	add_child(UI.spacer(4))
	var l = UI.label(text, 9, UI.RED)
	add_child(l)


func _row(text: String) -> HBoxContainer:
	var h = HBoxContainer.new()
	h.add_theme_constant_override("separation", 4)
	var l = UI.label(text, 8, UI.DIM)
	l.custom_minimum_size = Vector2(104, 20)
	h.add_child(l)
	add_child(h)
	return h


func _slider_row(text: String, key: String) -> void:
	var h = _row(text)
	var s = UI.slider(Settings.num(key))
	s.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var val = UI.label("%d%%" % int(round(Settings.num(key) * 100.0)), 8, UI.BONE)
	val.custom_minimum_size = Vector2(34, 20)
	val.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	s.value_changed.connect(func(v: float) -> void:
		Settings.set_v(key, v)
		val.text = "%d%%" % int(round(v * 100.0)))
	h.add_child(s)
	h.add_child(val)


func _toggle_row(text: String, key: String) -> void:
	var h = _row(text)
	var b = UI.button("ON" if Settings.on(key) else "OFF", 9,
			UI.GREEN if Settings.on(key) else UI.RED_DARK, 20.0)
	b.custom_minimum_size = Vector2(58, 20)
	b.pressed.connect(func() -> void:
		Settings.toggle(key)
		var v = Settings.on(key)
		b.text = "ON" if v else "OFF"
		b.add_theme_stylebox_override("normal", UI.style(Color(0.16, 0.15, 0.17, 0.96),
				(UI.GREEN if v else UI.RED_DARK)))
		Audio.play("ui", -12.0, 1.0, 0.02))
	h.add_child(UI.hsep(4))
	h.add_child(b)
	h.add_child(UI.spacer(0))


func _cycle_row(text: String, key: String, names: Array) -> void:
	var h = _row(text)
	var left = UI.button("<", 9, UI.DIM, 20.0)
	left.custom_minimum_size = Vector2(20, 20)
	var val = UI.label(String(names[clampi(Settings.idx(key), 0, names.size() - 1)]), 8, UI.GOLD,
			HORIZONTAL_ALIGNMENT_CENTER)
	val.custom_minimum_size = Vector2(76, 20)
	var right = UI.button(">", 9, UI.DIM, 20.0)
	right.custom_minimum_size = Vector2(20, 20)
	var refresh = func() -> void:
		val.text = String(names[clampi(Settings.idx(key), 0, names.size() - 1)])
		Audio.play("ui", -12.0, 1.0, 0.02)
	left.pressed.connect(func() -> void:
		Settings.cycle(key, names.size(), -1)
		refresh.call())
	right.pressed.connect(func() -> void:
		Settings.cycle(key, names.size(), 1)
		refresh.call())
	h.add_child(left)
	h.add_child(val)
	h.add_child(right)
