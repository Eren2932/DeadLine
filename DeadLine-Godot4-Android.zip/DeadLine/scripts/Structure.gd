extends StaticBody2D
class_name Structure
## Player-built defenses: barricade, sandbags, spikes, mine, sentry turret, tesla coil.

var game = null
var kind = "wall"
var hp = 100.0
var max_hp = 100.0
var dmg = 0.0
var rate = 1.0
var range_px = 200.0
var dps = 0.0
var aoe = 0.0
var cd = 0.0
var tick = 0.0
var dead = false

var spr: Sprite2D
var gun: Sprite2D
var states: Array = []
var hp_fg: ColorRect


func setup(p_game, p_kind: String, hp_mul: float = 1.0) -> void:
	game = p_game
	kind = p_kind
	var d: Dictionary = GameData.BUILDINGS.get(kind, GameData.BUILDINGS["wall"])
	max_hp = float(d.get("hp", 100.0)) * hp_mul
	hp = max_hp
	dmg = float(d.get("dmg", 0.0))
	rate = float(d.get("rate", 1.0))
	range_px = float(d.get("range", 200.0))
	dps = float(d.get("dps", 0.0))
	aoe = float(d.get("aoe", 0.0))
	add_to_group("structures")

	spr = Sprite2D.new()
	add_child(spr)

	var solid = true
	match kind:
		"wall":
			states = Art.build_states("wall")
			spr.texture = states[0] if states.size() > 0 else null
			spr.offset = Vector2(0, -11)
		"sandbag":
			spr.texture = Art.build_tex("sandbag")
			spr.offset = Vector2(0, -7)
		"spikes":
			spr.texture = Art.build_tex("spikes")
			spr.offset = Vector2(0, -6)
			solid = false
		"mine":
			spr.texture = Art.build_tex("mine")
			spr.offset = Vector2(0, -3)
			solid = false
		"turret":
			spr.texture = Art.build_tex("turret", "base")
			spr.offset = Vector2(0, -6)
			gun = Sprite2D.new()
			gun.texture = Art.build_tex("turret", "gun")
			gun.position = Vector2(0, -9)
			gun.offset = Vector2(4, 0)
			gun.z_index = 1
			add_child(gun)
		"tesla":
			spr.texture = Art.build_tex("tesla")
			spr.offset = Vector2(0, -12)

	collision_layer = 4 if solid else 0
	collision_mask = 0
	if solid:
		var cs = CollisionShape2D.new()
		var rc = RectangleShape2D.new()
		rc.size = Vector2(16, 12) if kind != "tesla" else Vector2(10, 10)
		cs.shape = rc
		cs.position = Vector2(0, -5)
		add_child(cs)

	hp_fg = ColorRect.new()
	hp_fg.color = Color(0.35, 0.8, 0.35)
	hp_fg.size = Vector2(16, 1)
	hp_fg.position = Vector2(-8, -26)
	hp_fg.visible = false
	add_child(hp_fg)


func _physics_process(delta: float) -> void:
	if dead or game == null:
		return
	cd = maxf(0.0, cd - delta)
	tick += delta

	match kind:
		"turret":
			var t = game.nearest_zombie(global_position, range_px)
			if t != null:
				var dir: Vector2 = ((t.global_position + Vector2(0, -10)) - (global_position + Vector2(0, -9))).normalized()
				if gun != null:
					gun.rotation = dir.angle()
					gun.scale = Vector2(1, -1) if dir.x < 0.0 else Vector2(1, 1)
				if cd <= 0.0:
					cd = 1.0 / maxf(0.2, rate)
					game.spawn_bullet(global_position + Vector2(0, -9) + dir * 8.0, dir, {
						"kind": "bullet",
						"dmg": dmg * game.structure_power(),
						"speed": 700.0,
						"pierce": 0,
						"knock": 30.0,
						"life": range_px / 700.0 + 0.2,
						"from_player": true,
					})
					Audio.play("shot", -18.0, randf_range(1.1, 1.3), 0.05)
		"tesla":
			if cd <= 0.0:
				var t2 = game.nearest_zombie(global_position, range_px)
				if t2 != null:
					cd = 1.0 / maxf(0.2, rate)
					game.chain_lightning(global_position + Vector2(0, -20), 4,
							dmg * game.structure_power(), range_px, false)
					Audio.play("zap", -14.0, randf_range(0.9, 1.1), 0.06)
		"spikes":
			if tick >= 0.2:
				tick = 0.0
				var mul: float = 1.0
				if game.player != null:
					mul = 1.0 + 0.6 * float(game.player.lvl("spikedmg"))
				for z in game.get_zombies():
					if z.global_position.distance_to(global_position) < 14.0:
						z.take_hit(dps * 0.2 * mul, Vector2.ZERO, false,
								z.global_position + Vector2(0, -6))
						take_structure_damage(0.6)
		"mine":
			for z in game.get_zombies():
				if z.global_position.distance_to(global_position) < 13.0:
					game.explode(global_position + Vector2(0, -4), aoe, dmg, true, 1.2)
					_destroy(false)
					return


func repair(fraction: float) -> void:
	## Called between waves: the line patches itself up a bit.
	if dead:
		return
	hp = clampf(hp + max_hp * fraction, 0.0, max_hp)
	hp_fg.visible = hp < max_hp
	hp_fg.size.x = 16.0 * clampf(hp / max_hp, 0.0, 1.0)
	if kind == "wall" and states.size() >= 3:
		var f = hp / max_hp
		spr.texture = states[0] if f > 0.66 else (states[1] if f > 0.33 else states[2])


func take_structure_damage(amount: float) -> void:
	if dead:
		return
	hp -= amount
	hp_fg.visible = hp < max_hp
	hp_fg.size.x = 16.0 * clampf(hp / max_hp, 0.0, 1.0)
	if kind == "wall" and states.size() >= 3:
		var f = hp / max_hp
		spr.texture = states[0] if f > 0.66 else (states[1] if f > 0.33 else states[2])
	if amount > 1.0 and game != null:
		game.fx.sparks(global_position + Vector2(randf_range(-6, 6), -8))
	if hp <= 0.0:
		_destroy(true)


func _destroy(with_fx: bool) -> void:
	if dead:
		return
	dead = true
	if with_fx and game != null:
		game.fx.smoke(global_position + Vector2(0, -6), 8)
		game.fx.sparks(global_position + Vector2(0, -6))
	remove_from_group("structures")
	queue_free()
