extends CharacterBody2D
class_name Player
## The survivor: movement, dash, weapon handling (every weapon kind), grenades,
## upgrades and damage taking. Aim is auto-assisted toward the nearest threat.

const BASE_SPEED := 78.0
const DASH_TIME := 0.24
const DASH_SPEED := 355.0
const INVULN_ON_HIT := 0.55
const MAX_WEAPONS := 4

var game = null

# ---- input (written by TouchPad / keyboard)
var move_input = Vector2.ZERO
var fire_held = false

# ---- body
var suit = "player_soldier"
var max_hp = 120.0
var hp = 120.0
var hp_base = 120.0                # body baseline
var hp_suit = 0.0                  # bonus from the equipped suit
var base_armor = 0.0
var base_regen = 0.0
var speed_mul_suit = 1.0
var dead = false
var invuln = 0.0
var facing = 1.0
var aim_dir = Vector2.RIGHT

# ---- inventory
var weapons: Array = []
var slot = 0
var melee_id = "none"
var ammo: Dictionary = {}          # rounds in the magazine, per weapon id
var reserve: Dictionary = {}       # spare rounds carried, per weapon id (-1 = infinite)
var reloading = false
var reload_t = 0.0
var reload_total = 0.6
var shot_cd = 0.0
var melee_cd = 0.0
var grenades = 3
var rage_t = 0.0

# ---- dash
var dash_cd = 0.0
var dash_t = 0.0

# ---- progression
var upgrades: Dictionary = {}
var xp = 0
var level = 1
var xp_next = 36

var spr: AnimatedSprite2D
var arm: Node2D                    # hand pivot: the gun is a child of this
var gun_spr: Sprite2D
var muzzle: Sprite2D
var shadow: Sprite2D
var hand_local = Vector2(6, -20)
var hand_frames: Dictionary = {}   # anim name -> Array[Vector2] grip per frame
var char_feet = 36.0
var char_half_w = 13.0
var muzzle_len = 16.0
var recoil = 0.0                   # pixels the gun is pushed back right now
var swing_t = 0.0                  # 0..1 melee swing progress
var dry_warned = false


# ------------------------------------------------------------------ setup
func setup(p_game, loadout: Dictionary) -> void:
	game = p_game
	suit = String(loadout.get("suit", "player_soldier"))
	if not GameData.SUITS.has(suit):
		suit = "player_soldier"
	var s: Dictionary = GameData.SUITS[suit]
	hp_base = 120.0
	hp_suit = float(s.get("hp", 0.0))
	max_hp = hp_base + hp_suit
	hp = max_hp
	base_armor = float(s.get("armor", 0.0))
	base_regen = float(s.get("regen", 0.0))
	speed_mul_suit = float(s.get("speed", 1.0))

	melee_id = String(loadout.get("melee", "none"))
	weapons.clear()
	var primary = String(loadout.get("primary", "ak47"))
	var sidearm = String(loadout.get("sidearm", "pistol"))
	if GameData.WEAPONS.has(sidearm):
		weapons.append(sidearm)
	if GameData.WEAPONS.has(primary) and primary != sidearm:
		weapons.append(primary)
	if weapons.is_empty():
		weapons.append("pistol")
	if melee_id != "none" and GameData.WEAPONS.has(melee_id):
		weapons.append(melee_id)
	slot = weapons.size() - 1 if melee_id == "none" else maxi(0, weapons.size() - 2)
	for w in weapons:
		ammo[w] = int(GameData.WEAPONS[w].get("mag", 10))
		reserve[w] = max_reserve(String(w))

	collision_layer = 1
	collision_mask = 0        # never blocked by our own walls / the horde
	motion_mode = CharacterBody2D.MOTION_MODE_FLOATING

	var shape = CollisionShape2D.new()
	var cs = CircleShape2D.new()
	cs.radius = 6.0
	shape.shape = cs
	shape.position = Vector2(0, -8)
	add_child(shape)

	shadow = Sprite2D.new()
	shadow.texture = Art.fx_tex("smoke")
	shadow.modulate = Color(0, 0, 0, 0.30)
	shadow.scale = Vector2(0.9, 0.35)
	shadow.z_index = -1
	add_child(shadow)

	spr = AnimatedSprite2D.new()
	spr.sprite_frames = Art.char_frames(suit)
	spr.offset = Vector2(0, Art.char_feet_offset(suit))
	spr.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	spr.animation = "idle"
	spr.play()
	add_child(spr)

	var info: Dictionary = Art.char_info(suit)
	char_feet = float(info.get("feet", 36))
	char_half_w = float(info.get("w", 26)) * 0.5
	if char_half_w <= 1.0:
		char_half_w = 13.0
	var hand: Array = info.get("hand", [17.0, 20.0])
	hand_local = _to_local(Vector2(float(hand[0]), float(hand[1])))
	# The rig exports the grip point of EVERY frame, so the weapon now rides in
	# the hands through the whole walk cycle instead of floating at a fixed
	# offset near the shoulders.
	hand_frames = {}
	for anim_name in ["idle", "run", "attack"]:
		var pts: Array = Art.char_hands(suit, anim_name)
		var conv: Array = []
		for pt in pts:
			conv.append(_to_local(pt))
		if not conv.is_empty():
			hand_frames[anim_name] = conv

	# The arm is the hand pivot. It rotates to the aim angle and mirrors with
	# scale.y = -1 when facing left, so the gun is always held upright and the
	# barrel always points exactly where the bullets go.
	arm = Node2D.new()
	arm.z_index = 1
	add_child(arm)

	gun_spr = Sprite2D.new()
	gun_spr.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	arm.add_child(gun_spr)

	muzzle = Sprite2D.new()
	muzzle.texture = Art.fx_tex("muzzle")
	muzzle.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	muzzle.visible = false
	muzzle.z_index = 2
	arm.add_child(muzzle)

	z_index = 6
	_refresh_gun()
	grenades = 3 + lvl("grenades") * 2


# ------------------------------------------------------------------ helpers
func _to_local(image_pt: Vector2) -> Vector2:
	## Image pixel -> node space (feet on the origin, centred horizontally).
	return Vector2(image_pt.x - char_half_w, image_pt.y - char_feet)


func grip_offset() -> Vector2:
	## Grip point of the frame that is on screen right now.
	var key = String(spr.animation) if spr != null else "idle"
	if hand_frames.has(key):
		var arr: Array = hand_frames[key]
		if not arr.is_empty():
			var i = clampi(spr.frame, 0, arr.size() - 1)
			return arr[i]
	return hand_local


func max_hp_total() -> float:
	## Base body + suit + HP cards + everything earned by levelling. The
	## survivor has to grow with the horde, otherwise one brute swipe ends a
	## 60 wave run.
	return hp_base + hp_suit + 30.0 * float(lvl("hp")) + GameData.player_hp_bonus(level)


func refresh_max_hp(carry_gain: bool = true) -> void:
	var before = max_hp
	max_hp = maxf(1.0, max_hp_total())
	if carry_gain and max_hp > before:
		hp = clampf(hp + (max_hp - before), 0.0, max_hp)
	hp = clampf(hp, 0.0, max_hp)


func on_level_up() -> void:
	## Every level: bigger frame, and a real chunk of health back. This is the
	## "we get stronger too" side of the difficulty curve.
	refresh_max_hp(true)
	heal(max_hp * GameData.LEVEL_HEAL_FRACTION)
	grenades += 1
	if game != null and game.fx != null:
		game.fx.float_text(global_position + Vector2(0, -30),
				Loc.f("LEVEL %d", [level]), UI.GOLD)


func lvl(id: String) -> int:
	return int(upgrades.get(id, 0))


func add_upgrade(id: String) -> void:
	upgrades[id] = lvl(id) + 1
	match id:
		"hp":
			refresh_max_hp(true)
			heal(30.0)
		"grenades":
			grenades += 2
		"dog":
			game.spawn_ally("pet_dog")
		"tiger":
			game.spawn_ally("pet_tiger")
		_:
			pass


func weapon_id() -> String:
	if weapons.is_empty():
		return "pistol"
	return String(weapons[clampi(slot, 0, weapons.size() - 1)])


func weapon() -> Dictionary:
	return GameData.WEAPONS.get(weapon_id(), GameData.WEAPONS["pistol"])


func dmg_mul() -> float:
	## Level based power keeps every gun relevant deep into a run, upgrades and
	## adrenaline stack on top of it.
	return (1.0 + 0.18 * float(lvl("dmg"))) * GameData.player_power(level) \
			* (1.6 if rage_t > 0.0 else 1.0)


func weapon_ap() -> float:
	## How much of the target armour this shot ignores. AP Rounds add to it.
	return clampf(float(weapon().get("ap", 0.0)) + 0.08 * float(lvl("pierce")), 0.0, 0.95)


func rate_mul() -> float:
	return (1.0 + 0.12 * float(lvl("rate"))) * (1.35 if rage_t > 0.0 else 1.0)


func mag_size(id: String) -> int:
	var base = int(GameData.WEAPONS.get(id, {}).get("mag", 10))
	if base <= 0:
		return 0
	return int(round(float(base) * (1.0 + 0.3 * float(lvl("mag")))))


func crit_chance() -> float:
	return 0.05 + 0.08 * float(lvl("crit"))


func crit_mul() -> float:
	return 2.0 + 0.5 * float(lvl("critdmg"))


func armor() -> float:
	return clampf(base_armor + 0.07 * float(lvl("armor")), 0.0, 0.70)


func armor_flat() -> float:
	## Flat plating: shaves a chunk off every single hit, which is what makes a
	## swarm of weak walkers survivable late on.
	return 2.0 * float(lvl("armor")) + GameData.player_armor_flat(level)


func move_speed() -> float:
	return BASE_SPEED * speed_mul_suit * (1.0 + 0.08 * float(lvl("speed")))


func dash_cooldown() -> float:
	return maxf(0.55, 1.5 * (1.0 - 0.20 * float(lvl("dash"))))


func dash_duration() -> float:
	return DASH_TIME + 0.02 * float(lvl("dash"))


func reload_progress() -> float:
	if not reloading or reload_total <= 0.0:
		return 0.0
	return clampf(1.0 - reload_t / reload_total, 0.0, 1.0)


func ammo_in_mag() -> int:
	return int(ammo.get(weapon_id(), 0))


func is_melee() -> bool:
	return String(weapon().get("kind", "bullet")) == "melee"


# ------------------------------------------------------------------ inventory
func add_weapon(id: String) -> bool:
	if not GameData.WEAPONS.has(id):
		return false
	if weapons.has(id):
		# already owned: the pickup simply tops the gun up
		ammo[id] = mag_size(id)
		reserve[id] = max_reserve(id)
		return true
	if weapons.size() >= MAX_WEAPONS:
		# replace the currently selected non-melee gun
		var target = slot
		if String(GameData.WEAPONS[String(weapons[target])].get("kind", "")) == "melee":
			target = 0
		weapons[target] = id
	else:
		weapons.append(id)
		slot = weapons.size() - 1
	ammo[id] = mag_size(id)
	reserve[id] = max_reserve(id)
	reloading = false
	dry_warned = false
	_refresh_gun()
	return true


func drop_weapon(id: String) -> bool:
	## Sell / drop a gun. The last shooting weapon can never be dropped.
	if not weapons.has(id):
		return false
	var guns = 0
	for w in weapons:
		if String(GameData.WEAPONS[String(w)].get("kind", "")) != "melee":
			guns += 1
	if String(GameData.WEAPONS[id].get("kind", "")) != "melee" and guns <= 1:
		return false
	weapons.erase(id)
	ammo.erase(id)
	reserve.erase(id)
	slot = clampi(slot, 0, maxi(0, weapons.size() - 1))
	reloading = false
	_refresh_gun()
	return true


func owns(id: String) -> bool:
	return weapons.has(id)


func max_reserve(id: String) -> int:
	var base = int(GameData.WEAPONS.get(id, {}).get("reserve", 0))
	if base < 0:
		return -1
	return int(round(float(base) * (1.0 + 0.25 * float(lvl("mag")))))


func reserve_ammo(id: String) -> int:
	if max_reserve(id) < 0:
		return -1
	return int(reserve.get(id, 0))


func add_reserve(id: String, amount: int) -> void:
	if max_reserve(id) < 0:
		return
	reserve[id] = clampi(int(reserve.get(id, 0)) + amount, 0, max_reserve(id))


func fill_reserve(id: String) -> void:
	if max_reserve(id) < 0:
		return
	reserve[id] = max_reserve(id)
	ammo[id] = mag_size(id)


func total_ammo(id: String) -> int:
	## Rounds in the mag plus spare rounds (-1 when the gun never runs dry).
	if max_reserve(id) < 0:
		return -1
	return int(ammo.get(id, 0)) + int(reserve.get(id, 0))


func is_dry(id: String) -> bool:
	if String(GameData.WEAPONS.get(id, {}).get("kind", "bullet")) == "melee":
		return false
	return total_ammo(id) == 0


func auto_swap_if_dry() -> void:
	## When the current gun is empty and no spare rounds are left, switch to
	## something that can still shoot instead of clicking on an empty chamber.
	if not is_dry(weapon_id()):
		return
	for i in range(weapons.size()):
		var idx = posmod(slot + 1 + i, weapons.size())
		var id = String(weapons[idx])
		if not is_dry(id):
			select_slot(idx)
			if not dry_warned:
				dry_warned = true
				game.hud.flash_banner(Loc.t("OUT OF AMMO - SWAPPING"), UI.RED)
			return


func select_slot(i: int) -> void:
	if weapons.is_empty():
		return
	slot = clampi(i, 0, weapons.size() - 1)
	reloading = false
	_refresh_gun()
	Audio.play("click", -14.0)


func next_weapon() -> void:
	if weapons.is_empty():
		return
	select_slot(posmod(slot + 1, weapons.size()))


func refill_ammo() -> void:
	for w in weapons:
		ammo[w] = mag_size(String(w))
		fill_reserve(String(w))
	reloading = false
	dry_warned = false


func add_grenades(n: int) -> void:
	grenades += n


func add_ammo_fraction(f: float) -> void:
	## Ammo pickup: tops every carried gun up by a share of its full reserve.
	for w in weapons:
		var id = String(w)
		var full = max_reserve(id)
		if full <= 0:
			continue
		add_reserve(id, maxi(1, int(round(float(full) * f))))
	dry_warned = false


func give_rage(seconds: float) -> void:
	rage_t = maxf(rage_t, seconds)
	game.fx.big_text(global_position + Vector2(0, -26), Loc.t("ADRENALINE"), UI.RED)


func heal(amount: float) -> void:
	hp = clampf(hp + amount, 0.0, max_hp)


func _refresh_gun() -> void:
	var id = weapon_id()
	gun_spr.texture = Art.weapon_tex(id)
	var info = Art.weapon_info(id)
	var grip: Array = info.get("grip", [3.0, 4.0])
	var mz: Array = info.get("muzzle", [float(info.get("w", 20)), float(grip[1])])
	gun_spr.offset = Vector2(-float(grip[0]), -float(grip[1]))
	gun_spr.position = Vector2.ZERO
	muzzle_len = maxf(6.0, float(mz[0]) - float(grip[0]))
	muzzle.position = Vector2(muzzle_len, float(mz[1]) - float(grip[1]))


# ------------------------------------------------------------------ loop
func _physics_process(delta: float) -> void:
	if game == null:
		return
	if dead:
		return

	invuln = maxf(0.0, invuln - delta)
	shot_cd = maxf(0.0, shot_cd - delta)
	melee_cd = maxf(0.0, melee_cd - delta)
	dash_cd = maxf(0.0, dash_cd - delta)
	rage_t = maxf(0.0, rage_t - delta)

	var regen = base_regen + float(lvl("regen"))
	if regen > 0.0 and hp < max_hp:
		heal(regen * delta)

	# ---- reload
	if reloading:
		reload_t -= delta
		if reload_t <= 0.0:
			reloading = false
			_finish_reload()

	# ---- movement
	var mv = move_input.limit_length(1.0)
	if dash_t > 0.0:
		dash_t -= delta
		var dash_dir = mv if mv.length() > 0.2 else aim_dir
		velocity = dash_dir.normalized() * DASH_SPEED
		if lvl("dashkill") > 0:
			for z in game.zombies_near(global_position, 18.0):
				if not z.dead:
					z.take_hit(70.0 * float(lvl("dashkill")) * GameData.player_power(level),
							velocity.normalized() * 140.0, false, z.hit_center(), 0.4)
	else:
		velocity = mv * move_speed()
	move_and_slide()
	global_position.y = clampf(global_position.y, GameData.BAND_TOP, GameData.BAND_BOT)
	global_position.x = clampf(global_position.x, GameData.play_left(), GameData.play_right())

	# ---- aim: never lock on to something the player cannot see on screen
	var reach = minf(float(weapon().get("range", 300.0)), game.visible_half_w() + 10.0)
	var target = game.best_target(global_position + Vector2(0, -10), reach)
	if target != null:
		aim_dir = (target.hit_center() - muzzle_pos()).normalized()
	elif mv.length() > 0.15:
		aim_dir = Vector2(signf(mv.x) if absf(mv.x) > 0.05 else facing, 0.0).normalized()
	if absf(aim_dir.x) > 0.05:
		facing = signf(aim_dir.x)
	spr.flip_h = facing < 0.0

	# ---- animation
	# The cycle is driven by how fast the body ACTUALLY moves, so the feet stop
	# sliding: slow walk = slow steps, sprint = fast steps.
	var want_anim = "idle"
	if swing_t > 0.0 and is_melee() and spr.sprite_frames.has_animation("attack"):
		want_anim = "attack"
	elif mv.length() > 0.12 or dash_t > 0.0:
		want_anim = "run"
	if spr.animation != want_anim:
		spr.animation = want_anim
		spr.frame = 0
		spr.play()
	if want_anim == "run":
		var ref_speed = maxf(60.0, BASE_SPEED)
		spr.speed_scale = clampf(velocity.length() / ref_speed, 0.45, 2.4)
	else:
		spr.speed_scale = 1.0

	# ---- arm / weapon transform
	recoil = maxf(0.0, recoil - delta * 26.0)
	swing_t = maxf(0.0, swing_t - delta * 7.0)
	var grip = grip_offset()
	var hand = Vector2(grip.x * facing, grip.y)
	arm.scale = Vector2(1.0, -1.0 if facing < 0.0 else 1.0)
	if is_melee():
		# swing arc: 1 -> 0 sweeps the blade from over the shoulder to the ground
		var ang = lerpf(-1.05, 0.75, 1.0 - swing_t) if swing_t > 0.0 else -0.35
		arm.rotation = (0.0 if facing > 0.0 else PI) + ang * facing
		arm.position = hand
	else:
		arm.rotation = aim_dir.angle()
		arm.position = hand - aim_dir * recoil
	gun_spr.visible = gun_spr.texture != null

	# ---- shooting
	var want_fire: bool = fire_held or (Settings.on("autofire") and target != null)
	if want_fire and not game.is_over() and not game.in_prep():
		fire()
	elif want_fire and game.in_prep() and target != null:
		fire()


func muzzle_pos() -> Vector2:
	var g = grip_offset()
	return global_position + Vector2(g.x * facing, g.y) + aim_dir * muzzle_len


# ------------------------------------------------------------------ shooting
func fire() -> void:
	if dead or reloading or shot_cd > 0.0:
		return
	var id = weapon_id()
	var w = weapon()
	var kind = String(w.get("kind", "bullet"))

	if kind == "melee":
		_melee_swing(w)
		return

	if ammo_in_mag() <= 0:
		start_reload()
		auto_swap_if_dry()
		return

	shot_cd = 1.0 / maxf(0.05, float(w.get("rate", 3.0)) * rate_mul())
	ammo[id] = ammo_in_mag() - 1

	var count = int(w.get("count", 1)) + lvl("multishot")
	var spread = float(w.get("spread", 3.0))
	var dmg = float(w.get("dmg", 10.0)) * dmg_mul()
	var knock = float(w.get("knock", 30.0)) * (1.0 + 0.5 * float(lvl("knock")))
	var pierce = int(w.get("pierce", 0)) + lvl("pierce")
	var from = muzzle_pos()

	match kind:
		"laser":
			for i in range(count):
				var d = aim_dir.rotated(deg_to_rad(randf_range(-spread, spread)))
				game.hitscan(from, d, float(w.get("range", 500.0)), dmg, pierce + 2, knock,
						crit_chance(), crit_mul(), Color(0.6, 0.9, 1.0) if id != "gauss"
						else Color(0.75, 0.6, 1.0), weapon_ap())
		"tesla":
			game.chain_lightning(from, 4 + lvl("multishot"), dmg, 150.0, true, weapon_ap())
		"flame":
			for i in range(count + 2):
				var d = aim_dir.rotated(deg_to_rad(randf_range(-spread, spread)))
				game.spawn_bullet(from, d, _cfg(w, dmg * 0.34, knock * 0.1, 0, {
					"kind": "flame", "tex": "flame", "speed": 210.0, "life": 0.42,
					"burn": 2.2 + 0.6 * float(lvl("burn")), "scale": 1.2,
					"color": Color(1.0, 0.8, 0.4),
				}))
		"rocket":
			for i in range(count):
				var d = aim_dir.rotated(deg_to_rad(randf_range(-spread, spread)))
				game.spawn_bullet(from, d, _cfg(w, dmg, knock, 0, {
					"kind": "rocket", "tex": "rocket", "speed": float(w.get("speed", 320.0)),
					"life": 2.0, "aoe": maxf(48.0, float(w.get("aoe", 60.0))),
					"homing": 0.25 if lvl("magnet") > 0 else 0.0,
				}))
		"grenade":
			for i in range(count):
				var d = aim_dir.rotated(deg_to_rad(randf_range(-spread, spread)))
				game.spawn_bullet(from, d, _cfg(w, dmg, knock, 0, {
					"kind": "grenade", "tex": "bullet_big", "speed": float(w.get("speed", 300.0)),
					"life": 1.1, "aoe": maxf(46.0, float(w.get("aoe", 56.0))), "spin": 10.0,
				}))
		"pellet":
			for i in range(count):
				var d = aim_dir.rotated(deg_to_rad(randf_range(-spread, spread)))
				game.spawn_bullet(from, d, _cfg(w, dmg, knock, pierce, {
					"kind": "pellet", "tex": "bullet", "speed": float(w.get("speed", 520.0)),
					"life": float(w.get("range", 180.0)) / maxf(1.0, float(w.get("speed", 520.0))) + 0.05,
				}))
		_:
			for i in range(count):
				var d = aim_dir.rotated(deg_to_rad(randf_range(-spread, spread)))
				var big = dmg > 40.0
				game.spawn_bullet(from, d, _cfg(w, dmg, knock, pierce, {
					"kind": "bullet", "tex": "bullet_big" if big else "bullet",
					"speed": float(w.get("speed", 620.0)),
					"life": float(w.get("range", 340.0)) / maxf(1.0, float(w.get("speed", 620.0))) + 0.06,
					"scale": 1.0,
				}))

	# ---- feedback
	_muzzle_flash(kind)
	game.shake(float(w.get("shake", 1.0)) * 0.9)
	if kind != "flame" or randf() < 0.25:
		Audio.play(_shot_sound(id, kind), -8.0, randf_range(0.94, 1.08), 0.02)
	if kind in ["bullet", "pellet"]:
		game.fx.casing(muzzle_pos() + Vector2(-2 * facing, -1), aim_dir)
	recoil = minf(recoil + float(w.get("shake", 1.0)) * 1.1 + 1.0, 4.0)
	if ammo_in_mag() <= 0:
		start_reload()
		auto_swap_if_dry()


func _cfg(w: Dictionary, dmg: float, knock: float, pierce: int, extra: Dictionary) -> Dictionary:
	var cfg = {
		"dmg": dmg,
		"knock": knock,
		"pierce": pierce,
		"from_player": true,
		"crit": crit_chance(),
		"crit_mul": crit_mul(),
		"explosive": 0.12 * float(lvl("explosive")),
		"burn": 1.8 * float(lvl("burn")),
		"slow": 1.2 if lvl("slow") > 0 else 0.0,
		"ap": weapon_ap(),
	}
	for k in extra.keys():
		cfg[k] = extra[k]
	return cfg


func _shot_sound(id: String, kind: String) -> String:
	match kind:
		"pellet":
			return "shotgun"
		"laser":
			return "laser"
		"tesla":
			return "zap"
		"flame":
			return "flame"
		"rocket", "grenade":
			return "shot_big"
		_:
			if id == "minigun" or id == "uzi" or id == "lmg":
				return "shot"
			return "shot_big" if float(GameData.WEAPONS[id].get("dmg", 10)) > 35.0 else "shot"


func _muzzle_flash(kind: String) -> void:
	if kind == "melee":
		return
	muzzle.visible = true
	muzzle.rotation = 0.0
	muzzle.scale = Vector2.ONE * randf_range(0.8, 1.25)
	muzzle.modulate = Color(1.0, 0.9, 0.6) if kind != "laser" else Color(0.7, 0.9, 1.0)
	var tw = create_tween()
	tw.tween_interval(0.05)
	tw.tween_callback(func() -> void: muzzle.visible = false)


func _melee_swing(w: Dictionary) -> void:
	if melee_cd > 0.0:
		return
	melee_cd = 1.0 / maxf(0.2, float(w.get("rate", 2.0)) * rate_mul())
	var reach = float(w.get("range", 26.0))
	var dmg = float(w.get("dmg", 30.0)) * dmg_mul()
	Audio.play("saw" if weapon_id() == "chainsaw" else "whoosh", -10.0, randf_range(0.95, 1.1), 0.02)
	var center = global_position + Vector2(0, -10)
	var hit = false
	for z in game.zombies_near(center + Vector2(facing * reach * 0.5, 0), reach + 14.0):
		if z.dead:
			continue
		var to: Vector2 = z.hit_center() - center
		if to.length() > reach + z.radius:
			continue
		if signf(to.x) != facing and absf(to.x) > 4.0:
			continue
		z.take_hit(dmg, Vector2(facing, -0.25) * float(w.get("knock", 120.0)),
				randf() < crit_chance() + 0.15, z.hit_center(), weapon_ap())
		if lvl("burn") > 0:
			z.ignite(1.5 * float(lvl("burn")))
		hit = true
	swing_t = 1.0
	if hit:
		game.shake(1.2)
		game.hitstop(0.045)
	var sweep = create_tween()
	sweep.tween_property(spr, "rotation_degrees", 6.0 * facing, 0.05)
	sweep.tween_property(spr, "rotation_degrees", 0.0, 0.1)


func start_reload() -> void:
	if reloading or dead:
		return
	var id = weapon_id()
	if is_melee():
		return
	if ammo_in_mag() >= mag_size(id):
		return
	if reserve_ammo(id) == 0:
		auto_swap_if_dry()
		return
	reloading = true
	reload_total = float(weapon().get("reload", 1.2)) * (1.0 - 0.15 * float(lvl("reload")))
	reload_total = maxf(0.18, reload_total)
	reload_t = reload_total
	Audio.play("reload", -10.0, randf_range(0.95, 1.05))


# ------------------------------------------------------------------ reloading
func _finish_reload() -> void:
	var id = weapon_id()
	var want = mag_size(id) - int(ammo.get(id, 0))
	if want <= 0:
		return
	if max_reserve(id) < 0:
		ammo[id] = mag_size(id)
		return
	var got = mini(want, int(reserve.get(id, 0)))
	ammo[id] = int(ammo.get(id, 0)) + got
	reserve[id] = int(reserve.get(id, 0)) - got


# ------------------------------------------------------------------ abilities
func dash() -> void:
	if dead or dash_cd > 0.0 or dash_t > 0.0:
		return
	dash_cd = dash_cooldown()
	dash_t = dash_duration()
	invuln = maxf(invuln, dash_t + 0.18)
	Audio.play("dash", -10.0, randf_range(0.95, 1.1))
	game.fx.smoke(global_position + Vector2(0, -4), 5, Color(0.5, 0.47, 0.42, 0.6))


func throw_grenade() -> void:
	if dead or grenades <= 0:
		return
	grenades -= 1
	var from = muzzle_pos()
	var boost = 1.0 + 0.35 * float(lvl("nadedmg"))
	var blast = 78.0 * (1.0 + 0.18 * float(lvl("nadedmg")))
	var dmg = (140.0 + 18.0 * float(level)) * dmg_mul() * boost
	# Aim at the fattest cluster in range instead of lobbing it at the nearest
	# scrub: the fuse is timed so the grenade lands right on that spot.
	var dir = aim_dir
	var travel = 1.15
	var spot: Vector2 = game.best_cluster(from, 260.0, blast)
	if spot != Vector2.ZERO:
		var to: Vector2 = spot - from
		dir = to.normalized()
		travel = clampf(to.length() / 300.0, 0.14, 1.4)
	game.spawn_bullet(from, dir, {
		"kind": "grenade", "tex": "bullet_big", "dmg": dmg, "speed": 300.0,
		"life": travel, "aoe": blast, "from_player": true, "knock": 190.0, "spin": 12.0,
		"ap": 0.5, "crit": crit_chance(), "crit_mul": crit_mul(),
		"color": Color(0.7, 0.9, 0.6),
	})
	Audio.play("shot", -14.0, 0.7)


# ------------------------------------------------------------------ damage
func take_damage(amount: float, from_pos: Vector2 = Vector2.ZERO) -> void:
	if dead or invuln > 0.0:
		return
	var final = maxf(amount * (1.0 - armor()) - armor_flat(), amount * 0.15)
	hp -= final
	invuln = INVULN_ON_HIT
	game.fx.blood(global_position + Vector2(0, -12), 6, Color(0.7, 0.1, 0.1),
			(global_position - from_pos).normalized(), 80.0)
	# thrown away from whatever just hit us, so a hit from the left is felt as a
	# hit from the left
	if from_pos != Vector2.ZERO:
		game.kick(from_pos.direction_to(global_position), 2.4)
	else:
		game.shake(2.2)
	game.hud.hurt_pulse()
	game.haptic(45 if final < max_hp * 0.12 else 95)
	Audio.play("hurt", -6.0, randf_range(0.95, 1.05))
	if hp <= 0.0:
		_die()


func on_kill(z) -> void:
	if lvl("lifesteal") > 0:
		heal(float(lvl("lifesteal")))


func _die() -> void:
	dead = true
	hp = 0.0
	fire_held = false
	if spr.sprite_frames.has_animation("death"):
		spr.animation = "death"
		spr.frame = 0
		spr.play()
	arm.visible = false
	game.fx.gore(global_position + Vector2(0, -12), Color(0.7, 0.1, 0.1))
	game.on_player_died()
