extends StaticBody2D
class_name Structure
## Player-built defenses: barricade, sandbags, spikes, mine, sentry turret,
## tesla coil.
##
## v2.0: every structure has a limited lifetime measured in waves, real prices,
## much weaker turrets, damage-type resistances and an aggro point the horde can
## actually attack. Mines are indestructible but consumed on trigger.

var game = null
var kind = "wall"
var hp = 100.0
var max_hp = 100.0
var dmg = 0.0
var rate = 1.0
var range_px = 130.0
var dps = 0.0
var aoe = 0.0
var knock = 6.0
var chain = 3
var solid = true
var cd = 0.0
var tick = 0.0
var dead = false
var invincible = false

var waves_left = 4
var max_waves = 4

var spr: Sprite2D
var gun: Sprite2D
var states: Array = []
var hp_fg: ColorRect
var hp_bg: ColorRect
var life_lbl: Label


func setup(p_game, p_kind: String, hp_mul: float = 1.0, extra_waves: int = 0) -> void:
	game = p_game
	kind = p_kind
	var d: Dictionary = GameData.building(kind)
	var base_hp = float(d.get("hp", 100.0))
	invincible = base_hp < 0.0
	max_hp = maxf(1.0, base_hp) * hp_mul
	hp = max_hp
	dmg = float(d.get("dmg", 0.0))
	rate = float(d.get("rate", 1.0))
	range_px = float(d.get("range", 130.0))
	dps = float(d.get("dps", 0.0))
	aoe = float(d.get("aoe", 0.0))
	knock = float(d.get("knock", 6.0))
	chain = int(d.get("chain", 3))
	solid = bool(d.get("solid", false))
	max_waves = int(d.get("life", 4)) + maxi(0, extra_waves)
	waves_left = max_waves
	add_to_group("structures")

	spr = Sprite2D.new()
	spr.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	add_child(spr)

	match kind:
		"wall":
			states = Art.build_states("wall")
			spr.texture = states[0] if states.size() > 0 else null
			spr.offset = Vector2(0, -11)
		"sandbag":
			spr.texture = Art.build_tex("sandbag")
			spr.offset = Vector2(0, -7)
		"spikes":
			spr.texture = Art.build_tex("spikes")
			spr.offset = Vector2(0, -6)
		"mine":
			spr.texture = Art.build_tex("mine")
			spr.offset = Vector2(0, -3)
		"turret":
			spr.texture = Art.build_tex("turret", "base")
			spr.offset = Vector2(0, -6)
			gun = Sprite2D.new()
			gun.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
			gun.texture = Art.build_tex("turret", "gun")
			gun.position = Vector2(0, -9)
			gun.offset = Vector2(4, 0)
			gun.z_index = 1
			add_child(gun)
		"tesla":
			spr.texture = Art.build_tex("tesla")
			spr.offset = Vector2(0, -12)

	collision_layer = 4 if solid else 0
	collision_mask = 0
	if solid:
		var cs = CollisionShape2D.new()
		var rc = RectangleShape2D.new()
		rc.size = Vector2(16, 12)
		cs.shape = rc
		cs.position = Vector2(0, -5)
		add_child(cs)

	hp_bg = ColorRect.new()
	hp_bg.color = Color(0.08, 0.07, 0.08, 0.85)
	hp_bg.size = Vector2(18, 3)
	hp_bg.position = Vector2(-9, -27)
	hp_bg.visible = false
	add_child(hp_bg)

	hp_fg = ColorRect.new()
	hp_fg.color = Color(0.35, 0.8, 0.35)
	hp_fg.size = Vector2(16, 1)
	hp_fg.position = Vector2(-8, -26)
	hp_fg.visible = false
	add_child(hp_fg)

	life_lbl = Label.new()
	life_lbl.add_theme_font_size_override("font_size", 7)
	life_lbl.add_theme_color_override("font_color", Color(1.0, 0.83, 0.31, 0.9))
	life_lbl.position = Vector2(-9, -40)
	life_lbl.text = "%d" % waves_left
	add_child(life_lbl)
	_refresh_bar()


# ------------------------------------------------------------------ helpers
func hp_frac() -> float:
	if invincible:
		return 1.0
	return clampf(hp / maxf(1.0, max_hp), 0.0, 1.0)


func aggro_point() -> Vector2:
	## Where a zombie should stand to chew on this thing.
	return global_position + Vector2(0, -6)


func is_target_for_horde() -> bool:
	## Mines are not worth attacking, everything else is.
	return not dead and kind != "mine"


func _refresh_bar() -> void:
	if hp_fg == null:
		return
	var f = hp_frac()
	var show: bool = (not invincible) and f < 0.999
	hp_fg.visible = show
	hp_bg.visible = show
	hp_fg.size.x = 16.0 * f
	hp_fg.color = Color(0.35, 0.8, 0.35) if f > 0.5 else (
			Color(0.95, 0.75, 0.25) if f > 0.25 else Color(0.85, 0.25, 0.22))
	if life_lbl != null:
		life_lbl.text = Loc.f("%dw", [maxi(0, waves_left)])
		# green = plenty, gold = one spare wave, red = dies after this one
		if waves_left >= 3:
			life_lbl.modulate = Color(0.55, 1.0, 0.6, 1.0)
		elif waves_left == 2:
			life_lbl.modulate = Color(1.0, 0.85, 0.35, 1.0)
		else:
			life_lbl.modulate = Color(1.0, 0.38, 0.32, 1.0)
	if kind == "wall" and states.size() >= 3:
		spr.texture = states[0] if f > 0.66 else (states[1] if f > 0.33 else states[2])
	if waves_left <= 1:
		spr.modulate = Color(1.0, 0.78, 0.72, 1.0)


# ------------------------------------------------------------------ wave hook
func on_wave_end(repair_fraction: float) -> void:
	## Called by the game once a wave is cleared: patch up a bit, then age.
	if dead:
		return
	if not invincible:
		hp = clampf(hp + max_hp * repair_fraction, 0.0, max_hp)
	waves_left -= 1
	if waves_left <= 0:
		if game != null:
			game.fx.smoke(global_position + Vector2(0, -6), 6)
		_destroy(false)
		return
	_refresh_bar()


# ------------------------------------------------------------------ loop
func _physics_process(delta: float) -> void:
	if dead or game == null:
		return
	cd = maxf(0.0, cd - delta)
	tick += delta

	match kind:
		"turret":
			_tick_turret()
		"tesla":
			_tick_tesla()
		"spikes":
			_tick_spikes()
		"mine":
			_tick_mine()


func _tick_turret() -> void:
	var t = game.best_target(global_position + Vector2(0, -9), range_px)
	if t == null:
		return
	var dir: Vector2 = (t.hit_center() - (global_position + Vector2(0, -9))).normalized()
	if gun != null:
		gun.rotation = dir.angle()
		gun.scale = Vector2(1, -1) if dir.x < 0.0 else Vector2(1, 1)
	if cd > 0.0:
		return
	cd = 1.0 / maxf(0.2, rate * game.structure_rate())
	game.spawn_bullet(global_position + Vector2(0, -9) + dir * 8.0, dir, {
		"kind": "bullet",
		"dmg": dmg * game.structure_power(),
		"speed": 620.0,
		"pierce": 0,
		"knock": knock,
		"ap": 0.15,
		"life": range_px / 620.0 + 0.12,
		"from_player": true,
	})
	Audio.play("shot", -20.0, randf_range(1.1, 1.3), 0.05)


func _tick_tesla() -> void:
	if cd > 0.0:
		return
	var t2 = game.best_target(global_position + Vector2(0, -14), range_px)
	if t2 == null:
		return
	cd = 1.0 / maxf(0.2, rate * game.structure_rate())
	game.chain_lightning(global_position + Vector2(0, -18), chain,
			dmg * game.structure_power(), range_px, false)
	Audio.play("zap", -15.0, randf_range(0.9, 1.1), 0.06)


func _tick_spikes() -> void:
	if tick < 0.2:
		return
	tick = 0.0
	var mul: float = 1.0
	if game.player != null and is_instance_valid(game.player):
		mul = 1.0 + 0.6 * float(game.player.lvl("spikedmg"))
	for z in game.zombies_near(global_position, 18.0):
		if z.dead:
			continue
		if z.global_position.distance_to(global_position) < 14.0:
			z.take_hit(dps * 0.2 * mul, Vector2.ZERO, false,
					z.global_position + Vector2(0, -6), 0.35)
			take_structure_damage(0.4, "melee")


func _tick_mine() -> void:
	for z in game.zombies_near(global_position, 16.0):
		if z.dead:
			continue
		if z.global_position.distance_to(global_position) < 13.0:
			game.explode(global_position + Vector2(0, -4), aoe,
					dmg * game.structure_power(), true, 1.2)
			_destroy(false)
			return


# ------------------------------------------------------------------ damage
func take_structure_damage(amount: float, dmg_type: String = "hit") -> void:
	if dead or invincible:
		return
	var reduced = amount * (1.0 - GameData.structure_resist(kind, dmg_type))
	if reduced <= 0.0:
		return
	hp -= reduced
	_refresh_bar()
	if reduced > 1.5 and game != null:
		game.fx.sparks(global_position + Vector2(randf_range(-6, 6), -8))
	if hp <= 0.0:
		_destroy(true)


func repair(fraction: float) -> void:
	if dead or invincible:
		return
	hp = clampf(hp + max_hp * fraction, 0.0, max_hp)
	_refresh_bar()


func _destroy(with_fx: bool) -> void:
	if dead:
		return
	dead = true
	if with_fx and game != null:
		game.fx.smoke(global_position + Vector2(0, -6), 8)
		game.fx.sparks(global_position + Vector2(0, -6))
	remove_from_group("structures")
	queue_free()
