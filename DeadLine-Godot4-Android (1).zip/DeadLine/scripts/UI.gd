extends RefCounted
class_name UI
## Shared widget factory so the menu, HUD and overlays all look like one game.

const RED := Color(0.82, 0.19, 0.18)
const RED_DARK := Color(0.42, 0.08, 0.09)
const BONE := Color(0.93, 0.91, 0.85)
const DIM := Color(0.68, 0.66, 0.66)
const GREEN := Color(0.35, 0.76, 0.35)
const GOLD := Color(1.0, 0.83, 0.31)
const BLUE := Color(0.38, 0.72, 1.0)
const PANEL := Color(0.09, 0.085, 0.10, 0.95)
const PANEL_SOFT := Color(0.14, 0.13, 0.15, 0.92)

## Meta key holding the untranslated source string of a widget.
const LOC_SRC := "loc_src"


static func font_of(node: Control) -> Font:
	return node.get_theme_default_font()


static func tr_ui(text: String) -> String:
	## Every widget built through this factory is translated on creation, so the
	## whole shell is localized without touching hundreds of call sites.
	## Looked up defensively: UI is a static helper and may run before the Loc
	## autoload exists (tool scripts, isolated tests).
	var loop = Engine.get_main_loop()
	var tree = loop as SceneTree
	if tree == null or tree.root == null:
		return text
	var loc = tree.root.get_node_or_null("Loc")
	if loc == null:
		return text
	return String(loc.t(text))


static func retranslate(node: Node) -> void:
	## Walks a built UI tree and re-applies the current language to every widget
	## that came out of this factory. Lets an open HUD switch language on the fly
	## instead of waiting for the next scene load.
	if node.has_meta(LOC_SRC):
		var src = String(node.get_meta(LOC_SRC))
		if node is Label:
			(node as Label).text = tr_ui(src)
		elif node is Button:
			(node as Button).text = tr_ui(src)
	for c in node.get_children():
		retranslate(c)


static func label(text: String, size: int = 9, color: Color = BONE,
		align: int = HORIZONTAL_ALIGNMENT_LEFT) -> Label:
	var l = Label.new()
	l.set_meta(LOC_SRC, text)
	l.text = tr_ui(text)
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", color)
	l.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.92))
	l.add_theme_constant_override("outline_size", 3)
	l.horizontal_alignment = align
	l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	return l


static func style(bg: Color, border: Color, width: int = 1, radius: int = 2) -> StyleBoxFlat:
	var sb = StyleBoxFlat.new()
	sb.bg_color = bg
	sb.border_color = border
	sb.set_border_width_all(width)
	sb.set_corner_radius_all(radius)
	sb.content_margin_left = 6
	sb.content_margin_right = 6
	sb.content_margin_top = 4
	sb.content_margin_bottom = 4
	return sb


static func button(text: String, size: int = 10, accent: Color = RED,
		min_h: float = 26.0) -> Button:
	var b = Button.new()
	b.set_meta(LOC_SRC, text)
	b.text = tr_ui(text)
	b.focus_mode = Control.FOCUS_NONE
	b.custom_minimum_size = Vector2(0, min_h)
	b.add_theme_font_size_override("font_size", size)
	b.add_theme_color_override("font_color", BONE)
	b.add_theme_color_override("font_hover_color", Color(1, 1, 1))
	b.add_theme_color_override("font_pressed_color", accent.lightened(0.4))
	b.add_theme_stylebox_override("normal", style(Color(0.16, 0.15, 0.17, 0.96), accent.darkened(0.25)))
	b.add_theme_stylebox_override("hover", style(Color(0.22, 0.20, 0.23, 0.98), accent))
	b.add_theme_stylebox_override("pressed", style(accent.darkened(0.55), accent.lightened(0.2)))
	b.add_theme_stylebox_override("disabled", style(Color(0.13, 0.13, 0.14, 0.8), Color(0.3, 0.3, 0.3)))
	return b


static func big_button(text: String, accent: Color = RED) -> Button:
	var b = button(text, 14, accent, 40.0)
	b.add_theme_constant_override("outline_size", 4)
	return b


static func panel(bg: Color = PANEL, border: Color = Color(0.30, 0.10, 0.11)) -> PanelContainer:
	var p = PanelContainer.new()
	p.add_theme_stylebox_override("panel", style(bg, border, 1, 3))
	return p


static func spacer(h: float) -> Control:
	var c = Control.new()
	c.custom_minimum_size = Vector2(0, h)
	return c


static func hsep(w: float) -> Control:
	var c = Control.new()
	c.custom_minimum_size = Vector2(w, 0)
	return c


static func sprite_rect(tex: Texture2D, box: Vector2) -> TextureRect:
	var tr = TextureRect.new()
	tr.texture = tex
	tr.custom_minimum_size = box
	tr.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	tr.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	tr.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	return tr


static func slider(value: float, step: float = 0.05) -> HSlider:
	var s = HSlider.new()
	s.min_value = 0.0
	s.max_value = 1.0
	s.step = step
	s.value = value
	s.custom_minimum_size = Vector2(96, 18)
	s.focus_mode = Control.FOCUS_NONE
	return s
