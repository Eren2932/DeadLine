import sys, os, json, math, random
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from PIL import Image
from core import *
import things
POLY = things.POLY
WOOD = things.WOOD
STEEL = things.STEEL
import chars as C
import things as T

os.makedirs(OUT, exist_ok=True)
M = {"chars": {}, "weapons": {}, "fx": {}, "env": {}, "build": {}, "ui": {}}

# ============================ CHARACTERS ============================
PLAYERS = {
    "player_soldier": C.pal((226, 176, 138), (92, 104, 74), (66, 72, 58), (58, 42, 32),
                            gear=(74, 80, 60)),
    "player_juggernaut": C.pal((214, 168, 130), (96, 100, 88), (72, 76, 68), (40, 38, 36),
                               gear=(104, 108, 96)),
    "player_survivor": C.pal((232, 188, 150), (60, 82, 122), (52, 52, 62), (86, 56, 34),
                             gear=(70, 66, 60)),
    "player_swat": C.pal((214, 170, 132), (42, 48, 62), (34, 38, 48), (28, 26, 26),
                         gear=(52, 58, 72)),
    "player_medic": C.pal((236, 194, 158), (218, 220, 226), (72, 78, 86), (108, 74, 40),
                          gear=(196, 62, 58)),
}
def hand_list(hands):
    return [[round(h[0], 2), round(h[1], 2)] for h in hands]


for name, P in PLAYERS.items():
    helm = name not in ("player_survivor", "player_medic")
    kw = dict(helmet=helm, vest=True, arm_reach=1.0, backpack=True, aim=True)
    # 4 frame breathing idle, 8 frame run - both in the weapon hold pose so the
    # gun stays locked in the hands through the whole cycle
    idle, hands = C.anim(P, 4, walk=0.0, breathe=1.0, **kw)
    run, rhands = C.anim(P, 8, walk=1.0, lean=0.5, **kw)
    atk, ahands = C.attack_frames(P, 5, reach=1.15, helmet=helm, vest=True, backpack=True)
    dth = C.death_frames(P, 6, helmet=helm, vest=True, gore=0.5)
    M["chars"][name] = {
        "idle": strip(idle, name + "_idle.png"),
        "run": strip(run, name + "_run.png"),
        "attack": strip(atk, name + "_attack.png"),
        "death": strip(dth, name + "_death.png"),
        "hand": [round(hands[0][0], 2), round(hands[0][1], 2)],
        "hands": {"idle": hand_list(hands), "run": hand_list(rhands),
                  "attack": hand_list(ahands)},
        "h": C.CH, "feet": C.FEET,
    }

ZOMBIES = {
    "z_walker": dict(P=C.pal((128, 170, 112), (96, 78, 100), (62, 64, 84), (46, 52, 42), bare_arms=True),
                     hunch=0.75, torn=0.7, gore=0.55, fat=0.0, frames=8, cw=26, ch=38, feet=36),
    "z_nurse": dict(P=C.pal((150, 186, 138), (226, 226, 232), (206, 206, 214), (58, 40, 34), bare_arms=True),
                    hunch=0.6, torn=0.8, gore=0.8, fat=0.0, frames=8, cw=26, ch=38, feet=36),
    "z_worker": dict(P=C.pal((120, 158, 104), (206, 118, 40), (70, 66, 60), (40, 34, 30), bare_arms=True),
                     hunch=0.7, torn=0.6, gore=0.5, fat=0.15, frames=8, cw=26, ch=38, feet=36),
    "z_runner": dict(limp=0.05, lean=1.3, P=C.pal((162, 188, 120), (168, 58, 58), (48, 52, 66), (30, 28, 26), bare_arms=True),
                     hunch=1.0, torn=0.9, gore=0.7, fat=0.0, frames=8, cw=26, ch=38, feet=36),
    "z_spitter": dict(P=C.pal((122, 168, 78), (108, 140, 60), (58, 74, 44), (44, 60, 34),
                             blood=(168, 210, 60), bare_arms=True),
                      hunch=0.85, torn=0.8, gore=0.9, fat=0.3, frames=8, cw=26, ch=38, feet=36),
    "z_bloater": dict(limp=0.85, P=C.pal((138, 156, 96), (120, 122, 92), (76, 74, 64), (48, 48, 40),
                             blood=(120, 160, 40), bare_arms=True),
                      hunch=0.5, torn=0.9, gore=0.9, fat=0.9, frames=8, cw=28, ch=38, feet=36,
                      up=1.15),
    "z_cop": dict(P=C.pal((126, 162, 110), (46, 54, 76), (40, 44, 56), (32, 30, 28),
                          gear=(58, 64, 82), bare_arms=False),
                  hunch=0.7, torn=0.45, gore=0.5, fat=0.15, frames=8, cw=26, ch=38, feet=36,
                  helmet=True, vest=True),
    "z_hazmat": dict(P=C.pal((132, 172, 108), (214, 198, 74), (188, 172, 62), (40, 38, 34),
                             blood=(168, 210, 60), gear=(120, 128, 96), bare_arms=False),
                     hunch=0.75, torn=0.5, gore=0.6, fat=0.1, frames=8, cw=26, ch=38, feet=36,
                     helmet=True, vest=True),
    "z_brute": dict(limp=0.7, lean=0.9, P=C.pal((104, 146, 92), (86, 62, 58), (58, 52, 50), (32, 30, 28), bare_arms=True),
                    hunch=0.85, torn=0.7, gore=1.0, fat=0.55, frames=8, cw=27, ch=38, feet=36,
                    up=1.42),
}
def upscale(frames, k):
    out = []
    for f in frames:
        out.append(f.resize((int(round(f.width * k)), int(round(f.height * k))), Image.NEAREST))
    return out

for name, z in ZOMBIES.items():
    kw = dict(hunch=z["hunch"], torn=z["torn"], gore=z["gore"], fat=z["fat"],
              cw=z["cw"], ch=z["ch"], feet=z["feet"], arm_reach=1.35,
              helmet=z.get("helmet", False), vest=z.get("vest", False))
    # runners sprint cleanly, everything else drags a leg and shambles
    limp = z.get("limp", 0.55)
    walk, hands = C.anim(z["P"], z["frames"], walk=1.0, limp=limp,
                         lean=z.get("lean", 0.6), **kw)
    idle, _ = C.anim(z["P"], 4, walk=0.0, breathe=1.0, limp=limp, **kw)
    atk, _ah = C.attack_frames(z["P"], 5, reach=1.45,
                               hunch=z["hunch"], torn=z["torn"], gore=z["gore"],
                               fat=z["fat"], cw=z["cw"], ch=z["ch"], feet=z["feet"],
                               helmet=z.get("helmet", False), vest=z.get("vest", False))
    dth = C.death_frames(z["P"], 6, hunch=z["hunch"], torn=z["torn"], gore=1.0, fat=z["fat"],
                         cw=z["cw"], ch=z["ch"], feet=z["feet"],
                         helmet=z.get("helmet", False), vest=z.get("vest", False))
    k = z.get("up", 1.0)
    if k != 1.0:
        idle, walk, atk, dth = upscale(idle, k), upscale(walk, k), upscale(atk, k), upscale(dth, k)
    M["chars"][name] = {
        "idle": strip(idle, name + "_idle.png"),
        "run": strip(walk, name + "_run.png"),
        "attack": strip(atk, name + "_attack.png"),
        "death": strip(dth, name + "_death.png"),
        "h": int(round(z["ch"] * k)), "feet": int(round(z["feet"] * k)),
    }

# crawler: rotated dragging zombie
cr_p = C.pal((132, 164, 104), (92, 76, 92), (60, 62, 78), (40, 44, 38), bare_arms=True)
cr_frames = []
for i in range(8):
    im, _ = C.draw_char(cr_p, phase=i / 8.0, walk=1.0, hunch=1.0, torn=1.0, gore=1.0,
                        cw=26, ch=38, feet=36, arm_reach=1.5, limp=0.9)
    r = im.rotate(-72, resample=Image.NEAREST, center=(13, 34), expand=False)
    out = new(30, 20)
    out.alpha_composite(r.crop((0, 20, 26, 38)), (2, 1))
    cr_frames.append(out)
M["chars"]["z_crawler"] = {
    "idle": strip(cr_frames[:4], "z_crawler_idle.png"),
    "run": strip(cr_frames, "z_crawler_run.png"),
    "attack": strip(cr_frames[:4], "z_crawler_attack.png"),
    "death": strip(cr_frames[:4], "z_crawler_death.png"),
    "h": 20, "feet": 18,
}

# friendly pets
def quadruped(n, w, h, body, ground, hip_pairs, head, stripes=(), lw=2, bound=1.0):
    """Generic four legged gait: diagonal pairs, planted feet, spine bob."""
    out = []
    for i in range(n):
        im = new(w, h)
        ph = i / float(n)
        a = ph * math.tau
        bob = (-math.cos(2.0 * a) * 0.5 + 0.5) * 1.2 * bound
        by = -bob
        rect(im, hip_pairs[0][0] - 1, 6 + by, hip_pairs[1][0] + 2, ground - 5 + by, body)
        disc(im, head[0], head[1] + by, 3, body)
        for sx in stripes:
            rect(im, sx, 6 + by, sx, ground - 6 + by, (40, 32, 28, 255))
        px(im, head[0] + 2, head[1] - 1 + by, (250, 250, 120, 255) if stripes
           else (30, 24, 22, 255))
        rect(im, head[0] + 3, head[1] + 1 + by, head[0] + 4, head[1] + 1 + by,
             (40, 34, 30, 255))
        # tail
        limb(im, hip_pairs[0][0] - 2, 7 + by, hip_pairs[0][0] - 6,
             4 + math.sin(a) * 2.0 + by, 2, body)
        # legs: front-left / rear-right move together
        for k, (ox, off) in enumerate(hip_pairs):
            for j, (dx, phase_off, col) in enumerate((
                    (0.0, off, dark(body, 0.2)), (2.0, off + 0.5, body))):
                fx_off, fy, _pl = C._foot(ph + phase_off, 3.4 * bound, 2.2 * bound,
                                          float(ground))
                limb(im, ox + dx, ground - 5 + by, ox + dx + fx_off, fy, lw, col)
        volumize(im); outline(im)
        out.append(im)
    return out


dog_frames = quadruped(6, 24, 16, (216, 198, 156, 255), 14,
                       [(7, 0.0), (15, 0.5)], (19, 6), lw=2, bound=1.0)
M["chars"]["pet_dog"] = {"idle": strip(dog_frames[:3], "pet_dog_idle.png"),
                         "run": strip(dog_frames, "pet_dog_run.png"),
                         "death": strip(dog_frames[:2], "pet_dog_death.png"),
                         "h": 16, "feet": 15}

tiger_frames = quadruped(6, 30, 18, (226, 138, 44, 255), 16,
                         [(8, 0.0), (18, 0.5)], (24, 7),
                         stripes=(10, 13, 16, 19), lw=3, bound=1.2)
M["chars"]["pet_tiger"] = {"idle": strip(tiger_frames[:3], "pet_tiger_idle.png"),
                           "run": strip(tiger_frames, "pet_tiger_run.png"),
                           "death": strip(tiger_frames[:2], "pet_tiger_death.png"),
                           "h": 18, "feet": 17}

# ============================ WEAPONS ============================
GUNDEF = {
    "pistol":      dict(L=14, mag=3),
    "magnum":      dict(L=16, mag=2, barrel=(150, 152, 160, 255), accent=(198, 160, 60, 255)),
    "uzi":         dict(L=16, mag=6),
    "mp5":         dict(L=20, mag=5, stock=POLY),
    "ak47":        dict(L=26, mag=5, stock=WOOD, foregrip=True),
    "m4":          dict(L=25, mag=5, stock=POLY, scope=True, foregrip=True),
    "shotgun":     dict(L=26, mag=0, stock=WOOD, tube=True, muzzle_w=3),
    "autoshotgun": dict(L=27, mag=6, stock=POLY, drum=True, muzzle_w=3),
    "sniper":      dict(L=32, mag=3, stock=WOOD, scope=True, muzzle_w=2),
    "railgun":     dict(L=32, mag=3, stock=POLY, scope=True, barrel=(120, 200, 235, 255),
                        accent=(96, 220, 255, 255)),
    "minigun":     dict(L=30, mag=0, drum=True, barrel=(96, 100, 112, 255), muzzle_w=4),
    "rpg":         dict(L=32, mag=0, tube=True, barrel=(88, 104, 72, 255), muzzle_w=5,
                        stock=(70, 84, 58, 255), foregrip=True),
    "grenadier":   dict(L=24, mag=0, drum=True, stock=POLY, muzzle_w=4),
    "flamer":      dict(L=24, mag=7, barrel=(150, 70, 40, 255), foregrip=True, muzzle_w=3),
    "laser":       dict(L=26, mag=4, body=(60, 66, 84, 255), barrel=(120, 220, 255, 255),
                        accent=(96, 220, 255, 255), scope=True),
    "lmg":         dict(L=30, mag=0, drum=True, stock=POLY, foregrip=True, muzzle_w=3,
                        barrel=(104, 106, 114, 255)),
    "gauss":       dict(L=34, mag=3, stock=POLY, scope=True, barrel=(168, 148, 240, 255),
                        accent=(206, 170, 255, 255), foregrip=True, muzzle_w=3),
    "tesla":       dict(L=24, mag=4, body=(58, 62, 78, 255), barrel=(180, 240, 255, 255),
                        accent=(140, 235, 255, 255), drum=True),
}
for name, kw in GUNDEF.items():
    im, muz, grip = T.gun(**kw)
    save(im, "w_" + name + ".png")
    M["weapons"][name] = {"path": "res://art/w_%s.png" % name, "muzzle": list(muz),
                          "grip": list(grip), "w": im.width, "h": im.height}
for name, fn in (("chainsaw", T.chainsaw), ("katana", T.katana)):
    im, muz, grip = fn()
    save(im, "w_" + name + ".png")
    M["weapons"][name] = {"path": "res://art/w_%s.png" % name, "muzzle": list(muz),
                          "grip": list(grip), "w": im.width, "h": im.height}

# ============================ BUILDABLES ============================
for i in range(3):
    save(T.barricade(i), "b_wall_%d.png" % i)
M["build"]["wall"] = {"states": ["res://art/b_wall_0.png", "res://art/b_wall_1.png",
                                 "res://art/b_wall_2.png"], "w": 22, "h": 24}
save(T.sandbag(), "b_sandbag.png");     M["build"]["sandbag"] = {"path": "res://art/b_sandbag.png"}
save(T.spikes(), "b_spikes.png");       M["build"]["spikes"] = {"path": "res://art/b_spikes.png"}
save(T.tesla(), "b_tesla.png");         M["build"]["tesla"] = {"path": "res://art/b_tesla.png"}
save(T.mine(), "b_mine.png");           M["build"]["mine"] = {"path": "res://art/b_mine.png"}
tb, tg = T.turret_parts()
save(tb, "b_turret_base.png"); save(tg, "b_turret_gun.png")
M["build"]["turret"] = {"base": "res://art/b_turret_base.png", "gun": "res://art/b_turret_gun.png"}
save(T.crate(), "p_crate.png")
save(T.barrel_prop(), "p_barrel.png")
save(T.gravestone(), "p_grave.png")
M["fx"]["crate"] = "res://art/p_crate.png"
M["env"]["props"] = ["res://art/p_crate.png", "res://art/p_barrel.png", "res://art/p_grave.png"]

# ============================ FX ============================
def dot(size, col):
    im = new(size, size)
    disc(im, size / 2 - 0.5, size / 2 - 0.5, size / 2 - 0.5, col)
    return im

save(dot(4, (168, 24, 28, 255)), "fx_blood.png");   M["fx"]["blood"] = "res://art/fx_blood.png"
save(dot(3, (250, 226, 130, 255)), "fx_spark.png"); M["fx"]["spark"] = "res://art/fx_spark.png"
save(dot(6, (120, 116, 112, 255)), "fx_smoke.png"); M["fx"]["smoke"] = "res://art/fx_smoke.png"
save(dot(4, (176, 220, 60, 255)), "fx_acid.png");   M["fx"]["acid"] = "res://art/fx_acid.png"

rnd = random.Random(11)
splats = []
for i in range(4):
    im = new(26, 12)
    for _ in range(70):
        x = rnd.gauss(13, 5); y = rnd.gauss(8, 2.2)
        px(im, x, y, (126, 16, 20, 255) if rnd.random() < 0.7 else (86, 10, 14, 255))
    for _ in range(16):
        px(im, rnd.gauss(13, 9), rnd.gauss(8, 3.4), (108, 12, 16, 255))
    save(im, "fx_splat_%d.png" % i)
    splats.append("res://art/fx_splat_%d.png" % i)
M["fx"]["splats"] = splats

gibs = []
for i, (w, h, col) in enumerate(((7, 7, (188, 150, 120)), (9, 4, (150, 176, 118)),
                                 (10, 5, (120, 160, 100)), (6, 8, (176, 60, 56)),
                                 (5, 5, (222, 226, 220)), (8, 6, (150, 30, 34)))):
    im = new(w, h)
    for y in range(h):
        for x in range(w):
            if rnd.random() < 0.82:
                px(im, x, y, tuple(list(col) + [255]))
    volumize(im); outline(im)
    save(im, "fx_gib_%d.png" % i)
    gibs.append("res://art/fx_gib_%d.png" % i)
M["fx"]["gibs"] = gibs

mf = []
for i in range(3):
    im = new(14, 12)
    s = (1.0, 1.35, 0.7)[i]
    disc(im, 3, 6, 2.4 * s, (255, 244, 190, 255))
    disc(im, 6, 6, 2.0 * s, (255, 196, 78, 255))
    limb(im, 6, 6, 6 + 5 * s, 6, 2, (255, 216, 120, 255))
    limb(im, 5, 6, 5 + 4 * s, 3, 1, (255, 180, 70, 255))
    limb(im, 5, 6, 5 + 4 * s, 9, 1, (255, 180, 70, 255))
    mf.append(im)
M["fx"]["muzzle"] = strip(mf, "fx_muzzle.png")

ex = []
for i in range(8):
    im = new(56, 56)
    t = i / 7.0
    r = 4 + t * 22
    for k in range(140):
        a = rnd.random() * math.tau
        rr = r * (0.55 + rnd.random() * 0.5)
        x = 28 + math.cos(a) * rr; y = 28 + math.sin(a) * rr
        c = (255, 240, 180, 255) if t < 0.3 else ((255, 168, 50, 255) if t < 0.6 else (90, 82, 78, 255))
        disc(im, x, y, 2 - t, c)
    if t < 0.5:
        disc(im, 28, 28, r * 0.55, (255, 250, 220, 255))
    ex.append(im)
M["fx"]["explosion"] = strip(ex, "fx_explosion.png")

def proj(w, h, col, glow=None):
    im = new(w, h)
    rect(im, 0, 0, w - 1, h - 1, col)
    if glow:
        rect(im, 0, 0, w - 1, 0, glow)
    return im

save(proj(7, 2, (255, 226, 132, 255), (255, 250, 210, 255)), "fx_bullet.png")
save(proj(10, 3, (255, 200, 90, 255), (255, 246, 200, 255)), "fx_bullet_big.png")
save(proj(16, 3, (130, 236, 255, 255), (240, 254, 255, 255)), "fx_laser.png")
M["fx"]["bullet"] = "res://art/fx_bullet.png"
M["fx"]["bullet_big"] = "res://art/fx_bullet_big.png"
M["fx"]["laser"] = "res://art/fx_laser.png"

rk = new(16, 7)
rect(rk, 0, 2, 9, 4, (96, 98, 106, 255))
rect(rk, 9, 1, 13, 5, (168, 62, 52, 255))
rect(rk, 13, 2, 15, 4, (208, 96, 60, 255))
rect(rk, 2, 0, 4, 1, (72, 76, 84, 255))
rect(rk, 2, 5, 4, 6, (72, 76, 84, 255))
volumize(rk); outline(rk)
save(rk, "fx_rocket.png"); M["fx"]["rocket"] = "res://art/fx_rocket.png"

fl = new(10, 10)
disc(fl, 4.5, 4.5, 4.4, (255, 118, 30, 255))
disc(fl, 4.5, 4.5, 2.6, (255, 196, 70, 255))
disc(fl, 4.5, 4.5, 1.2, (255, 250, 210, 255))
save(fl, "fx_flame.png"); M["fx"]["flame"] = "res://art/fx_flame.png"

cs = new(4, 2)
rect(cs, 0, 0, 3, 1, (214, 176, 66, 255))
save(cs, "fx_casing.png"); M["fx"]["casing"] = "res://art/fx_casing.png"

med = new(11, 9)
rect(med, 1, 1, 9, 7, (232, 232, 236, 255))
rect(med, 4, 2, 6, 6, (206, 40, 40, 255))
rect(med, 2, 3, 8, 5, (206, 40, 40, 255))
volumize(med); outline(med)
save(med, "p_medkit.png"); M["fx"]["medkit"] = "res://art/p_medkit.png"

csh = new(11, 7)
rect(csh, 1, 1, 9, 5, (86, 168, 96, 255))
rect(csh, 3, 2, 7, 4, (196, 226, 176, 255))
rect(csh, 4, 3, 6, 3, (60, 120, 70, 255))
volumize(csh); outline(csh)
save(csh, "p_cash.png"); M["fx"]["cash"] = "res://art/p_cash.png"

grd = new(64, 300)
for y in range(300):
    if y < 14:
        base = (58, 44, 40)
    elif y < 30:
        base = (74, 96, 52)
    elif y < 34:
        base = (96, 88, 62)
    elif y < 96:
        base = (58, 58, 62)
    elif y < 104:
        base = (92, 82, 58)
    else:
        base = (70, 56, 44)
    for x in range(64):
        n = rnd.randint(-5, 5)
        px(grd, x, y, (base[0] + n, base[1] + n, base[2] + n, 255))
hline(grd, 0, 63, 30, (88, 116, 60, 255))
hline(grd, 0, 63, 34, (40, 40, 44, 255))
for x in range(4, 64, 16):
    rect(grd, x, 64, x + 7, 65, (214, 196, 78, 255))
hline(grd, 0, 63, 94, (40, 40, 44, 255))
hline(grd, 0, 63, 96, (104, 94, 66, 255))
for _ in range(260):
    x = rnd.randint(0, 63); y = rnd.randint(105, 299)
    px(grd, x, y, (60, 48, 38, 255))
save(grd, "env_ground.png"); M["env"]["ground"] = "res://art/env_ground.png"

# ============================ ENVIRONMENT ============================
sky = new(320, 200)
for y in range(200):
    t = y / 199.0
    c = (int(28 + 92 * t), int(20 + 34 * t), int(38 + 30 * t), 255)
    hline(sky, 0, 319, y, c)
for _ in range(90):
    x = rnd.randint(0, 319); y = rnd.randint(0, 90)
    px(sky, x, y, (232, 226, 200, 255))
disc(sky, 250, 46, 14, (226, 84, 62, 255))
disc(sky, 250, 46, 11, (255, 150, 92, 255))
save(sky, "env_sky.png"); M["env"]["sky"] = "res://art/env_sky.png"

mt = new(320, 90)
h = 40
for x in range(320):
    h += rnd.choice((-2, -1, -1, 0, 1, 1, 2))
    h = max(18, min(70, h))
    rect(mt, x, 90 - h, x, 89, (74, 52, 58, 255))
    rect(mt, x, 90 - h, x, 90 - h + 2, (104, 74, 74, 255))
save(mt, "env_mountains.png"); M["env"]["mountains"] = "res://art/env_mountains.png"

city = new(320, 80)
x = 0
while x < 320:
    w = rnd.randint(14, 34); hh = rnd.randint(24, 74)
    rect(city, x, 80 - hh, x + w, 79, (46, 40, 54, 255))
    rect(city, x, 80 - hh, x + w, 80 - hh, (66, 58, 74, 255))
    for wy in range(80 - hh + 3, 78, 5):
        for wx in range(x + 2, x + w - 1, 4):
            if rnd.random() < 0.35:
                rect(city, wx, wy, wx + 1, wy + 2, (226, 170, 70, 255))
    x += w + rnd.randint(0, 4)
save(city, "env_city.png"); M["env"]["city"] = "res://art/env_city.png"

fence = new(64, 46)
rect(fence, 0, 30, 63, 45, (74, 96, 52, 255))
for i in range(0, 64, 2):
    rect(fence, i, 26 + rnd.randint(0, 3), i, 33, (58, 84, 42, 255))
for i in range(0, 64, 16):
    rect(fence, i, 6, i + 1, 30, (104, 108, 116, 255))
for y in (10, 18, 26):
    hline(fence, 0, 63, y, (128, 132, 140, 255))
save(fence, "env_fence.png"); M["env"]["fence"] = "res://art/env_fence.png"

road = new(64, 64)
for y in range(64):
    base = (58, 58, 62) if y > 8 else (86, 74, 52)
    for x in range(64):
        n = rnd.randint(-6, 6)
        px(road, x, y, (base[0] + n, base[1] + n, base[2] + n, 255))
hline(road, 0, 63, 6, (92, 82, 58, 255))
hline(road, 0, 63, 8, (40, 40, 44, 255))
for x in range(4, 64, 16):
    rect(road, x, 34, x + 7, 35, (214, 196, 78, 255))
hline(road, 0, 63, 58, (74, 70, 66, 255))
hline(road, 0, 63, 60, (96, 84, 60, 255))
rect(road, 0, 61, 63, 63, (86, 70, 48, 255))
save(road, "env_road.png"); M["env"]["road"] = "res://art/env_road.png"

# ============================ UI ============================
jb = new(72, 72)
disc(jb, 35.5, 35.5, 34, (255, 255, 255, 26))
disc(jb, 35.5, 35.5, 30, (0, 0, 0, 0))
disc(jb, 35.5, 35.5, 33, (255, 255, 255, 46))
disc(jb, 35.5, 35.5, 31, (0, 0, 0, 0))
save(jb, "ui_joy_base.png"); M["ui"]["joy_base"] = "res://art/ui_joy_base.png"
jk = new(34, 34)
disc(jk, 16.5, 16.5, 16, (232, 60, 52, 190))
disc(jk, 16.5, 16.5, 11, (255, 138, 120, 200))
save(jk, "ui_joy_knob.png"); M["ui"]["joy_knob"] = "res://art/ui_joy_knob.png"

ic = new(512, 512)
head = new(64, 64)
disc(head, 32, 34, 22, (128, 170, 112, 255))
rect(head, 12, 34, 52, 46, (128, 170, 112, 255))
rect(head, 20, 26, 27, 31, (240, 240, 232, 255)); rect(head, 22, 28, 24, 30, (140, 20, 20, 255))
rect(head, 37, 26, 44, 31, (240, 240, 232, 255)); rect(head, 39, 28, 41, 30, (140, 20, 20, 255))
rect(head, 20, 40, 44, 46, (36, 26, 30, 255))
for x in range(21, 44, 4):
    rect(head, x, 40, x + 1, 43, (238, 238, 226, 255))
for _ in range(120):
    x = rnd.randint(10, 54); y = rnd.randint(14, 52)
    if get(head, x, y)[3] != 0 and rnd.random() < 0.4:
        px(head, x, y, (150, 26, 26, 255))
volumize(head); outline(head)
ic_bg = Image.new("RGBA", (64, 64), (26, 18, 22, 255))
for y in range(64):
    hline(ic_bg, 0, 63, y, (int(24 + y), 14, int(20 + y // 2), 255))
ic_bg.alpha_composite(head)
save(ic_bg.resize((512, 512), Image.NEAREST), "icon.png")

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
# --- menu skull logo (big) ---
skull = new(48, 48)
disc(skull, 24, 22, 15, (226, 222, 208, 255))
rect(skull, 14, 22, 33, 32, (226, 222, 208, 255))
rect(skull, 18, 32, 29, 40, (214, 208, 194, 255))
rect(skull, 15, 16, 21, 23, (26, 20, 24, 255))
rect(skull, 26, 16, 32, 23, (26, 20, 24, 255))
rect(skull, 22, 24, 25, 28, (26, 20, 24, 255))
for sx in range(18, 30, 3):
    rect(skull, sx, 33, sx + 1, 39, (30, 24, 28, 255))
rect(skull, 17, 36, 30, 36, (30, 24, 28, 255))
for _ in range(90):
    x = rnd.randint(12, 35); y = rnd.randint(10, 41)
    if get(skull, x, y)[3] != 0 and rnd.random() < 0.35:
        px(skull, x, y, (150, 26, 26, 255))
volumize(skull); outline(skull)
save(skull, "ui_skull.png"); M["ui"]["skull"] = "res://art/ui_skull.png"

with open(os.path.join(OUT, "manifest.json"), "w") as f:
    json.dump(M, f, indent=1)

# Also emit a GDScript constant so the data is always shipped inside exports.
gd = json.dumps(M, indent=1)
with open(os.path.join(ROOT, "scripts", "ArtManifest.gd"), "w") as f:
    f.write("## AUTO-GENERATED by tools/build.py - do not edit by hand.\n")
    f.write("## Layout of every generated sprite sheet, weapon, fx and environment texture.\n")
    f.write("extends RefCounted\n\n")
    f.write("const DATA := " + gd + "\n")
print("chars:", len(M["chars"]), "weapons:", len(M["weapons"]))
print("files:", len(os.listdir(OUT)))
