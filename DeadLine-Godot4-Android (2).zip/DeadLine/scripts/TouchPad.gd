extends Control
class_name TouchPad
## Real multi-touch controls: a floating stick on one side, action buttons on the
## other. Everything is drawn in _draw() and hit-tested by hand, so holding the
## stick while pressing FIRE always works (no mouse-emulation conflicts).

const STICK_RADIUS := 30.0
const ZONE_H := 190.0

var game = null

var stick_touch = -1
var place_touch = -1
var stick_center = Vector2.ZERO
var stick_knob = Vector2.ZERO
var _was_stick = false

var buttons: Array = []
var _base_tex: Texture2D
var _knob_tex: Texture2D
var _font: Font
var _last_size = Vector2.ZERO


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	_base_tex = Art.ui_tex("joy_base")
	_knob_tex = Art.ui_tex("joy_knob")
	_font = ThemeDB.fallback_font
	set_process(true)
	_layout()


func _layout() -> void:
	_last_size = size
	var w = size.x
	var h = size.y
	# 16:9 landscape: thumbstick hugs the bottom-left corner, the action cluster
	# the bottom-right one, and the middle of the screen stays free for the fight.
	var right_stick = Settings.idx("joy_side") == 1
	var stick_x = 62.0 if not right_stick else w - 62.0
	stick_center = Vector2(stick_x, h - 58.0)
	stick_knob = stick_center

	var bx = w - 50.0 if not right_stick else 50.0
	var mirror = -1.0 if right_stick else 1.0
	buttons = [
		{"id": "fire", "c": Vector2(bx, h - 40.0), "r": 25.0, "label": "FIRE", "col": UI.RED},
		{"id": "dash", "c": Vector2(bx - 52.0 * mirror, h - 34.0), "r": 18.0, "label": "DASH",
			"col": UI.BLUE},
		{"id": "nade", "c": Vector2(bx - 8.0 * mirror, h - 92.0), "r": 17.0, "label": "NADE",
			"col": UI.GREEN},
		{"id": "swap", "c": Vector2(bx - 52.0 * mirror, h - 82.0), "r": 16.0, "label": "GUN",
			"col": UI.GOLD},
		{"id": "reload", "c": Vector2(bx + 14.0 * mirror, h - 136.0), "r": 16.0, "label": "RLD",
			"col": UI.DIM},
		{"id": "build", "c": Vector2(bx - 34.0 * mirror, h - 128.0), "r": 16.0, "label": "BLD",
			"col": UI.BLUE},
		# class skill: one button, one identity per suit
		{"id": "skill", "c": Vector2(bx - 78.0 * mirror, h - 60.0), "r": 17.0, "label": "SKL",
			"col": UI.GOLD},
		# grenade type switch, right under the throw button
		{"id": "ntype", "c": Vector2(bx + 24.0 * mirror, h - 100.0), "r": 12.0, "label": "TYP",
			"col": UI.GREEN},
	]
	for b in buttons:
		b["touch"] = -1
		b["down"] = false


func _process(_delta: float) -> void:
	if size != _last_size:
		_layout()
	var pl = game.player if game != null else null
	if pl == null or not is_instance_valid(pl):
		return

	if stick_touch >= 0:
		var v = (stick_knob - stick_center) / STICK_RADIUS
		pl.move_input = v.limit_length(1.0)
		_was_stick = true
	elif _was_stick:
		pl.move_input = Vector2.ZERO
		_was_stick = false

	if not Settings.on("autofire"):
		pl.fire_held = _is_down("fire")
	queue_redraw()


func _is_down(id: String) -> bool:
	for b in buttons:
		if String(b["id"]) == id:
			return bool(b["down"])
	return false


# ================================================================ input
func _input(event: InputEvent) -> void:
	if game == null or game.hud == null:
		return
	if event is InputEventScreenTouch:
		var t = event as InputEventScreenTouch
		if t.pressed:
			_press(t.position, t.index)
		else:
			_release(t.index)
	elif event is InputEventScreenDrag:
		var dr = event as InputEventScreenDrag
		if dr.index == stick_touch:
			stick_knob = stick_center + (dr.position - stick_center).limit_length(STICK_RADIUS)
		elif dr.index == place_touch and game.hud.build_mode:
			game.set_ghost(_to_world(dr.position))


func _press(pos: Vector2, index: int) -> void:
	if game.hud.blocks_touch():
		return
	# action buttons first
	for b in buttons:
		if String(b["id"]) == "fire" and Settings.on("autofire"):
			continue
		if pos.distance_to(b["c"] as Vector2) <= float(b["r"]) * 1.25:
			b["touch"] = index
			b["down"] = true
			_trigger(String(b["id"]))
			return
	# anything drawn on top of the HUD (weapon strip, prep card, build bar, the
	# top status bar) owns its own taps - the stick must never steal them
	if game.hud.point_blocked(pos):
		return
	# stick zone
	var right_stick = Settings.idx("joy_side") == 1
	var in_zone: bool = pos.y > size.y - ZONE_H and (
			(pos.x < size.x * 0.42) if not right_stick else (pos.x > size.x * 0.58))
	if in_zone and stick_touch == -1:
		stick_touch = index
		stick_center = pos
		stick_knob = pos
		return
	# world tap in build mode: show the ghost now, commit it on release, so the
	# finger can be dragged around until the spot is actually right
	if game.hud.build_mode and not game.hud.point_blocked(pos):
		place_touch = index
		game.set_ghost(_to_world(pos))


func _to_world(pos: Vector2) -> Vector2:
	return get_viewport().get_canvas_transform().affine_inverse() * pos


func _release(index: int) -> void:
	if index == place_touch:
		place_touch = -1
		if game.hud.build_mode and game.ghost_active():
			game.place_build(game.ghost_spot())
	if index == stick_touch:
		stick_touch = -1
		stick_knob = stick_center
		_layout()
	for b in buttons:
		if int(b["touch"]) == index:
			b["touch"] = -1
			b["down"] = false


func _trigger(id: String) -> void:
	var pl = game.player
	if pl == null or not is_instance_valid(pl):
		return
	match id:
		"dash":
			pl.dash()
		"nade":
			pl.throw_grenade()
		"swap":
			pl.next_weapon()
		"reload":
			pl.start_reload()
		"build":
			game.hud.toggle_build()
		"skill":
			pl.use_ability()
		"ntype":
			pl.cycle_nade(1)
		_:
			pass


# ================================================================ drawing
func _draw() -> void:
	var pl = game.player if game != null else null
	# ---- stick
	var base_a = 0.32 if stick_touch < 0 else 0.6
	if _base_tex != null:
		draw_texture(_base_tex, stick_center - _base_tex.get_size() * 0.5,
				Color(1, 1, 1, base_a))
	else:
		draw_arc(stick_center, STICK_RADIUS, 0.0, TAU, 24, Color(1, 1, 1, base_a), 2.0)
	if _knob_tex != null:
		draw_texture(_knob_tex, stick_knob - _knob_tex.get_size() * 0.5,
				Color(1, 1, 1, base_a + 0.25))
	else:
		draw_circle(stick_knob, 9.0, Color(0.9, 0.3, 0.3, base_a + 0.3))

	# ---- buttons
	for b in buttons:
		var id = String(b["id"])
		if id == "fire" and Settings.on("autofire"):
			continue
		var c: Vector2 = b["c"]
		var r: float = float(b["r"])
		var col: Color = b["col"]
		var down: bool = bool(b["down"])
		draw_circle(c, r, Color(0.05, 0.05, 0.06, 0.55 if not down else 0.8))
		draw_arc(c, r, 0.0, TAU, 28, Color(col.r, col.g, col.b, 0.85), 2.0)
		if down:
			draw_circle(c, r - 3.0, Color(col.r, col.g, col.b, 0.30))

		# cooldown / ammo overlays
		if pl != null and is_instance_valid(pl):
			if id == "dash" and pl.dash_cd > 0.0:
				var frac: float = clampf(pl.dash_cd / maxf(0.1, pl.dash_cooldown()), 0.0, 1.0)
				draw_arc(c, r - 4.0, -PI * 0.5, -PI * 0.5 + TAU * frac, 24,
						Color(1, 1, 1, 0.45), 3.0)
			if id == "reload" and pl.reloading:
				draw_arc(c, r - 4.0, -PI * 0.5, -PI * 0.5 + TAU * pl.reload_progress(), 24,
						Color(1.0, 0.8, 0.3, 0.7), 3.0)

			if id == "skill" and pl.ability_cd > 0.0:
				var sfrac: float = clampf(pl.ability_cd / maxf(0.1, pl.ability_total_cd()),
						0.0, 1.0)
				draw_arc(c, r - 4.0, -PI * 0.5, -PI * 0.5 + TAU * sfrac, 24,
						Color(1, 1, 1, 0.45), 3.0)
			elif id == "skill":
				# ready: a soft pulse so it reads as "press me" at a glance
				var pulse: float = 0.35 + 0.25 * sin(float(Time.get_ticks_msec()) * 0.006)
				draw_circle(c, r - 5.0, Color(UI.GOLD.r, UI.GOLD.g, UI.GOLD.b, pulse * 0.5))
			if id == "ntype" or id == "nade":
				var icon = Art.ui_tex(String(GameData.grenade(pl.nade_type).get("icon", "nade_frag")))
				if icon != null:
					var isz: Vector2 = icon.get_size()
					var at: Vector2 = c - isz * 0.5 + Vector2(0.0, -3.0 if id == "nade" else 0.0)
					draw_texture(icon, at, Color(1, 1, 1, 0.95))

		var label = String(b["label"])
		if id == "nade" and pl != null and is_instance_valid(pl):
			label = "%d" % pl.nade_count()
		elif id == "ntype":
			label = ""
		elif id == "skill" and pl != null and is_instance_valid(pl):
			label = "SKL" if pl.ability_cd <= 0.0 else "%d" % int(ceil(pl.ability_cd))
		if _font != null and label != "":
			label = Loc.t(label)
			var w = _font.get_string_size(label, HORIZONTAL_ALIGNMENT_LEFT, -1, 8).x
			draw_string(_font, c + Vector2(-w * 0.5, 3.0), label, HORIZONTAL_ALIGNMENT_LEFT, -1, 8,
					Color(1, 1, 1, 0.9))
