extends Node2D
class_name Game
## The run itself: world, camera, waves, spawning, combat helpers, economy,
## building, upgrades, crates, events, pause and game over.
##
## Everything is built from code so nothing can break in the editor.

const BULLET_POOL := 240
const GRID_CELL := 48.0
const SPAWN_MARGIN := 46.0
const COMBO_TIME := 3.2

# ---------------------------------------------------------------- state
var state = "prep"                 # "prep" | "fight" | "over"
var wave = 0
var cash = 220
var kills = 0
var score = 0
var combo = 0
var combo_t = 0.0
var prep_time = 20.0
var to_spawn = 0
var spawn_t = 0.0
var wave_hp = 1.0
var wave_spd = 1.0
var event_id = "none"
var boss = null
var build_kind = ""
var run_time = 0.0
var paused = false
var hazards: Array = []            # burning ground / gas clouds from grenades
var restored_from_save = false
## Mirror of the real screen centre, used by the horde for level-of-detail.
var cam_center_x = 0.0
var lod_dist = 620.0
var _hud_t = 0.0

# ---------------------------------------------------------------- nodes
var world: Node2D
var ghost: BuildGhost
var parallax: Array = []            # [{"node": Node2D, "factor": float}]
var entities: Node2D
var cam: Camera2D
var sky_rect: ColorRect            # instant flat sky, painted before any texture
var env = null                      # EnvCity instance, or null when scenery failed
var fx = null
var hud = null
var player = null
var night: CanvasModulate

var zombies: Array = []
var structures: Array = []
var allies: Array = []
var crates: Array = []
var _bullets: Array = []            # free pool
var _grid: Dictionary = {}
var _beams: Array = []
# ---- camera feel. _shake is "trauma" in 0..1, not a pixel amount: it decays
# exponentially and drives a multi-frequency wobble, a directional kick and a
# small rotation, which reads like a real impact instead of white noise.
var _shake = 0.0
var _shake_dir = Vector2.ZERO
var _shake_t = 0.0
var _zoom_punch = 0.0
# ---- haptics. Kills are collected inside a short window so one buzz covers a
# whole grenade wipe instead of machine-gunning the motor.
var _hap_kills = 0
var _hap_window = 0.0
var _hitstop_until = 0
var _suspend_at = -9999


# ================================================================ setup
func _ready() -> void:
	randomize()
	Engine.time_scale = 1.0
	get_tree().paused = false
	_build_world()
	_build_bullets()
	fx = Fx.new()
	fx.z_index = 10
	add_child(fx)
	hud = HUD.new()
	hud.game = self
	add_child(hud)
	_spawn_player()
	_build_camera()
	var pet = Save.loadout_get("pet")
	if pet != "none":
		spawn_ally(pet)
	state = "prep"
	prep_time = GameData.PREP_TIME_FIRST
	# ---- continue / checkpoint: rebuild the run before the first frame runs
	var restore: Dictionary = {}
	if Save.pending_checkpoint and Save.has_checkpoint():
		restore = Save.checkpoint_data()
	elif Save.pending_continue and Save.has_run():
		restore = Save.run_data()
	Save.pending_continue = false
	Save.pending_checkpoint = false
	if not restore.is_empty():
		apply_run(restore)
	cam_center_x = player.global_position.x
	hud.show_prep(prep_time)
	if restored_from_save:
		hud.flash_banner(UI.tr_f("RUN RESTORED - WAVE %d", [wave + 1]), UI.GOLD)
	else:
		hud.flash_banner("HOLD THE LINE", UI.RED)
	# Language can be switched from the pause menu mid-run; the HUD relabels
	# itself instead of needing a restart.
	var _loc = UI.loc_node()
	if _loc != null and _loc.has_signal("language_changed"):
		_loc.connect("language_changed", hud.on_language_changed)
	Music.play("battle", 1.5)
	# Scenery last, and deferred: gameplay is already standing before a single
	# background texture is touched.
	call_deferred("_build_scenery")


func _exit_tree() -> void:
	Engine.time_scale = 1.0
	get_tree().paused = false


# ================================================= OS integration (Android)
func _notification(what: int) -> void:
	# Back gesture / back button: the engine used to quit the app outright
	# (quit_on_go_back is off in project.godot now). In game it closes whatever
	# is open, or pauses - it never kills the run.
	if what == NOTIFICATION_WM_GO_BACK_REQUEST:
		_on_back_request()
	elif what == NOTIFICATION_APPLICATION_PAUSED \
			or what == NOTIFICATION_APPLICATION_FOCUS_OUT \
			or what == NOTIFICATION_WM_WINDOW_FOCUS_OUT:
		_on_app_suspend()


func _on_back_request() -> void:
	if state == "over":
		return_to_menu()
		return
	if hud != null and is_instance_valid(hud):
		if paused:
			toggle_pause()
			return
		if hud.back_request():
			return
	if not paused:
		toggle_pause()


func _on_app_suspend() -> void:
	## The player just switched away. Bank everything and freeze, so coming back
	## lands exactly where they left instead of on a fresh wave 1.
	if state == "over":
		return
	# Android fires several of these back to back (focus out, then paused).
	# One write is enough.
	var now = Time.get_ticks_msec()
	if now - _suspend_at < 400:
		return
	_suspend_at = now
	suspend_save()
	Settings.flush()
	if not paused:
		toggle_pause()


func suspend_save() -> void:
	## Snapshot taken even in the middle of a fight - the wave you were in
	## restarts from its own prep phase, with everything you were carrying.
	if player == null or not is_instance_valid(player) or player.dead:
		return
	if wave <= 0:
		return
	var snap = serialize_run()
	if state != "prep":
		snap["wave"] = maxi(0, wave - 1)
	snap["live"] = true
	Save.save_run(snap)


func _build_world() -> void:
	world = Node2D.new()
	add_child(world)

	# The flat sky goes down FIRST and unconditionally. It is a ColorRect - no
	# file, no import, nothing that can be missing - so from the very first
	# frame the arena is a night sky. Every layer, the moon and the weather are
	# added later, on top of this, and are all allowed to fail.
	sky_rect = ColorRect.new()
	sky_rect.color = GameData.theme_sky_color()
	sky_rect.position = Vector2(-6000.0, -700.0)
	sky_rect.size = Vector2(GameData.ARENA_W + 12000.0, 1400.0)
	sky_rect.z_index = -80
	sky_rect.mouse_filter = Control.MOUSE_FILTER_IGNORE
	world.add_child(sky_rect)

	entities = Node2D.new()
	entities.y_sort_enabled = true
	world.add_child(entities)

	ghost = BuildGhost.new()
	world.add_child(ghost)
	ghost.setup(self)

	# scenery props along the far pavement
	var props: Array = Art.env_props()
	if not props.is_empty():
		for i in range(26):
			var s = Sprite2D.new()
			s.texture = Art.tex(String(props[randi() % props.size()]))
			s.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
			s.position = Vector2(randf_range(40.0, GameData.ARENA_W - 40.0),
					randf_range(GameData.HORIZON_Y + 1.0, GameData.BAND_TOP - 3.0))
			s.z_index = -8
			world.add_child(s)

	night = CanvasModulate.new()
	night.color = Color(1, 1, 1)
	add_child(night)


func _build_flat_world() -> void:
	## v3 background, the proven one. Used when EnvCity is unavailable for any
	## reason at all, so "no new city" can never mean "no game".
	var sky = _layer(Art.env_tex("sky"), 0.0, -170.0, 3.2)
	var mountains = _layer(Art.env_tex("mountains"), 0.15, -96.0, 1.0)
	var city = _layer(Art.env_tex("city"), 0.35, -104.0, 1.0)
	var fence = _layer(Art.env_tex("fence"), 0.62, -54.0, 1.0)
	var ground = _layer(Art.env_tex("ground"), 1.0, -6.0, 1.0)
	var road = _layer(Art.env_tex("road"), 1.0, -4.0, 1.0)
	if sky != null:
		sky.z_index = -40
	if mountains != null:
		mountains.z_index = -30
	if city != null:
		city.z_index = -25
	if fence != null:
		fence.z_index = -20
	if ground != null:
		ground.z_index = -12
	if road != null:
		road.z_index = -10


func _build_scenery() -> void:
	## Called deferred, at the very end of _ready, i.e. AFTER the player, the HUD
	## and the camera exist. Three guards, in order:
	##   1. the script itself may be missing or fail to compile -> load() is null
	##   2. it may not expose build() -> has_method check
	##   3. it may find no art at all -> built == 0
	## Any of the three lands on the v3 background and a playable run.
	if world == null or not is_instance_valid(world):
		return
	if not GameData.BELT_ENABLED:
		_build_flat_world()
		return
	var env_script = load("res://scripts/EnvCity.gd")
	if env_script == null:
		push_warning("EnvCity script unavailable - falling back to the flat city")
		_build_flat_world()
		return
	var e = env_script.new()
	if e == null or not e.has_method("build"):
		push_warning("EnvCity has no build() - falling back to the flat city")
		_build_flat_world()
		return
	var made = int(e.build(self))
	if made <= 0:
		push_warning("EnvCity found no art - falling back to the flat city")
		_build_flat_world()
		return
	env = e


func _layer(tex: Texture2D, factor: float, y: float, v_scale: float = 1.0) -> Node2D:
	## A scrolling background band. The strip is only as wide as the screen plus
	## two spare tiles and is re-wrapped every frame with fposmod, so the layer
	## can never run out, drift away or "slide off" the level like it used to.
	if tex == null:
		return null
	var holder = Node2D.new()
	holder.position.y = y
	var tw = maxf(8.0, float(tex.get_width()))
	var span = max_visible_w() + tw * 2.0
	var tiles = int(ceil(span / tw)) + 1
	for i in range(tiles):
		var s = Sprite2D.new()
		s.texture = tex
		s.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
		s.centered = false
		s.position = Vector2(float(i) * tw, 0.0)
		s.scale = Vector2(1.0, v_scale)
		holder.add_child(s)
	world.add_child(holder)
	parallax.append({"node": holder, "factor": factor, "base_y": y, "tile_w": tw})
	return holder


# ================================================================ view helpers
func visible_half_w() -> float:
	## Half of what the player actually sees, in world pixels.
	return get_viewport_rect().size.x * 0.5 / maxf(0.1, Settings.zoom())


func visible_half_h() -> float:
	return get_viewport_rect().size.y * 0.5 / maxf(0.1, Settings.zoom())


func max_visible_w() -> float:
	## Widest possible view over every zoom setting (used to size the parallax).
	var z = 99.0
	for v in Settings.ZOOM_VALUES:
		z = minf(z, float(v))
	return get_viewport_rect().size.x / maxf(0.1, z)


func on_screen(pos: Vector2, margin: float = 0.0) -> bool:
	return absf(pos.x - cam_center_x) < visible_half_w() + margin


func _build_camera() -> void:
	cam = Camera2D.new()
	cam.zoom = Vector2.ONE * Settings.zoom()
	cam.position_smoothing_enabled = true
	cam.position_smoothing_speed = 7.0
	cam.limit_left = int(GameData.play_left() - 24.0)
	cam.limit_right = int(GameData.play_right() + 24.0)
	cam.limit_top = -600
	cam.limit_bottom = 400
	# The roll used by the shake is tiny (about one degree at full strength) and
	# it is what turns a jitter into an impact, so the camera has to honour it.
	cam.ignore_rotation = false
	add_child(cam)
	cam.make_current()
	cam.global_position = Vector2(player.global_position.x,
			GameData.cam_y(player.global_position.y))


func _build_bullets() -> void:
	for i in range(BULLET_POOL):
		var b = Bullet.new()
		add_child(b)
		_bullets.append(b)
	for i in range(6):
		var l = Line2D.new()
		l.width = 2.0
		l.visible = false
		l.z_index = 9
		l.default_color = Color(0.7, 0.95, 1.0)
		add_child(l)
		_beams.append(l)


func _spawn_player() -> void:
	player = Player.new()
	entities.add_child(player)
	player.global_position = Vector2(GameData.ARENA_W * 0.5, (GameData.BAND_TOP + GameData.BAND_BOT) * 0.5)
	player.setup(self, Save.loadout())


# ================================================================ loop
func _process(delta: float) -> void:
	run_time += delta
	_keyboard(delta)
	_tick_hazards(delta)

	if Engine.time_scale < 1.0 and Time.get_ticks_msec() > _hitstop_until:
		Engine.time_scale = 1.0

	# camera follow + shake
	if player != null and is_instance_valid(player):
		# look ahead in the direction the survivor faces so the horde is on
		# screen long before it can reach him
		var lead = clampf(player.aim_dir.x, -1.0, 1.0) * visible_half_w() * 0.18
		var target = Vector2(player.global_position.x + lead,
				GameData.cam_y(player.global_position.y))
		cam.global_position = cam.global_position.lerp(target, clampf(delta * 5.0, 0.0, 1.0))
	_tick_camera_feel(delta)
	_tick_haptics(delta)

	# Parallax: wrap each band around what the camera ACTUALLY shows.
	# cam.global_position is the unclamped follow target - at the ends of the
	# arena the camera is pinned by its limits, so using it made every layer
	# slide off and left one half of the screen bare. get_screen_center_position()
	# is the clamped, real centre, which kills that bug for good.
	var cx = cam.get_screen_center_position().x
	cam_center_x = cx
	lod_dist = visible_half_w() + 140.0
	var edge = visible_half_w() + 2.0
	for l in parallax:
		var n: Node2D = l["node"]
		var f: float = float(l["factor"])
		var tw: float = float(l["tile_w"])
		n.position.x = cx - edge - tw - fposmod(cx * f, tw)
	if env != null:
		env.tick(delta, cx)

	if combo_t > 0.0:
		combo_t -= delta
		if combo_t <= 0.0:
			combo = 0

	match state:
		"prep":
			# The countdown is frozen while the shop, the build bar or any other
			# overlay is open, so nobody gets jumped mid-purchase.
			if not hud.blocks_timer():
				prep_time -= delta
			hud.update_prep(prep_time)
			if prep_time <= 0.0:
				start_wave()
		"fight":
			_spawn_step(delta)
		_:
			pass

	# The HUD rebuilds a lot of strings, 20 Hz is plenty and saves frames when
	# the screen is full of bodies.
	_hud_t += delta
	if _hud_t >= 0.05 or state != "fight":
		_hud_t = 0.0
		hud.refresh()


func _physics_process(_delta: float) -> void:
	_rebuild_grid()
	_cleanup()


func _cleanup() -> void:
	for i in range(zombies.size() - 1, -1, -1):
		var z = zombies[i]
		if z == null or not is_instance_valid(z) or z.dead:
			zombies.remove_at(i)
	for i in range(structures.size() - 1, -1, -1):
		var s = structures[i]
		if s == null or not is_instance_valid(s) or s.dead:
			structures.remove_at(i)
	for i in range(allies.size() - 1, -1, -1):
		if allies[i] == null or not is_instance_valid(allies[i]):
			allies.remove_at(i)
	for i in range(crates.size() - 1, -1, -1):
		if crates[i] == null or not is_instance_valid(crates[i]):
			crates.remove_at(i)


func _keyboard(_delta: float) -> void:
	if player == null or not is_instance_valid(player) or player.dead:
		return
	var kb = Vector2.ZERO
	if Input.is_key_pressed(KEY_A) or Input.is_key_pressed(KEY_LEFT):
		kb.x -= 1.0
	if Input.is_key_pressed(KEY_D) or Input.is_key_pressed(KEY_RIGHT):
		kb.x += 1.0
	if Input.is_key_pressed(KEY_W) or Input.is_key_pressed(KEY_UP):
		kb.y -= 1.0
	if Input.is_key_pressed(KEY_S) or Input.is_key_pressed(KEY_DOWN):
		kb.y += 1.0
	if kb.length() > 0.05:
		player.move_input = kb.normalized()
	if Input.is_key_pressed(KEY_CTRL):
		player.fire_held = true


func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo:
		var k = (event as InputEventKey).keycode
		match k:
			KEY_ESCAPE:
				toggle_pause()
			KEY_E:
				player.dash()
			KEY_Q:
				player.next_weapon()
			KEY_G:
				player.throw_grenade()
			KEY_T:
				player.cycle_nade(1)
			KEY_F:
				player.use_ability()
			KEY_R:
				player.start_reload()
			KEY_B:
				hud.toggle_build()
			KEY_SPACE:
				if state == "prep":
					start_wave()
			KEY_1, KEY_2, KEY_3, KEY_4:
				player.select_slot(k - KEY_1)
			_:
				pass


# ================================================================ waves
func start_wave() -> void:
	if state == "fight" or state == "over":
		return
	wave += 1
	state = "fight"
	# v4.1: the wave scales with the wave number AND with how strong the
	# survivor actually is (pressure_mul). Player damage is multiplicative, so a
	# purely wave-based curve is always outrun by a good build - that is exactly
	# what the testers ran into around wave 30.
	wave_hp = GameData.wave_hp_mul(wave) * Settings.diff_hp() \
			* GameData.pressure_mul(player.level)
	wave_spd = GameData.wave_speed_mul(wave) * Settings.diff_speed()
	to_spawn = int(round(float(GameData.wave_count(wave)) * Settings.diff_count()))
	player.on_wave_start()
	spawn_t = 0.35
	prep_time = 0.0
	event_id = _roll_event()
	_apply_event_visuals()
	# Bandolier resupply between waves, into the type the player is carrying
	if player.lvl("grenades") > 0:
		player.add_grenades(player.lvl("grenades"))
	hud.hide_overlays()
	hud.on_wave_start(wave, event_id)
	Audio.play("siren", -12.0)
	if GameData.is_boss_wave(wave):
		Music.play("boss", 1.0)
		for i in range(GameData.boss_count(wave)):
			_spawn_boss()
		_spawn_escort(GameData.boss_escort(wave))
	else:
		Music.play("battle", 1.0)
		# a champion keeps the four waves between bosses from being a stroll
		if randf() < GameData.champion_chance(wave):
			_spawn_champion()
	if wave % 2 == 0:
		_schedule_airdrop()


func _roll_event() -> String:
	if wave < 3:
		return "none"
	var total = 0
	for e in GameData.EVENTS:
		total += int(e.get("weight", 1))
	var pick = randi() % maxi(1, total)
	for e in GameData.EVENTS:
		pick -= int(e.get("weight", 1))
		if pick < 0:
			return String(e.get("id", "none"))
	return "none"


func _apply_event_visuals() -> void:
	match event_id:
		"night":
			night.color = Color(0.42, 0.46, 0.62)
		"fog":
			night.color = Color(0.72, 0.85, 0.7)
		_:
			night.color = Color(1, 1, 1)


func _spawn_step(delta: float) -> void:
	spawn_t -= delta
	if to_spawn > 0 and spawn_t <= 0.0:
		if zombies.size() < GameData.alive_cap(wave, Settings.max_alive()):
			_spawn_zombie()
			to_spawn -= 1
			var rate = GameData.spawn_interval(wave) * Settings.diff_rate()
			if event_id == "horde":
				rate *= 0.55
			spawn_t = rate * randf_range(0.7, 1.25)
		else:
			spawn_t = 0.25
	if to_spawn <= 0 and zombies.is_empty():
		_end_wave()


func _end_wave() -> void:
	state = "prep"
	boss = null
	night.color = Color(1, 1, 1)
	build_kind = ""
	var reward = int(round(float(GameData.wave_reward(wave)) * Settings.diff_cash()))
	cash += reward
	score += wave * 120
	prep_time = GameData.INTERMISSION_TIME
	hud.show_prep(prep_time)
	hud.flash_banner(UI.tr_f("WAVE %d CLEARED  +$%d", [wave, reward]), UI.GOLD)
	Audio.play("levelup", -6.0)
	Music.play("battle", 2.0)
	# structures patch themselves up a little, then age by one wave
	for i in range(structures.size() - 1, -1, -1):
		var s = structures[i]
		if s != null and is_instance_valid(s) and not s.dead:
			s.on_wave_end(0.2)
	# tell the player which buildings are on their last wave instead of letting
	# them vanish without warning
	var dying = 0
	for s in structures:
		if s != null and is_instance_valid(s) and not s.dead and s.waves_left <= 1:
			dying += 1
	hud.set_wear_warning(dying)
	_cleanup()
	# a small grenade resupply every wave, Bandolier makes it bigger
	player.add_grenades(1 + player.lvl("grenades"))
	# a free supply pick every third wave keeps the build going even when the
	# level ups slow down
	if wave % 3 == 0:
		offer_upgrades()
	autosave()


func _pick_type() -> String:
	var pool: Array = []
	var total = 0
	for id in GameData.ZOMBIES.keys():
		var d: Dictionary = GameData.ZOMBIES[id]
		if wave < int(d.get("min_wave", 1)):
			continue
		if id == GameData.BOSS_TYPE and not GameData.is_boss_wave(wave):
			if wave < 12:
				continue
		var w = int(d.get("weight", 10))
		if event_id == "runners" and String(d.get("behavior", "walk")) == "walk":
			w = int(float(w) * 0.5)
		if event_id == "runners" and id == "z_runner":
			w *= 4
		if event_id == "fog" and String(d.get("behavior", "")) == "spit":
			w *= 3
		if w <= 0:
			continue
		pool.append({"id": id, "w": w})
		total += w
	if pool.is_empty():
		return "z_walker"
	var pick = randi() % maxi(1, total)
	for p in pool:
		pick -= int(p["w"])
		if pick < 0:
			return String(p["id"])
	return "z_walker"


func _spawn_zombie() -> void:
	var type = _pick_type()
	var elite = ""
	var chance = GameData.elite_chance(wave) + (0.35 if event_id == "elites" else 0.0)
	if randf() < chance:
		elite = String(GameData.ELITE_ORDER[randi() % GameData.ELITE_ORDER.size()])
	var hp_mul = wave_hp * (0.65 if event_id == "horde" else 1.0)
	var spd = wave_spd * (1.35 if event_id == "runners" else 1.0)
	var z = Zombie.new()
	entities.add_child(z)
	z.global_position = _spawn_pos()
	z.setup(self, type, hp_mul, spd, elite, false,
			GameData.wave_armor(wave) * Settings.diff_armor(),
			GameData.wave_dmg_mul(wave))
	zombies.append(z)


func _spawn_boss() -> void:
	var z = Zombie.new()
	entities.add_child(z)
	z.global_position = _spawn_pos()
	z.setup(self, GameData.BOSS_TYPE, wave_hp, wave_spd * 0.85, "", true,
			GameData.wave_armor(wave) * Settings.diff_armor(),
			GameData.wave_dmg_mul(wave),
			GameData.boss_hp_mul(wave) * Settings.diff_boss(),
			GameData.boss_dmg_mul(wave) * (1.0 + (Settings.diff_boss() - 1.0) * 0.4),
			GameData.boss_armor(wave) * Settings.diff_armor())
	zombies.append(z)
	boss = z
	hud.flash_banner("BOSS INCOMING", UI.RED)
	Audio.play("roar", -2.0)
	Music.duck(-6.0, 0.5)
	shake(6.0)


func _spawn_escort(count: int) -> void:
	## Elite bodyguards that walk in with the boss. No more kiting a lone boss
	## around an empty street for two minutes.
	for i in range(count):
		var elite = String(GameData.ELITE_ORDER[i % GameData.ELITE_ORDER.size()])
		var z = Zombie.new()
		entities.add_child(z)
		z.global_position = _spawn_pos()
		z.setup(self, "z_cop" if i % 2 == 0 else "z_brute", wave_hp, wave_spd, elite, false,
				GameData.wave_armor(wave) * Settings.diff_armor(),
				GameData.wave_dmg_mul(wave))
		zombies.append(z)


func _spawn_champion() -> void:
	## Mini-boss on a normal wave: a brute-class body with champion stats, no
	## boss health bar, real threat.
	var z = Zombie.new()
	entities.add_child(z)
	z.is_champion = true
	z.global_position = _spawn_pos()
	var type = "z_brute" if wave >= 14 else "z_cop"
	z.setup(self, type, wave_hp, wave_spd * 0.95,
			String(GameData.ELITE_ORDER[randi() % GameData.ELITE_ORDER.size()]), false,
			GameData.wave_armor(wave) * Settings.diff_armor(),
			GameData.wave_dmg_mul(wave))
	zombies.append(z)
	hud.flash_banner(UI.tr_ui("CHAMPION SPOTTED"), UI.GOLD)
	Audio.play("roar", -8.0, 1.15)


func spawn_boss_adds(from_boss, count: int) -> void:
	## A boss entering a rage phase screams in reinforcements around itself.
	## Hard capped by the alive budget so a phone never melts.
	if from_boss == null or not is_instance_valid(from_boss):
		return
	var budget = GameData.alive_cap(wave, Settings.max_alive()) - zombies.size()
	var n = mini(count, maxi(0, budget))
	for i in range(n):
		var z = Zombie.new()
		entities.add_child(z)
		var pool = ["z_runner", "z_crawler", "z_walker", "z_worker"]
		if wave >= 20:
			pool.append("z_cop")
		var type = String(pool[randi() % pool.size()])
		var side = -1.0 if randf() < 0.5 else 1.0
		z.global_position = Vector2(
				clampf(from_boss.global_position.x + side * randf_range(40.0, 130.0),
						GameData.play_left() + 6.0, GameData.play_right() - 6.0),
				GameData.spawn_y(0.34, 0.92))
		z.setup(self, type, wave_hp * 0.8, wave_spd * 1.1, "", false,
				GameData.wave_armor(wave) * Settings.diff_armor(),
				GameData.wave_dmg_mul(wave))
		zombies.append(z)
		fx.smoke(z.global_position + Vector2(0, -6), 3, Color(0.4, 0.5, 0.4, 0.5))


func _spawn_pos() -> Vector2:
	var half = visible_half_w() + SPAWN_MARGIN
	var side = 1.0 if randf() < 0.5 else -1.0
	var x = player.global_position.x + side * (half + randf_range(0.0, 90.0))
	if x < GameData.play_left() + 8.0 or x > GameData.play_right() - 8.0:
		x = player.global_position.x - side * (half + randf_range(0.0, 90.0))
	x = clampf(x, GameData.play_left() + 6.0, GameData.play_right() - 6.0)
	return Vector2(x, GameData.spawn_y(0.34, 0.92))


# ================================================================ rewards
func on_zombie_died(z, overkill: float) -> void:
	# Chain Reaction: a corpse killed while Explosive Rounds are in play goes off
	# like a bloater. Great crowd tech, and it does NOT scale off boss HP.
	if player != null and is_instance_valid(player) and player.lvl("chainblast") > 0:
		var n = player.lvl("chainblast")
		if randf() < 0.20 + 0.12 * float(n):
			var pow_ = (34.0 + 16.0 * float(n)) * GameData.player_power(player.level)
			explode(z.hit_center(), 44.0 + 6.0 * float(n), pow_, true, 0.7, 0.35)
	kills += 1
	_hap_kills += 1
	_hap_window = 0.32
	combo += 1
	combo_t = COMBO_TIME
	var mul = combo_mul()
	var money = int(round(float(z.cash) * mul * cash_mul() * GameData.cash_wave_mul(wave)
			* Settings.diff_cash()))
	if event_id == "bounty":
		money *= 2
	cash += money
	score += int(round(float(z.cash) * 12.0 * mul))
	add_xp(int(round(float(z.xp) * xp_mul() * GameData.xp_wave_mul(wave) * Settings.diff_xp())))
	player.on_kill(z)
	if z == boss:
		boss = null
		hitstop(0.16)
		if player != null and is_instance_valid(player):
			kick(z.hit_center().direction_to(player.global_position), 8.0)
		else:
			shake(7.0)
		zoom_punch(0.8)
		haptic(150)
		hud.flash_banner("BOSS DOWN", UI.GOLD)
		fx.big_text(z.hit_center(), "+$%d" % money, UI.GOLD)
		Music.play("battle", 1.5)
	elif combo > 0 and combo % 15 == 0:
		fx.big_text(z.hit_center(), UI.tr_f("x%d COMBO", [combo]), UI.GOLD)
	var drop_p = GameData.drop_chance(wave) * (1.0 + 0.5 * float(player.lvl("scav")))
	if z.is_boss:
		drop_p = 1.0
	if randf() < drop_p:
		_drop_pickup(z.global_position)


func combo_mul() -> float:
	return clampf(1.0 + float(combo) * 0.010, 1.0, 1.5)


func cash_mul() -> float:
	return 1.0 + 0.20 * float(player.lvl("greed")) + 0.1 * float(player.lvl("magnet"))


func xp_mul() -> float:
	return 1.0 + 0.25 * float(player.lvl("xp"))


func add_xp(amount: int) -> void:
	player.xp += amount
	# Bounded on purpose: a single frame can never grant more than 24 levels, and
	# if xp_to_next() ever returned 0 an unbounded while here would hard-freeze
	# the game on a black frame. Twenty-four is far past any real XP dump.
	for _i in range(24):
		if player.xp < player.xp_next or player.xp_next <= 0:
			break
		player.xp -= player.xp_next
		player.level += 1
		# polynomial, not exponential: level 66 costs ~2k XP, not 90 million
		player.xp_next = GameData.xp_to_next(player.level)
		# bigger health pool + a real heal, so the survivor scales with the horde
		player.on_level_up()
		offer_upgrades()


func offer_upgrades() -> void:
	var pool: Array = []
	for u in GameData.UPGRADES:
		var id = String(u["id"])
		if player.lvl(id) >= int(u.get("max", 5)):
			continue
		var tier = int(u.get("tier", 1))
		if tier == 2 and player.level < 4:
			continue
		if tier == 3 and player.level < 9:
			continue
		pool.append(u)
	pool.shuffle()
	var picks: Array = []
	var want = 3 if player.level < 12 else 4
	for i in range(mini(want, pool.size())):
		picks.append(pool[i])
	if picks.is_empty():
		return
	Audio.play("levelup", -6.0)
	Engine.time_scale = 1.0
	hud.show_upgrades(picks)
	get_tree().paused = true


func pick_upgrade(id: String) -> void:
	player.add_upgrade(id)
	get_tree().paused = false
	hud.hide_overlays()
	Audio.play("coin", -8.0)


# ================================================================ pickups / crates
func _roll_drop() -> String:
	var total = 0
	for dd in GameData.DROPS:
		total += int(dd.get("weight", 1))
	var pick = randi() % maxi(1, total)
	for dd in GameData.DROPS:
		pick -= int(dd.get("weight", 1))
		if pick < 0:
			return String(dd.get("id", "cash"))
	return "cash"


func _drop_pickup(pos: Vector2) -> void:
	var kind = _roll_drop()
	var s = Sprite2D.new()
	match kind:
		"ammo":
			s.texture = Art.fx_tex("bullet_big")
			s.scale = Vector2.ONE * 2.2
			s.modulate = Color(0.7, 0.9, 1.0)
		"nades":
			s.texture = Art.fx_tex("rocket")
			s.scale = Vector2.ONE * 1.3
			s.modulate = Color(0.85, 1.0, 0.75)
		"medkit":
			s.texture = Art.fx_tex("medkit")
		_:
			s.texture = Art.fx_tex("cash")
	s.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	s.position = pos + Vector2(0, -4)
	s.z_index = 3
	world.add_child(s)
	crates.append(s)
	s.set_meta("loot", kind)
	s.set_meta("crate", false)
	var tw = create_tween()
	tw.tween_property(s, "position", s.position + Vector2(0, -5), 0.4)
	tw.tween_property(s, "position", s.position, 0.4)
	tw.set_loops(20)


func _schedule_airdrop() -> void:
	var tmr = get_tree().create_timer(randf_range(8.0, 18.0))
	tmr.timeout.connect(_spawn_airdrop)


func _spawn_airdrop() -> void:
	if state != "fight":
		return
	var x = clampf(player.global_position.x + randf_range(-140.0, 140.0), 30.0, GameData.ARENA_W - 30.0)
	var target = Vector2(x, randf_range(GameData.BAND_TOP + 10.0, GameData.BAND_BOT - 6.0))
	var s = Sprite2D.new()
	s.texture = Art.fx_tex("crate")
	s.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	s.position = target - Vector2(0, 220.0)
	s.scale = Vector2.ONE * 1.4
	s.z_index = 7
	world.add_child(s)
	crates.append(s)
	s.set_meta("crate", true)
	s.set_meta("loot", _roll_loot())
	Audio.play("horn", -8.0)
	hud.flash_banner("AIRDROP INBOUND", UI.BLUE)
	var tw = create_tween()
	tw.tween_property(s, "position", target, 1.9).set_ease(Tween.EASE_IN)
	tw.tween_callback(func() -> void:
		if is_instance_valid(s):
			fx.smoke(s.position, 8, Color(0.55, 0.5, 0.45, 0.7))
			shake(2.0)
			Audio.play("thud", -8.0))


func _roll_loot() -> String:
	var total = 0
	for l in GameData.CRATE_LOOT:
		total += int(l.get("weight", 1))
	var pick = randi() % maxi(1, total)
	for l in GameData.CRATE_LOOT:
		pick -= int(l.get("weight", 1))
		if pick < 0:
			return String(l.get("id", "cash"))
	return "cash"


func _collect(node: Sprite2D) -> void:
	var loot = String(node.get_meta("loot", "cash"))
	match loot:
		"cash":
			var money = 40 + wave * 8
			cash += money
			fx.float_text(node.position, "+$%d" % money, UI.GOLD)
			Audio.play("coin", -8.0)
		"ammo":
			if node.get_meta("crate", false):
				player.refill_ammo()
				fx.float_text(node.position, "AMMO FULL", UI.BLUE)
			else:
				player.add_ammo_fraction(0.35)
				fx.float_text(node.position, "+AMMO", UI.BLUE)
			Audio.play("reload", -8.0)
		"heal", "medkit":
			var amount = maxf(45.0, player.max_hp * 0.35)
			player.heal(amount)
			fx.float_text(node.position, UI.tr_f("+%d HP", [int(amount)]), UI.GREEN)
			Audio.play("heal", -8.0)
		"nades":
			player.add_grenades(3)
			fx.float_text(node.position, "+3 GRENADES", UI.BONE)
			Audio.play("click", -8.0)
		"rage":
			player.give_rage(9.0)
			Audio.play("levelup", -8.0)
		"weapon":
			var order: Array = GameData.SHOP_ORDER
			var pool: Array = []
			for cand in order:
				if weapon_unlocked(String(cand)) and not player.owns(String(cand)):
					pool.append(cand)
			if pool.is_empty():
				pool = order.duplicate()
			var id = String(pool[randi() % pool.size()])
			if player.add_weapon(id):
				fx.big_text(node.position, UI.tr_ui(String(GameData.WEAPONS[id].get("name", id))), UI.BLUE)
			Audio.play("coin", -6.0)
		_:
			cash += 40
	if node.get_meta("crate", false):
		Audio.play("crate", -8.0)
		fx.smoke(node.position, 6, Color(0.6, 0.55, 0.5, 0.7))
	node.queue_free()


# ================================================================ combat helpers
func _rebuild_grid() -> void:
	_grid.clear()
	for z in zombies:
		if z == null or not is_instance_valid(z) or z.dead:
			continue
		var key = int(floor(z.global_position.x / GRID_CELL))
		if not _grid.has(key):
			_grid[key] = []
		(_grid[key] as Array).append(z)
	# pickup magnet / collection
	if player != null and is_instance_valid(player) and not player.dead:
		var reach = 30.0 if player.lvl("magnet") > 0 else 13.0
		for c in crates:
			if c == null or not is_instance_valid(c):
				continue
			if c.position.distance_to(player.global_position + Vector2(0, -8)) < reach:
				_collect(c)


func get_zombies() -> Array:
	return zombies


func get_structures() -> Array:
	return structures


func zombies_near(pos: Vector2, r: float) -> Array:
	var out: Array = []
	var c0 = int(floor((pos.x - r) / GRID_CELL))
	var c1 = int(floor((pos.x + r) / GRID_CELL))
	for c in range(c0, c1 + 1):
		if not _grid.has(c):
			continue
		for z in (_grid[c] as Array):
			if z == null or not is_instance_valid(z) or z.dead:
				continue
			if absf(z.global_position.y - pos.y) > r + 44.0:
				continue
			out.append(z)
	return out


func nearest_zombie(pos: Vector2, max_range: float = 400.0):
	## Grid based, so a 70 body horde does not cost an O(n) scan per shot.
	var best = null
	var best_d = max_range * max_range
	for z in zombies_near(pos, max_range):
		if z.dead:
			continue
		var d: float = pos.distance_squared_to(z.hit_center())
		if d < best_d:
			best_d = d
			best = z
	return best


func best_target(pos: Vector2, max_range: float = 400.0):
	## Like nearest_zombie, but a boss or an elite standing a bit further away
	## wins over the nearest trash walker. Used by turrets, allies and auto-aim.
	var best = null
	var best_score = -1.0
	for z in zombies_near(pos, max_range):
		if z.dead:
			continue
		var dist: float = pos.distance_to(z.hit_center())
		if dist > max_range:
			continue
		var score: float = (1.0 - dist / max_range) * 100.0 + minf(z.threat() * 0.03, 60.0)
		if score > best_score:
			best_score = score
			best = z
	return best


func best_cluster(pos: Vector2, max_range: float, blast: float) -> Vector2:
	## Where a grenade should land: the spot that catches the most (and the
	## meanest) bodies, instead of the closest scrub at the edge of the screen.
	var cands: Array = zombies_near(pos, max_range)
	var best_pos = Vector2.ZERO
	var best_score = 0.0
	for z in cands:
		if z.dead:
			continue
		var c: Vector2 = z.hit_center()
		if pos.distance_to(c) > max_range:
			continue
		var score = 0.0
		for o in cands:
			if o.dead:
				continue
			if c.distance_to(o.hit_center()) <= blast:
				score += 1.0 + minf(o.threat() * 0.004, 3.0)
		if score > best_score:
			best_score = score
			best_pos = c
	return best_pos


func nearest_structure(pos: Vector2, max_range: float = 60.0):
	var best = null
	var best_d = max_range * max_range
	for s in structures:
		if s == null or not is_instance_valid(s) or s.dead:
			continue
		if not s.is_target_for_horde():
			continue
		var d: float = pos.distance_squared_to(s.aggro_point())
		if d < best_d:
			best_d = d
			best = s
	return best


func structure_in_front(pos: Vector2, dir_x: float, reach: float) -> Structure:
	if dir_x == 0.0:
		return null
	var best = null
	var best_dx = reach
	for s in structures:
		if s == null or not is_instance_valid(s) or s.dead:
			continue
		if String(s.kind) == "mine" or String(s.kind) == "spikes":
			continue
		var dx: float = (s.global_position.x - pos.x) * dir_x
		if dx < 0.0 or dx > reach:
			continue
		if absf(s.global_position.y - pos.y) > 15.0:
			continue
		if dx < best_dx:
			best_dx = dx
			best = s
	return best


func structure_power() -> float:
	if player == null or not is_instance_valid(player):
		return 1.0
	return 1.0 + 0.25 * float(player.lvl("turretdmg"))


func structure_rate() -> float:
	if player == null or not is_instance_valid(player):
		return 1.0
	return 1.0 + 0.20 * float(player.lvl("turretrate"))


func count_structures(kind: String) -> int:
	var c = 0
	for s in structures:
		if s != null and is_instance_valid(s) and not s.dead and String(s.kind) == kind:
			c += 1
	return c


func spawn_bullet(pos: Vector2, dir: Vector2, cfg: Dictionary) -> void:
	if _bullets.is_empty():
		return
	var b = _bullets.pop_back()
	b.launch(self, pos, dir, cfg)


func recycle_bullet(b) -> void:
	if not _bullets.has(b):
		_bullets.append(b)


func hitscan(from: Vector2, dir: Vector2, max_range: float, dmg: float, pierce: int,
		knock: float, crit_chance: float, crit_mul: float,
		color: Color = Color(0.7, 0.95, 1.0), ap: float = 0.0) -> void:
	var d = dir.normalized()
	var hits: Array = []
	for z in zombies:
		if z == null or not is_instance_valid(z) or z.dead:
			continue
		var c: Vector2 = z.hit_center()
		var to: Vector2 = c - from
		var along: float = to.dot(d)
		if along < 0.0 or along > max_range:
			continue
		var perp: float = absf(to.cross(d))
		if perp > z.radius + 7.0:
			continue
		hits.append({"z": z, "t": along})
	hits.sort_custom(func(a, b): return float(a["t"]) < float(b["t"]))
	var end = from + d * max_range
	var used = 0
	for h in hits:
		if used > pierce:
			break
		var z = h["z"]
		var at: Vector2 = from + d * float(h["t"])
		var crit = randf() < crit_chance
		z.take_hit(dmg * (crit_mul if crit else 1.0), d * knock, crit, at, ap)
		if used == pierce:
			end = at
		used += 1
	_beam(from, end, color)
	fx.sparks(end, -d)


func _beam(a: Vector2, b: Vector2, color: Color) -> void:
	if _beams.is_empty():
		return
	var l: Line2D = _beams.pop_front()
	_beams.append(l)
	l.points = PackedVector2Array([a, b])
	l.default_color = color
	l.width = 2.6
	l.visible = true
	l.modulate = Color(1, 1, 1, 1)
	var tw = create_tween()
	tw.tween_property(l, "modulate:a", 0.0, 0.12)
	tw.tween_callback(func() -> void: l.visible = false)


func chain_lightning(from: Vector2, count: int, dmg: float, max_range: float,
		from_player: bool = true, ap: float = 0.30) -> void:
	var pos = from
	var hit_ids: Dictionary = {}
	for i in range(count):
		var best = null
		var best_d = max_range * max_range
		for z in zombies:
			if z == null or not is_instance_valid(z) or z.dead:
				continue
			if hit_ids.has(z.get_instance_id()):
				continue
			var d: float = pos.distance_squared_to(z.hit_center())
			if d < best_d:
				best_d = d
				best = z
		if best == null:
			break
		hit_ids[best.get_instance_id()] = true
		var at: Vector2 = best.hit_center()
		_beam(pos, at, Color(0.6, 0.85, 1.0))
		best.take_hit(dmg, (at - pos).normalized() * 40.0, false, at, ap)
		best.stagger(0.25)
		fx.sparks(at, Vector2.UP)
		pos = at
	Audio.play("zap", -10.0, randf_range(0.95, 1.1), 0.02)


func explode(pos: Vector2, radius: float, dmg: float, from_player: bool = true,
		scale: float = 1.0, ap: float = 0.35) -> void:
	fx.explosion(pos, scale)
	fx.shockwave(pos, radius, Color(1.0, 0.8, 0.45, 0.55))
	var caught = 0
	for z0 in zombies_near(pos, radius):
		if not z0.dead:
			caught += 1
	if player != null and is_instance_valid(player):
		kick(pos.direction_to(player.global_position + Vector2(0, -10)),
				(3.2 + minf(float(caught), 10.0) * 0.45) * scale)
	else:
		shake(3.5 * scale)
	zoom_punch(0.35 * scale + 0.03 * minf(float(caught), 8.0))
	if caught >= 3:
		haptic(30 + caught * 8)
	hitstop(0.05 if caught < 5 else 0.09)
	Audio.play("explosion", -4.0, randf_range(0.92, 1.08))
	Music.duck(-4.0, 0.3)
	for z in zombies_near(pos, radius + 20.0):
		if z.dead:
			continue
		var dist: float = pos.distance_to(z.hit_center())
		if dist > radius:
			continue
		var falloff: float = 1.0 - clampf(dist / radius, 0.0, 1.0) * 0.55
		z.take_hit(dmg * falloff, (z.hit_center() - pos).normalized() * 120.0, false,
				z.hit_center(), ap)
	if not from_player and player != null and is_instance_valid(player):
		var pd: float = pos.distance_to(player.global_position + Vector2(0, -10))
		if pd < radius:
			player.take_damage(dmg * 0.5 * (1.0 - pd / radius), pos)
	for s in structures:
		if s == null or not is_instance_valid(s) or s.dead:
			continue
		if pos.distance_to(s.global_position) < radius and not from_player:
			s.take_structure_damage(dmg * 0.4, "blast")


func _tick_camera_feel(delta: float) -> void:
	## Trauma-based shake: quadratic falloff so the tail is soft, three
	## frequencies so it never sounds like a buzz, plus a directional kick and a
	## tiny roll. A punch on the zoom sells big blasts without moving the world.
	var m = Settings.shake_mul()
	_zoom_punch = maxf(0.0, _zoom_punch - delta * 2.6)
	cam.zoom = Vector2.ONE * Settings.zoom() * (1.0 - _zoom_punch * 0.06 * minf(m, 1.0))
	if _shake <= 0.002 or m <= 0.0:
		_shake = 0.0
		_shake_dir = _shake_dir.lerp(Vector2.ZERO, clampf(delta * 10.0, 0.0, 1.0))
		cam.offset = cam.offset.lerp(Vector2.ZERO, clampf(delta * 12.0, 0.0, 1.0))
		cam.rotation = lerpf(cam.rotation, 0.0, clampf(delta * 12.0, 0.0, 1.0))
		return
	_shake_t += delta
	# exponential-ish decay: strong hits ring longer than taps
	_shake = maxf(0.0, _shake - delta * (1.35 + _shake * 2.4))
	var t = _shake * _shake
	var w = _shake_t * 44.0
	var ox = sin(w) * 0.55 + sin(w * 1.83 + 1.7) * 0.3 + sin(w * 3.1 + 0.4) * 0.15
	var oy = sin(w * 0.91 + 2.4) * 0.5 + sin(w * 2.17 + 0.9) * 0.28
	cam.offset = (Vector2(ox, oy * 0.62) * (t * 16.0) + _shake_dir * (t * 13.0)) * m
	_shake_dir = _shake_dir.lerp(Vector2.ZERO, clampf(delta * 5.5, 0.0, 1.0))
	cam.rotation = deg_to_rad(sin(w * 0.77) * t * 1.05 * minf(m, 1.0))


func _tick_haptics(delta: float) -> void:
	if _hap_window <= 0.0:
		return
	_hap_window = maxf(0.0, _hap_window - delta)
	if _hap_window > 0.0:
		return
	# window closed: one buzz whose length scales with how big the wipe was
	if _hap_kills >= 3:
		Settings.vibrate(clampi(22 + _hap_kills * 7, 22, 130))
	_hap_kills = 0


func haptic(ms: int) -> void:
	Settings.vibrate(clampi(ms, 8, 220))


func shake(amount: float) -> void:
	## Old call sites pass 0..12 "pixels"; that maps onto trauma so every
	## existing hit, blast and stomp keeps its relative weight.
	_shake = minf(_shake + amount / 11.0, 1.0)


func kick(dir: Vector2, amount: float) -> void:
	## Directional punch - used for explosions and boss stomps so the camera is
	## thrown away from the impact instead of jittering in place.
	shake(amount)
	if dir.length() > 0.01:
		_shake_dir = (_shake_dir + dir.normalized() * clampf(amount / 8.0, 0.0, 1.2)).limit_length(1.4)


func zoom_punch(amount: float) -> void:
	_zoom_punch = minf(_zoom_punch + amount, 1.0)


func hitstop(seconds: float) -> void:
	if Settings.quality() == 0:
		return
	_hitstop_until = maxi(_hitstop_until, Time.get_ticks_msec() + int(seconds * 1000.0))
	Engine.time_scale = 0.32


# ================================================================ building / shop
func can_build(kind: String) -> bool:
	## Cash AND the per-kind limit AND the global cap all have to allow it.
	if not GameData.BUILDINGS.has(kind):
		return false
	if cash < int(GameData.BUILDINGS[kind].get("price", 99999)):
		return false
	if count_structures(kind) >= GameData.structure_limit(kind):
		return false
	if structures.size() >= GameData.BUILD_TOTAL_LIMIT:
		return false
	return true


func build_spot(world_pos: Vector2) -> Vector2:
	return Vector2(clampf(world_pos.x, GameData.play_left(), GameData.play_right()),
			clampf(world_pos.y, GameData.BAND_TOP + 4.0, GameData.BAND_BOT))


func build_valid_at(pos: Vector2) -> bool:
	## Used both by place_build and by the live placement ghost, so what you see
	## is exactly what the game will accept.
	if pos.x < GameData.play_left() or pos.x > GameData.play_right():
		return false
	if pos.y < GameData.BAND_TOP + 2.0 or pos.y > GameData.BAND_BOT + 1.0:
		return false
	for s in structures:
		if s == null or not is_instance_valid(s) or s.dead:
			continue
		if s.global_position.distance_to(pos) < GameData.BUILD_SPACING:
			return false
	return true


func select_build(kind: String) -> void:
	build_kind = kind


func structure_life_for(kind: String) -> int:
	## How many waves a structure of this kind would survive if placed right now,
	## Field Repairs included. This is the number the build bar shows.
	var extra = 0
	if player != null and is_instance_valid(player):
		extra = int(player.lvl("structlife"))
	return GameData.structure_life(kind) + maxi(0, extra)


func place_build(world_pos: Vector2) -> bool:
	if build_kind == "" or not GameData.BUILDINGS.has(build_kind):
		return false
	var price = int(GameData.BUILDINGS[build_kind].get("price", 100))
	if cash < price:
		return _deny("NOT ENOUGH CASH")
	if count_structures(build_kind) >= GameData.structure_limit(build_kind):
		return _deny(UI.tr_f("LIMIT %d REACHED", [GameData.structure_limit(build_kind)]))
	if structures.size() >= GameData.BUILD_TOTAL_LIMIT:
		return _deny("FIELD IS FULL")
	var pos = build_spot(world_pos)
	if not build_valid_at(pos):
		return _deny("TOO CLOSE")
	cash -= price
	_place_structure(build_kind, pos, 0)
	fx.smoke(pos, 5, Color(0.6, 0.55, 0.5, 0.6))
	Audio.play("build", -8.0)
	return true


func weapon_unlocked(id: String) -> bool:
	## Guns show up in the market as the run gets deeper AND as the survivor
	## levels up, so wave 1 cash can never buy a railgun.
	var w: Dictionary = GameData.WEAPONS.get(id, {})
	if maxi(1, wave) < int(w.get("unlock", 1)):
		return false
	if player != null and is_instance_valid(player):
		if player.level < int(w.get("unlock_level", 1)):
			return false
	return true


func weapon_lock_reason(id: String) -> String:
	var w: Dictionary = GameData.WEAPONS.get(id, {})
	if maxi(1, wave) < int(w.get("unlock", 1)):
		return "WAVE %d" % int(w.get("unlock", 1))
	if player != null and is_instance_valid(player) and player.level < int(w.get("unlock_level", 1)):
		return "LVL %d" % int(w.get("unlock_level", 1))
	return ""


func weapon_price(id: String) -> int:
	return int(GameData.WEAPONS.get(id, {}).get("price", 99999))


func sell_price(id: String) -> int:
	return int(round(float(weapon_price(id)) * GameData.SELL_REFUND))


func ammo_price(id: String) -> int:
	## Only pay for the rounds that are actually missing.
	var full = player.max_reserve(id)
	if full <= 0:
		return 0
	var missing = float(full - player.reserve_ammo(id)) / float(full)
	if missing <= 0.001:
		return 0
	return maxi(10, int(round(float(GameData.WEAPONS[id].get("ammo_price", 100)) * missing)))


func refill_all_price() -> int:
	var total = 0
	for w in player.weapons:
		total += ammo_price(String(w))
	return total


func heal_price() -> int:
	var missing = clampf(1.0 - player.hp / maxf(1.0, player.max_hp), 0.0, 1.0)
	return maxi(0, int(round(float(GameData.MEDKIT_PRICE) * missing)))


func _deny(reason: String) -> bool:
	## flash_banner translates plain keys itself, so both "NOT ENOUGH CASH" and
	## an already formatted "LIMIT 4 REACHED" come out right.
	hud.flash_banner(reason, UI.RED)
	Audio.play("empty", -10.0)
	return false


func buy_weapon(id: String) -> bool:
	var w: Dictionary = GameData.WEAPONS.get(id, {})
	if w.is_empty():
		return false
	if player.owns(id):
		return _deny("ALREADY OWNED")
	if not weapon_unlocked(id):
		return _deny("LOCKED - NEEDS %s" % weapon_lock_reason(id))
	if player.weapons.size() >= Player.MAX_WEAPONS:
		return _deny("SELL A WEAPON FIRST")
	var price = weapon_price(id)
	if cash < price:
		return _deny("NOT ENOUGH CASH")
	cash -= price
	player.add_weapon(id)
	Audio.play("coin", -6.0)
	hud.flash_banner(UI.tr_f("%s ACQUIRED", [UI.tr_ui(String(w.get("name", id)))]), UI.GOLD)
	return true


func sell_weapon(id: String) -> bool:
	if not player.owns(id):
		return false
	var refund = sell_price(id)
	if not player.drop_weapon(id):
		return _deny("YOU NEED A GUN")
	cash += refund
	Audio.play("coin", -8.0)
	hud.flash_banner(UI.tr_f("SOLD  +$%d", [refund]), UI.GOLD)
	return true


func buy_ammo(id: String) -> bool:
	var price = ammo_price(id)
	if price <= 0:
		return _deny("AMMO IS FULL")
	if cash < price:
		return _deny("NOT ENOUGH CASH")
	cash -= price
	player.fill_reserve(id)
	Audio.play("reload", -8.0)
	return true


func buy_ammo_all() -> bool:
	var price = refill_all_price()
	if price <= 0:
		return _deny("AMMO IS FULL")
	if cash < price:
		return _deny("NOT ENOUGH CASH")
	cash -= price
	player.refill_ammo()
	Audio.play("reload", -8.0)
	return true


func grenade_price(id: String = "") -> int:
	var key = id if id != "" else player.nade_type
	return int(GameData.grenade(key).get("price", GameData.GRENADE_PRICE))


func buy_grenade(id: String = "") -> bool:
	## Buys the selected grenade type. Locked types say why instead of taking
	## the money and giving nothing.
	var key = id if id != "" else player.nade_type
	if not GameData.grenade_unlocked(key, wave):
		return _deny(UI.tr_f("UNLOCKS ON WAVE %d",
				[int(GameData.grenade(key).get("unlock", 1))]))
	var price = grenade_price(key)
	if cash < price:
		return _deny("NOT ENOUGH CASH")
	var before = player.nade_count(key)
	player.add_nades(key, 1)
	if player.nade_count(key) == before:
		return _deny("GRENADE POUCH IS FULL")
	cash -= price
	Audio.play("coin", -8.0)
	return true


func plate_price() -> int:
	## Field plating: instant shield refill plus a temporary overshield for the
	## next fight. Only sold if the survivor actually runs the Riot Shield card.
	return 150 + 30 * wave


func buy_plate() -> bool:
	if player == null or not is_instance_valid(player):
		return false
	if player.lvl("shield") <= 0:
		return _deny("NO SHIELD EQUIPPED")
	var price = plate_price()
	if cash < price:
		return _deny("NOT ENOUGH CASH")
	cash -= price
	player.shield = player.shield_max() * 1.5
	player.shield_t = 0.0
	Audio.play("coin", -8.0)
	hud.flash_banner(UI.tr_ui("PLATING BOLTED ON"), UI.BLUE)
	hud.refresh()
	return true


func repair_price() -> int:
	return 90 + 18 * wave


func buy_repair() -> bool:
	## Patches every standing structure back to full and buys them one more wave
	## of life. Turret builds finally have a money sink.
	var live = 0
	for st in structures:
		if st != null and is_instance_valid(st) and not st.dead:
			live += 1
	if live <= 0:
		return _deny("NOTHING TO REPAIR")
	var price = repair_price()
	if cash < price:
		return _deny("NOT ENOUGH CASH")
	cash -= price
	for st in structures:
		if st != null and is_instance_valid(st) and not st.dead:
			st.on_wave_end(1.0)
			st.waves_left += 1
	Audio.play("build", -8.0)
	hud.flash_banner(UI.tr_f("%d STRUCTURES REPAIRED", [live]), UI.GREEN)
	hud.refresh()
	return true


func airdrop_price() -> int:
	return 320 + 40 * wave


func buy_airdrop() -> bool:
	## Calls a supply crate in on demand instead of praying for the wave timer.
	var price = airdrop_price()
	if cash < price:
		return _deny("NOT ENOUGH CASH")
	cash -= price
	_spawn_airdrop()
	Audio.play("siren", -14.0)
	hud.flash_banner(UI.tr_ui("AIRDROP INBOUND"), UI.GOLD)
	hud.refresh()
	return true


func buy_heal() -> bool:
	var price = heal_price()
	if price <= 0:
		return _deny("ALREADY AT FULL HP")
	if cash < price:
		return _deny("NOT ENOUGH CASH")
	cash -= price
	player.heal(player.max_hp)
	Audio.play("heal", -8.0)
	return true


func spawn_ally(kind: String) -> void:
	var a = Ally.new()
	entities.add_child(a)
	a.global_position = player.global_position + Vector2(randf_range(-20, 20), 0)
	a.setup(self, kind, 1.0 + 0.25 * float(player.level))
	allies.append(a)


# ================================================================ flow
func in_prep() -> bool:
	return state == "prep"


func is_over() -> bool:
	return state == "over"


func set_ghost(world_pos: Vector2) -> void:
	## Live placement preview, driven by the finger on screen.
	if ghost == null or build_kind == "":
		return
	ghost.show_at(build_spot(world_pos))


func ghost_spot() -> Vector2:
	if ghost == null:
		return Vector2.ZERO
	return ghost.spot


func ghost_active() -> bool:
	return ghost != null and ghost.active


func hide_ghost() -> void:
	if ghost != null:
		ghost.hide_ghost()


func zombies_left() -> int:
	return to_spawn + zombies.size()


func time_left() -> float:
	return maxf(0.0, prep_time)


func skip_prep() -> void:
	## "START NOW" button: jump straight into the wave.
	if state == "prep":
		start_wave()


func toggle_pause() -> void:
	if state == "over":
		return
	paused = not paused
	Engine.time_scale = 1.0
	get_tree().paused = paused
	if paused:
		if state == "prep":
			autosave()
		hud.show_pause()
	else:
		hud.hide_overlays()


func on_player_died() -> void:
	if state == "over":
		return
	state = "over"
	Engine.time_scale = 1.0
	var earned = Save.report_run(wave, kills, score)
	Save.set_run_live(false)
	# the run itself is gone, but a checkpoint from wave 15+ survives so a long
	# run is never wiped by one bad second
	Save.clear_run(true)
	Music.play("menu", 2.0)
	shake(8.0)
	hud.show_game_over(wave, kills, score, earned)


func restart() -> void:
	Engine.time_scale = 1.0
	get_tree().paused = false
	Save.pending_continue = false
	Save.pending_checkpoint = false
	Save.clear_run()
	get_tree().change_scene_to_file("res://Game.tscn")


func restart_from_checkpoint() -> void:
	## "CONTINUE FROM CHECKPOINT" on the death screen: reload the scene and let
	## _ready rebuild the snapshot.
	if not Save.has_checkpoint():
		restart()
		return
	Engine.time_scale = 1.0
	get_tree().paused = false
	Save.pending_checkpoint = true
	get_tree().change_scene_to_file("res://Game.tscn")


func save_and_exit() -> void:
	## Pause menu: bank the run, then drop to the main menu.
	autosave()
	return_to_menu()


func return_to_menu() -> void:
	Save.set_run_live(false)
	Settings.flush()
	Engine.time_scale = 1.0
	get_tree().paused = false
	get_tree().change_scene_to_file("res://Main.tscn")


# ================================================================ run saving
func serialize_run() -> Dictionary:
	## One flat snapshot of the whole run: wave, wallet, the survivor and every
	## thing they built or brought. This is what makes "continue" honest instead
	## of just remembering a wave number.
	var st: Array = []
	for s in structures:
		if s == null or not is_instance_valid(s) or s.dead:
			continue
		st.append({
			"kind": s.kind,
			"x": s.global_position.x,
			"y": s.global_position.y,
			"hp": s.hp,
			"waves_left": s.waves_left,
		})
	var al: Array = []
	for a in allies:
		if a != null and is_instance_valid(a) and not a.dead:
			al.append(a.kind)
	return {
		"wave": wave,
		"cash": cash,
		"kills": kills,
		"score": score,
		"run_time": run_time,
		"player": player.serialize() if player != null and is_instance_valid(player) else {},
		"structures": st,
		"allies": al,
	}


func autosave(force_checkpoint: bool = false) -> void:
	## Called between waves and when the game is paused in prep. Never during a
	## fight: a save taken mid wave would restore a half spawned horde.
	if state == "over" or player == null or not is_instance_valid(player) or player.dead:
		return
	if wave <= 0:
		return
	var snap = serialize_run()
	# Marked live: if the OS kills the app without warning, the next launch
	# comes straight back into this run.
	snap["live"] = true
	var cp = GameData.checkpoint_wave_for(wave)
	if force_checkpoint or (cp > 0 and wave == cp):
		Save.save_checkpoint(snap)
		if hud != null:
			hud.flash_banner(UI.tr_f("CHECKPOINT - WAVE %d", [wave]), UI.BLUE)
	else:
		Save.save_run(snap)
		if hud != null:
			hud.show_saved_tag()


func apply_run(d: Dictionary) -> void:
	## Rebuilds a saved run. Everything is guarded, so a save from a slightly
	## different build loads what it can instead of crashing the scene.
	if d.is_empty():
		return
	wave = maxi(0, int(d.get("wave", 0)))
	cash = maxi(0, int(d.get("cash", 220)))
	kills = maxi(0, int(d.get("kills", 0)))
	score = maxi(0, int(d.get("score", 0)))
	run_time = maxf(0.0, float(d.get("run_time", 0.0)))
	wave_hp = GameData.wave_hp_mul(wave + 1) * Settings.diff_hp() \
			* GameData.pressure_mul(player.level)
	wave_spd = GameData.wave_speed_mul(wave + 1) * Settings.diff_speed()
	var pd: Variant = d.get("player", {})
	if typeof(pd) == TYPE_DICTIONARY and player != null and is_instance_valid(player):
		player.restore(pd as Dictionary)
		var px = float((pd as Dictionary).get("x", player.global_position.x))
		var py = float((pd as Dictionary).get("y", player.global_position.y))
		player.global_position = Vector2(
				clampf(px, 40.0, GameData.ARENA_W - 40.0),
				clampf(py, GameData.BAND_TOP, GameData.BAND_BOT))
	for e in (d.get("structures", []) as Array):
		if typeof(e) != TYPE_DICTIONARY:
			continue
		var se: Dictionary = e
		var kind = String(se.get("kind", ""))
		if not GameData.BUILDINGS.has(kind):
			continue
		var pos = Vector2(float(se.get("x", 0.0)), float(se.get("y", 0.0)))
		var node = _place_structure(kind, pos, int(se.get("waves_left",
				structure_life_for(kind))))
		if node != null:
			node.hp = clampf(float(se.get("hp", node.hp)), 1.0, node.max_hp)
	for a in (d.get("allies", []) as Array):
		var kind2 = String(a)
		if GameData.PETS.has(kind2):
			spawn_ally(kind2)
	prep_time = GameData.INTERMISSION_TIME
	state = "prep"
	restored_from_save = true
	if hud != null:
		hud.on_language_changed()


# ================================================================ hazards
func spawn_hazard(pos: Vector2, kind: String, radius: float, dps: float,
		seconds: float, slow: bool = false) -> void:
	## Burning ground and gas clouds left by incendiary / gas grenades. Kept as
	## plain data ticked by the game loop: no extra nodes, no pooling surprises.
	hazards.append({
		"pos": pos, "kind": kind, "r": radius, "dps": dps, "t": seconds,
		"total": seconds, "slow": slow, "tick": 0.0,
	})


func _tick_hazards(delta: float) -> void:
	for i in range(hazards.size() - 1, -1, -1):
		var h: Dictionary = hazards[i]
		h["t"] = float(h["t"]) - delta
		if float(h["t"]) <= 0.0:
			hazards.remove_at(i)
			continue
		var pos: Vector2 = h["pos"]
		var r: float = float(h["r"])
		var fire = String(h["kind"]) == "fire"
		# visuals: a few puffs a second, never a particle storm
		h["tick"] = float(h["tick"]) - delta
		if float(h["tick"]) <= 0.0:
			h["tick"] = 0.12
			var spot = pos + Vector2(randf_range(-r, r) * 0.8, randf_range(-6.0, 6.0))
			if on_screen(spot, 60.0):
				if fire:
					fx.flame_puff(spot)
				else:
					fx.smoke(spot, 3, Color(0.62, 0.78, 0.32, 0.55))
			for z in zombies_near(pos, r):
				if z.dead:
					continue
				z.take_hit(float(h["dps"]) * 0.12, Vector2.ZERO, false, z.hit_center(), 0.3)
				if fire:
					z.ignite(1.2)
				elif bool(h["slow"]):
					z.chill(0.8)
		hazards[i] = h


func heal_allies(amount: float) -> void:
	## Medic skill: the field kit also welds the defence line back together and
	## buys every nearby building one more wave of life.
	var pl_pos = player.global_position if player != null and is_instance_valid(player) \
			else Vector2.ZERO
	for s in structures:
		if s == null or not is_instance_valid(s) or s.dead:
			continue
		if s.global_position.distance_to(pl_pos) > 220.0:
			continue
		s.hp = minf(s.max_hp, s.hp + amount)
		s.waves_left = mini(s.max_waves, s.waves_left + 1)
		fx.smoke(s.global_position + Vector2(0, -10), 3, Color(0.5, 1.0, 0.6, 0.5))
		fx.float_text(s.global_position + Vector2(0, -26), "+", Color(0.5, 1.0, 0.6))


func _place_structure(kind: String, pos: Vector2, waves_left: int):
	## Shared by building and by loading a save, so a restored barricade is the
	## exact same object as one placed by hand.
	var st = Structure.new()
	entities.add_child(st)
	st.global_position = pos
	var hp_mul = 1.0
	var life_bonus = 0
	if player != null and is_instance_valid(player):
		hp_mul = 1.0 + 0.35 * float(player.lvl("structhp"))
		life_bonus = player.lvl("structlife")
	st.setup(self, kind, hp_mul, life_bonus)
	if waves_left > 0:
		st.waves_left = mini(st.max_waves, waves_left)
	structures.append(st)
	return st
