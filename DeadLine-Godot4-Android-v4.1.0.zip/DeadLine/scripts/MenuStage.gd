extends RefCounted
## ============================================================================
## MenuStage - the v4.1 main menu diorama.
##
## WHY THIS FILE EXISTS
## The old menu background called Art.env_tex("sky"/"mountains"/"city"/...),
## which are the flat v3 strips. v4 replaced them with ten baked, themed bands
## per location (art/env/<theme>/*.png) and nobody ever rewired the menu, so the
## start screen was drawing leftover art at hand-guessed screen fractions: a
## strip of sky at the top, a strip of road in the middle, and raw background
## colour across the rest of the screen. That is the "half a screen of nothing"
## bug.
##
## The other half of the bug was the survivor. In game the body sheets carry NO
## arms - the engine rigs an upper arm, a forearm and the weapon onto the
## shoulder pivot that tools/chars.py exports per frame. The menu instead drew
## the "pose" sheet (which has arms, with EMPTY hands) and then parented a
## weapon sprite at a hard-coded +16,-26 offset. Two arms, no grip, gun floating
## somewhere near the chest. Hence "he does not even hold the rifle right".
##
## So this stage does it properly:
##   * the real ten-band themed set for the CURRENT location, mapped through the
##     same world -> screen transform the in-game camera uses, so it fills the
##     frame at any aspect ratio;
##   * the theme's moon, weather and city twinkle;
##   * a crowd placed on the belt, scaled by depth like real zombies;
##   * the survivor built from the SAME parts and posed with the SAME IK as
##     Player.gd, so the rifle sits in both hands, at the shoulder, pointing at
##     the horde, and recoils when it fires.
##
## Like EnvCity this is a plain RefCounted with no class_name, loaded through
## load() and null-checked by Menu.gd. If it ever fails to compile or throws,
## the menu falls back to a flat themed backdrop and the game still boots. The
## start screen is allowed to fail. The game is not.
## ============================================================================

# ---- geometry, mirrored from EnvCity.LAYERS (tools/check.py guards the drift)
const LAYERS := [
	{"n": "sky", "y": -160.0, "f": 0.00, "z": -60},
	{"n": "far", "y": -110.0, "f": 0.20, "z": -50},
	{"n": "mid", "y": -92.0, "f": 0.40, "z": -46},
	{"n": "near", "y": -72.0, "f": 0.66, "z": -42},
	{"n": "fence", "y": -60.0, "f": 0.80, "z": -38},
	{"n": "fog", "y": -52.0, "f": 0.86, "z": -34},
	{"n": "curb_far", "y": -35.0, "f": 1.00, "z": -30},
	{"n": "road", "y": -22.0, "f": 1.00, "z": -28},
	{"n": "curb_near", "y": 72.0, "f": 1.00, "z": 120},
	{"n": "props_near", "y": 50.0, "f": 1.00, "z": 122},
]

## Per theme: moon anchor, weather and its tint. Same table as EnvCity.ENV, kept
## local so this file has no hard dependency on that script being loadable.
const ENV := {
	"neon": {"moon_ax": 0.18, "moon_y": -86.0, "weather": "rain",
			"pcolor": "8f7ad8", "amount": 130},
	"blood": {"moon_ax": 0.72, "moon_y": -80.0, "weather": "ash",
			"pcolor": "ffb99a", "amount": 70},
	"toxic": {"moon_ax": 0.30, "moon_y": -84.0, "weather": "spore",
			"pcolor": "c6ff7a", "amount": 70},
	"cold": {"moon_ax": 0.80, "moon_y": -90.0, "weather": "snow",
			"pcolor": "ffffff", "amount": 110},
}

## World y of the camera's focus point, so the belt sits where it does in game:
## the middle of the walkable band, lifted by the camera's own offset.
const REF_Y := 9.0            # (BELT_TOP + BELT_BOT) * 0.5 - CAM_LIFT
const PIX_REF := 180.0        # viewport height that equals 1:1 pixel scale x2

# ---- hero hold, mirrored from Player.gd so the pose reads identically
const HOLD_AIM := Vector2(6.0, 3.2)
const HOLD_REST := Vector2(3.4, 6.4)
const REST_ANGLE := 0.72

var menu: Node2D = null
var scale_px := 2.0
var vp := Vector2(640, 360)
var scroll := 0.0
var t := 0.0

var layers: Array = []        # {node, factor, width}
var crowd: Array = []         # {node, speed, wy}
var twinkle: Array = []
var moon: Sprite2D = null

# ---- hero rig
var hero: Node2D = null
var hero_body: AnimatedSprite2D = null
var hero_rig: Node2D = null
var hero_gun: Sprite2D = null
var hero_flash: Sprite2D = null
var hero_parts: Dictionary = {}
var hero_arm_len := Vector2(7.0, 7.0)
var hero_feet := 36.0
var hero_half_w := 13.0
var hero_sh := Vector2(2.0, -26.0)
var hero_grip := Vector2.ZERO
var hero_fore := Vector2(5.0, 0.0)
var hero_muzzle := Vector2(14.0, 0.0)
var gun_angle := 0.0
var recoil := 0.0
var recoil_rot := 0.0
var shot_t := 1.2
var flash_t := 0.0


func env_dict() -> Dictionary:
	var d = ENV.get(GameData.theme_key(), null)
	if typeof(d) != TYPE_DICTIONARY:
		return ENV["neon"]
	return d


func sy(world_y: float) -> float:
	## World y -> screen y. One transform for the whole stage, which is exactly
	## what the old hand-picked "vp.y * 0.68" fractions were missing.
	return vp.y * 0.5 + (world_y - REF_Y) * scale_px


# ================================================================ build
func build(m: Node2D) -> int:
	menu = m
	if menu == null or not is_instance_valid(menu):
		return 0
	vp = menu.get_viewport_rect().size
	if vp.x < 16.0 or vp.y < 16.0:
		vp = Vector2(640, 360)
	scale_px = maxf(1.0, vp.y / PIX_REF)

	_build_backdrop()
	var built = _build_layers()
	if built == 0:
		# No themed art on disk at all: the caller falls back to the old strips.
		return 0
	_build_moon()
	_build_weather()
	_build_crowd()
	_build_hero()
	_build_grade()
	return built


func _build_backdrop() -> void:
	## A full-bleed plate of the theme's sky colour behind everything. Even if a
	## band is missing, a wrong aspect ratio can never show raw clear colour.
	var r = ColorRect.new()
	r.color = GameData.theme_sky_color()
	r.size = vp * 3.0
	r.position = -vp
	r.z_index = -70
	r.mouse_filter = Control.MOUSE_FILTER_IGNORE
	menu.add_child(r)


func _build_layers() -> int:
	var built = 0
	for spec in LAYERS:
		var key = String(spec["n"])
		var tex = Art.tex(GameData.env_path(key))
		if tex == null:
			continue
		var holder = Node2D.new()
		holder.position.y = sy(float(spec["y"]))
		holder.z_index = int(spec["z"])
		menu.add_child(holder)
		var tile_w = maxf(8.0, float(tex.get_width()) * scale_px)
		var count = int(ceil(vp.x * 2.0 / tile_w)) + 3
		for i in range(count):
			var s = Sprite2D.new()
			s.texture = tex
			s.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
			s.centered = false
			s.position = Vector2(float(i) * tile_w, 0.0)
			s.scale = Vector2.ONE * scale_px
			holder.add_child(s)
		layers.append({"node": holder, "factor": float(spec["f"]), "width": tile_w})
		if key == "sky":
			_add_twinkle(holder, 16, Color(1, 1, 1), -150.0, -104.0, 1.6)
		elif key == "mid":
			_add_twinkle(holder, 12, Color(1.0, 0.95, 0.77), -88.0, -40.0, 3.0)
		built += 1
	return built


func _add_twinkle(holder: Node2D, count: int, col: Color, y0: float, y1: float,
		speed: float) -> void:
	## Window lights and stars. Children of the parallax holder, so they scroll
	## and wrap with their band for free.
	var tex = Art.fx_tex("spark")
	if tex == null:
		return
	var n = count if Settings.idx("quality") > 0 else int(count / 2)
	for i in range(n):
		var s = Sprite2D.new()
		s.texture = tex
		s.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
		s.modulate = col
		s.scale = Vector2.ONE * randf_range(0.5, 1.0) * scale_px * 0.5
		s.position = Vector2(randf_range(0.0, vp.x * 2.0),
				sy(randf_range(y0, y1)) - holder.position.y)
		holder.add_child(s)
		twinkle.append({"node": s, "phase": randf() * TAU, "speed": speed,
				"base": randf_range(0.35, 0.9)})


func _build_moon() -> void:
	var tex = Art.tex(GameData.env_path("moon"))
	if tex == null:
		return
	var e = env_dict()
	moon = Sprite2D.new()
	moon.texture = tex
	moon.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	moon.scale = Vector2.ONE * scale_px
	moon.position = Vector2(vp.x * float(e.get("moon_ax", 0.2)),
			sy(float(e.get("moon_y", -86.0))))
	moon.z_index = -58
	menu.add_child(moon)


func _build_weather() -> void:
	var tex = Art.fx_tex("spark")
	if tex == null:
		return
	var e = env_dict()
	var amount = int(float(e.get("amount", 90)) * _weather_mul())
	if amount <= 0:
		return
	var p = CPUParticles2D.new()
	p.texture = tex
	p.amount = amount
	p.lifetime = 2.2
	p.preprocess = 1.5
	p.local_coords = false
	p.z_index = 124
	p.emission_shape = CPUParticles2D.EMISSION_SHAPE_RECTANGLE
	p.emission_rect_extents = Vector2(vp.x * 0.75, 10.0)
	p.position = Vector2(vp.x * 0.5, -20.0)
	p.color = Color.html(String(e.get("pcolor", "ffffff")))
	p.gravity = Vector2.ZERO
	match String(e.get("weather", "rain")):
		"rain":
			p.direction = Vector2(-0.34, 1.0)
			p.initial_velocity_min = 320.0
			p.initial_velocity_max = 420.0
			p.scale_amount_min = 0.5
			p.scale_amount_max = 1.0
			p.lifetime = 1.3
		"snow":
			p.direction = Vector2(0.12, 1.0)
			p.initial_velocity_min = 30.0
			p.initial_velocity_max = 60.0
			p.spread = 24.0
			p.scale_amount_min = 0.6
			p.scale_amount_max = 1.2
			p.lifetime = 4.5
		"ash":
			p.direction = Vector2(0.2, 1.0)
			p.initial_velocity_min = 22.0
			p.initial_velocity_max = 52.0
			p.spread = 30.0
			p.scale_amount_min = 0.5
			p.scale_amount_max = 1.1
			p.lifetime = 5.0
		_:
			p.direction = Vector2(-0.1, 1.0)
			p.initial_velocity_min = 16.0
			p.initial_velocity_max = 40.0
			p.spread = 35.0
			p.scale_amount_min = 0.6
			p.scale_amount_max = 1.3
			p.lifetime = 5.5
	p.scale_amount_min *= scale_px * 0.6
	p.scale_amount_max *= scale_px * 0.6
	menu.add_child(p)


func _weather_mul() -> float:
	var q = Settings.idx("quality")
	return 0.35 if q == 0 else (0.7 if q == 1 else 1.0)


# ---------------------------------------------------------------- the horde
func _build_crowd() -> void:
	## Bodies stand ON the belt, at a world y, and are scaled by depth exactly
	## like in game - which is why the crowd now reads as a street full of
	## zombies instead of a row of stickers at one size.
	var types = ["z_walker", "z_nurse", "z_worker", "z_runner", "z_cop", "z_hazmat",
			"z_crawler", "z_brute", "z_bloater"]
	var n = 9 if Settings.idx("quality") > 0 else 6
	for i in range(n):
		var id = String(types[i % types.size()])
		var frames = Art.char_frames(id)
		if frames == null:
			continue
		var a = AnimatedSprite2D.new()
		a.sprite_frames = frames
		a.animation = "walk" if frames.has_animation("walk") else "idle"
		a.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
		a.offset = Vector2(0, Art.char_feet_offset(id))
		a.speed_scale = randf_range(0.75, 1.25)
		a.play()
		var wy = randf_range(GameData.belt_top() + 8.0, GameData.belt_bot() - 4.0)
		var depth = GameData.scale_at(wy)
		a.scale = Vector2.ONE * scale_px * depth
		a.position = Vector2(randf_range(vp.x * 0.30, vp.x * 1.25), sy(wy))
		# Depth sorting: whoever is nearer the camera draws in front.
		a.z_index = 20 + int((wy - GameData.belt_top()) * 0.5)
		menu.add_child(a)
		crowd.append({"node": a, "speed": randf_range(8.0, 20.0) * depth, "wy": wy})


# ---------------------------------------------------------------- the survivor
func _build_hero() -> void:
	var suit = String(Save.loadout_get("suit"))
	var frames = Art.char_frames(suit)
	if frames == null:
		return
	var wy = GameData.belt_bot() - 16.0
	var depth = GameData.scale_at(wy)

	hero = Node2D.new()
	hero.position = Vector2(vp.x * 0.20, sy(wy))
	hero.z_index = 30 + int((wy - GameData.belt_top()) * 0.5)
	menu.add_child(hero)

	hero_body = AnimatedSprite2D.new()
	hero_body.sprite_frames = frames
	# "idle", NOT "pose": the walk/idle sheets are the armless ones the rig is
	# designed around. The posed sheet has its own baked arms and empty hands,
	# and that is precisely what made the menu gun look glued on.
	hero_body.animation = "idle" if frames.has_animation("idle") else "pose"
	hero_body.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	hero_body.offset = Vector2(0, Art.char_feet_offset(suit))
	hero_body.play()
	hero.add_child(hero_body)

	var info: Dictionary = Art.char_info(suit)
	hero_feet = float(info.get("feet", 36))
	hero_half_w = maxf(1.0, float(info.get("w", 26)) * 0.5)
	hero_arm_len = Art.char_arm_lengths(suit)

	var shp: Array = Art.char_shoulders(suit, "idle")
	if not shp.is_empty():
		hero_sh = _to_local(shp[0] as Vector2).round()

	hero_rig = Node2D.new()
	hero.add_child(hero_rig)
	for key in ["upper_back", "fore_back", "upper_front", "fore_front"]:
		var piece: Dictionary = Art.char_limb(suit, key)
		if piece.is_empty():
			continue
		var sp = Sprite2D.new()
		sp.texture = piece.get("tex", null)
		sp.centered = false
		sp.offset = -(piece.get("pivot", Vector2.ZERO) as Vector2)
		sp.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
		sp.z_index = -1 if key.ends_with("back") else 2
		hero_rig.add_child(sp)
		hero_parts[key] = sp

	hero_gun = Sprite2D.new()
	hero_gun.centered = false
	hero_gun.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	hero_gun.z_index = 1
	hero_rig.add_child(hero_gun)

	hero_flash = Sprite2D.new()
	hero_flash.texture = Art.fx_tex("muzzle")
	hero_flash.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	hero_flash.visible = false
	hero_flash.z_index = 3
	hero_gun.add_child(hero_flash)

	# The gun the player actually has equipped, anchored on its real grip point.
	var wid = String(Save.loadout_get("primary"))
	var tex = Art.weapon_tex(wid)
	var wm: Dictionary = Art.weapon_info(wid)
	if tex != null:
		hero_gun.texture = tex
		hero_grip = Art.weapon_point(wid, "grip")
		hero_fore = Art.weapon_point(wid, "fore") - hero_grip
		hero_muzzle = Art.weapon_point(wid, "muzzle") - hero_grip
		hero_gun.offset = -hero_grip
		if hero_flash != null:
			hero_flash.position = hero_muzzle
	elif not wm.is_empty():
		hero_gun.visible = false

	hero_rig.scale = Vector2.ONE * depth
	hero_body.scale = Vector2.ONE * depth
	hero.scale = Vector2.ONE * scale_px
	gun_angle = -0.18
	_pose(0.0, true)


func _to_local(image_pt: Vector2) -> Vector2:
	return Vector2(image_pt.x - hero_half_w, image_pt.y - hero_feet)


static func solve_ik(root: Vector2, target: Vector2, l1: float, l2: float,
		flip: float) -> Vector2:
	## Same two bone solver as Player.gd: clamp the reach, then swing the elbow
	## out by the remaining slack. Out of range simply straightens the arm.
	var to = target - root
	var d = to.length()
	if d < 0.0001:
		return root + Vector2(l1, 0)
	var reach = clampf(d, absf(l1 - l2) + 0.01, l1 + l2 - 0.01)
	var dir = to / d
	var a = (l1 * l1 - l2 * l2 + reach * reach) / (2.0 * reach)
	var h = sqrt(maxf(0.0, l1 * l1 - a * a))
	var perp = Vector2(-dir.y, dir.x) * flip
	return root + dir * a + perp * h


func _pose(delta: float, instant: bool) -> void:
	if hero_rig == null or hero_gun == null:
		return
	# The survivor is watching the street: the muzzle tracks the nearest body,
	# with a slow breathing sway on top so the pose is never frozen.
	var want = -0.16 + sin(t * 1.15) * 0.045
	var target = _nearest_crowd()
	if target != Vector2.ZERO:
		var to = target - (hero.position + Vector2(hero_sh.x, hero_sh.y) * scale_px)
		want = clampf(Vector2(absf(to.x), to.y).angle(), -0.55, 0.34)
		want += sin(t * 1.15) * 0.03
	if instant:
		gun_angle = want
	else:
		gun_angle += clampf(wrapf(want - gun_angle, -PI, PI), -6.0 * delta, 6.0 * delta)

	var ang = gun_angle - recoil_rot
	var dir = Vector2.RIGHT.rotated(ang)
	var hold = HOLD_REST.lerp(HOLD_AIM, 1.0)
	var rear = hero_sh + hold.rotated(ang) - dir * recoil
	var front = rear + hero_fore.rotated(ang)
	hero_gun.position = rear
	hero_gun.rotation = ang
	hero_gun.visible = hero_gun.texture != null
	_pose_arm("upper_back", "fore_back", hero_sh + Vector2(-1.2, 1.0), rear)
	_pose_arm("upper_front", "fore_front", hero_sh + Vector2(0.6, 0.2), front)


func _pose_arm(upper_key: String, fore_key: String, root: Vector2, hand: Vector2) -> void:
	var up: Sprite2D = hero_parts.get(upper_key, null)
	var fo: Sprite2D = hero_parts.get(fore_key, null)
	if up == null or fo == null:
		return
	var elbow = solve_ik(root, hand, hero_arm_len.x, hero_arm_len.y, 1.0)
	up.position = root
	up.rotation = (elbow - root).angle()
	fo.position = elbow
	fo.rotation = (hand - elbow).angle()


func _nearest_crowd() -> Vector2:
	if hero == null:
		return Vector2.ZERO
	var best = Vector2.ZERO
	var bd = 1.0e9
	for c in crowd:
		var n: AnimatedSprite2D = c["node"]
		if n == null or not is_instance_valid(n):
			continue
		if n.position.x < hero.position.x + 20.0:
			continue
		var d = n.position.x - hero.position.x
		if d < bd:
			bd = d
			best = n.position + Vector2(0.0, -14.0 * scale_px)
	return best


# ---------------------------------------------------------------- grade
func _build_grade() -> void:
	## Menu grade: darken so the UI reads, then a soft vignette. Both live above
	## the scenery and below the UI CanvasLayer, so buttons stay crisp.
	var dim = ColorRect.new()
	dim.color = Color(0.02, 0.01, 0.03, 0.42)
	dim.size = vp * 3.0
	dim.position = -vp
	dim.z_index = 125
	dim.mouse_filter = Control.MOUSE_FILTER_IGNORE
	menu.add_child(dim)

	var tex = Art.fx_tex("vignette")
	if tex == null:
		return
	var v = Sprite2D.new()
	v.texture = tex
	v.centered = false
	v.position = Vector2.ZERO
	v.scale = Vector2(vp.x / maxf(1.0, float(tex.get_width())),
			vp.y / maxf(1.0, float(tex.get_height())))
	v.modulate = Color(1, 1, 1, 0.55)
	v.z_index = 126
	menu.add_child(v)


# ================================================================ tick
func update(delta: float) -> void:
	t += delta
	scroll += delta * 11.0
	for l in layers:
		var n: Node2D = l["node"]
		if n == null or not is_instance_valid(n):
			continue
		var w: float = float(l["width"])
		# One tile of slack on the left, so a fast parallax band can never open
		# a gap at the screen edge on a wide device.
		n.position.x = -w - fmod(scroll * float(l["factor"]), w)
	for tw in twinkle:
		var s: Sprite2D = tw["node"]
		if s == null or not is_instance_valid(s):
			continue
		var a = float(tw["base"]) * (0.55 + 0.45 * sin(t * float(tw["speed"]) + float(tw["phase"])))
		s.modulate.a = clampf(a, 0.0, 1.0)
	for c in crowd:
		var n2: AnimatedSprite2D = c["node"]
		if n2 == null or not is_instance_valid(n2):
			continue
		n2.position.x -= float(c["speed"]) * delta
		if n2.position.x < -60.0:
			# Recycled at a fresh depth, so the crowd keeps reshuffling instead
			# of looping the same silhouettes at the same size forever.
			var wy = randf_range(GameData.belt_top() + 8.0, GameData.belt_bot() - 4.0)
			var depth = GameData.scale_at(wy)
			c["wy"] = wy
			c["speed"] = randf_range(8.0, 20.0) * depth
			n2.scale = Vector2.ONE * scale_px * depth
			n2.z_index = 20 + int((wy - GameData.belt_top()) * 0.5)
			n2.position = Vector2(vp.x + randf_range(30.0, 220.0), sy(wy))
	_tick_hero(delta)


func _tick_hero(delta: float) -> void:
	if hero == null or not is_instance_valid(hero):
		return
	recoil = maxf(0.0, recoil - delta * 34.0)
	recoil_rot = maxf(0.0, recoil_rot - delta * 5.5)
	if flash_t > 0.0:
		flash_t -= delta
		if flash_t <= 0.0 and hero_flash != null:
			hero_flash.visible = false
	shot_t -= delta
	if shot_t <= 0.0:
		shot_t = randf_range(1.4, 3.4)
		# A burst: kick the weapon, flash the muzzle. No bullets, no zombies
		# dying - the menu is a diorama, not a live run.
		if hero_gun != null and hero_gun.texture != null:
			recoil = 2.6
			recoil_rot = 0.16
			if hero_flash != null:
				hero_flash.visible = true
				hero_flash.rotation = randf_range(-0.2, 0.2)
				hero_flash.scale = Vector2.ONE * randf_range(0.85, 1.15)
				flash_t = 0.055
	_pose(delta, false)
