extends Control
class_name TouchPad
## v4 — УПРАВЛЕНИЕ ПОД БОЛЬШОЙ ПАЛЕЦ.
##
## Что было не так: восемь кнопок фиксированными координатами в углу. На 5"
## экране половина из них лежала вне досягаемости большого пальца, RLD и TYP
## находились в самой дальней точке, а «GUN» жал тот, кто и так не успевал.
## Плюс размеры (r = 12..16) меньше физического минимума 9 мм.
##
## Что теперь:
##   1. Кластер строится ПРОЦЕДУРНО по дуге вокруг точки опоры пальца. Радиус
##      дуги и угловой шаг считаются из радиусов самих кнопок, поэтому зазор
##      никогда не падает ниже MIN_GAP — это математика, а не расстановка
##      руками, и она не ломается ни на одном соотношении сторон.
##   2. Кнопки КОНТЕКСТНЫЕ: в бою их три-четыре. RLD появляется, только когда
##      магазин неполон, BLD — только в подготовке, TYP — только пока палец
##      держит гранату.
##   3. Ни одна кнопка не мельче MIN_R. tools/lint.py проверяет и радиусы, и
##      зазоры на четырёх разрешениях, так что «мелкая кнопка» больше не
##      может доехать до сборки.

const STICK_RADIUS := 30.0
const ZONE_H := 190.0

## Физический минимум: 15 px в игровом разрешении 640x360 — это ~9 мм на
## телефоне. Ниже опускаться нельзя, палец начинает промахиваться.
const MIN_R := 15.0
## Минимальный зазор между краями соседних кнопок.
const MIN_GAP := 10.0
## Долгое нажатие на гранату раскрывает веер типов.
const HOLD_TIME := 0.26

## Угловое окно кластера, отсчёт от нижней кромки экрана вверх. Границы взяты
## так, чтобы кнопка при любом радиусе дуги осталась внутри экрана — поэтому
## после раскладки НИЧЕГО не нужно обрезать по краям. Прошлая версия обрезала,
## и на 640x300 обрезка сталкивала кнопки в кашу (поймано tools/lint.py).
## 20°, а не 8°: на малой дуге первая кнопка своим радиусом вылезала за нижнюю
## кромку экрана (поймано tools/lint.py на 640x300 и 600x338).
const ARC_A_MIN := 20.0
const ARC_A_MAX := 88.0
const ARC_R_MIN := 56.0
## Больше пяти кнопок в одном кольце большой палец не обслуживает — остальные
## уходят на внутреннее кольцо.
const RING_MAX := 5

## Явное соответствие тип гранаты -> ключ иконки. Раньше ключ склеивался из
## строки, и проверка ассетов не могла его увидеть.
const NADE_ICON := {
	"frag": "nade_frag",
	"incend": "nade_incend",
	"gas": "nade_gas",
	"shock": "nade_shock",
}

var game = null

var stick_touch = -1
var place_touch = -1
var stick_center = Vector2.ZERO
var stick_knob = Vector2.ZERO
var _was_stick = false

var buttons: Array = []
var _base_tex: Texture2D
var _knob_tex: Texture2D
var _font: Font
var _last_size = Vector2.ZERO
var _last_sig = ""
var _hold_t = 0.0
var _fan_open = false
var _fan: Array = []


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	_base_tex = Art.ui_tex("joy_base")
	_knob_tex = Art.ui_tex("joy_knob")
	_font = ThemeDB.fallback_font
	set_process(true)
	_layout()


# ================================================================ раскладка
func _active_ids() -> Array:
	## Единственное место, которое решает, что сейчас на экране. Порядок = приоритет
	## по удобству: самое частое действие ближе всего к пальцу.
	var pl = game.player if game != null else null
	if pl == null or not is_instance_valid(pl):
		return ["fire", "dash"]
	var ids: Array = []
	if not Settings.on("autofire"):
		ids.append("fire")
	ids.append("dash")
	if pl.nade_count() > 0:
		ids.append("nade")
	ids.append("skill")
	# контекст: перезарядка нужна только когда она реально нужна
	var cap = int(pl.weapon().get("mag", 0))
	if cap > 0 and not pl.reloading and pl.ammo_in_mag() < cap:
		ids.append("reload")
	# контекст: стройка — в подготовке между волнами (и пока режим открыт)
	var building = game.hud != null and game.hud.build_mode
	if building or (game != null and String(game.state) == "prep"):
		ids.append("build")
	ids.append("swap")
	return ids


func _sig() -> String:
	## Подпись состояния: пересобираем дугу только когда набор реально изменился,
	## а не каждый кадр.
	return "%s|%dx%d|%d|%d" % [",".join(PackedStringArray(_active_ids())),
			int(size.x), int(size.y), Settings.idx("joy_side"), Settings.idx("hud_scale")]


func _layout() -> void:
	_last_size = size
	_last_sig = _sig()
	var w = size.x
	var h = size.y
	var right_stick = Settings.idx("joy_side") == 1
	var k = Settings.hud_scale()

	var stick_x = 62.0 if not right_stick else w - 62.0
	stick_center = Vector2(stick_x, h - 58.0)
	stick_knob = stick_center

	# Точка опоры = основание большого пальца в нижнем углу. Всё строится от неё.
	var mirror = -1.0 if right_stick else 1.0
	var pivot = Vector2(w - 18.0 if not right_stick else 18.0, h - 12.0)

	var ids = _active_ids()
	var specs = {
		"fire":   {"r": 26.0, "label": "FIRE", "col": UI.RED},
		"dash":   {"r": 19.0, "label": "DASH", "col": UI.BLUE},
		"nade":   {"r": 18.0, "label": "NADE", "col": UI.GREEN},
		"skill":  {"r": 18.0, "label": "SKL",  "col": UI.GOLD},
		"reload": {"r": 16.0, "label": "RLD",  "col": UI.DIM},
		"build":  {"r": 16.0, "label": "BLD",  "col": UI.BLUE},
		"swap":   {"r": 16.0, "label": "GUN",  "col": UI.GOLD},
	}

	var radii: Array = []
	var max_r = MIN_R
	for id in ids:
		var r = maxf(MIN_R, float((specs[id] as Dictionary)["r"]) * k)
		radii.append(r)
		max_r = maxf(max_r, r)

	# Разделение на кольца: первое — под подушечку пальца, второе — глубже.
	var n1 = mini(ids.size(), RING_MAX)
	var r1_list: Array = radii.slice(0, n1)
	var r2_list: Array = radii.slice(n1)

	var side = -1.0 if not right_stick else 1.0
	var pivot = Vector2(w - 20.0, h - 14.0) if not right_stick else Vector2(20.0, h - 14.0)
	var arc_max = maxf(_min_arc(r1_list, 14.0), minf(h - 16.0 - max_r, w * 0.55))
	var arc_r = _fit_arc(r1_list, arc_max)
	# Второе кольцо отстоит радиально ровно на диаметр самой крупной кнопки плюс
	# зазор: тогда зазор между кольцами гарантирован для ЛЮБОЙ пары.
	var arc_r2 = arc_r - (2.0 * max_r + MIN_GAP)
	var r2_min = _min_arc(r2_list, 14.0)
	if not r2_list.is_empty() and arc_r2 < r2_min:
		arc_r = r2_min + 2.0 * max_r + MIN_GAP
		arc_r = minf(arc_r, arc_max)
		arc_r2 = arc_r - (2.0 * max_r + MIN_GAP)

	buttons = []
	_place_ring(ids.slice(0, n1), r1_list, arc_r, pivot, side, specs)
	if not r2_list.is_empty():
		_place_ring(ids.slice(n1), r2_list, arc_r2, pivot, side, specs)
	_build_fan(k)


func _ring_span(radii: Array, arc_r: float) -> float:
	## Суммарный угол, который занимает кольцо при данном радиусе. Шаг между
	## соседями считается через хорду (r1 + r2 + MIN_GAP), поэтому зазор — это
	## следствие математики, а не удачной расстановки координат.
	var total = 0.0
	for i in range(1, radii.size()):
		var chord = (float(radii[i - 1]) + float(radii[i]) + MIN_GAP) * 0.5
		total += 2.0 * asin(clampf(chord / maxf(1.0, arc_r), 0.0, 1.0))
	return total


func _min_arc(radii: Array, pivot_dy: float) -> float:
	## Радиус, при котором САМАЯ НИЖНЯЯ кнопка кольца целиком влезает по высоте.
	## Считается из просвета, а не подбирается на глаз.
	if radii.is_empty():
		return ARC_R_MIN
	var need = float(radii[0]) + 2.0 - pivot_dy
	if need <= 0.0:
		return ARC_R_MIN
	return maxf(ARC_R_MIN, need / maxf(0.05, sin(deg_to_rad(ARC_A_MIN))))


func _fit_arc(radii: Array, arc_max: float) -> float:
	## Подбираем МИНИМАЛЬНЫЙ радиус дуги, при котором кольцо влезает в окно
	## ARC_A_MIN..ARC_A_MAX. Занимаемый угол монотонно падает с ростом радиуса,
	## поэтому обычного прохода с шагом 2 px достаточно и он предсказуем.
	var span_max = deg_to_rad(ARC_A_MAX - ARC_A_MIN)
	var r = _min_arc(radii, 14.0)
	while r < arc_max:
		if _ring_span(radii, r) <= span_max:
			return r
		r += 2.0
	return arc_max


func _place_ring(ids: Array, radii: Array, arc_r: float, pivot: Vector2,
		side: float, specs: Dictionary) -> void:
	var ang = deg_to_rad(ARC_A_MIN)
	for i in range(ids.size()):
		var id = String(ids[i])
		var r = float(radii[i])
		if i > 0:
			var chord = (float(radii[i - 1]) + r + MIN_GAP) * 0.5
			ang += 2.0 * asin(clampf(chord / maxf(1.0, arc_r), 0.0, 1.0))
		var c = pivot + Vector2(cos(ang) * arc_r * side, -sin(ang) * arc_r)
		var sp: Dictionary = specs[id]
		buttons.append({"id": id, "c": c, "r": r, "label": String(sp["label"]),
				"col": sp["col"], "touch": -1, "down": false})


func _build_fan(k: float) -> void:
	## Веер типов гранат: раскрывается над кнопкой NADE по долгому нажатию.
	_fan = []
	var host: Dictionary = {}
	for b in buttons:
		if String(b["id"]) == "nade":
			host = b
			break
	if host.is_empty():
		return
	var kinds = NADE_ICON.keys()
	var r = maxf(13.0, 14.0 * k)
	var c0: Vector2 = host["c"]
	var step = 2.0 * r + MIN_GAP
	for i in range(kinds.size()):
		var c = c0 + Vector2(0, -float(host["r"]) - r - MIN_GAP - float(i) * step)
		c.y = clampf(c.y, r + 2.0, size.y - r - 2.0)
		_fan.append({"id": "nk_" + kinds[i], "kind": kinds[i], "c": c, "r": r})


# ================================================================ процесс
func _process(delta: float) -> void:
	if size != _last_size or _sig() != _last_sig:
		_layout()
	var pl = game.player if game != null else null
	if pl == null or not is_instance_valid(pl):
		return

	if stick_touch >= 0:
		var v = (stick_knob - stick_center) / STICK_RADIUS
		pl.move_input = v.limit_length(1.0)
		_was_stick = true
	elif _was_stick:
		pl.move_input = Vector2.ZERO
		_was_stick = false

	# долгое нажатие на гранату -> веер типов
	if _is_down("nade") and not _fan_open:
		_hold_t += delta
		if _hold_t >= HOLD_TIME:
			_fan_open = true
			Audio.play("ui", -20.0, 1.2, 0.0)
	elif not _is_down("nade"):
		_hold_t = 0.0

	if not Settings.on("autofire"):
		pl.fire_held = _is_down("fire")
	queue_redraw()


func _is_down(id: String) -> bool:
	for b in buttons:
		if String(b["id"]) == id:
			return bool(b["down"])
	return false


func _btn(id: String) -> Dictionary:
	for b in buttons:
		if String(b["id"]) == id:
			return b
	return {}


# ================================================================ ввод
func _input(event: InputEvent) -> void:
	if game == null or game.hud == null:
		return
	if event is InputEventScreenTouch:
		var t = event as InputEventScreenTouch
		if t.pressed:
			_press(t.position, t.index)
		else:
			_release(t.index, t.position)
	elif event is InputEventScreenDrag:
		var dr = event as InputEventScreenDrag
		if dr.index == stick_touch:
			stick_knob = stick_center + (dr.position - stick_center).limit_length(STICK_RADIUS)
		elif dr.index == place_touch and game.hud.build_mode:
			game.set_ghost(_to_world(dr.position))


func _press(pos: Vector2, index: int) -> void:
	if game.hud.blocks_touch():
		return
	# открытый веер перехватывает нажатие первым
	if _fan_open:
		for f in _fan:
			if pos.distance_to(f["c"] as Vector2) <= float(f["r"]) * 1.3:
				_pick_nade(String(f["kind"]))
				return
	for b in buttons:
		if pos.distance_to(b["c"] as Vector2) <= float(b["r"]) * 1.25:
			b["touch"] = index
			b["down"] = true
			if String(b["id"]) != "nade":
				_trigger(String(b["id"]))
			return
	if game.hud.point_blocked(pos):
		return
	var right_stick = Settings.idx("joy_side") == 1
	var in_zone: bool = pos.y > size.y - ZONE_H and (
			(pos.x < size.x * 0.42) if not right_stick else (pos.x > size.x * 0.58))
	if in_zone and stick_touch == -1:
		stick_touch = index
		stick_center = pos
		stick_knob = pos
		return
	if game.hud.build_mode and not game.hud.point_blocked(pos):
		place_touch = index
		game.set_ghost(_to_world(pos))


func _to_world(pos: Vector2) -> Vector2:
	return get_viewport().get_canvas_transform().affine_inverse() * pos


func _release(index: int, pos: Vector2 = Vector2.ZERO) -> void:
	if index == place_touch:
		place_touch = -1
		if game.hud.build_mode and game.ghost_active():
			game.place_build(game.ghost_spot())
	if index == stick_touch:
		stick_touch = -1
		stick_knob = stick_center
	for b in buttons:
		if int(b["touch"]) == index:
			# Граната срабатывает НА ОТПУСКАНИЕ: короткий тап — бросок, долгое
			# удержание — выбор типа, и бросок при этом не тратится.
			if String(b["id"]) == "nade":
				if _fan_open:
					var picked = false
					for f in _fan:
						if pos.distance_to(f["c"] as Vector2) <= float(f["r"]) * 1.3:
							_pick_nade(String(f["kind"]))
							picked = true
							break
					if not picked:
						pass
					_fan_open = false
				else:
					_trigger("nade")
			_hold_t = 0.0
			b["touch"] = -1
			b["down"] = false


func _pick_nade(kind: String) -> void:
	var pl = game.player
	if pl == null or not is_instance_valid(pl):
		return
	pl.nade_type = kind
	_fan_open = false
	_hold_t = 0.0
	Audio.play("click", -18.0, 1.0, 0.0)


func _trigger(id: String) -> void:
	var pl = game.player
	if pl == null or not is_instance_valid(pl):
		return
	match id:
		"dash":
			pl.dash()
		"nade":
			pl.throw_grenade()
		"swap":
			pl.next_weapon()
		"reload":
			pl.start_reload()
		"build":
			game.hud.toggle_build()
		"skill":
			pl.use_ability()
		_:
			pass


# ================================================================ отрисовка
func _draw() -> void:
	_draw_stick()
	var pl = game.player if game != null else null
	if pl != null and not is_instance_valid(pl):
		pl = null
	for b in buttons:
		_draw_button(b, pl)
	if _fan_open:
		_draw_fan(pl)


func _draw_stick() -> void:
	var a = Settings.hud_alpha()
	var base_a = a * (0.45 if stick_touch < 0 else 0.85)
	if _base_tex != null:
		draw_texture(_base_tex, stick_center - _base_tex.get_size() * 0.5,
				Color(1, 1, 1, base_a))
	else:
		draw_arc(stick_center, STICK_RADIUS, 0.0, TAU, 24, Color(1, 1, 1, base_a), 2.0)
	if _knob_tex != null:
		draw_texture(_knob_tex, stick_knob - _knob_tex.get_size() * 0.5,
				Color(1, 1, 1, minf(1.0, base_a + 0.25)))
	else:
		draw_circle(stick_knob, 9.0, Color(0.9, 0.3, 0.3, minf(1.0, base_a + 0.3)))


func _draw_button(b: Dictionary, pl: Node) -> void:
	var id = String(b["id"])
	var c: Vector2 = b["c"]
	var r = float(b["r"])
	var col: Color = b["col"]
	var a = Settings.hud_alpha()
	var down = bool(b["down"])

	# готовность действия: недоступное рисуется приглушённым, а не исчезает —
	# палец должен помнить, где оно лежит.
	var ready = true
	var frac = 1.0
	var badge = ""
	if pl != null:
		match id:
			"dash":
				ready = pl.dash_cd <= 0.0
				frac = 1.0 - clampf(pl.dash_cd / 1.2, 0.0, 1.0)
			"skill":
				ready = pl.ability_ready()
				frac = 1.0 if ready else 0.0
				if not ready:
					badge = str(int(ceil(pl.ability_cd)))
			"nade":
				var n = pl.nade_count()
				ready = n > 0
				badge = str(n)
			"reload":
				ready = not pl.reloading
				badge = str(pl.ammo_in_mag())

	var fill_a = a * (0.34 if not down else 0.62) * (1.0 if ready else 0.45)
	draw_circle(c, r, Color(0.04, 0.04, 0.05, fill_a + 0.12))
	draw_circle(c, r - 2.0, Color(col.r, col.g, col.b, fill_a * 0.55))
	draw_arc(c, r, 0.0, TAU, 28, Color(col.r, col.g, col.b, a * (1.0 if ready else 0.5)), 2.0)
	if frac < 1.0:
		# сектор перезарядки/откат: видно, сколько осталось
		draw_arc(c, r - 4.0, -PI * 0.5, -PI * 0.5 + TAU * frac, 24,
				Color(1, 1, 1, a * 0.7), 2.0)
	if _font != null:
		var label = String(b["label"])
		var fs = 9 if r >= 18.0 else 8
		var tw = _font.get_string_size(label, HORIZONTAL_ALIGNMENT_LEFT, -1, fs).x
		draw_string(_font, c + Vector2(-tw * 0.5, 3.0), label,
				HORIZONTAL_ALIGNMENT_LEFT, -1, fs, Color(1, 1, 1, a * (1.0 if ready else 0.55)))
		if badge != "":
			var bw = _font.get_string_size(badge, HORIZONTAL_ALIGNMENT_LEFT, -1, 8).x
			var bc = c + Vector2(r * 0.62, -r * 0.62)
			draw_circle(bc, 7.0, Color(0.05, 0.05, 0.06, a * 0.9))
			draw_string(_font, bc + Vector2(-bw * 0.5, 3.0), badge,
					HORIZONTAL_ALIGNMENT_LEFT, -1, 8, Color(1, 1, 1, a))


func _draw_fan(pl: Node) -> void:
	var a = Settings.hud_alpha()
	var cur = String(pl.nade_type) if pl != null else "frag"
	for f in _fan:
		var c: Vector2 = f["c"]
		var r = float(f["r"])
		var kind = String(f["kind"])
		var sel = kind == cur
		var col = UI.GOLD if sel else UI.GREEN
		draw_circle(c, r, Color(0.04, 0.04, 0.05, a * 0.85))
		draw_arc(c, r, 0.0, TAU, 24, Color(col.r, col.g, col.b, a), 2.0 if sel else 1.0)
		var tex = Art.ui_tex(String(NADE_ICON.get(kind, "nade_frag")))
		if tex != null:
			draw_texture(tex, c - tex.get_size() * 0.5, Color(1, 1, 1, a))
		elif _font != null:
			var s = kind.substr(0, 3).to_upper()
			var tw = _font.get_string_size(s, HORIZONTAL_ALIGNMENT_LEFT, -1, 8).x
			draw_string(_font, c + Vector2(-tw * 0.5, 3.0), s,
					HORIZONTAL_ALIGNMENT_LEFT, -1, 8, Color(1, 1, 1, a))
		if pl != null:
			var n = pl.nade_count(kind)
			var bs = str(n)
			var bw = _font.get_string_size(bs, HORIZONTAL_ALIGNMENT_LEFT, -1, 8).x
			draw_string(_font, c + Vector2(r - bw * 0.5 + 6.0, r - 2.0), bs,
					HORIZONTAL_ALIGNMENT_LEFT, -1, 8, Color(1, 1, 1, a * 0.9))
