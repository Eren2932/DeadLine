extends CharacterBody2D
class_name Ally
## Friendly pet (dog / tiger): charges the nearest zombie and mauls it.

var game = null
var kind = "pet_dog"
var speed = 90.0
var dmg = 18.0
var rate = 2.2
var cd = 0.0
var spr: AnimatedSprite2D


func setup(p_game, p_kind: String, power: float = 1.0) -> void:
	game = p_game
	kind = p_kind
	if kind == "pet_tiger":
		speed = 115.0
		dmg = 46.0 * power
		rate = 1.8
	else:
		speed = 96.0
		dmg = 20.0 * power
		rate = 2.4

	collision_layer = 0
	collision_mask = 0
	motion_mode = CharacterBody2D.MOTION_MODE_FLOATING
	add_to_group("allies")

	spr = AnimatedSprite2D.new()
	spr.sprite_frames = Art.char_frames(kind)
	spr.offset = Vector2(0, Art.char_feet_offset(kind))
	spr.play("run")
	add_child(spr)

	var cs = CollisionShape2D.new()
	var c = CircleShape2D.new()
	c.radius = 5.0
	cs.shape = c
	cs.position = Vector2(0, -4)
	add_child(cs)


func _physics_process(delta: float) -> void:
	if game == null or game.player == null:
		return
	cd = maxf(0.0, cd - delta)
	var t = game.nearest_zombie(global_position, 260.0)
	var goal: Vector2
	if t != null:
		goal = t.global_position
	else:
		goal = game.player.global_position + Vector2(-18.0, 6.0)

	var to = goal - global_position
	if to.length() > 10.0:
		velocity = to.normalized() * speed
	else:
		velocity = Vector2.ZERO
		if t != null and cd <= 0.0:
			cd = 1.0 / rate
			t.take_hit(dmg, (t.global_position - global_position).normalized() * 70.0,
					false, t.global_position + Vector2(0, -8))
			Audio.play("hit", -16.0, 1.3, 0.06)
	if velocity.x != 0.0:
		spr.flip_h = velocity.x < 0.0
	global_position = World.clamp_pos(global_position)
	if World.ENABLED:
		var _d = World.depth_of(global_position.y)
		scale = Vector2.ONE * World.scale_at(_d)
		z_index = World.z_at(_d)
	move_and_slide()
