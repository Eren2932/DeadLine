extends CharacterBody2D
class_name Player
## The survivor: movement, dash, weapon handling (every weapon kind), grenades,
## upgrades and damage taking. Aim is auto-assisted toward the nearest threat.

const BASE_SPEED := 78.0
const DASH_TIME := 0.24
const DASH_SPEED := 355.0
const INVULN_ON_HIT := 0.55
const MAX_WEAPONS := 4

var game = null

# ---- input (written by TouchPad / keyboard)
var move_input = Vector2.ZERO
var fire_held = false

# ---- body
var suit = "player_soldier"
var max_hp = 120.0
var hp = 120.0
var hp_base = 120.0                # body baseline
var hp_suit = 0.0                  # bonus from the equipped suit
var base_armor = 0.0
var base_regen = 0.0
var speed_mul_suit = 1.0
var dead = false
var invuln = 0.0
var facing = 1.0
var aim_dir = Vector2.RIGHT
var aim_target = null              # sticky: no more flicking between zombies
var _target_hold = 0.0

# ---- inventory
var weapons: Array = []
var slot = 0
var melee_id = "none"
var ammo: Dictionary = {}          # rounds in the magazine, per weapon id
var reserve: Dictionary = {}       # spare rounds carried, per weapon id (-1 = infinite)
var reloading = false
var reload_t = 0.0
var reload_total = 0.6
var shot_cd = 0.0
var melee_cd = 0.0
var grenades = 3
var rage_t = 0.0

# ---- dash
var dash_cd = 0.0
var dash_t = 0.0

# ---- progression
var upgrades: Dictionary = {}
var xp = 0
var level = 1
var xp_next = 36

# ---- rig (v3): the body sheet has no arms, both arms are rigged live with two
# bone IK straight onto the grip and the foregrip of the held weapon. That is
# what welds the gun into the hands at every aim angle, through recoil, while
# reloading and while it hangs at the hip.
const HOLD_AIM := Vector2(6.0, 3.2)     # rear hand vs shoulder, weapon up
const HOLD_REST := Vector2(3.4, 6.4)    # rear hand vs shoulder, weapon lowered
const REST_ANGLE := 0.72                # radians, muzzle down at ease
const RELOAD_ANGLE := 0.46
const AIM_TURN := 13.0                  # rad/s the aim can swing
const GUN_TURN := 16.0                  # rad/s the weapon can swing
const REST_DELAY := 1.35                # seconds of calm before it is lowered
const MAX_PITCH := 0.62                 # rad, keeps the pose readable

var spr: AnimatedSprite2D
var rig: Node2D                    # mirrored container: everything held
var gun_spr: Sprite2D
var muzzle: Sprite2D
var shadow: Sprite2D
var arm_pieces: Dictionary = {}    # key -> Sprite2D (upper/fore, front/back)
var arm_len = Vector2(5.2, 5.6)
var has_rig = false
var hand_local = Vector2(6, -20)
var hand_frames: Dictionary = {}   # anim name -> Array[Vector2] grip per frame
var sh_frames: Dictionary = {}     # anim name -> Array[Vector2] shoulder per frame
var char_feet = 36.0
var char_half_w = 13.0
var muzzle_len = 16.0
var grip_pt = Vector2.ZERO         # weapon grip in weapon pixels
var fore_off = Vector2(5, 0)       # grip -> foregrip, weapon pixels
var muzzle_off = Vector2(14, 0)    # grip -> muzzle, weapon pixels
var recoil = 0.0                   # pixels the gun is pushed back right now
var recoil_rot = 0.0               # radians of muzzle climb
var swing_t = 0.0                  # 0..1 melee swing progress
var dry_warned = false
var gun_angle = 0.0                # smoothed weapon angle in rig space
var raise_t = 0.0                  # 0 = at the hip, 1 = shouldered
var calm_t = 0.0                   # seconds since the last reason to aim

# ---- grenades (one pool per type) + class skill
var nade_type = "frag"
var nades: Dictionary = {}
var ability_cd = 0.0
var ability_t = 0.0                # active window of the class skill
var iron_t = 0.0                   # juggernaut damage soak
var class_rank = 0


# ------------------------------------------------------------------ setup
func setup(p_game, loadout: Dictionary) -> void:
	game = p_game
	suit = String(loadout.get("suit", "player_soldier"))
	if not GameData.SUITS.has(suit):
		suit = "player_soldier"
	var s: Dictionary = GameData.SUITS[suit]
	hp_base = 120.0
	hp_suit = float(s.get("hp", 0.0))
	max_hp = hp_base + hp_suit
	hp = max_hp
	base_armor = float(s.get("armor", 0.0))
	base_regen = float(s.get("regen", 0.0))
	speed_mul_suit = float(s.get("speed", 1.0))

	melee_id = String(loadout.get("melee", "none"))
	weapons.clear()
	var primary = String(loadout.get("primary", "ak47"))
	var sidearm = String(loadout.get("sidearm", "pistol"))
	if GameData.WEAPONS.has(sidearm):
		weapons.append(sidearm)
	if GameData.WEAPONS.has(primary) and primary != sidearm:
		weapons.append(primary)
	if weapons.is_empty():
		weapons.append("pistol")
	if melee_id != "none" and GameData.WEAPONS.has(melee_id):
		weapons.append(melee_id)
	slot = weapons.size() - 1 if melee_id == "none" else maxi(0, weapons.size() - 2)
	for w in weapons:
		ammo[w] = int(GameData.WEAPONS[w].get("mag", 10))
		reserve[w] = max_reserve(String(w))

	collision_layer = 1
	collision_mask = 0        # never blocked by our own walls / the horde
	motion_mode = CharacterBody2D.MOTION_MODE_FLOATING

	var shape = CollisionShape2D.new()
	var cs = CircleShape2D.new()
	cs.radius = 6.0
	shape.shape = cs
	shape.position = Vector2(0, -8)
	add_child(shape)

	shadow = Sprite2D.new()
	shadow.texture = Art.fx_tex("smoke")
	shadow.modulate = Color(0, 0, 0, 0.30)
	shadow.scale = Vector2(0.9, 0.35)
	shadow.z_index = -1
	add_child(shadow)
	_apply_depth()

	class_rank = Save.class_rank(suit)
	max_hp += GameData.class_hp_bonus(class_rank)
	hp = max_hp

	spr = AnimatedSprite2D.new()
	spr.sprite_frames = Art.char_frames(suit)
	spr.offset = Vector2(0, Art.char_feet_offset(suit))
	spr.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	spr.animation = "idle"
	spr.play()
	add_child(spr)

	var info: Dictionary = Art.char_info(suit)
	char_feet = float(info.get("feet", 36))
	char_half_w = float(info.get("w", 26)) * 0.5
	if char_half_w <= 1.0:
		char_half_w = 13.0
	var hand: Array = info.get("hand", [17.0, 20.0])
	hand_local = _to_local(Vector2(float(hand[0]), float(hand[1])))
	# The rig exports the grip point of EVERY frame, so the weapon now rides in
	# the hands through the whole walk cycle instead of floating at a fixed
	# offset near the shoulders.
	hand_frames = {}
	sh_frames = {}
	for anim_name in ["idle", "run", "attack"]:
		var pts: Array = Art.char_hands(suit, anim_name)
		var conv: Array = []
		for pt in pts:
			conv.append(_to_local(pt))
		if not conv.is_empty():
			hand_frames[anim_name] = conv
		var shp: Array = Art.char_shoulders(suit, anim_name)
		var sconv: Array = []
		for pt in shp:
			# snapped to whole pixels: the sheet itself is pixel art, so a
			# fractional pivot is exactly what used to make the gun shimmer
			sconv.append(_to_local(pt).round())
		if not sconv.is_empty():
			sh_frames[anim_name] = sconv
	has_rig = Art.char_has_rig(suit) and not sh_frames.is_empty()
	arm_len = Art.char_arm_lengths(suit)

	# Everything held lives inside one mirrored container, so the whole rig is
	# solved in right-facing space and flipped in one place. No per-sprite
	# mirroring maths, no chance of the gun ending up upside down.
	rig = Node2D.new()
	add_child(rig)

	for key in ["upper_back", "fore_back", "upper_front", "fore_front"]:
		var piece: Dictionary = Art.char_limb(suit, key)
		if piece.is_empty():
			continue
		var sp = Sprite2D.new()
		sp.texture = piece.get("tex", null)
		sp.centered = false
		sp.offset = -(piece.get("pivot", Vector2.ZERO) as Vector2)
		sp.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
		sp.z_index = -1 if key.ends_with("back") else 2
		rig.add_child(sp)
		arm_pieces[key] = sp

	gun_spr = Sprite2D.new()
	gun_spr.centered = false
	gun_spr.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	gun_spr.z_index = 1
	rig.add_child(gun_spr)

	muzzle = Sprite2D.new()
	muzzle.texture = Art.fx_tex("muzzle")
	muzzle.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	muzzle.visible = false
	muzzle.z_index = 3
	gun_spr.add_child(muzzle)

	z_index = 6
	_refresh_gun()
	grenades = 3 + lvl("grenades") * 2
	nades = {"frag": grenades}
	for id in GameData.GRENADE_ORDER:
		if not nades.has(id):
			nades[id] = 0
	nade_type = "frag"
	_pose_rig(0.0, true)


# ------------------------------------------------------------------ helpers
func _to_local(image_pt: Vector2) -> Vector2:
	## Image pixel -> node space (feet on the origin, centred horizontally).
	return Vector2(image_pt.x - char_half_w, image_pt.y - char_feet)


func grip_offset() -> Vector2:
	## Where the rear hand actually is on the frame that is on screen right now.
	if has_rig and rig != null and gun_spr != null:
		return Vector2(gun_spr.position.x * facing, gun_spr.position.y)
	var key = String(spr.animation) if spr != null else "idle"
	if hand_frames.has(key):
		var arr: Array = hand_frames[key]
		if not arr.is_empty():
			var i = clampi(spr.frame, 0, arr.size() - 1)
			return arr[i]
	return hand_local


func shoulder_offset() -> Vector2:
	## Shoulder pivot of the current frame, in right-facing local space.
	var key = String(spr.animation) if spr != null else "idle"
	if sh_frames.has(key):
		var arr: Array = sh_frames[key]
		if not arr.is_empty():
			var i = clampi(spr.frame, 0, arr.size() - 1)
			return arr[i]
	return Vector2(0, -22)


func _apply_depth() -> void:
	## v4: глубина видна физически. Дальше по поясу — мельче и рисуется раньше,
	## ближе — крупнее и перекрывает. Тень масштабируется вместе с телом, и
	## именно она приземляет спрайт на асфальт, убивая эффект «наклейки».
	if not World.ENABLED:
		return
	var d = World.depth_of(global_position.y)
	var s = World.scale_at(d)
	scale = Vector2(s, s)
	z_index = World.z_at(d)
	if shadow != null and is_instance_valid(shadow):
		shadow.scale = Vector2(0.9, 0.35) * s


func shoulder_pos() -> Vector2:
	## World space shoulder: the one true origin for aiming. Aiming used to be
	## measured from the muzzle, which is itself derived from the aim - a
	## feedback loop that made the weapon shiver every frame.
	var s = shoulder_offset()
	return global_position + Vector2(s.x * facing, s.y)


static func solve_ik(root: Vector2, target: Vector2, l1: float, l2: float,
		flip: float) -> Vector2:
	## Elbow position for a two bone arm. Reach is clamped, so an out of range
	## target simply straightens the arm instead of tearing it apart.
	var to = target - root
	var d = to.length()
	if d < 0.0001:
		to = Vector2(0.0001, 0.0)
		d = 0.0001
	d = clampf(d, absf(l1 - l2) + 0.02, l1 + l2 - 0.02)
	var u = to.normalized()
	var a = (l1 * l1 - l2 * l2 + d * d) / (2.0 * d)
	var h = sqrt(maxf(0.0, l1 * l1 - a * a))
	var mid = root + u * a
	return mid + Vector2(-u.y, u.x) * h * flip


func arm_reach_px() -> float:
	return arm_len.x + arm_len.y


func max_hp_total() -> float:
	## Base body + suit + HP cards + everything earned by levelling. The
	## survivor has to grow with the horde, otherwise one brute swipe ends a
	## 60 wave run.
	return hp_base + hp_suit + 30.0 * float(lvl("hp")) + GameData.player_hp_bonus(level)


func refresh_max_hp(carry_gain: bool = true) -> void:
	var before = max_hp
	max_hp = maxf(1.0, max_hp_total())
	if carry_gain and max_hp > before:
		hp = clampf(hp + (max_hp - before), 0.0, max_hp)
	hp = clampf(hp, 0.0, max_hp)


func on_level_up() -> void:
	## Every level: bigger frame, and a real chunk of health back. This is the
	## "we get stronger too" side of the difficulty curve.
	refresh_max_hp(true)
	heal(max_hp * GameData.LEVEL_HEAL_FRACTION)
	grenades += 1
	if game != null and game.fx != null:
		game.fx.float_text(global_position + Vector2(0, -30),
				UI.tr_f("LEVEL %d", [level]), UI.GOLD)


func lvl(id: String) -> int:
	return int(upgrades.get(id, 0))


func add_upgrade(id: String) -> void:
	upgrades[id] = lvl(id) + 1
	match id:
		"hp":
			refresh_max_hp(true)
			heal(30.0)
		"grenades":
			grenades += 2
		"dog":
			game.spawn_ally("pet_dog")
		"tiger":
			game.spawn_ally("pet_tiger")
		_:
			pass


func weapon_id() -> String:
	if weapons.is_empty():
		return "pistol"
	return String(weapons[clampi(slot, 0, weapons.size() - 1)])


func weapon() -> Dictionary:
	return GameData.WEAPONS.get(weapon_id(), GameData.WEAPONS["pistol"])


func dmg_mul() -> float:
	## Level based power keeps every gun relevant deep into a run, upgrades and
	## adrenaline stack on top of it.
	return (1.0 + 0.18 * float(lvl("dmg"))) * GameData.player_power(level) \
			* (1.6 if rage_t > 0.0 else 1.0)


func weapon_ap() -> float:
	## How much of the target armour this shot ignores. AP Rounds add to it.
	return clampf(float(weapon().get("ap", 0.0)) + 0.08 * float(lvl("pierce")), 0.0, 0.95)


func rate_mul() -> float:
	var suit_rate = float(GameData.SUITS.get(suit, {}).get("rate", 1.0))
	return (1.0 + 0.12 * float(lvl("rate"))) * (1.35 if rage_t > 0.0 else 1.0) * suit_rate


func mag_size(id: String) -> int:
	var base = int(GameData.WEAPONS.get(id, {}).get("mag", 10))
	if base <= 0:
		return 0
	return int(round(float(base) * (1.0 + 0.3 * float(lvl("mag")))))


func crit_chance() -> float:
	return 0.05 + 0.08 * float(lvl("crit"))


func crit_mul() -> float:
	return 2.0 + 0.5 * float(lvl("critdmg"))


func armor() -> float:
	return clampf(base_armor + 0.07 * float(lvl("armor")), 0.0, 0.70)


func armor_flat() -> float:
	## Flat plating: shaves a chunk off every single hit, which is what makes a
	## swarm of weak walkers survivable late on.
	return 2.0 * float(lvl("armor")) + GameData.player_armor_flat(level)


func move_speed() -> float:
	return BASE_SPEED * speed_mul_suit * (1.0 + 0.08 * float(lvl("speed")))


func dash_cooldown() -> float:
	var suit_dash = float(GameData.SUITS.get(suit, {}).get("dash", 1.0))
	return maxf(0.35, 1.5 * suit_dash * (1.0 - 0.20 * float(lvl("dash"))))


func dash_duration() -> float:
	return DASH_TIME + 0.02 * float(lvl("dash"))


func reload_progress() -> float:
	if not reloading or reload_total <= 0.0:
		return 0.0
	return clampf(1.0 - reload_t / reload_total, 0.0, 1.0)


func ammo_in_mag() -> int:
	return int(ammo.get(weapon_id(), 0))


func is_melee() -> bool:
	return String(weapon().get("kind", "bullet")) == "melee"


# ------------------------------------------------------------------ inventory
func add_weapon(id: String) -> bool:
	if not GameData.WEAPONS.has(id):
		return false
	if weapons.has(id):
		# already owned: the pickup simply tops the gun up
		ammo[id] = mag_size(id)
		reserve[id] = max_reserve(id)
		return true
	if weapons.size() >= MAX_WEAPONS:
		# replace the currently selected non-melee gun
		var target = slot
		if String(GameData.WEAPONS[String(weapons[target])].get("kind", "")) == "melee":
			target = 0
		weapons[target] = id
	else:
		weapons.append(id)
		slot = weapons.size() - 1
	ammo[id] = mag_size(id)
	reserve[id] = max_reserve(id)
	reloading = false
	dry_warned = false
	_refresh_gun()
	return true


func drop_weapon(id: String) -> bool:
	## Sell / drop a gun. The last shooting weapon can never be dropped.
	if not weapons.has(id):
		return false
	var guns = 0
	for w in weapons:
		if String(GameData.WEAPONS[String(w)].get("kind", "")) != "melee":
			guns += 1
	if String(GameData.WEAPONS[id].get("kind", "")) != "melee" and guns <= 1:
		return false
	weapons.erase(id)
	ammo.erase(id)
	reserve.erase(id)
	slot = clampi(slot, 0, maxi(0, weapons.size() - 1))
	reloading = false
	_refresh_gun()
	return true


func owns(id: String) -> bool:
	return weapons.has(id)


func max_reserve(id: String) -> int:
	var base = int(GameData.WEAPONS.get(id, {}).get("reserve", 0))
	if base < 0:
		return -1
	return int(round(float(base) * (1.0 + 0.25 * float(lvl("mag")))))


func reserve_ammo(id: String) -> int:
	if max_reserve(id) < 0:
		return -1
	return int(reserve.get(id, 0))


func add_reserve(id: String, amount: int) -> void:
	if max_reserve(id) < 0:
		return
	reserve[id] = clampi(int(reserve.get(id, 0)) + amount, 0, max_reserve(id))


func fill_reserve(id: String) -> void:
	if max_reserve(id) < 0:
		return
	reserve[id] = max_reserve(id)
	ammo[id] = mag_size(id)


func total_ammo(id: String) -> int:
	## Rounds in the mag plus spare rounds (-1 when the gun never runs dry).
	if max_reserve(id) < 0:
		return -1
	return int(ammo.get(id, 0)) + int(reserve.get(id, 0))


func is_dry(id: String) -> bool:
	if String(GameData.WEAPONS.get(id, {}).get("kind", "bullet")) == "melee":
		return false
	return total_ammo(id) == 0


func auto_swap_if_dry() -> void:
	## When the current gun is empty and no spare rounds are left, switch to
	## something that can still shoot instead of clicking on an empty chamber.
	if not is_dry(weapon_id()):
		return
	for i in range(weapons.size()):
		var idx = posmod(slot + 1 + i, weapons.size())
		var id = String(weapons[idx])
		if not is_dry(id):
			select_slot(idx)
			if not dry_warned:
				dry_warned = true
				game.hud.flash_banner(UI.tr_ui("OUT OF AMMO - SWAPPING"), UI.RED)
			return


func select_slot(i: int) -> void:
	if weapons.is_empty():
		return
	slot = clampi(i, 0, weapons.size() - 1)
	reloading = false
	_refresh_gun()
	Audio.play("click", -14.0)


func next_weapon() -> void:
	if weapons.is_empty():
		return
	select_slot(posmod(slot + 1, weapons.size()))


func refill_ammo() -> void:
	for w in weapons:
		ammo[w] = mag_size(String(w))
		fill_reserve(String(w))
	reloading = false
	dry_warned = false


func add_grenades(n: int) -> void:
	## Kept for pickups and shop code: tops up the selected type.
	add_nades(nade_type if nades.has(nade_type) else "frag", n)
	return


func _add_grenades_legacy(n: int) -> void:
	grenades += n


func add_ammo_fraction(f: float) -> void:
	## Ammo pickup: tops every carried gun up by a share of its full reserve.
	for w in weapons:
		var id = String(w)
		var full = max_reserve(id)
		if full <= 0:
			continue
		add_reserve(id, maxi(1, int(round(float(full) * f))))
	dry_warned = false


func give_rage(seconds: float) -> void:
	rage_t = maxf(rage_t, seconds)
	game.fx.big_text(global_position + Vector2(0, -26), UI.tr_ui("ADRENALINE"), UI.RED)


func heal(amount: float) -> void:
	hp = clampf(hp + amount, 0.0, max_hp)


func _refresh_gun() -> void:
	## Reads the anchors the art pipeline exports for this weapon: the grip
	## (rear hand), the foregrip (front hand) and the muzzle. Every one of them
	## sits on drawn metal, so the hands can never float next to the gun.
	var id = weapon_id()
	gun_spr.texture = Art.weapon_tex(id)
	var info = Art.weapon_info(id)
	var grip: Array = info.get("grip", [3.0, 4.0])
	grip_pt = Vector2(float(grip[0]), float(grip[1]))
	var w_px = float(info.get("w", 20))
	var mz: Array = info.get("muzzle", [w_px - 2.0, grip_pt.y])
	var fr: Array = info.get("fore", [minf(w_px - 2.0, grip_pt.x + 5.0), grip_pt.y])
	muzzle_off = Vector2(float(mz[0]), float(mz[1])) - grip_pt
	fore_off = Vector2(float(fr[0]), float(fr[1])) - grip_pt
	# the front hand can never be asked to reach further than the arm goes: it
	# slides back along the handguard instead of detaching from the weapon
	var max_fore = maxf(1.0, arm_reach_px() * 0.94 - HOLD_AIM.x + 1.0)
	if fore_off.x > max_fore:
		fore_off.x = max_fore
	gun_spr.offset = -grip_pt
	muzzle_len = maxf(4.0, muzzle_off.length())
	muzzle.position = muzzle_off


# ------------------------------------------------------------------ loop
func _physics_process(delta: float) -> void:
	if game == null:
		return
	if dead:
		return

	invuln = maxf(0.0, invuln - delta)
	shot_cd = maxf(0.0, shot_cd - delta)
	melee_cd = maxf(0.0, melee_cd - delta)
	dash_cd = maxf(0.0, dash_cd - delta)
	rage_t = maxf(0.0, rage_t - delta)
	ability_cd = maxf(0.0, ability_cd - delta)
	iron_t = maxf(0.0, iron_t - delta)

	var regen = base_regen + float(lvl("regen"))
	if regen > 0.0 and hp < max_hp:
		heal(regen * delta)

	# ---- reload
	if reloading:
		reload_t -= delta
		if reload_t <= 0.0:
			reloading = false
			_finish_reload()

	# ---- movement
	var mv = move_input.limit_length(1.0)
	if dash_t > 0.0:
		dash_t -= delta
		var dash_dir = mv if mv.length() > 0.2 else aim_dir
		velocity = dash_dir.normalized() * DASH_SPEED
		if lvl("dashkill") > 0:
			for z in game.zombies_near(global_position, 18.0):
				if not z.dead:
					z.take_hit(70.0 * float(lvl("dashkill")) * GameData.player_power(level),
							velocity.normalized() * 140.0, false, z.hit_center(), 0.4)
	else:
		# v4: движение вдоль улицы и в глубину — разные скорости. Иначе шаг
		# «вглубь» из-за перспективного сжатия выглядит вдвое быстрее шага вбок.
		velocity = Vector2(mv.x, mv.y * World.DEPTH_SPEED) * move_speed()
	move_and_slide()
	global_position = World.clamp_pos(global_position)
	global_position.x = clampf(global_position.x, GameData.play_left(), GameData.play_right())
	_apply_depth()

	# ---- aim: measured from the SHOULDER, smoothed, and sticky on one target.
	# Measuring from the muzzle fed the aim back into itself and re-picking the
	# nearest zombie every frame flicked the gun around - that was the shake.
	var reach = minf(float(weapon().get("range", 300.0)), game.visible_half_w() + 10.0)
	var origin = shoulder_pos()
	_target_hold = maxf(0.0, _target_hold - delta)
	if not _target_valid(reach) or _target_hold <= 0.0:
		var found = game.best_target(origin, reach)
		if found != null or aim_target == null or not _target_valid(reach):
			aim_target = found
		_target_hold = 0.32
	var target = aim_target
	var desired = aim_dir
	if target != null:
		desired = (target.hit_center() - origin).normalized()
	elif mv.length() > 0.15:
		desired = Vector2(signf(mv.x) if absf(mv.x) > 0.05 else facing, 0.0).normalized()
	else:
		desired = Vector2(facing, 0.0)
	# keep the pose readable: no shooting straight up out of a side view
	var pitch = clampf(asin(clampf(desired.y, -1.0, 1.0)), -MAX_PITCH, MAX_PITCH)
	desired = Vector2(signf(desired.x) if absf(desired.x) > 0.001 else facing, 0.0) \
			.rotated(pitch * (1.0 if desired.x >= 0.0 else -1.0))
	var da = aim_dir.angle_to(desired)
	aim_dir = aim_dir.rotated(clampf(da, -AIM_TURN * delta, AIM_TURN * delta)).normalized()
	if absf(aim_dir.x) > 0.05:
		facing = signf(aim_dir.x)
	spr.flip_h = facing < 0.0

	# ---- animation
	# The cycle is driven by how fast the body ACTUALLY moves, so the feet stop
	# sliding: slow walk = slow steps, sprint = fast steps.
	var want_anim = "idle"
	if swing_t > 0.0 and is_melee() and spr.sprite_frames.has_animation("attack"):
		want_anim = "attack"
	elif mv.length() > 0.12 or dash_t > 0.0:
		want_anim = "run"
	if spr.animation != want_anim:
		spr.animation = want_anim
		spr.frame = 0
		spr.play()
	if want_anim == "run":
		var ref_speed = maxf(60.0, BASE_SPEED)
		spr.speed_scale = clampf(velocity.length() / ref_speed, 0.45, 2.4)
	else:
		spr.speed_scale = 1.0

	# ---- rig: weapon + both arms
	recoil = maxf(0.0, recoil - delta * 26.0)
	recoil_rot = maxf(0.0, recoil_rot - delta * 5.5)
	swing_t = maxf(0.0, swing_t - delta * 7.0)
	var busy = fire_held or reloading or target != null or dash_t > 0.0 or swing_t > 0.0
	calm_t = 0.0 if busy else calm_t + delta
	var want_up = 0.0 if calm_t > REST_DELAY else 1.0
	raise_t = move_toward(raise_t, want_up, delta * (7.0 if want_up > 0.5 else 3.2))
	_pose_rig(delta, false)

	# ---- shooting
	var want_fire: bool = fire_held or (Settings.on("autofire") and target != null)
	if want_fire and not game.is_over() and not game.in_prep():
		fire()
	elif want_fire and game.in_prep() and target != null:
		fire()


func muzzle_pos() -> Vector2:
	## The real world muzzle of the sprite that is on screen: bullets, flashes,
	## casings and smoke all come out of the same pixel the barrel ends on.
	if has_rig and gun_spr != null:
		var local: Vector2 = gun_spr.position + muzzle_off.rotated(gun_spr.rotation)
		return global_position + Vector2(local.x * facing, local.y)
	var g = grip_offset()
	return global_position + Vector2(g.x * facing, g.y) + aim_dir * muzzle_len


func _target_valid(reach: float) -> bool:
	if aim_target == null or not is_instance_valid(aim_target):
		aim_target = null
		return false
	if aim_target.dead:
		return false
	return aim_target.global_position.distance_to(global_position) <= reach + 24.0


func _pose_rig(delta: float, instant: bool) -> void:
	## Solves the whole hold in one place, in right-facing space, then mirrors
	## the container. Order on screen: back arm, weapon, front arm - so the gun
	## sits inside the hands instead of on top of the survivor.
	if rig == null or gun_spr == null:
		return
	rig.scale = Vector2(facing, 1.0)
	gun_spr.visible = gun_spr.texture != null
	var sh = shoulder_offset()
	var melee = is_melee()

	# ---- target angle for the weapon
	var aim_local = Vector2(aim_dir.x * facing, aim_dir.y)
	var want_ang = aim_local.angle()
	if melee:
		want_ang = lerpf(-1.15, 0.85, 1.0 - swing_t) if swing_t > 0.0 else -0.30
	elif reloading:
		want_ang = RELOAD_ANGLE
	else:
		want_ang = lerpf(REST_ANGLE, want_ang, raise_t) - recoil_rot
	if instant:
		gun_angle = want_ang
	else:
		var d = wrapf(want_ang - gun_angle, -PI, PI)
		gun_angle += clampf(d, -GUN_TURN * delta, GUN_TURN * delta)

	# ---- hands
	var hold = HOLD_REST.lerp(HOLD_AIM, raise_t)
	if melee:
		hold = Vector2(5.2, 2.2)
	var dir = Vector2.RIGHT.rotated(gun_angle)
	var rear = sh + hold.rotated(gun_angle) - dir * recoil
	var fore_local = fore_off
	if melee:
		fore_local = Vector2(minf(fore_off.x, 3.0), fore_off.y + 1.0)
	var front = rear + fore_local.rotated(gun_angle)
	if reloading:
		# the support hand leaves the handguard, slaps a fresh mag in and comes
		# back - a real reload beat instead of a frozen pose
		var t = reload_progress()
		var pull = sin(clampf(t, 0.0, 1.0) * PI)
		front += Vector2(-3.0, 6.0) * pull
	gun_spr.position = rear
	gun_spr.rotation = gun_angle

	# ---- arms follow the hands, never the other way round
	_pose_arm("upper_back", "fore_back", sh + Vector2(-1.2, 1.0), rear, 1.0)
	_pose_arm("upper_front", "fore_front", sh + Vector2(0.6, 0.2), front, 1.0)


func _pose_arm(upper_key: String, fore_key: String, root: Vector2, hand: Vector2,
		flip: float) -> void:
	var up: Sprite2D = arm_pieces.get(upper_key, null)
	var fo: Sprite2D = arm_pieces.get(fore_key, null)
	if up == null or fo == null:
		return
	var elbow = solve_ik(root, hand, arm_len.x, arm_len.y, flip)
	up.position = root
	up.rotation = (elbow - root).angle()
	fo.position = elbow
	fo.rotation = (hand - elbow).angle()
	up.visible = true
	fo.visible = true


# ------------------------------------------------------------------ shooting
func fire() -> void:
	if dead or reloading or shot_cd > 0.0:
		return
	var id = weapon_id()
	var w = weapon()
	var kind = String(w.get("kind", "bullet"))

	if kind == "melee":
		_melee_swing(w)
		return

	if ammo_in_mag() <= 0:
		start_reload()
		auto_swap_if_dry()
		return

	shot_cd = 1.0 / maxf(0.05, float(w.get("rate", 3.0)) * rate_mul())
	ammo[id] = ammo_in_mag() - 1

	var count = int(w.get("count", 1)) + lvl("multishot")
	var spread = float(w.get("spread", 3.0))
	var dmg = float(w.get("dmg", 10.0)) * dmg_mul()
	var knock = float(w.get("knock", 30.0)) * (1.0 + 0.5 * float(lvl("knock")))
	var pierce = int(w.get("pierce", 0)) + lvl("pierce")
	var from = muzzle_pos()

	match kind:
		"laser":
			for i in range(count):
				var d = aim_dir.rotated(deg_to_rad(randf_range(-spread, spread)))
				game.hitscan(from, d, float(w.get("range", 500.0)), dmg, pierce + 2, knock,
						crit_chance(), crit_mul(), Color(0.6, 0.9, 1.0) if id != "gauss"
						else Color(0.75, 0.6, 1.0), weapon_ap())
		"tesla":
			game.chain_lightning(from, 4 + lvl("multishot"), dmg, 150.0, true, weapon_ap())
		"flame":
			for i in range(count + 2):
				var d = aim_dir.rotated(deg_to_rad(randf_range(-spread, spread)))
				game.spawn_bullet(from, d, _cfg(w, dmg * 0.34, knock * 0.1, 0, {
					"kind": "flame", "tex": "flame", "speed": 210.0, "life": 0.42,
					"burn": 2.2 + 0.6 * float(lvl("burn")), "scale": 1.2,
					"color": Color(1.0, 0.8, 0.4),
				}))
		"rocket":
			for i in range(count):
				var d = aim_dir.rotated(deg_to_rad(randf_range(-spread, spread)))
				game.spawn_bullet(from, d, _cfg(w, dmg, knock, 0, {
					"kind": "rocket", "tex": "rocket", "speed": float(w.get("speed", 320.0)),
					"life": 2.0, "aoe": maxf(48.0, float(w.get("aoe", 60.0))),
					"homing": 0.25 if lvl("magnet") > 0 else 0.0,
				}))
		"grenade":
			for i in range(count):
				var d = aim_dir.rotated(deg_to_rad(randf_range(-spread, spread)))
				game.spawn_bullet(from, d, _cfg(w, dmg, knock, 0, {
					"kind": "grenade", "tex": "bullet_big", "speed": float(w.get("speed", 300.0)),
					"life": 1.1, "aoe": maxf(46.0, float(w.get("aoe", 56.0))), "spin": 10.0,
				}))
		"pellet":
			for i in range(count):
				var d = aim_dir.rotated(deg_to_rad(randf_range(-spread, spread)))
				game.spawn_bullet(from, d, _cfg(w, dmg, knock, pierce, {
					"kind": "pellet", "tex": "bullet", "speed": float(w.get("speed", 520.0)),
					"life": float(w.get("range", 180.0)) / maxf(1.0, float(w.get("speed", 520.0))) + 0.05,
				}))
		_:
			for i in range(count):
				var d = aim_dir.rotated(deg_to_rad(randf_range(-spread, spread)))
				var big = dmg > 40.0
				game.spawn_bullet(from, d, _cfg(w, dmg, knock, pierce, {
					"kind": "bullet", "tex": "bullet_big" if big else "bullet",
					"speed": float(w.get("speed", 620.0)),
					"life": float(w.get("range", 340.0)) / maxf(1.0, float(w.get("speed", 620.0))) + 0.06,
					"scale": 1.0,
				}))

	# ---- feedback
	_muzzle_flash(kind)
	game.shake(float(w.get("shake", 1.0)) * 0.9)
	if kind != "flame" or randf() < 0.25:
		Audio.play(_shot_sound(id, kind), -8.0, randf_range(0.94, 1.08), 0.02)
	if kind in ["bullet", "pellet"]:
		game.fx.casing(muzzle_pos() + Vector2(-2 * facing, -1), aim_dir)
	recoil = minf(recoil + float(w.get("shake", 1.0)) * 1.1 + 1.0, 4.0)
	# the muzzle climbs and settles: recoil you can actually read on screen
	recoil_rot = minf(recoil_rot + 0.05 + 0.035 * float(w.get("shake", 1.0)), 0.30)
	raise_t = 1.0
	calm_t = 0.0
	if ammo_in_mag() <= 0:
		start_reload()
		auto_swap_if_dry()


func _cfg(w: Dictionary, dmg: float, knock: float, pierce: int, extra: Dictionary) -> Dictionary:
	var cfg = {
		"dmg": dmg,
		"knock": knock,
		"pierce": pierce,
		"from_player": true,
		"crit": crit_chance(),
		"crit_mul": crit_mul(),
		"explosive": 0.12 * float(lvl("explosive")),
		"burn": 1.8 * float(lvl("burn")),
		"slow": 1.2 if lvl("slow") > 0 else 0.0,
		"ap": weapon_ap(),
	}
	for k in extra.keys():
		cfg[k] = extra[k]
	return cfg


func _shot_sound(id: String, kind: String) -> String:
	match kind:
		"pellet":
			return "shotgun"
		"laser":
			return "laser"
		"tesla":
			return "zap"
		"flame":
			return "flame"
		"rocket", "grenade":
			return "shot_big"
		_:
			if id == "minigun" or id == "uzi" or id == "lmg":
				return "shot"
			return "shot_big" if float(GameData.WEAPONS[id].get("dmg", 10)) > 35.0 else "shot"


func _muzzle_flash(kind: String) -> void:
	if kind == "melee":
		return
	muzzle.visible = true
	muzzle.rotation = 0.0
	muzzle.scale = Vector2.ONE * randf_range(0.8, 1.25)
	muzzle.modulate = Color(1.0, 0.9, 0.6) if kind != "laser" else Color(0.7, 0.9, 1.0)
	var tw = create_tween()
	tw.tween_interval(0.05)
	tw.tween_callback(func() -> void: muzzle.visible = false)


func _melee_swing(w: Dictionary) -> void:
	if melee_cd > 0.0:
		return
	melee_cd = 1.0 / maxf(0.2, float(w.get("rate", 2.0)) * rate_mul())
	var reach = float(w.get("range", 26.0))
	var dmg = float(w.get("dmg", 30.0)) * dmg_mul()
	Audio.play("saw" if weapon_id() == "chainsaw" else "whoosh", -10.0, randf_range(0.95, 1.1), 0.02)
	var center = global_position + Vector2(0, -10)
	var hit = false
	for z in game.zombies_near(center + Vector2(facing * reach * 0.5, 0), reach + 14.0):
		if z.dead:
			continue
		var to: Vector2 = z.hit_center() - center
		if to.length() > reach + z.radius:
			continue
		if signf(to.x) != facing and absf(to.x) > 4.0:
			continue
		z.take_hit(dmg, Vector2(facing, -0.25) * float(w.get("knock", 120.0)),
				randf() < crit_chance() + 0.15, z.hit_center(), weapon_ap())
		if lvl("burn") > 0:
			z.ignite(1.5 * float(lvl("burn")))
		hit = true
	swing_t = 1.0
	if hit:
		game.shake(1.2)
		game.hitstop(0.045)
	var sweep = create_tween()
	sweep.tween_property(spr, "rotation_degrees", 6.0 * facing, 0.05)
	sweep.tween_property(spr, "rotation_degrees", 0.0, 0.1)


func start_reload() -> void:
	if reloading or dead:
		return
	var id = weapon_id()
	if is_melee():
		return
	if ammo_in_mag() >= mag_size(id):
		return
	if reserve_ammo(id) == 0:
		auto_swap_if_dry()
		return
	reloading = true
	reload_total = float(weapon().get("reload", 1.2)) * (1.0 - 0.15 * float(lvl("reload")))
	reload_total = maxf(0.18, reload_total)
	reload_t = reload_total
	Audio.play("reload", -10.0, randf_range(0.95, 1.05))


# ------------------------------------------------------------------ reloading
func _finish_reload() -> void:
	var id = weapon_id()
	var want = mag_size(id) - int(ammo.get(id, 0))
	if want <= 0:
		return
	if max_reserve(id) < 0:
		ammo[id] = mag_size(id)
		return
	var got = mini(want, int(reserve.get(id, 0)))
	ammo[id] = int(ammo.get(id, 0)) + got
	reserve[id] = int(reserve.get(id, 0)) - got


# ------------------------------------------------------------------ abilities
func dash() -> void:
	if dead or dash_cd > 0.0 or dash_t > 0.0:
		return
	dash_cd = dash_cooldown()
	dash_t = dash_duration()
	invuln = maxf(invuln, dash_t + 0.18)
	Audio.play("dash", -10.0, randf_range(0.95, 1.1))
	game.fx.smoke(global_position + Vector2(0, -4), 5, Color(0.5, 0.47, 0.42, 0.6))


func nade_count(id: String = "") -> int:
	var key = nade_type if id == "" else id
	return int(nades.get(key, 0))


func nade_total() -> int:
	var n = 0
	for id in GameData.GRENADE_ORDER:
		n += int(nades.get(id, 0))
	return n


func add_nades(id: String, n: int) -> void:
	if not GameData.GRENADES.has(id):
		return
	var cap = int(GameData.grenade(id).get("max", 9)) + lvl("grenades")
	nades[id] = clampi(nade_count(id) + n, 0, cap)
	grenades = nade_total()


func cycle_nade(step: int = 1) -> void:
	## Rotates through the types the player actually has unlocked this run.
	var order: Array = GameData.GRENADE_ORDER
	var wave = game.wave if game != null else 1
	for i in range(order.size()):
		var idx = posmod(order.find(nade_type) + step * (i + 1), order.size())
		var id = String(order[idx])
		if GameData.grenade_unlocked(id, wave):
			nade_type = id
			Audio.play("click", -14.0)
			if game != null and game.hud != null:
				game.hud.flash_banner(UI.tr_ui(String(GameData.grenade(id).get("name",
						"Frag Grenade"))), GameData.grenade(id).get("color", UI.BONE))
			return


func throw_grenade() -> void:
	if dead:
		return
	if nade_count() <= 0:
		# never a dead button: roll onto a type that still has stock
		cycle_nade(1)
		if nade_count() <= 0:
			if game != null and game.hud != null:
				game.hud.flash_banner(UI.tr_ui("NO GRENADES"), UI.RED)
			return
	var g: Dictionary = GameData.grenade(nade_type)
	nades[nade_type] = nade_count() - 1
	grenades = nade_total()
	var from = muzzle_pos()
	var boost = 1.0 + 0.35 * float(lvl("nadedmg"))
	var blast = float(g.get("aoe", 78.0)) * (1.0 + 0.18 * float(lvl("nadedmg")))
	var dmg = (140.0 + 18.0 * float(level)) * dmg_mul() * boost \
			* float(g.get("dmg", 1.0))
	# Aim at the fattest cluster in range instead of lobbing it at the nearest
	# scrub: the fuse is timed so the grenade lands right on that spot.
	var dir = aim_dir
	var travel = 1.15
	var spot: Vector2 = game.best_cluster(from, 260.0, blast)
	if spot != Vector2.ZERO:
		var to: Vector2 = spot - from
		dir = to.normalized()
		travel = clampf(to.length() / 300.0, 0.14, 1.4)
	var cfg = {
		"kind": "grenade", "tex": "bullet_big", "dmg": dmg, "speed": 300.0,
		"life": travel, "aoe": blast, "from_player": true, "knock": 190.0, "spin": 12.0,
		"ap": 0.5, "crit": crit_chance(), "crit_mul": crit_mul(),
		"color": g.get("color", Color(0.7, 0.9, 0.6)),
		"nade": nade_type,
	}
	if g.has("hazard"):
		cfg["hazard"] = String(g.get("hazard", "fire"))
		cfg["haz_time"] = float(g.get("haz_time", 5.0)) * boost
		cfg["haz_dps"] = float(g.get("haz_dps", 20.0)) * dmg_mul()
		cfg["haz_radius"] = float(g.get("haz_radius", 54.0))
	if g.has("chain"):
		cfg["chain"] = int(g.get("chain", 6))
		cfg["stun"] = float(g.get("stun", 2.0))
	if bool(g.get("slow", false)):
		cfg["slow"] = 2.4
	game.spawn_bullet(from, dir, cfg)
	Audio.play("shot", -14.0, 0.7)


# ------------------------------------------------------------------ class skill
func ability_id() -> String:
	return GameData.suit_ability(suit)


func ability_total_cd() -> float:
	return GameData.suit_ability_cd(suit, class_rank)


func ability_ready() -> bool:
	return not dead and ability_cd <= 0.0


func ability_ratio() -> float:
	var total = ability_total_cd()
	if total <= 0.0:
		return 1.0
	return clampf(1.0 - ability_cd / total, 0.0, 1.0)


func use_ability() -> void:
	## One button, one identity per class. This is what makes the suits play
	## differently instead of being a stat sheet with a new colour.
	if not ability_ready():
		return
	var power = GameData.class_power(class_rank)
	ability_cd = ability_total_cd()
	var id = ability_id()
	match id:
		"resupply":
			reloading = false
			for w in weapons:
				ammo[w] = mag_size(String(w))
			add_ammo_fraction(0.5 * power)
			add_nades("frag", 1 + int(class_rank / 2))
			dry_warned = false
			game.fx.float_text(global_position + Vector2(0, -34), UI.tr_ui("RESUPPLY"), UI.GOLD)
		"flashbang":
			var hit = 0
			for z in game.zombies_near(global_position, 130.0 * power):
				if z.dead:
					continue
				z.stagger(2.0 * power)
				z.take_hit(30.0 * power * dmg_mul(), Vector2(signf(z.global_position.x
						- global_position.x), -0.2) * 120.0, false, z.hit_center(), 0.3)
				hit += 1
			game.fx.shockwave(global_position + Vector2(0, -14), 90.0 * power,
					Color(0.85, 0.95, 1.0, 0.7))
			game.shake(3.0)
			game.fx.float_text(global_position + Vector2(0, -34), UI.tr_ui("FLASHBANG"), UI.BLUE)
			if hit > 0:
				game.hitstop(0.06)
		"adrenaline":
			give_rage(6.0 * power)
			invuln = maxf(invuln, 0.6)
			dash_cd = 0.0
		"fieldkit":
			heal(max_hp * 0.4 * power)
			game.heal_allies(60.0 * power)  # medics keep the pets alive too
			game.fx.float_text(global_position + Vector2(0, -34), UI.tr_ui("FIELD KIT"),
					Color(0.5, 1.0, 0.6))
		"ironskin":
			iron_t = 4.0 + 0.5 * float(class_rank)
			invuln = maxf(invuln, 0.4)
			for z in game.zombies_near(global_position, 60.0):
				if not z.dead:
					z.take_hit(60.0 * power * dmg_mul(), (z.hit_center()
							- global_position).normalized() * 260.0, false,
							z.hit_center(), 0.4)
			game.shake(4.0)
			game.kick(Vector2.DOWN, 3.0)
			game.fx.float_text(global_position + Vector2(0, -34), UI.tr_ui("IRON SKIN"),
					Color(0.8, 0.85, 1.0))
		_:
			pass
	Audio.play("levelup", -8.0)
	game.haptic(70)


# ------------------------------------------------------------------ damage
func take_damage(amount: float, from_pos: Vector2 = Vector2.ZERO) -> void:
	if dead or invuln > 0.0:
		return
	if iron_t > 0.0:
		amount *= 0.15
	var final = maxf(amount * (1.0 - armor()) - armor_flat(), amount * 0.15)
	hp -= final
	invuln = INVULN_ON_HIT
	game.fx.blood(global_position + Vector2(0, -12), 6, Color(0.7, 0.1, 0.1),
			(global_position - from_pos).normalized(), 80.0)
	# thrown away from whatever just hit us, so a hit from the left is felt as a
	# hit from the left
	if from_pos != Vector2.ZERO:
		game.kick(from_pos.direction_to(global_position), 2.4)
	else:
		game.shake(2.2)
	game.hud.hurt_pulse()
	game.haptic(45 if final < max_hp * 0.12 else 95)
	Audio.play("hurt", -6.0, randf_range(0.95, 1.05))
	if hp <= 0.0:
		_die()


func on_kill(z) -> void:
	if lvl("lifesteal") > 0:
		heal(float(lvl("lifesteal")))


func _die() -> void:
	dead = true
	hp = 0.0
	fire_held = false
	if spr.sprite_frames.has_animation("death"):
		spr.animation = "death"
		spr.frame = 0
		spr.play()
	if rig != null:
		rig.visible = false
	game.fx.gore(global_position + Vector2(0, -12), Color(0.7, 0.1, 0.1))
	game.on_player_died()


# ------------------------------------------------------------------ save/load
func serialize() -> Dictionary:
	## Everything about this survivor that a run save has to remember. Kept
	## flat and plain so an old save can never crash a new build.
	var ammo_out: Dictionary = {}
	for k in ammo.keys():
		ammo_out[String(k)] = int(ammo[k])
	var res_out: Dictionary = {}
	for k in reserve.keys():
		res_out[String(k)] = int(reserve[k])
	var nade_out: Dictionary = {}
	for k in nades.keys():
		nade_out[String(k)] = int(nades[k])
	var up_out: Dictionary = {}
	for k in upgrades.keys():
		up_out[String(k)] = int(upgrades[k])
	return {
		"suit": suit,
		"hp": hp,
		"max_hp": max_hp,
		"level": level,
		"xp": int(xp),
		"weapons": weapons.duplicate(),
		"slot": slot,
		"ammo": ammo_out,
		"reserve": res_out,
		"nades": nade_out,
		"nade_type": nade_type,
		"upgrades": up_out,
		"x": global_position.x,
		"y": global_position.y,
		"depth": World.depth_of(global_position.y),
		"space": 4,
		"facing": facing,
		"ability_cd": ability_cd,
	}


func restore(d: Dictionary) -> void:
	## Rebuilds the survivor from a run save. Anything missing falls back to the
	## fresh-run value, so half written or older saves still load.
	if d.is_empty():
		return
	upgrades = {}
	var up: Dictionary = d.get("upgrades", {})
	for k in up.keys():
		upgrades[String(k)] = int(up[k])
	level = maxi(1, int(d.get("level", 1)))
	xp = int(d.get("xp", 0))
	weapons = []
	for w in (d.get("weapons", []) as Array):
		if GameData.WEAPONS.has(String(w)):
			weapons.append(String(w))
	if weapons.is_empty():
		weapons = ["pistol"]
	slot = clampi(int(d.get("slot", 0)), 0, weapons.size() - 1)
	ammo = {}
	var am: Dictionary = d.get("ammo", {})
	for k in am.keys():
		ammo[String(k)] = int(am[k])
	reserve = {}
	var rs: Dictionary = d.get("reserve", {})
	for k in rs.keys():
		reserve[String(k)] = int(rs[k])
	for w in weapons:
		if not ammo.has(w):
			ammo[w] = mag_size(String(w))
		if not reserve.has(w):
			reserve[w] = max_reserve(String(w))
	nades = {}
	var nd: Dictionary = d.get("nades", {})
	for id in GameData.GRENADE_ORDER:
		nades[id] = int(nd.get(id, 0))
	if nade_total() <= 0:
		nades["frag"] = 2
	grenades = nade_total()
	nade_type = String(d.get("nade_type", "frag"))
	if not GameData.GRENADES.has(nade_type):
		nade_type = "frag"
	refresh_max_hp(false)
	max_hp = maxf(20.0, float(d.get("max_hp", max_hp)))
	hp = clampf(float(d.get("hp", max_hp)), 1.0, max_hp)
	facing = 1.0 if float(d.get("facing", 1.0)) >= 0.0 else -1.0
	ability_cd = maxf(0.0, float(d.get("ability_cd", 0.0)))
	reloading = false
	reload_t = 0.0
	_refresh_gun()
	if spr != null:
		spr.play("idle")
	_pose_rig(0.0, true)
