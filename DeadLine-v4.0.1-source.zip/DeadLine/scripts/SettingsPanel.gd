extends VBoxContainer
class_name SettingsPanel
## Reusable options screen: used by the main menu and by the in-game pause menu.

var _rows: Array = []


func _ready() -> void:
	add_theme_constant_override("separation", 3)
	_build()


func _build() -> void:
	_header("LANGUAGE")
	_lang_row()
	_header("AUDIO")
	_slider_row("MASTER", "vol_master")
	_slider_row("MUSIC", "vol_music")
	_slider_row("SFX", "vol_sfx")
	_toggle_row("MUSIC ON", "music_on")
	_toggle_row("SOUND FX", "sfx_on")
	_header("GRAPHICS")
	_cycle_row("CAMERA", "zoom", Settings.ZOOM_NAMES)
	_cycle_row("BLOOD", "gore", Settings.GORE_NAMES)
	_cycle_row("SCREEN SHAKE", "shake", Settings.SHAKE_NAMES)
	_cycle_row("QUALITY", "quality", Settings.QUALITY_NAMES)
	_toggle_row("DAMAGE NUMBERS", "dmg_numbers")
	_toggle_row("SHOW FPS", "show_fps")
	_header("CONTROLS & GAME")
	_cycle_row("STICK SIDE", "joy_side", Settings.SIDE_NAMES)
	_toggle_row("AUTO FIRE", "autofire")
	_toggle_row("VIBRATION", "vibration")
	_cycle_row("DIFFICULTY", "difficulty", Settings.DIFF_NAMES)


const LANG_FALLBACK := ["ENGLISH", "РУССКИЙ", "ESPANOL", "PORTUGUES"]


func _lang_names() -> Array:
	## Read straight off the Loc autoload when it is there, with a hard coded
	## fallback so the language selector is ALWAYS on screen and always tappable,
	## even if localization itself is having a bad day.
	var loc = UI.loc_node()
	if loc != null and loc.has_method("label_of") and loc.has_method("count"):
		var out: Array = []
		for i in range(int(loc.call("count"))):
			out.append(String(loc.call("label_of", i)))
		if out.size() > 0:
			return out
	return LANG_FALLBACK.duplicate()


func _lang_index() -> int:
	var loc = UI.loc_node()
	if loc != null:
		return int(loc.get("lang_index"))
	return maxi(0, Settings.idx("lang"))


func _lang_row() -> void:
	## Built from the exact same primitives as every other cycle row, because
	## that path is proven. Switching language repaints the whole shell, so the
	## rebuild is deferred: nothing is freed while we are still inside the button
	## signal that asked for it.
	var names = _lang_names()
	var h = _row("LANGUAGE")
	var left = UI.button("<", 9, UI.DIM, 20.0)
	left.custom_minimum_size = Vector2(20, 20)
	var val = UI.label(String(names[clampi(_lang_index(), 0, names.size() - 1)]), 8, UI.GOLD,
			HORIZONTAL_ALIGNMENT_CENTER)
	val.custom_minimum_size = Vector2(76, 20)
	var right = UI.button(">", 9, UI.DIM, 20.0)
	right.custom_minimum_size = Vector2(20, 20)
	var step = func(dir: int) -> void:
		var loc = UI.loc_node()
		var n = names.size()
		var next = (clampi(_lang_index(), 0, n - 1) + dir + n) % n
		if loc != null and loc.has_method("set_index"):
			loc.call("set_index", next)
		else:
			Settings.set_v("lang", next)
		val.text = String(names[clampi(next, 0, n - 1)])
		Audio.play("ui", -12.0, 1.0, 0.02)
		if is_inside_tree():
			call_deferred("_rebuild")
	left.pressed.connect(step.bind(-1))
	right.pressed.connect(step.bind(1))
	h.add_child(left)
	h.add_child(val)
	h.add_child(right)


func _rebuild() -> void:
	if not is_inside_tree():
		return
	for c in get_children():
		remove_child(c)
		c.queue_free()
	_rows.clear()
	_build()


func _header(text: String) -> void:
	add_child(UI.spacer(4))
	var l = UI.label(text, 9, UI.RED)
	add_child(l)


func _row(text: String) -> HBoxContainer:
	var h = HBoxContainer.new()
	h.add_theme_constant_override("separation", 4)
	var l = UI.label(text, 8, UI.DIM)
	l.custom_minimum_size = Vector2(104, 20)
	h.add_child(l)
	add_child(h)
	return h


func _slider_row(text: String, key: String) -> void:
	var h = _row(text)
	var s = UI.slider(Settings.num(key))
	s.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var val = UI.label("%d%%" % int(round(Settings.num(key) * 100.0)), 8, UI.BONE)
	val.custom_minimum_size = Vector2(34, 20)
	val.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	s.value_changed.connect(func(v: float) -> void:
		Settings.set_v(key, v)
		val.text = "%d%%" % int(round(v * 100.0)))
	h.add_child(s)
	h.add_child(val)


func _toggle_row(text: String, key: String) -> void:
	var h = _row(text)
	var b = UI.button("ON" if Settings.on(key) else "OFF", 9,
			UI.GREEN if Settings.on(key) else UI.RED_DARK, 20.0)
	b.custom_minimum_size = Vector2(58, 20)
	b.pressed.connect(func() -> void:
		Settings.toggle(key)
		var v = Settings.on(key)
		b.text = UI.tr_ui("ON") if v else UI.tr_ui("OFF")
		b.add_theme_stylebox_override("normal", UI.style(Color(0.16, 0.15, 0.17, 0.96),
				(UI.GREEN if v else UI.RED_DARK)))
		Audio.play("ui", -12.0, 1.0, 0.02))
	h.add_child(UI.hsep(4))
	h.add_child(b)
	h.add_child(UI.spacer(0))


func _cycle_row(text: String, key: String, names: Array) -> void:
	var h = _row(text)
	var left = UI.button("<", 9, UI.DIM, 20.0)
	left.custom_minimum_size = Vector2(20, 20)
	var val = UI.label(String(names[clampi(Settings.idx(key), 0, names.size() - 1)]), 8, UI.GOLD,
			HORIZONTAL_ALIGNMENT_CENTER)
	val.custom_minimum_size = Vector2(76, 20)
	var right = UI.button(">", 9, UI.DIM, 20.0)
	right.custom_minimum_size = Vector2(20, 20)
	var refresh = func() -> void:
		val.text = UI.tr_ui(String(names[clampi(Settings.idx(key), 0, names.size() - 1)]))
		Audio.play("ui", -12.0, 1.0, 0.02)
	left.pressed.connect(func() -> void:
		Settings.cycle(key, names.size(), -1)
		refresh.call())
	right.pressed.connect(func() -> void:
		Settings.cycle(key, names.size(), 1)
		refresh.call())
	h.add_child(left)
	h.add_child(val)
	h.add_child(right)
