extends Node
class_name WorldSpace
## v4 — БЕЛТ-СКРОЛЛЕР: единственный источник правды о геометрии улицы.
##
## Модель: мир двумерный, но координаты не экранные.
##   x     — вдоль улицы (как было),
##   depth — поперёк улицы, 0.0 (дальний бордюр) .. 1.0 (ближний бордюр).
## Экранный Y — ПРОИЗВОДНАЯ величина: screen_y = BELT_TOP + depth * BELT_H.
##
## Почему так: до v4 глубина не существовала, были два clampf по position.y.
## Верхняя граница визуально попадала на забор (слой параллакса 0.62, то есть
## другое пространство), нижняя — на осевую разметку, а асфальт ниже неё был
## мёртвым. Обе границы были невидимыми и не совпадали с картинкой.
##
## ВАЖНО: y и depth связаны линейно, поэтому расстояние по y УЖЕ в пикселях и
## его не нужно домножать на BELT_H второй раз. Это главный источник ошибок
## при миграции — все старые «фаджи» вида (r + 44.0) убираются, а не правятся.

## Аварийный выключатель. false — геометрия v3 (узкая полоса, без глубины).
## Оставлен, чтобы откатить релиз одной строкой, если на телефонах вылезет
## что-то, чего мы не увидели на десктопе.
const ENABLED := true

# ------------------------------------------------------------------ геометрия
const HORIZON_Y := -34.0   ## основание забора, дальний край мира
const CURB_H := 12.0       ## дальний тротуар: декор, ходить нельзя
const BELT_TOP := -22.0    ## depth = 0.0, дальний бордюр
const BELT_BOT := 72.0     ## depth = 1.0, ближний бордюр
const BELT_H := 94.0       ## рабочая глубина: было 78, стало 94, и вся по асфальту
const SCALE_FAR := 0.88
const SCALE_NEAR := 1.10

## Геометрия v3 — только для ENABLED = false.
const LEGACY_TOP := -44.0
const LEGACY_BOT := 34.0

## Движение «в глубину» медленнее движения вдоль улицы: без этого перспективное
## сжатие читается как «персонаж бегает вглубь быстрее, чем вбок».
const DEPTH_SPEED := 0.62

## Полутолщина тела по глубине. Пуля попадает, если её коридор пересёкся с этим.
const GIRTH_ZOMBIE := 7.0
const GIRTH_PLAYER := 6.0
## Зазор по глубине, на котором засчитывается удар в ближнем бою.
const MELEE_GAP := 18.0

## Мёртвая зона камеры по вертикали: игрок пересекает пояс, а вид не ползёт
## под ним — камера реагирует только у бордюров.
const CAM_DEADZONE := 28.0

## Шаг квантования масштаба. Пиксель-арт при плавном scale «кипит», поэтому
## масштаб прилипает к сетке 1/32 — глубина видна, дрожания нет.
const SCALE_STEP := 0.03125


# ------------------------------------------------------------------ границы
func top() -> float:
	return BELT_TOP if ENABLED else LEGACY_TOP


func bot() -> float:
	return BELT_BOT if ENABLED else LEGACY_BOT


func height() -> float:
	return maxf(1.0, bot() - top())


func mid() -> float:
	return (top() + bot()) * 0.5


# ------------------------------------------------------------------ depth <-> y
func screen_y(depth: float) -> float:
	return top() + clampf(depth, 0.0, 1.0) * height()


func depth_of(y: float) -> float:
	return clampf((y - top()) / height(), 0.0, 1.0)


func clamp_y(y: float) -> float:
	return clampf(y, top(), bot())


func clamp_pos(p: Vector2) -> Vector2:
	return Vector2(p.x, clamp_y(p.y))


# ------------------------------------------------------------------ перспектива
func scale_at(depth: float) -> float:
	if not ENABLED:
		return 1.0
	var s = lerpf(SCALE_FAR, SCALE_NEAR, clampf(depth, 0.0, 1.0))
	return snappedf(s, SCALE_STEP)


func scale_of_y(y: float) -> float:
	return scale_at(depth_of(y))


func z_at(depth: float) -> int:
	## Сортировка бесплатная: чем ближе к игроку, тем выше z. Y-sort больше
	## не нужен и выключается, иначе они спорят друг с другом.
	return 4 + int(round(clampf(depth, 0.0, 1.0) * 100.0))


func z_of_y(y: float) -> int:
	return z_at(depth_of(y))


# ------------------------------------------------------------------ попадания
func corridor_hit(y_a: float, y_b: float, girth: float) -> bool:
	## «Тот же коридор глубины», а не пиксельное совпадение Y.
	return absf(y_a - y_b) <= maxf(0.5, girth)


func in_melee(y_a: float, y_b: float) -> bool:
	return absf(y_a - y_b) <= MELEE_GAP


func flat_dist(a: Vector2, b: Vector2) -> float:
	## Расстояние в мировых единицах. Раньше взрывы считались по экранному Y с
	## поправкой на глаз, из-за чего граната била «строкой», а не площадью.
	return a.distance_to(b)


# ------------------------------------------------------------------ спавн
func spawn_y(lo: float = 0.06, hi: float = 0.94) -> float:
	return screen_y(randf_range(lo, hi))


func spawn_depth(lo: float = 0.06, hi: float = 0.94) -> float:
	return randf_range(lo, hi)


func from_legacy_y(y: float) -> float:
	## Сейв v3 -> пояс v4. Старая полоса (-44..34) растягивается на новый пояс
	## пропорционально: после обновления все стоят на той же относительной
	## глубине, а не телепортируются в забор.
	var d = clampf((y - LEGACY_TOP) / (LEGACY_BOT - LEGACY_TOP), 0.0, 1.0)
	return screen_y(d)


func migrate_y(y: float, space: int) -> float:
	## space пишется в снапшот: 4 — координата уже в поясе, 0 — наследие v3.
	if not ENABLED or space >= 4:
		return clamp_y(y)
	return from_legacy_y(y)


func lane_bias() -> float:
	## Разброс «коридора» у зомби: без него толпа марширует одной линией.
	return randf_range(-0.16, 0.16) * height() * 0.5
