"""Deep static lint for the GDScript layer: unknown identifiers, undefined
locals, bad indentation, unbalanced brackets, suspicious type inference.
Run:  python3 tools/lint.py
"""
import os, re, sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
S = os.path.join(ROOT, "scripts")

KEYWORDS = set("""if elif else for while match break continue pass return func var const
class class_name extends enum signal static await yield super self true false null and or not
in is as void breakpoint assert preload load range print push_error push_warning when
tool onready export setget PI TAU INF NAN""".split())

GLOBAL_FUNCS = set("""abs absf absi acos asin atan atan2 bytes_to_var ceil ceilf ceili clamp
clampf clampi cos cosh db_to_linear deg_to_rad ease error_string exp floor floorf floori fmod
fposmod hash instance_from_id inverse_lerp is_equal_approx is_finite is_inf is_instance_id_valid
is_instance_valid is_nan is_zero_approx lerp lerpf lerp_angle linear_to_db log max maxf maxi min
minf mini move_toward nearest_po2 pingpong posmod pow print printerr print_rich prints printt
push_error push_warning rad_to_deg rand_from_seed randf randf_range randfn randi randi_range
randomize remap rid_allocate_id round roundf roundi seed sign signf signi sin sinh smoothstep
snapped snappedf snappedi sqrt step_decimals str str_to_var tan tanh type_convert type_exists
typeof var_to_bytes var_to_str weakref wrap wrapf wrapi range len bool int float""".split())

GLOBAL_CLASSES = set("""Node Node2D Control CanvasLayer CanvasItem CanvasModulate Camera2D Sprite2D
AnimatedSprite2D SpriteFrames Texture2D ImageTexture Image Label Button ColorRect Line2D Timer
CPUParticles2D CharacterBody2D StaticBody2D RigidBody2D Area2D CollisionShape2D CircleShape2D
RectangleShape2D CapsuleShape2D PhysicsRayQueryParameters2D Vector2 Vector2i Vector3 Rect2 Rect2i
Color Transform2D Basis Quaternion Plane AABB Dictionary Array PackedByteArray PackedInt32Array
PackedFloat32Array PackedVector2Array PackedStringArray PackedColorArray String StringName NodePath
RID Callable Signal Variant Object RefCounted Resource Engine OS Time Input InputEvent
InputEventScreenTouch InputEventScreenDrag InputEventMouseButton InputEventMouseMotion InputEventKey
InputMap ProjectSettings DisplayServer RenderingServer AudioServer AudioStreamPlayer
AudioStreamPlayer2D AudioStream AudioStreamWAV AudioStreamOggVorbis AudioStreamPlaybackPolyphonic
AudioStreamRandomizer FileAccess DirAccess JSON ResourceLoader ResourceSaver SceneTree Tween
StyleBoxFlat StyleBoxEmpty StyleBox Font FontFile SystemFont FontVariation Theme HBoxContainer VBoxContainer GridContainer
PanelContainer ScrollContainer MarginContainer CenterContainer TextureRect TextureButton
ProgressBar HSlider VSlider CheckButton OptionButton RichTextLabel NinePatchRect ShaderMaterial
Shader CanvasItemMaterial Performance Viewport SubViewport Window Marker2D PhysicsBody2D
GPUParticles2D Curve Gradient GradientTexture1D Geometry2D Mutex Thread Semaphore
TileMap TileSet Script GDScript PackedScene SceneTreeTimer PhysicsDirectSpaceState2D
KinematicCollision2D PhysicsPointQueryParameters2D PhysicsShapeQueryParameters2D
BaseButton Container Range TranslationServer AudioEffect AudioBusLayout MainLoop""".split())

ENGINE_MEMBERS = set("""global_position global_rotation global_scale position rotation scale visible
modulate self_modulate name z_index z_as_relative queue_free free add_child remove_child get_parent
get_children get_child get_child_count get_node get_node_or_null has_node find_child owner
add_to_group remove_from_group is_in_group get_tree get_viewport get_viewport_rect get_window
set_process set_physics_process set_process_input set_process_unhandled_input is_processing
process_mode create_tween queue_redraw request_ready is_node_ready duplicate get_instance_id
set_meta get_meta has_meta remove_meta call call_deferred callv connect disconnect emit_signal
is_connected notification propagate_call move_child get_index get_path get_script set_script
velocity move_and_slide move_and_collide is_on_floor is_on_wall get_slide_collision_count
get_slide_collision get_last_slide_collision motion_mode floor_stop_on_slope up_direction
collision_layer collision_mask set_collision_layer_value set_collision_mask_value
shape input_pickable monitoring monitorable get_overlapping_bodies get_overlapping_areas
texture centered offset flip_h flip_v region_enabled region_rect hframes vframes frame
frame_coords sprite_frames animation autoplay play stop pause is_playing speed_scale
text label_settings horizontal_alignment vertical_alignment autowrap_mode clip_text
size custom_minimum_size anchor_left anchor_top anchor_right anchor_bottom
offset_left offset_top offset_right offset_bottom set_anchors_preset set_offsets_preset
set_anchors_and_offsets_preset grow_horizontal grow_vertical mouse_filter mouse_default_cursor_shape
focus_mode disabled toggle_mode button_pressed pressed_no_signal pressed released
tooltip_text add_theme_color_override add_theme_font_size_override add_theme_stylebox_override
add_theme_constant_override add_theme_font_override get_theme_font get_theme_default_font
get_global_rect get_rect has_point encloses intersects grow abs
size_flags_horizontal size_flags_vertical alignment add_spacer columns
color points width default_color closed antialiased add_point clear_points
emitting amount lifetime one_shot explosiveness randomness direction spread gravity
initial_velocity_min initial_velocity_max scale_amount_min scale_amount_max damping_min
damping_max angular_velocity_min angular_velocity_max color_ramp restart
layer follow_viewport_enabled
draw draw_line draw_rect draw_circle draw_arc draw_texture draw_texture_rect draw_string
draw_polyline draw_colored_polygon draw_set_transform draw_multiline
stream volume_db pitch_scale bus playing finished autostart wait_time timeout start
zoom limit_left limit_right limit_top limit_bottom position_smoothing_enabled
position_smoothing_speed make_current enabled ignore_rotation
is_queued_for_deletion is_inside_tree ready tree_exiting
material light_mask use_parent_material show_behind_parent top_level clip_children
set_deferred get set_indexed tween_property tween_callback tween_interval set_ease set_trans
set_loops kill is_valid chain parallel
_ready _process _physics_process _draw _input _unhandled_input _notification _init _enter_tree
_exit_tree _gui_input""".split())

TYPE_CONSTS = set(["TYPE_NIL","TYPE_BOOL","TYPE_INT","TYPE_FLOAT","TYPE_STRING","TYPE_VECTOR2",
"TYPE_VECTOR2I","TYPE_RECT2","TYPE_COLOR","TYPE_ARRAY","TYPE_DICTIONARY","TYPE_OBJECT",
"TYPE_CALLABLE","TYPE_STRING_NAME","TYPE_PACKED_BYTE_ARRAY","NOTIFICATION_WM_GO_BACK_REQUEST",
"NOTIFICATION_APPLICATION_FOCUS_OUT","NOTIFICATION_WM_CLOSE_REQUEST","MOUSE_BUTTON_LEFT",
"NOTIFICATION_APPLICATION_PAUSED","NOTIFICATION_APPLICATION_RESUMED",
"NOTIFICATION_APPLICATION_FOCUS_IN","NOTIFICATION_WM_WINDOW_FOCUS_OUT",
"NOTIFICATION_WM_WINDOW_FOCUS_IN","NOTIFICATION_EXIT_TREE","NOTIFICATION_ENTER_TREE",
"NOTIFICATION_OS_MEMORY_WARNING",
"MOUSE_BUTTON_RIGHT","HORIZONTAL_ALIGNMENT_LEFT","HORIZONTAL_ALIGNMENT_CENTER",
"HORIZONTAL_ALIGNMENT_RIGHT","HORIZONTAL_ALIGNMENT_FILL","VERTICAL_ALIGNMENT_TOP",
"VERTICAL_ALIGNMENT_CENTER","VERTICAL_ALIGNMENT_BOTTOM","AtlasTexture","TextServer","ThemeDB",
"OK","FAILED","ERR_FILE_NOT_FOUND","SIDE_LEFT","SIDE_TOP","SIDE_RIGHT","SIDE_BOTTOM"])
KEY_CONSTS = set(re.findall(r"KEY_\w+", " ".join(["KEY_%s" % c for c in
    list("ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789")]) +
    " KEY_ESCAPE KEY_ENTER KEY_SPACE KEY_SHIFT KEY_CTRL KEY_ALT KEY_TAB KEY_LEFT KEY_RIGHT KEY_UP KEY_DOWN KEY_P KEY_F1"))

# member sets per script file
def members(src):
    m = set(re.findall(r"^\s*func ([a-zA-Z_]\w*)", src, re.M))
    m |= set(re.findall(r"^\s*static func ([a-zA-Z_]\w*)", src, re.M))
    m |= set(re.findall(r"^var ([a-zA-Z_]\w*)", src, re.M))
    m |= set(re.findall(r"^@onready var ([a-zA-Z_]\w*)", src, re.M))
    m |= set(re.findall(r"^const ([A-Za-z_]\w*)", src, re.M))
    m |= set(re.findall(r"^signal ([a-zA-Z_]\w*)", src, re.M))
    m |= set(re.findall(r"^enum ([A-Za-z_]\w*)", src, re.M))
    return m

def strip_code(line):
    """remove strings and trailing comment"""
    out, i, n = [], 0, len(line)
    while i < n:
        c = line[i]
        if c == "#":
            break
        if c in "\"'":
            q = c
            i += 1
            while i < n and line[i] != q:
                if line[i] == "\\":
                    i += 1
                i += 1
            i += 1
            out.append('""')
            continue
        out.append(c)
        i += 1
    return "".join(out)

files = {f: open(os.path.join(S, f)).read() for f in sorted(os.listdir(S)) if f.endswith(".gd")}
class_names = set(re.findall(r"^class_name (\w+)", "\n".join(files.values()), re.M))
proj = open(os.path.join(ROOT, "project.godot")).read()
autoloads = set(re.findall(r'^(\w+)="\*res://', proj, re.M))

errors, warns = [], []
KNOWN = (GLOBAL_FUNCS | GLOBAL_CLASSES | KEYWORDS | class_names | autoloads
         | ENGINE_MEMBERS | TYPE_CONSTS | KEY_CONSTS | {"_"})

for fname, src in files.items():
    lines = src.split("\n")
    mem = members(src)
    scope = set()          # locals of the current function
    depth_ok = True
    in_func = None
    open_br = 0
    for i, raw in enumerate(lines, 1):
        code = strip_code(raw)
        if raw.strip() and raw.startswith(" ") and open_br == 0:
            errors.append("%s:%d space indentation" % (fname, i))
        # bracket balance (per logical line, continuation aware)
        open_br += code.count("(") + code.count("[") + code.count("{")
        open_br -= code.count(")") + code.count("]") + code.count("}")
        m = re.match(r"^(?:static )?func ([a-zA-Z_]\w*)\((.*)", code)
        if m:
            in_func = m.group(1)
            scope = set()
            sig = m.group(2)
            j = i
            while sig.count("(") + 1 > sig.count(")") + 0 and j < len(lines):
                j += 1
                sig += strip_code(lines[j - 1])
            sig_inner = sig[:sig.rfind(")")] if ")" in sig else sig
            for part in sig_inner.split(","):
                mm = re.match(r"\s*([a-zA-Z_]\w*)", part)
                if mm:
                    scope.add(mm.group(1))
            sig_skip = j
            continue
        if in_func is None:
            continue
        # collect declarations on this line
        for d in re.findall(r"\bvar ([a-zA-Z_]\w*)", code):
            scope.add(d)
        for d in re.findall(r"\bfor ([a-zA-Z_]\w*) in\b", code):
            scope.add(d)
        for d in re.findall(r"func\s*\(([^)]*)\)", code):   # lambda params
            for p in re.findall(r"([a-zA-Z_]\w*)", d):
                scope.add(p)
        # identifier usage check
        body = re.sub(r"\bvar ([a-zA-Z_]\w*)", "", code)
        for m2 in re.finditer(r"(?<![\w.$\"])([a-zA-Z_]\w*)", body):
            name = m2.group(1)
            if name in KNOWN or name in mem or name in scope:
                continue
            # type hints after ':' are class names, already covered
            errors.append("%s:%d unknown identifier '%s'  |%s" % (fname, i, name, raw.strip()[:70]))
    if open_br != 0:
        errors.append("%s: unbalanced brackets (%d)" % (fname, open_br))

# type inference: var x := <call on untyped>
for fname, src in files.items():
    for i, raw in enumerate(src.split("\n"), 1):
        if re.search(r"\bvar \w+ :=", raw):
            warns.append("%s:%d inferred type: %s" % (fname, i, raw.strip()[:80]))

# =====================================================================
# Duplicate dictionary keys.
# GDScript treats a repeated key in a dictionary LITERAL as a parse error, so
# one accidental repeat silently kills the whole script - and if that script is
# an autoload, it takes the game's UI down with it. This is the check whose
# absence cost us a full build (two "Incendiary" rows in Loc.gd).
# =====================================================================
def dict_key_dupes(src):
    """Returns [(line, key)] for string keys repeated inside one dict literal."""
    out, stack, i, n = [], [], 0, len(src)
    line = 1
    while i < n:
        c = src[i]
        if c == "\n":
            line += 1; i += 1; continue
        if c == "#":
            while i < n and src[i] != "\n":
                i += 1
            continue
        if c in "\"'":
            quote, j = c, i + 1
            buf = []
            while j < n:
                if src[j] == "\\":
                    buf.append(src[j:j + 2]); j += 2; continue
                if src[j] == quote:
                    break
                if src[j] == "\n":
                    break
                buf.append(src[j]); j += 1
            key = "".join(buf)
            i = j + 1
            # a string is a dict key only when the innermost bracket is '{'
            # and the next non-space character is ':'
            k = i
            while k < n and src[k] in " \t":
                k += 1
            if stack and stack[-1][0] == "{" and k < n and src[k] == ":" \
                    and (k + 1 >= n or src[k + 1] != "="):
                seen = stack[-1][1]
                if key in seen:
                    out.append((line, key))
                else:
                    seen.add(key)
            continue
        if c in "{[(":
            stack.append((c, set()))
        elif c in "}])":
            if stack:
                stack.pop()
        i += 1
    return out


for fname, src in files.items():
    for line, key in dict_key_dupes(src):
        errors.append("%s:%d DUPLICATE dictionary key \"%s\" - this is a PARSE ERROR "
                      "in GDScript and disables the whole script" % (fname, line, key))

# =====================================================================
# Localization table: row width and printf placeholders.
# A row with the wrong number of "%d"/"%s" used to be a hard runtime error at
# format time; UI.tr_f() now degrades gracefully, but it is still a bug.
# =====================================================================
loc_src = files.get("Loc.gd", "")
if loc_src:
    m = re.search(r"const LANGS\s*:?=\s*\[(.*?)\]", loc_src, re.S)
    n_langs = len(re.findall(r'"[^"]*"', m.group(1))) if m else 0
    want = max(0, n_langs - 1)
    body = loc_src[loc_src.find("const TABLE"):]

    def slots(t):
        out, i = 0, 0
        while i < len(t):
            if t[i] == "%":
                if i + 1 < len(t) and t[i + 1] == "%":
                    i += 2; continue
                out += 1
            i += 1
        return out

    for mm in re.finditer(r'^\t"((?:[^"\\]|\\.)*)":\s*\[(.*?)\],\s*$', body, re.M):
        key, inner = mm.group(1), mm.group(2)
        line = loc_src[:loc_src.find("const TABLE")].count("\n") + body[:mm.start()].count("\n") + 1
        vals = re.findall(r'"((?:[^"\\]|\\.)*)"', inner)
        if want and len(vals) != want:
            errors.append("Loc.gd:%d row \"%s\" has %d translations, expected %d"
                          % (line, key, len(vals), want))
        for v in vals:
            if slots(v) != slots(key):
                errors.append("Loc.gd:%d row \"%s\": translation \"%s\" has %d placeholders, "
                              "source has %d" % (line, key, v, slots(v), slots(key)))

# =====================================================================
# Android project settings that we depend on at runtime.
# =====================================================================
proj = open(os.path.join(ROOT, "project.godot"), encoding="utf-8").read()
for need, why in [("config/quit_on_go_back=false",
                   "back gesture would quit the app and kill the run"),
                  ("window/energy_saving/keep_screen_on=true",
                   "screen would sleep mid wave")]:
    if need not in proj:
        errors.append("project.godot: missing %s (%s)" % (need, why))


# =====================================================================
# v4 GEOMETRY (belt of depth) + THUMB ERGONOMICS
# ---------------------------------------------------------------------
# Эти правила существуют потому, что мы уже наступали на каждое из них:
#   * два источника чисел про полосу, разъехавшиеся между собой;
#   * clampf по position.y, живущий в семи файлах вместо одного;
#   * кнопка радиусом 12 px, доехавшая до сборки и найденная на телефоне.
# =====================================================================
world_src = files.get("World.gd", "")
if not world_src:
    errors.append("World.gd отсутствует: геометрия пояса не имеет источника правды")
else:
    def wconst(name, src=None):
        m = re.search(r"const %s\s*:?=\s*(-?[\d.]+)" % name, src or world_src)
        return float(m.group(1)) if m else None

    bt, bb, bh = wconst("BELT_TOP"), wconst("BELT_BOT"), wconst("BELT_H")
    if None in (bt, bb, bh):
        errors.append("World.gd: не найдены BELT_TOP / BELT_BOT / BELT_H")
    else:
        if abs((bb - bt) - bh) > 0.001:
            errors.append("World.gd: BELT_H=%g не равно BELT_BOT-BELT_TOP=%g" % (bh, bb - bt))
        if bh < 80.0:
            errors.append("World.gd: BELT_H=%g слишком мал, глубина не читается (нужно >= 80)" % bh)
        # GameData зеркалит World: разъезд этих чисел = невидимые стены
        gd_src = files.get("GameData.gd", "")
        gt = re.search(r"const BAND_TOP\s*:?=\s*(-?[\d.]+)", gd_src)
        gb = re.search(r"const BAND_BOT\s*:?=\s*(-?[\d.]+)", gd_src)
        if not gt or not gb:
            errors.append("GameData.gd: BAND_TOP / BAND_BOT не найдены")
        else:
            if abs(float(gt.group(1)) - bt) > 0.001:
                errors.append("GameData.BAND_TOP=%s разъехался с World.BELT_TOP=%g"
                              % (gt.group(1), bt))
            if abs(float(gb.group(1)) - bb) > 0.001:
                errors.append("GameData.BAND_BOT=%s разъехался с World.BELT_BOT=%g"
                              % (gb.group(1), bb))
    sf, sn = wconst("SCALE_FAR"), wconst("SCALE_NEAR")
    if sf is not None and sn is not None and sn <= sf:
        errors.append("World.gd: SCALE_NEAR должен быть больше SCALE_FAR, иначе глубины не видно")
    ds = wconst("DEPTH_SPEED")
    if ds is not None and not (0.4 <= ds <= 0.85):
        errors.append("World.gd: DEPTH_SPEED=%g вне разумного диапазона 0.40..0.85" % ds)

# Никто, кроме World.gd, не имеет права сам решать вертикальные границы.
for fname, src in files.items():
    if fname == "World.gd":
        continue
    for i, line in enumerate(src.splitlines(), 1):
        s = line.strip()
        if s.startswith("#") or s.startswith("##"):
            continue
        if re.search(r"(global_)?position\.y\s*=\s*clampf", s):
            errors.append("%s:%d самодельный clampf по position.y — используй "
                          "World.clamp_pos() / World.clamp_y()" % (fname, i))
        if re.search(r"clampf\s*\([^)]*BAND_(TOP|BOT)", s):
            errors.append("%s:%d кламп по GameData.BAND_* — границы задаёт только World"
                          % (fname, i))
        if "y_sort_enabled = true" in s:
            errors.append("%s:%d y_sort спорит с сортировкой по глубине (World.z_at)"
                          % (fname, i))

# --------------------------------------------------------------- эргономика
tp = files.get("TouchPad.gd", "")
if tp:
    def tconst(name):
        m = re.search(r"const %s\s*:?=\s*([\d.]+)" % name, tp)
        return float(m.group(1)) if m else None
    min_r, min_gap = tconst("MIN_R"), tconst("MIN_GAP")
    if min_r is None or min_r < 15.0:
        errors.append("TouchPad.MIN_R должен быть >= 15 px (~9 мм на телефоне), сейчас %s" % min_r)
    if min_gap is None or min_gap < 10.0:
        errors.append("TouchPad.MIN_GAP должен быть >= 10 px, сейчас %s" % min_gap)
    if "func _active_ids" not in tp:
        errors.append("TouchPad: пропал _active_ids() — кнопки перестали быть контекстными")

    # Повторяем раскладку дуги ТЕМ ЖЕ алгоритмом, что в TouchPad._layout, на
    # всех реальных разрешениях и всех размерах HUD. Любое перекрытие — ошибка
    # сборки, а не «поправим на телефоне».
    import math
    def gconst(name, default=None):
        m = re.search(r"const %s\s*:?=\s*(-?[\d.]+)" % name, tp)
        return float(m.group(1)) if m else default
    A_MIN, A_MAX = gconst("ARC_A_MIN", 20.0), gconst("ARC_A_MAX", 88.0)
    R_MIN, RING_MAX = gconst("ARC_R_MIN", 56.0), int(gconst("RING_MAX", 5))

    def min_arc(radii, pivot_dy=14.0):
        if not radii:
            return R_MIN
        need = radii[0] + 2.0 - pivot_dy
        if need <= 0.0:
            return R_MIN
        return max(R_MIN, need / max(0.05, math.sin(math.radians(A_MIN))))
    RADII = {"fire": 26.0, "dash": 19.0, "nade": 18.0, "skill": 18.0,
             "reload": 16.0, "build": 16.0, "swap": 16.0}
    SETS = [["dash", "swap"],
            ["dash", "nade", "skill", "swap"],
            ["fire", "dash", "nade", "skill", "swap"],
            ["fire", "dash", "nade", "skill", "reload", "swap"],
            ["fire", "dash", "nade", "skill", "reload", "build", "swap"]]
    RES = [(640, 360), (711, 360), (778, 360), (640, 300), (854, 360), (600, 338)]

    def ring_span(radii, arc_r):
        tot = 0.0
        for i in range(1, len(radii)):
            chord = (radii[i - 1] + radii[i] + min_gap) * 0.5
            tot += 2.0 * math.asin(min(1.0, max(0.0, chord / max(1.0, arc_r))))
        return tot

    def fit_arc(radii, arc_max):
        span_max = math.radians(A_MAX - A_MIN)
        r = min_arc(radii)
        while r < arc_max:
            if ring_span(radii, r) <= span_max:
                return r
            r += 2.0
        return arc_max

    def place(ids, radii, arc_r, pivot, side):
        out, ang = [], math.radians(A_MIN)
        for i, bid in enumerate(ids):
            r = radii[i]
            if i > 0:
                chord = (radii[i - 1] + r + min_gap) * 0.5
                ang += 2.0 * math.asin(min(1.0, max(0.0, chord / max(1.0, arc_r))))
            out.append((pivot[0] + math.cos(ang) * arc_r * side,
                        pivot[1] - math.sin(ang) * arc_r, r, bid))
        return out

    for hud_k in (0.88, 1.0, 1.15):
        for (w, h) in RES:
            for right in (False, True):
                for ids in SETS:
                    radii = [max(min_r, RADII[i] * hud_k) for i in ids]
                    max_r = max(radii)
                    n1 = min(len(ids), RING_MAX)
                    side = -1.0 if not right else 1.0
                    pivot = (w - 20.0, h - 14.0) if not right else (20.0, h - 14.0)
                    arc_max = max(min_arc(radii[:n1]), min(h - 16.0 - max_r, w * 0.55))
                    arc_r = fit_arc(radii[:n1], arc_max)
                    arc_r2 = arc_r - (2.0 * max_r + min_gap)
                    if radii[n1:] and arc_r2 < min_arc(radii[n1:]):
                        arc_r = min(min_arc(radii[n1:]) + 2.0 * max_r + min_gap, arc_max)
                        arc_r2 = arc_r - (2.0 * max_r + min_gap)
                    placed = place(ids[:n1], radii[:n1], arc_r, pivot, side)
                    if radii[n1:]:
                        placed += place(ids[n1:], radii[n1:], arc_r2, pivot, side)
                    tag = "%dx%d k=%.2f %s n=%d" % (w, h, hud_k,
                            "R" if right else "L", len(ids))
                    for a in range(len(placed)):
                        x1, y1, r1, i1 = placed[a]
                        if not (r1 + 1.0 <= x1 <= w - r1 - 1.0):
                            errors.append("TouchPad %s: %s уехала за экран по X (x=%.1f)"
                                          % (tag, i1, x1))
                        if not (r1 + 1.0 <= y1 <= h - r1 - 1.0):
                            errors.append("TouchPad %s: %s уехала за экран по Y (y=%.1f)"
                                          % (tag, i1, y1))
                        for b in range(a + 1, len(placed)):
                            x2, y2, r2, i2 = placed[b]
                            gap = math.hypot(x1 - x2, y1 - y2) - r1 - r2
                            if gap < min_gap - 0.51:
                                errors.append("TouchPad %s: %s и %s с зазором %.1f px "
                                              "(минимум %.0f)" % (tag, i1, i2, gap, min_gap))

# --------------------------------------------------------------- ассеты тем
env_dir = os.path.join(ROOT, "art", "env")
manifest_path = os.path.join(ROOT, "art", "manifest.json")
if os.path.isdir(env_dir):
    import json as _json
    _m = _json.load(open(manifest_path, encoding="utf-8"))
    keys = _m.get("env", {}).get("belt_keys", [])
    themes = _m.get("env", {}).get("themes", [])
    for th in themes:
        for k in keys:
            f = os.path.join(env_dir, th, k + ".png")
            if not os.path.isfile(f):
                errors.append("art/env/%s/%s.png отсутствует — слой пояса не загрузится"
                              % (th, k))

# ------------------------------------------- бейк должен закрывать весь кадр
## Баг v4.0.0: слои были 640x360, как «кадр телефона», но камера стоит на
## (player.y - 16) и при zoom 1.50 видит 240 world px. Когда игрок доходил до
## ближнего бордюра, низ экрана превращался в чёрную полосу 66 px. Правило
## считает то же самое из кода и валит сборку, а не глаз художника.

def _png_size(path):
    """Ширина/высота PNG из IHDR — без Pillow, чтобы правило работало в CI."""
    with open(path, "rb") as f:
        head = f.read(26)
    if head[:8] != b"\x89PNG\r\n\x1a\n" or head[12:16] != b"IHDR":
        return None
    return (int.from_bytes(head[16:20], "big"), int.from_bytes(head[20:24], "big"))


if os.path.isdir(env_dir):
    import json as _json2

    def _num(src, name, dflt=None):
        m = re.search(r"\b%s\s*:?=\s*(-?[\d.]+)" % name, src)
        return float(m.group(1)) if m else dflt

    _wsrc = open(os.path.join(S, "World.gd"), encoding="utf-8").read()
    _ssrc = open(os.path.join(S, "Settings.gd"), encoding="utf-8").read()
    _gsrc = open(os.path.join(S, "Game.gd"), encoding="utf-8").read()
    _belt_top = _num(_wsrc, "BELT_TOP", -22.0)
    _belt_bot = _num(_wsrc, "BELT_BOT", 72.0)
    _art_row = _num(_gsrc, "BELT_ART_ROW", 206.0)
    _zooms = [float(v) for v in re.findall(r"[\d.]+",
              (re.search(r"ZOOM_VALUES\s*:?=\s*\[([^\]]*)\]", _ssrc)
               or re.match("", "")).group(1))] if "ZOOM_VALUES" in _ssrc else [1.5]
    _zoom_min = min(_zooms) if _zooms else 1.5
    _cam_off = 16.0                                  # want_y = player.y - 16
    _m2 = re.search(r'window/size/viewport_height\s*=\s*(\d+)', proj)
    _vp_h = float(_m2.group(1)) if _m2 else 360.0
    _half_h = _vp_h * 0.5 / _zoom_min
    _need_top = _belt_top - _cam_off - _half_h
    _need_bot = _belt_bot - _cam_off + _half_h
    _img_top = _belt_top - _art_row                  # Game.BELT_ART_Y

    _has_fill = "_build_env_fills" in _gsrc and "fill_bot" in _gsrc
    for th in sorted(os.listdir(env_dir)):
        road = os.path.join(env_dir, th, "road.png")
        if not os.path.isfile(road):
            continue
        size = _png_size(road)
        if size is None:
            errors.append("art/env/%s/road.png не читается как PNG" % th)
            continue
        _img_bot = _img_top + size[1]
        if _img_top > _need_top + 0.01:
            errors.append("art/env/%s: бейк не кроет верх кадра — картинка "
                          "начинается на world y %.0f, камера видит с %.0f"
                          % (th, _img_top, _need_top))
        if _img_bot < _need_bot - 0.01:
            errors.append("art/env/%s: бейк короткий на %.0f px — камера при "
                          "zoom %.2f видит до world y %.0f, картинка кончается "
                          "на %.0f (снизу будет чёрная полоса %.0f px экрана)"
                          % (th, _need_bot - _img_bot, _zoom_min, _need_bot,
                             _img_bot, (_need_bot - _img_bot) * _zoom_min))
        mf = os.path.join(env_dir, th, "env_manifest.json")
        if not os.path.isfile(mf):
            errors.append("art/env/%s/env_manifest.json отсутствует" % th)
            continue
        _md = _json2.load(open(mf, encoding="utf-8"))
        _fl = _md.get("fill", {})
        for _k in ("top", "bottom"):
            if not str(_fl.get(_k, "")).startswith("#"):
                errors.append("art/env/%s: в манифесте нет fill.%s — движку "
                              "нечем закрасить край кадра" % (th, _k))
        _gh = float(_md.get("geometry", {}).get("H", 0))
        if abs(_gh - size[1]) > 0.5:
            errors.append("art/env/%s: geometry.H=%g разъехался с реальной "
                          "высотой PNG %d" % (th, _gh, size[1]))
    if not _has_fill:
        errors.append("Game.gd: пропала аварийная заливка окружения "
                      "(_build_env_fills) — край кадра снова может стать чёрным")

# ------------------------------------------------- версия видна в меню
## Пользователь ставит APK и первым делом смотрит на строку в меню. Если она
## отстала от project.godot, невозможно понять, стоит новая сборка или старая.
_ver = re.search(r'config/version="([^"]+)"', proj)
_men = open(os.path.join(S, "Menu.gd"), encoding="utf-8").read()
_vl = re.search(r'VERSION_LINE\s*:?=\s*"([^"]*)"', _men)
if _ver and _vl and _ver.group(1) not in _vl.group(1):
    errors.append("Menu.VERSION_LINE (\"%s\") отстала от project.godot "
                  "config/version=%s — в меню будет старый номер сборки"
                  % (_vl.group(1), _ver.group(1)))

print("files:", len(files))
print("ERRORS: %d" % len(errors))
for e in errors:
    print("  !", e)
print("WARNINGS: %d" % len(warns))
for w in warns[:40]:
    print("  -", w)
sys.exit(1 if errors else 0)
