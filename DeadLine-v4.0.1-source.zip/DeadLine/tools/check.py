"""Static sanity checker for the GDScript layer.
Catches the classic breakages: calling a function that does not exist, using a
sound / art / settings key that was never defined, referencing a missing file,
or mixing spaces into the tab indentation.
"""
import os, re, json, sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
S = os.path.join(ROOT, "scripts")
errors, warns = [], []

SKIP = {"ArtManifest.gd"}
files = {f: open(os.path.join(S, f)).read() for f in sorted(os.listdir(S))
         if f.endswith(".gd") and f not in SKIP}
manifest = json.load(open(os.path.join(ROOT, "art", "manifest.json")))

NODE_MEMBERS = set("""global_position position rotation scale visible modulate name z_index
queue_free is_instance_valid add_child get_parent get_children set_meta get_meta has_meta
velocity move_and_slide texture size color text offset_left offset_top offset_right
offset_bottom process_mode set_anchors_preset custom_minimum_size disabled pressed
mouse_filter get_global_rect has_point layer sprite_frames animation play frame speed_scale
flip_h flip_v points width default_color emitting restart amount lifetime one_shot
free duplicate get_instance_id call connect emit tooltip_text autowrap_mode
horizontal_alignment add_theme_color_override add_theme_font_size_override
add_theme_stylebox_override add_theme_constant_override create_tween queue_redraw
size_flags_horizontal size_flags_vertical get_viewport is_valid kill""".split())

def members(src):
    m = set(re.findall(r"^func ([a-zA-Z_][a-zA-Z0-9_]*)", src, re.M))
    m |= set(re.findall(r"^var ([a-zA-Z_][a-zA-Z0-9_]*)", src, re.M))
    m |= set(re.findall(r"^const ([A-Za-z_][A-Za-z0-9_]*)", src, re.M))
    m |= set(re.findall(r"^signal ([a-zA-Z_][a-zA-Z0-9_]*)", src, re.M))
    m |= set(re.findall(r"^static func ([a-zA-Z_][a-zA-Z0-9_]*)", src, re.M))
    return m

MEM = {f: members(src) for f, src in files.items()}

PREFIX = [
    ("game.fx.", "Fx.gd"), ("game.hud.", "HUD.gd"), ("game.player.", "Player.gd"),
    ("Settings.", "Settings.gd"), ("Music.", "Music.gd"), ("Save.", "SaveManager.gd"),
    ("Audio.", "Audio.gd"), ("Art.", "Art.gd"), ("GameData.", "GameData.gd"),
    ("UI.", "UI.gd"), ("game.", "Game.gd"), ("hud.", "HUD.gd"), ("fx.", "Fx.gd"),
    ("player.", "Player.gd"), ("pl.", "Player.gd"),
]

for fname, src in files.items():
    for i, line in enumerate(src.split("\n"), 1):
        if line.startswith(" ") and line.strip():
            errors.append("%s:%d space indentation" % (fname, i))
        if line.lstrip().startswith("#"):
            continue
        for pref, target in PREFIX:
            if fname == "Audio.gd" and pref == "pl.":
                continue
            for m in re.finditer(r"(?<![A-Za-z0-9_.])" + re.escape(pref) + r"([a-zA-Z_][a-zA-Z0-9_]*)", line):
                if fname == target:
                    continue
                attr = m.group(1)
                if attr in NODE_MEMBERS:
                    continue
                if attr not in MEM.get(target, set()):
                    errors.append("%s:%d  %s%s -> missing in %s" % (fname, i, pref, attr, target))
                break

# ---- sound keys
sounds = set(re.findall(r'"([a-z_]+)": "res://sfx/', files["Audio.gd"]))
for fname, src in files.items():
    for key in re.findall(r'Audio\.play\("([a-z_]+)"', src):
        if key not in sounds:
            errors.append("%s: unknown sound '%s'" % (fname, key))
for key in sounds:
    if not os.path.exists(os.path.join(ROOT, "sfx", key + ".wav")):
        errors.append("sfx/%s.wav missing" % key)

# ---- art keys
for fname, src in files.items():
    for group, fn in [("fx", "fx_tex"), ("fx", "fx_strip"), ("env", "env_tex"), ("ui", "ui_tex")]:
        for key in re.findall(r'Art\.%s\("([a-z_]+)"' % fn, src):
            if key not in manifest.get(group, {}):
                errors.append("%s: art %s key '%s' missing" % (fname, group, key))

# ---- settings keys
skeys = set(re.findall(r'"([a-z_]+)":', re.search(r"const DEFAULTS := \{(.*?)\n\}", files["Settings.gd"], re.S).group(1)))
for fname, src in files.items():
    for key in re.findall(r'Settings\.(?:on|num|idx|set_v|toggle|cycle)\("([a-z_]+)"', src):
        if key not in skeys:
            errors.append("%s: unknown setting '%s'" % (fname, key))

# ---- resource paths
for fname, src in files.items():
    for path in re.findall(r'"(res://[^"]+)"', src):
        if "*" in path:
            continue
        real = os.path.join(ROOT, path[6:])
        if not os.path.exists(real):
            errors.append("%s: missing resource %s" % (fname, path))

# ---- loadout / data consistency
gd = files["GameData.gd"]
all_dict_keys = set(re.findall(r'^\t"([a-z0-9_]+)": \{\n?', gd, re.M))
for block, kind in [("LOADOUT_PRIMARY_ORDER", "weapon"), ("LOADOUT_SIDEARM_ORDER", "weapon"),
                    ("LOADOUT_MELEE_ORDER", "weapon"), ("SUIT_ORDER", "char"), ("PET_ORDER", "char")]:
    m = re.search(r"const %s := \[(.*?)\]" % block, gd, re.S)
    if not m:
        errors.append("GameData: %s missing" % block)
        continue
    for item in re.findall(r'"([a-z0-9_]+)"', m.group(1)):
        if item == "none":
            continue
        if kind == "weapon" and item not in all_dict_keys:
            errors.append("GameData: %s references unknown weapon '%s'" % (block, item))
        if kind == "char" and item not in manifest["chars"]:
            errors.append("GameData: %s references unknown char '%s'" % (block, item))
for z in re.findall(r'^\t"(z_[a-z]+)": \{', gd, re.M):
    if z not in manifest["chars"]:
        errors.append("GameData: zombie '%s' has no art" % z)
wep_block = re.search(r"const WEAPONS := \{(.*?)\n\}\n", gd, re.S)
real_weapons = set(re.findall(r'^\t"([a-z0-9_]+)": \{', wep_block.group(1), re.M)) if wep_block else set()
for w in sorted(real_weapons):
    if w not in manifest["weapons"]:
        errors.append("weapon '%s' has no sprite" % w)

# ---- scenes / project
proj = open(os.path.join(ROOT, "project.godot")).read()
for auto in re.findall(r'^([A-Za-z]+)="\*(res://[^"]+)"', proj, re.M):
    if not os.path.exists(os.path.join(ROOT, auto[1][6:])):
        errors.append("autoload %s -> missing %s" % auto)
for scene in ["Main.tscn", "Game.tscn"]:
    txt = open(os.path.join(ROOT, scene)).read()
    for p in re.findall(r'path="(res://[^"]+)"', txt):
        if not os.path.exists(os.path.join(ROOT, p[6:])):
            errors.append("%s -> missing %s" % (scene, p))

print("scripts checked:", len(files))
print("ERRORS: %d" % len(errors))
for e in errors:
    print("  !", e)
print("warnings: %d" % len(warns))
for w in warns[:20]:
    print("  -", w)
sys.exit(1 if errors else 0)
