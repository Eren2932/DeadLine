#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
DeadLine — tools/env.py  (v2, belt-geometry aware)

Печёт фоновое окружение в PNG-слои под движок Godot, разрешение 640x360.
Геометрия берётся ИЗ ОДНОГО МЕСТА (класс Belt) и совпадает с World.gd:
    HORIZON_Y = -34, CURB_H = 12, BELT_TOP = -22, BELT_BOT = 72, BELT_H = 94

Что печём (все слои бесшовные по X, ширина = 640, тайлятся модулем):
    sky.png        — небо полосами (без градиентного мыла)
    moon.png       — луна + свечение (дизеринг Байера, без полос)
    far.png        — дальний город   (параллакс 0.20)
    mid.png        — средний город   (параллакс 0.40)
    near.png       — ближние крыши   (параллакс 0.66)
    fence.png      — сетчатый забор, разреженный (параллакс 0.80)
    fog.png        — приземный туман (альфа, ложится на линию бордюра)
    curb_far.png   — дальний тротуар + бордюр depth=0 (параллакс 1.0)
    road.png       — асфальт + полосы + осевая        (параллакс 1.0)
    curb_near.png  — ближний бордюр + тротуар          (параллакс 1.0)
    props_near.png — брошенные машины на ближнем тротуаре (параллакс 1.0)

Плюс env_manifest.json — данные для анимации в движке (звёзды, мерцающие
окна, партиклы, шаг разметки), чтобы Godot не пересчитывал градиенты.

Запуск:  python3 env.py --theme neon --seed 1337 --out ../assets/env/neon
         python3 env.py --all
"""

import argparse, json, math, os, random

from PIL import Image, ImageDraw

# ----------------------------------------------------------------------------
# 1. ГЕОМЕТРИЯ. Единственный источник правды. Совпадает с World.gd
# ----------------------------------------------------------------------------

class Belt:
    W = 640
    H = 360

    HORIZON_Y = -34.0   # линия основания забора, дальний край мира
    CURB_H    =  12.0   # дальний тротуар: декор, ходить нельзя
    BELT_TOP  = -22.0   # depth = 0.0
    BELT_BOT  =  72.0   # depth = 1.0
    BELT_H    =  94.0
    SCALE_FAR  = 0.88
    SCALE_NEAR = 1.10

    # world_y -> screen_y для превью (в игре это делает камера).
    # Ставим depth=1 на 300-ю строку: под поясом остаётся 60 px ближнего
    # тротуара с машинами, сверху 194 px города.
    Y0 = 228.0

    @classmethod
    def s(cls, world_y):
        return int(round(world_y + cls.Y0))

    @classmethod
    def screen_y(cls, depth):
        return cls.BELT_TOP + depth * cls.BELT_H

    @classmethod
    def sy(cls, depth):
        return cls.s(cls.screen_y(depth))

    @classmethod
    def scale_at(cls, depth):
        return cls.SCALE_FAR + (cls.SCALE_NEAR - cls.SCALE_FAR) * depth


B = Belt
W, H = B.W, B.H
HOR      = B.s(B.HORIZON_Y)        # 194 — основание забора / линия горизонта
CURB_TOP = HOR                     # 194
BELT_T   = B.sy(0.0)               # 206
BELT_B   = B.sy(1.0)               # 300

# ----------------------------------------------------------------------------
# 2. Утилиты
# ----------------------------------------------------------------------------

BAYER4 = [
    [0, 8, 2, 10],
    [12, 4, 14, 6],
    [3, 11, 1, 9],
    [15, 7, 13, 5],
]

def bayer(x, y):
    return (BAYER4[y & 3][x & 3] + 0.5) / 16.0


def _hash01(x, y):
    n = (x * 374761393 + y * 668265263) & 0xFFFFFFFF
    n = (n ^ (n >> 13)) * 1274126177 & 0xFFFFFFFF
    return ((n ^ (n >> 16)) & 0xFFFF) / 65535.0


def noise_thr(x, y, mixk=0.55):
    """Порог = смесь упорядоченного и белого шума. Ordered один даёт
    видимую сетку (квадратное гало вокруг луны), белый один — грязь."""
    return bayer(x, y) * (1.0 - mixk) + _hash01(x, y) * mixk

def hx(h):
    h = h.lstrip('#')
    return (int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16))

def mix(a, b, t):
    A, Bc = hx(a) if isinstance(a, str) else a, hx(b) if isinstance(b, str) else b
    t = max(0.0, min(1.0, t))
    return tuple(int(round(A[i] + (Bc[i] - A[i]) * t)) for i in range(3))

def shade(c, k):
    """k>1 светлее, k<1 темнее. Сохраняем «тон», не уплываем в серый."""
    c = hx(c) if isinstance(c, str) else c
    return tuple(max(0, min(255, int(round(v * k)))) for v in c)

def new_layer():
    return Image.new('RGBA', (W, H), (0, 0, 0, 0))

def px(img, x, y, color, a=255):
    """Пиксель с оборачиванием по X — так слой получается бесшовным."""
    if y < 0 or y >= H:
        return
    x %= W
    if len(color) == 4:
        a = color[3]
        color = color[:3]
    img.putpixel((x, y), (color[0], color[1], color[2], a))

def rect(img, x, y, w, h, color, a=255):
    for yy in range(y, y + h):
        if yy < 0 or yy >= H:
            continue
        for xx in range(x, x + w):
            px(img, xx, yy, color, a)

def dither_alpha(img, x, y, color, a, levels=5):
    """Пиксель с дизерингом альфы — убивает полосы на градиентах."""
    if a <= 0.001:
        return
    v = a * (levels - 1)
    lo = math.floor(v)
    frac = v - lo
    lvl = lo + (1 if frac > noise_thr(x, y) else 0)
    if lvl <= 0:
        return
    px(img, x, y, color, int(round(255 * min(1.0, lvl / (levels - 1)))))

# ----------------------------------------------------------------------------
# 3. Темы
# ----------------------------------------------------------------------------

THEMES = {
    'neon': dict(
        name='01 NEON DECAY',
        sky=['#07040f', '#0d0719', '#1a0c28', '#2c1038', '#4a1442'],
        stars=70,
        moon=dict(x=128, y=72, r=18, color='#efe6ff', glow='#7a4fd0'),
        far=dict(body='#150c26', rim='#26154a', minH=54, maxH=126, minW=18,
                 maxW=44, win='#4a2b7a', winSz=1, winGap=4, winDens=0.10),
        mid=dict(body='#1d1036', rim='#3a1f63', minH=34, maxH=82, minW=24,
                 maxW=52, win='#b06bd8', win2='#ff5fa2', winSz=2, winGap=4,
                 winDens=0.13, neon='#ff3d8b', beacon='#ff4d4d'),
        near=dict(body='#0a0616', rim='#1a0f2e', minH=18, maxH=44, minW=30,
                  maxW=62, win='#ff5fa2', winSz=2, winGap=6, winDens=0.06),
        fence='#2a1a44', fence_hi='#3d2864',
        curb='#241a3c', curb_hi='#3a2a5e', walk='#1b1430', walk_hi='#2a2046',
        # асфальт: поднят на 2 тона относительно оригинала #0c0818
        road_far='#191128', road_near='#221833', crack='#0e0a1a',
        line_center='#d8bf3f', line_edge='#8f86a8',
        car_body='#140d22', car_rim='#ff3d8b', car_glass='#2a1c47',
        fog='#3a1550', particle='rain', pcolor='#8f7ad8', beams=False,
    ),
    'bloodmoon': dict(
        name='02 BLOOD MOON',
        sky=['#0a0407', '#1a060b', '#320a11', '#54121a', '#7d1f1e'],
        stars=28,
        moon=dict(x=480, y=92, r=40, color='#ff6a4a', glow='#c02a1e'),
        far=dict(body='#1a0810', rim='#33121a', minH=58, maxH=132, minW=20,
                 maxW=46, win='#7a2a1a', winSz=1, winGap=5, winDens=0.05),
        mid=dict(body='#120509', rim='#3d1013', minH=32, maxH=80, minW=26,
                 maxW=54, win='#ffb347', winSz=1, winGap=5, winDens=0.07,
                 beacon='#ff3b30'),
        near=dict(body='#060203', rim='#170709', minH=16, maxH=42, minW=32,
                  maxW=66, win='#e08a3c', winSz=2, winGap=7, winDens=0.03),
        fence='#2b1013', fence_hi='#3f181c',
        curb='#2a1114', curb_hi='#3e1a1e', walk='#1d0c0f', walk_hi='#2c1317',
        road_far='#170c0e', road_near='#201215', crack='#0c0607',
        line_center='#c9a83f', line_edge='#9a7f78',
        car_body='#150a0c', car_rim='#ff6a4a', car_glass='#2c0d0f',
        fog='#6b1a1c', particle='ash', pcolor='#ffb99a', beams=False,
    ),
    'toxic': dict(
        name='03 TOXIC DAWN',
        sky=['#07110c', '#0f2317', '#1d3a24', '#395d2e', '#7d9a3e'],
        stars=14,
        moon=dict(x=200, y=150, r=22, color='#e6f58a', glow='#96b03a'),
        far=dict(body='#16281a', rim='#24401f', minH=50, maxH=120, minW=16,
                 maxW=40, win='#3f6b32', winSz=1, winGap=4, winDens=0.08),
        mid=dict(body='#0f1d13', rim='#2c4a26', minH=30, maxH=88, minW=14,
                 maxW=34, win='#9dff6b', winSz=1, winGap=4, winDens=0.10,
                 beacon='#ff4d4d'),
        near=dict(body='#06100a', rim='#122016', minH=16, maxH=40, minW=34,
                  maxW=70, win='#7fe04a', winSz=2, winGap=7, winDens=0.04),
        fence='#1d3323', fence_hi='#2c4a32',
        curb='#1c3020', curb_hi='#2c4630', walk='#142418', walk_hi='#1f3524',
        road_far='#12200f', road_near='#1a2b15', crack='#0a1409',
        line_center='#cbd44a', line_edge='#8ea07f',
        car_body='#0d1a10', car_rim='#9dff6b', car_glass='#1d3323',
        fog='#4a7a2e', particle='spore', pcolor='#c6ff7a', beams=False,
    ),
    'cold': dict(
        name='04 COLD RUINS',
        sky=['#05070d', '#0a1019', '#111d2e', '#1d3049', '#33506e'],
        stars=60,
        moon=dict(x=530, y=64, r=14, color='#dbeaff', glow='#3f6a9e'),
        far=dict(body='#101a28', rim='#1e3450', minH=56, maxH=130, minW=18,
                 maxW=42, win='#2f5d85', winSz=1, winGap=4, winDens=0.09),
        mid=dict(body='#0b1320', rim='#1b2f47', minH=32, maxH=80, minW=24,
                 maxW=52, win='#8fd8ff', win2='#ffd27a', winSz=1, winGap=4,
                 winDens=0.11, beacon='#ff5b5b'),
        near=dict(body='#050810', rim='#101b2a', minH=16, maxH=44, minW=32,
                  maxW=64, win='#7ab8e0', winSz=2, winGap=7, winDens=0.04),
        fence='#1d2c3e', fence_hi='#2c4157',
        curb='#93a8bd', curb_hi='#c3d4e4', walk='#dfe8f2', walk_hi='#ffffff',
        road_far='#141c28', road_near='#1c2634', crack='#0b1119',
        line_center='#c9b25a', line_edge='#b8c6d4',
        car_body='#0b1220', car_rim='#8fd8ff', car_glass='#1b2f47',
        fog='#2a4a6e', particle='snow', pcolor='#ffffff', beams=True,
    ),
}

# ----------------------------------------------------------------------------
# 4. Бейкеры
# ----------------------------------------------------------------------------

def bake_sky(p):
    """Небо полосами по 3 px — читается как пиксель-арт, а не как мыло."""
    img = Image.new('RGBA', (W, H), (0, 0, 0, 255))
    band = 3
    n = len(p['sky']) - 1
    for y in range(0, HOR + band, band):
        t = min(1.0, y / float(HOR))
        i = min(n - 1, int(t * n))
        f = t * n - i
        c = mix(p['sky'][i], p['sky'][i + 1], f)
        rect(img, 0, y, W, band, c)
    # ниже горизонта небо не нужно, но пусть будет глухая тьма, а не дырка
    rect(img, 0, HOR, W, H - HOR, hx(p['sky'][0]))
    return img


def bake_moon(p):
    """Луна + свечение через дизеринг. Причина: гладкий радиальный градиент
    в 8-битном небе даёт видимые кольца — это и были 'полосы у луны'."""
    img = new_layer()
    m = p['moon']
    mx, my, r = m['x'], m['y'], m['r']
    glow = hx(m['glow'])
    body = hx(m['color'])
    R = int(r * 2.9)
    for y in range(my - R, my + R + 1):
        if y < 0 or y >= HOR:
            continue
        for x in range(mx - R, mx + R + 1):
            d = math.hypot(x - mx, y - my)
            if d > R or d <= r:
                continue
            a = 0.60 * (1.0 - d / R) ** 3.6
            a *= 1.0 - 0.10 * _hash01(x, y)
            dither_alpha(img, x, y, glow, a)
    # плотное ядро свечения: 3 сплошных ступени, чтобы дизер не 'искрил'
    for step, alpha in ((1, 0.34), (2, 0.22), (3, 0.13)):
        rr = r + step
        for y in range(my - rr, my + rr + 1):
            for x in range(mx - rr, mx + rr + 1):
                d = math.hypot(x - mx, y - my)
                if r < d <= rr:
                    px(img, x, y, mix(m['glow'], m['color'], 0.25),
                       int(255 * alpha))
    # диск: без сглаживания, с лёгким терминатором и «морями»
    for y in range(my - r - 1, my + r + 2):
        for x in range(mx - r - 1, mx + r + 2):
            d = math.hypot(x - mx, y - my)
            if d > r:
                continue
            # шейдинг не полосами, а двумя тонами + дизер по границе
            k = 1.0 - 0.22 * ((x - mx) * 0.7 + (y - my) * 0.7) / max(1.0, r)
            c = shade(body, max(0.72, min(1.0, k)))
            edge = (d > r - 1.2)
            if edge and bayer(x, y) > 0.55:
                c = mix(c, glow, 0.5)
            px(img, x, y, c)
    for (ox, oy, rr) in ((-0.35, -0.20, 0.26), (0.30, 0.34, 0.18),
                         (0.05, -0.45, 0.12)):
        cx, cy, cr = mx + ox * r, my + oy * r, rr * r
        for y in range(int(cy - cr) - 1, int(cy + cr) + 2):
            for x in range(int(cx - cr) - 1, int(cx + cr) + 2):
                if math.hypot(x - cx, y - cy) <= cr:
                    px(img, x, y, mix(body, m['glow'], 0.45))
    return img


def bake_city(rnd, cfg, base_y, dip_strength=0.45, dip_w=0.20):
    """Силуэты города. Бесшовно: блоки идут по кругу, всё через px() с
    оборачиванием. Центр кадра специально проваливается — под HUD."""
    img = new_layer()
    body, rim = hx(cfg['body']), hx(cfg.get('rim') or cfg['body'])
    blocks = []
    x = 0
    while x < W:
        bw = int(cfg['minW'] + (cfg['maxW'] - cfg['minW']) * rnd.random())
        cx = (x + bw * 0.5) / W
        dip = 1.0 - dip_strength * math.exp(-((cx - 0.5) / dip_w) ** 2)
        bh = int((cfg['minH'] + (cfg['maxH'] - cfg['minH']) * rnd.random()) * dip)
        blocks.append(dict(x=x, w=bw, h=max(6, bh), s=rnd.random()))
        x += bw + (int(rnd.random() * 5) if rnd.random() > 0.72 else 0)
    # последний блок подрезаем, чтобы стык был по границе, а не по пикселю
    if blocks:
        blocks[-1]['w'] = max(6, W - blocks[-1]['x'])

    for b in blocks:
        y = base_y - b['h']
        rect(img, b['x'], y, b['w'], b['h'] + 3, body)
        rect(img, b['x'], y, b['w'], 1, rim)
        # вертикальная «нервюра» — читается как объём, дешево
        if b['w'] > 16:
            rect(img, b['x'] + b['w'] - 1, y + 1, 1, b['h'], shade(body, 0.78))
        # антенны, бак, надстройка
        if b['s'] > 0.72 and b['w'] > 10:
            ax = b['x'] + b['w'] // 2
            hh = 8 + int(b['s'] * 8)
            rect(img, ax, y - hh, 1, hh, body)
            if cfg.get('beacon') and b['s'] > 0.90:
                px(img, ax, y - hh - 1, hx(cfg['beacon']))
        if b['s'] < 0.22 and b['w'] > 16:
            rect(img, b['x'] + 3, y - 4, b['w'] - 7, 4, body)
            rect(img, b['x'] + 3, y - 4, b['w'] - 7, 1, rim)
        # окна: гаснут к центру кадра (читаемость HUD)
        if cfg.get('win'):
            gap, sz = cfg['winGap'], cfg['winSz']
            dim = 1.0 - 0.70 * math.exp(-(((b['x'] + b['w'] * .5) / W - .5) / .22) ** 2)
            wy = y + 4
            while wy < base_y - 3:
                wx = b['x'] + 2
                while wx < b['x'] + b['w'] - 2:
                    if rnd.random() < cfg['winDens'] * dim:
                        c = hx(cfg['win2']) if (cfg.get('win2') and rnd.random() > .85) \
                            else hx(cfg['win'])
                        a = int(115 + rnd.random() * 140)
                        rect(img, wx, wy, sz, sz, c, a)
                    wx += gap + sz
                wy += gap + sz
        # неоновая вывеска
        if cfg.get('neon') and b['s'] > 0.86 and b['w'] > 18:
            ny = y + 8
            rect(img, b['x'] + 4, ny, b['w'] - 8, 2, hx(cfg['neon']), 230)
            rect(img, b['x'] + 4, ny - 1, b['w'] - 8, 1, hx(cfg['neon']), 70)
            rect(img, b['x'] + 4, ny + 2, b['w'] - 8, 1, hx(cfg['neon']), 70)
    return img


def bake_fence(rnd, p):
    """ГЛАВНАЯ ПРАВКА: забор был сплошным и глушил город.
    Теперь: ниже (26 px вместо 40), сетка реже (шаг 4 px, альфа 90),
    столбы каждые 32 px, местами пролом — город виден сквозь него."""
    img = new_layer()
    base = HOR + 2
    top = base - 26
    col, hi = hx(p['fence']), hx(p['fence_hi'])
    holes = []
    x = 0
    while x < W:
        seg = 32
        if rnd.random() < 0.14:               # пролом
            holes.append((x, seg))
        x += seg
    def in_hole(xx):
        for hx0, hw in holes:
            if hx0 <= xx < hx0 + hw:
                return True
        return False

    # сетка ромбом, разреженная
    for y in range(top, base):
        for xx in range(W):
            if in_hole(xx):
                continue
            if (xx + y) % 4 == 0 or (xx - y) % 4 == 0:
                px(img, xx, y, col, 92)
    # верхний и нижний рельс
    for xx in range(W):
        if in_hole(xx):
            continue
        px(img, xx, top, hi, 190)
        px(img, xx, top + 1, col, 140)
        px(img, xx, base - 1, col, 170)
    # столбы + фундамент (чтобы забор стоял, а не висел)
    for x0 in range(0, W, 32):
        if in_hole(x0):
            continue
        rect(img, x0, top - 3, 2, 29, col, 220)
        px(img, x0, top - 3, hi, 235)
        px(img, x0 + 1, top - 3, hi, 235)
        rect(img, x0 - 1, base, 4, 2, shade(p['fence'], 0.7), 235)
    # подмятая сетка у проломов — силуэт «здесь прорвались»
    for hx0, hw in holes:
        for k in range(6):
            xx = hx0 + int(rnd.random() * hw)
            yy = base - 1 - int(rnd.random() * 8)
            px(img, xx, yy, col, 160)
    return img


def bake_curb_far(rnd, p):
    """depth = 0. Дальний тротуар (CURB_H = 12) + физический бордюр.
    Игрок упирается в НАРИСОВАННЫЙ бордюр, а не в воздух."""
    img = new_layer()
    walk, walk_hi = hx(p['walk']), hx(p['walk_hi'])
    curb, curb_hi = hx(p['curb']), hx(p['curb_hi'])
    rect(img, 0, CURB_TOP, W, int(B.CURB_H) - 4, walk)
    for x in range(0, W, 2):                      # плитка
        px(img, x, CURB_TOP + 2, walk_hi, 60)
    for x in range(0, W, 16):
        rect(img, x, CURB_TOP, 1, int(B.CURB_H) - 4, walk_hi, 45)
    # тело бордюра 4 px + светлая кромка ровно на BELT_TOP
    rect(img, 0, BELT_T - 4, W, 4, curb)
    rect(img, 0, BELT_T - 4, W, 1, curb_hi, 235)
    rect(img, 0, BELT_T - 1, W, 1, shade(p['curb'], 0.55))
    for x in range(0, W, 24):                     # стыки бордюрных камней
        rect(img, x, BELT_T - 4, 1, 4, shade(p['curb'], 0.45), 200)
    for _ in range(26):                           # выбоины
        x = rnd.randrange(W)
        px(img, x, BELT_T - 3, shade(p['curb'], 0.6))
        if rnd.random() > .6:
            px(img, x + 1, BELT_T - 2, shade(p['curb'], 0.6))
    return img


def bake_road(rnd, p):
    """Асфальт: 206..300 (94 px рабочей глубины). Поднят на 2 тона, иначе
    кровь и зомби сливаются. Дальше — темнее, ближе — светлее: это и есть
    читаемая глубина. Разметка впечатана (в движке скроллится от камеры)."""
    img = new_layer()
    far, near = hx(p['road_far']), hx(p['road_near'])
    crack = hx(p['crack'])
    for y in range(BELT_T, BELT_B):
        d = (y - BELT_T) / float(BELT_B - BELT_T)
        base = mix(far, near, d ** 0.85)
        for x in range(W):
            # зерно асфальта: сильнее вблизи, слабее вдали (перспектива)
            n = ((x * 7 + y * 13) % 17) / 17.0
            k = 1.0 + (n - 0.5) * (0.05 + 0.09 * d)
            px(img, x, y, shade(base, k))
    # краевые линии у бордюров
    for (yy, a) in ((BELT_T + 2, 120), (BELT_B - 4, 150)):
        for x in range(W):
            if (x % 2) == 0:
                px(img, x, yy, hx(p['line_edge']), a)
    # осевая: depth = 0.5, длина штриха и высота растут с глубиной
    yc = B.sy(0.5)
    step, dash = 24, 13
    for x in range(0, W, step):
        rect(img, x, yc, dash, 2, hx(p['line_center']), 190)
        rect(img, x, yc + 2, dash, 1, hx(p['line_center']), 60)
    # разделители полос: depth 0.25 и 0.75
    for d, a, st, dl in ((0.25, 90, 20, 8), (0.75, 110, 28, 15)):
        y = B.sy(d)
        for x in range(6, W, st):
            rect(img, x, y, dl, 1, hx(p['line_edge']), a)
    # трещины и пятна — плотнее вблизи
    for _ in range(220):
        d = rnd.random() ** 0.6
        y = int(BELT_T + d * (BELT_B - BELT_T))
        x = rnd.randrange(W)
        ln = 1 + int(rnd.random() * (2 + 4 * d))
        rect(img, x, y, ln, 1, crack, 200)
    for _ in range(26):                       # маслянные пятна
        d = rnd.random()
        cx, cy = rnd.randrange(W), int(BELT_T + d * (BELT_B - BELT_T))
        r = 3 + int(rnd.random() * 7 * (0.5 + d))
        for y in range(cy - r // 2, cy + r // 2 + 1):
            for x in range(cx - r, cx + r + 1):
                if ((x - cx) / max(1.0, r)) ** 2 + ((y - cy) / max(1.0, r / 2.0)) ** 2 <= 1:
                    dither_alpha(img, x, y, crack, 0.55)
    # люки — ориентиры глубины
    for _ in range(3):
        d = 0.25 + rnd.random() * 0.6
        cx, cy = rnd.randrange(W), B.sy(d)
        r = 5
        for y in range(cy - 3, cy + 4):
            for x in range(cx - r, cx + r + 1):
                if ((x - cx) / float(r)) ** 2 + ((y - cy) / 3.0) ** 2 <= 1:
                    px(img, x, y, shade(p['road_near'], 0.72))
        rect(img, cx - r, cy - 3, 2 * r + 1, 1, shade(p['road_near'], 1.25), 120)
    return img


def bake_curb_near(rnd, p):
    """depth = 1. Ближний бордюр + тротуар. Снизу мир заканчивается
    физически, а не чёрной дыркой."""
    img = new_layer()
    walk, walk_hi = hx(p['walk']), hx(p['walk_hi'])
    curb, curb_hi = hx(p['curb']), hx(p['curb_hi'])
    rect(img, 0, BELT_B, W, 5, curb)
    rect(img, 0, BELT_B, W, 1, curb_hi, 240)
    rect(img, 0, BELT_B + 4, W, 1, shade(p['curb'], 0.5))
    for x in range(0, W, 26):
        rect(img, x, BELT_B, 1, 5, shade(p['curb'], 0.45), 210)
    rect(img, 0, BELT_B + 5, W, H - BELT_B - 5, walk)
    for i, y in enumerate(range(BELT_B + 9, H, 11)):   # швы плит, в перспективе
        for x in range(0, W, 4):
            px(img, x, y, walk_hi, 20)
    for x in range(0, W, 46):
        rect(img, x, BELT_B + 5, 1, H - BELT_B - 5, walk_hi, 26)
    for _ in range(44):                          # мусор
        x, y = rnd.randrange(W), BELT_B + 6 + rnd.randrange(H - BELT_B - 6)
        px(img, x, y, shade(p['walk'], 0.72 if rnd.random() > .5 else 1.3))
    return img


# Четыре архетипа кузова. Один силуэт, повторённый вдоль улицы, читался как
# обои — это было главным минусом первого прогона.
#            hood   cab    cab_x  cab_w  tint
CAR_KINDS = {
    'sedan':  (0.52,  0.42,  0.26,  0.52,  1.00),
    'van':    (0.34,  0.66,  0.16,  0.68,  0.94),
    'pickup': (0.58,  0.40,  0.18,  0.34,  1.06),
    'wreck':  (0.46,  0.30,  0.24,  0.44,  0.68),
}


def _car(img, p, x, y, w, h, rnd, flip=False, kind='sedan'):
    """Профиль машины, а не прямоугольник: капот, наклонная крыша, арки,
    колёса. Кузов чуть светлее тротуара + рим-лайт только по верхним
    кромкам — так силуэт читается, но не превращается в UI-рамку."""
    hr, cr, cxr, cwr, tint = CAR_KINDS.get(kind, CAR_KINDS['sedan'])
    # плюс личный разброс тона: две одинаковые машины рядом больше не стоят
    tint *= 0.88 + rnd.random() * 0.26
    body_lo = shade(p['car_body'], 1.25 * tint)
    body_hi = shade(p['car_body'], 1.85 * tint)
    glass   = shade(p['car_glass'], 1.15)
    rimc    = hx(p['car_rim'])

    hood_h  = max(6, int(h * hr))             # высота капота/багажника
    cab_h   = max(4, int(h * cr))              # высота салона над капотом
    cab_x   = x + int(w * cxr)
    cab_w   = max(6, int(w * cwr))
    if flip:
        cab_x = x + w - int(w * cxr) - cab_w
    if kind == 'wreck':
        # разбитая: просевшая на брюхо и без стёкол
        y += 1 + int(rnd.random() * 2)
        glass = shade(p['car_body'], 0.55)

    # тень под машиной (сначала, чтобы кузов лёг сверху)
    for k in range(w + 10):
        dither_alpha(img, x - 5 + k, y, (0, 0, 0), 0.62)
        dither_alpha(img, x - 3 + k, y + 1, (0, 0, 0), 0.34)

    # нижняя часть кузова с вертикальным «градиентом» в 3 тона
    for yy in range(y - hood_h, y):
        t = (yy - (y - hood_h)) / float(max(1, hood_h))
        c = mix(body_hi, body_lo, t ** 0.7)
        rect(img, x + 1, yy, w - 2, 1, c)
    rect(img, x, y - hood_h + 1, 1, hood_h - 2, body_lo)          # скруглы
    rect(img, x + w - 1, y - hood_h + 1, 1, hood_h - 2, body_lo)

    # салон: наклонные стойки
    for i in range(cab_h):
        yy = y - hood_h - cab_h + i
        inset = max(0, int((cab_h - i) * 0.55))
        cx0, cw = cab_x + inset, cab_w - inset * 2
        if cw <= 2:
            continue
        rect(img, cx0, yy, cw, 1, mix(body_hi, body_lo, i / float(cab_h)))
        if i >= 1 and cw > 4:
            rect(img, cx0 + 1, yy, cw - 2, 1, glass if i < cab_h - 2 else
                 mix(body_hi, body_lo, .5))
    # блик по стеклу
    for k in range(cab_w // 2):
        dither_alpha(img, cab_x + cab_w // 3 + k, y - hood_h - cab_h + 2,
                     (255, 255, 255), 0.30)

    # рим-лайт: только крыша и линия капота
    top_y = y - hood_h - cab_h
    for k in range(cab_w):
        inset = max(0, int(cab_h * 0.55))
        if inset <= k < cab_w - inset:
            dither_alpha(img, cab_x + k, top_y, rimc, 0.55)
    for k in range(w - 2):
        if not (cab_x - x - 1 <= k <= cab_x - x + cab_w):
            dither_alpha(img, x + 1 + k, y - hood_h, rimc, 0.42)

    # фара / стоп
    lx = x + w - 4 if not flip else x + 2
    rect(img, lx, y - hood_h + 2, 3, 2, rimc, 240)
    dither_alpha(img, lx - 1, y - hood_h + 3, rimc, 0.55)
    dither_alpha(img, lx + 3, y - hood_h + 3, rimc, 0.55)

    # арки и колёса
    for wxr in (x + int(w * 0.15), x + int(w * 0.68)):
        rect(img, wxr - 1, y - hood_h, 12, 2, shade(p['car_body'], 0.55))
        rect(img, wxr, y - 6, 10, 6, (10, 8, 16))
        rect(img, wxr + 2, y - 5, 6, 4, shade(p['car_body'], 0.75))
        rect(img, wxr + 3, y - 4, 4, 2, shade(p['car_body'], 1.1))

    # разбитое стекло / вмятина — «эта машина стоит тут давно»
    if rnd.random() > 0.45:
        dx = cab_x + 2 + int(rnd.random() * max(1, cab_w - 5))
        rect(img, dx, top_y + 2, 3, 2, shade(p['car_body'], 0.6))
    if rnd.random() > 0.7:
        rect(img, x + int(w * .5), y - hood_h + 1, 5, 2, shade(p['car_body'], 0.7))


def bake_props_near(rnd, p):
    """Брошенные машины и баки на ближнем тротуаре: подрезаны срезом экрана,
    это и читается как 'ближе идти некуда'."""
    img = new_layer()
    xs = []
    # Порядок кузовов тасуется, а не выбирается независимо в каждой точке:
    # так исключены два одинаковых силуэта подряд.
    bag = ['sedan', 'van', 'pickup', 'sedan', 'wreck', 'pickup', 'van', 'sedan']
    rnd.shuffle(bag)
    bi = 0
    x = 10
    while x < W - 40:
        w = 78 + int(rnd.random() * 46)
        if rnd.random() < 0.66:
            kind = bag[bi % len(bag)]
            bi += 1
            if kind == 'van':
                w = int(w * 0.86)
            elif kind == 'pickup':
                w = int(w * 1.12)
            base = H - 4 - int(rnd.random() * 10)
            _car(img, p, x, base, w, 26 + int(rnd.random() * 8), rnd,
                 flip=rnd.random() > .5, kind=kind)
            xs.append((x, w))
            # рваный шаг: ритм «через равные промежутки» и был виден как повтор
            x += w + 14 + int(rnd.random() * 72)
        else:
            # мусорный бак
            bw, bh = 20, 24
            base = H - 2 - int(rnd.random() * 12)
            rect(img, x, base - bh, bw, bh, shade(p['car_body'], 1.3))
            rect(img, x, base - bh, bw, 2, shade(p['car_body'], 2.0))
            rect(img, x - 1, base - bh - 2, bw + 2, 2, shade(p['car_body'], 1.6))
            for k in range(bw + 4):
                dither_alpha(img, x - 2 + k, base, (0, 0, 0), 0.5)
            x += bw + 26 + int(rnd.random() * 50)
    return img


def bake_fog(p):
    """Приземный туман: ложится ровно на линию бордюра depth=0."""
    img = new_layer()
    col = hx(p['fog'])
    top, bot = HOR - 16, BELT_T + 6
    for y in range(top, bot):
        t = (y - top) / float(bot - top)
        a = 0.30 * math.sin(math.pi * min(1.0, max(0.0, t))) ** 0.8
        for x in range(W):
            n = 0.75 + 0.25 * math.sin(x * 0.07 + y * 0.4)
            dither_alpha(img, x, y, col, a * n)
    return img

# ----------------------------------------------------------------------------
# 5. Данные для анимации в движке
# ----------------------------------------------------------------------------

def anim_data(rnd, p):
    stars = [dict(x=rnd.randrange(W), y=rnd.randrange(0, HOR - 60),
                  b=round(0.30 + rnd.random() * 0.70, 3),
                  ph=round(rnd.random() * 6.283, 3),
                  sz=2 if rnd.random() > 0.90 else 1)
             for _ in range(p['stars'])]
    flick = [dict(x=rnd.randrange(W), y=60 + rnd.randrange(0, 110),
                  ph=round(rnd.random() * 6.283, 3),
                  sp=round(0.5 + rnd.random() * 2.0, 3))
             for _ in range(14)]
    counts = dict(rain=110, snow=90, ash=55, spore=55)
    return dict(
        geometry=dict(W=W, H=H, HORIZON=HOR, CURB_TOP=CURB_TOP,
                      BELT_TOP=BELT_T, BELT_BOT=BELT_B,
                      BELT_H=int(B.BELT_H),
                      SCALE_FAR=B.SCALE_FAR, SCALE_NEAR=B.SCALE_NEAR,
                      world=dict(HORIZON_Y=B.HORIZON_Y, CURB_H=B.CURB_H,
                                 BELT_TOP=B.BELT_TOP, BELT_BOT=B.BELT_BOT)),
        parallax=dict(far=0.20, mid=0.40, near=0.66, fence=0.80, ground=1.0),
        stars=stars, flicker_windows=flick,
        particles=dict(kind=p['particle'], count=counts[p['particle']],
                       color=p['pcolor']),
        road_marking=dict(step=24, dash=13, from_camera=True),
        beams=p['beams'], vignette='menu_only',
    )

# ----------------------------------------------------------------------------
# 6. Превью (то, что смотрим глазами) — плоская склейка + партиклы
# ----------------------------------------------------------------------------

def draw_particles(img, rnd, p, n):
    col = hx(p['pcolor'])
    kind = p['particle']
    for _ in range(n):
        x, y = rnd.randrange(W), rnd.randrange(H)
        s = 0.4 + rnd.random() * 1.2
        if kind == 'rain':
            for k in range(6):
                dither_alpha(img, x - int(k * 0.34), y + k, col, 0.42 * s)
        elif kind == 'snow':
            dither_alpha(img, x, y, col, 0.85)
            if s > 1.2:
                dither_alpha(img, x + 1, y, col, 0.6)
        else:
            dither_alpha(img, x, y, col, 0.55)


def compose(layers, order):
    out = Image.new('RGBA', (W, H), (0, 0, 0, 255))
    for k in order:
        out.alpha_composite(layers[k])
    return out


def bake_theme(theme, seed, outdir, preview_only=False):
    p = THEMES[theme]
    rnd = random.Random(seed)
    L = {}
    L['sky']        = bake_sky(p)
    L['moon']       = bake_moon(p)
    L['far']        = bake_city(random.Random(seed + 1), p['far'],  HOR + 2, 0.45, 0.20)
    L['mid']        = bake_city(random.Random(seed + 2), p['mid'],  HOR + 3, 0.40, 0.19)
    L['near']       = bake_city(random.Random(seed + 3), p['near'], HOR + 4, 0.35, 0.18)
    L['fog']        = bake_fog(p)
    L['fence']      = bake_fence(random.Random(seed + 4), p)
    L['curb_far']   = bake_curb_far(random.Random(seed + 5), p)
    L['road']       = bake_road(random.Random(seed + 6), p)
    L['curb_near']  = bake_curb_near(random.Random(seed + 7), p)
    L['props_near'] = bake_props_near(random.Random(seed + 8), p)

    order = ['sky', 'moon', 'far', 'mid', 'near', 'fog', 'fence',
             'curb_far', 'road', 'curb_near', 'props_near']

    os.makedirs(outdir, exist_ok=True)
    if not preview_only:
        for k in order:
            L[k].save(os.path.join(outdir, k + '.png'))
        with open(os.path.join(outdir, 'env_manifest.json'), 'w') as f:
            json.dump(anim_data(random.Random(seed + 99), p), f,
                      indent=2, ensure_ascii=False)

    # превью
    prev = compose(L, order)
    ad = anim_data(random.Random(seed + 99), p)
    for st in ad['stars']:                       # звёзды в фазе t=0
        a = st['b'] * (0.6 + 0.4 * math.sin(st['ph']))
        for dy in range(st['sz']):
            for dx in range(st['sz']):
                dither_alpha(prev, st['x'] + dx, st['y'] + dy, (255, 255, 255), a)
    for f in ad['flicker_windows']:
        if math.sin(f['ph']) > 0.75:
            px(prev, f['x'], f['y'], hx('#fff3c4'), 140)
    draw_particles(prev, random.Random(seed + 5), p, ad['particles']['count'])
    return L, prev, order


def debug_overlay(prev):
    """Схема геометрии поверх кадра: где depth 0 / 0.5 / 1 и где границы."""
    img = prev.copy()
    d = ImageDraw.Draw(img)
    marks = [(HOR, (120, 200, 255), 'HORIZON_Y = -34  (fence base)'),
             (BELT_T, (0, 255, 120), 'BELT_TOP  depth=0  (curb)'),
             (B.sy(0.5), (255, 220, 60), 'depth=0.5  (center line)'),
             (BELT_B, (255, 80, 120), 'BELT_BOT  depth=1  (near curb)')]
    for y, c, label in marks:
        for x in range(0, W, 4):
            for k in range(2):
                if 0 <= x + k < W:
                    img.putpixel((x + k, y), c + (255,))
        d.text((6, max(0, y - 11)), label, fill=c + (255,))
    d.text((6, 6), 'DeadLine v4 - BELT GEOMETRY  640x360', fill=(255, 255, 255, 255))
    d.text((6, 18), 'walkable depth = 94 px (was 78, and half of it was off-asphalt)',
           fill=(200, 200, 220, 255))
    return img

# ----------------------------------------------------------------------------

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--theme', default='neon', choices=list(THEMES))
    ap.add_argument('--seed', type=int, default=1337)
    ap.add_argument('--out', default='./out')
    ap.add_argument('--all', action='store_true')
    ap.add_argument('--preview-only', action='store_true')
    a = ap.parse_args()
    themes = list(THEMES) if a.all else [a.theme]
    for t in themes:
        outdir = os.path.join(a.out, t) if a.all else a.out
        _, prev, _ = bake_theme(t, a.seed, outdir, a.preview_only)
        os.makedirs(a.out, exist_ok=True)
        prev.save(os.path.join(a.out, 'preview_%s_v2.png' % t))
        prev.resize((W * 2, H * 2), Image.NEAREST).save(
            os.path.join(a.out, 'preview_%s_v2_x2.png' % t))
        if t == 'neon':
            debug_overlay(prev).resize((W * 2, H * 2), Image.NEAREST).save(
                os.path.join(a.out, 'preview_%s_v2_geometry.png' % t))
        print('baked', t, '->', outdir)


if __name__ == '__main__':
    main()
