# DEAD LINE v4.1.0 - "Pressure"

## 1. Main menu (fixed)
- New `scripts/MenuStage.gd`: the start screen is now a real diorama of the
  CURRENT location (one of the 4 themes), built from the same baked bands,
  the same belt geometry and the same two-bone arm rig the game uses.
- The hero holds the gun correctly: grip / support hand / muzzle come from the
  new `Art.weapon_point()` table, the same anchors `Player.gd` rigs onto.
- Full-bleed sky plate + baked vignette (`fx_vignette.png`, new in the art
  pipeline) - no more half-empty screen on any aspect ratio.
- Old flat-strip background kept as an automatic fallback.

## 2. Difficulty overhaul (the tester complaints)
- `boss_hit_cap()`: no single hit may remove more than 7.5%..3% of a boss
  health pool. A maxed rifle or a lucky railgun crit can no longer delete a
  boss - burst gets you in, sustained DPS finishes the job.
- Boss rage phases at 72% / 45% / 20% HP: +speed, +damage, +armour, all
  effects cleared, reinforcements screamed in, 1.1s telegraph window.
- Boss ground slam (AoE + camera kick) - standing still is no longer free.
- Bosses: super-linear HP curve (~4x v4.0 at wave 50), more armour, elite
  escorts from wave 15, twin bosses from wave 35, three from wave 60.
- Champions (mini-bosses) on normal waves from wave 8.
- Horde really grows: wave_count cap 70 -> 130, spawn interval floor
  0.30s -> 0.16s, wave-aware alive cap, alive budget per quality up to 96.
- `pressure_mul(level)`: the horde reacts to how strong the build actually got
  (capped at +90%), so a good build can no longer outscale the curve.
- Boss / elite / champion resistances: burn and chill heavily reduced, stun
  capped at 0.35s on bosses - no more stun-locking a boss to death.
- NIGHTMARE is now an actual nightmare: HP x2.1, count x1.55, armour x1.45,
  boss x1.7, spawn interval x0.74. Cash x1.6 and XP x1.4 to match.

## 3. Ability rebalance (exact tester list)
- Double Tap: extra projectiles, but -35% damage per projectile.
- Incendiary: max level 4 -> 1, weaker burn (4 + 0.8% max HP dps).
- Cryo Rounds: max level 3 -> 1, chill 1.2s -> 0.8s and weaker slow factor.
- Stopping Power: +40% -> +15% knockback, max level 4 -> 3.

## 4. New cards
Executioner (+22% vs elites/bosses), Headhunter (+35% headshot), Ricochet,
Riot Shield (recharging shield pool), Second Wind (cheat death once per wave),
Shockwave Dash, Ammo Printer, Chain Reaction.

## 5. Arsenal + market
- 7 new weapons, fully generated pixel art: Nailgun, Sawed-Off, Tactical
  Crossbow, SVD Dragunov, Cryo Projector, Plasma Lance, Flak Cannon.
- 2 new throwables: Cryo Charge (flash freeze) and Sticky Bomb (boss opener).
- New market services: Field Plating, Repair All Structures, Call Airdrop.
- Shop shelf groups defined (`SHOP_TABS` / `SHOP_GROUPS`).

## Still open (next pass)
- HUD: shield bar, shop tab row and the three new service buttons are defined
  in data/logic but not wired into the shop UI yet.
- Online / co-op design + the Brawl Stars style dimensionality question.
