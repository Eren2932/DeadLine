# DeadLine v4.2.0 - balance pass (tester items 20-24)

## 20. Mines scale off the target
- Mine damage is now **50% of the target's max HP**, and **2.5% on bosses**.
- Implemented as a new `Zombie.take_percent_wound()` that **bypasses armour,
  armour pierce and the boss per-hit cap** - otherwise boss armour (35%) and
  `boss_hit_cap()` would have quietly turned 2.5% into ~0.9%.
- The old flat 260 damage stays as a **floor**: percentage alone would barely
  scratch a 20 HP walker, so the mine takes whichever is bigger.
- Tunables: `GameData.MINE_HP_FRAC`, `GameData.MINE_BOSS_FRAC`.

## 21. Explosive Rounds nerfed
- Chance per card: **12% -> 3%** (`EXPLOSIVE_CHANCE_PER_CARD`).
- Proc blast damage: **0.60x -> 0.45x** of the shot, i.e. **-25%**
  (`EXPLOSIVE_BLAST_MUL`).
- Card text updated to the real number, so the UI no longer lies.
- **Grenades were not touched** - they scale off the separate Demolition card
  and nerfing them here would have hit a build the tester did not mention.

## 22. Armour bar
- New **armour pool**: eats damage before HP, drawn as a grey bar directly
  under the health bar with the remaining value on the right.
- Base **25** at level 1, **+15% of base per level** (linear).
  Kevlar Plate cards add **+10% each** on top, so the stat stays alive late.
- Order of absorption: **Riot Shield -> armour plates -> HP**.
- Refills **at the start of every wave** and **on level up**. Percentage and
  flat armour reduction still work as before, on top of this.
- Breaking the plates plays a spark burst and a "ARMOUR BROKEN" float
  (localized RU/ES/PT).
- Saved and restored with the run (`armor_pool`), so checkpoints are honest.
- Note: **linear**, not compounding, on purpose. 25 * 1.15^29 would be ~1450
  armour by level 30 and would have made the survivor unkillable.

## 23. Dash reined in
- Bulldozer damage per level: **70 -> 52.5** (-25%).
- Sprint Boost cooldown reduction: **-20% -> -13.3%** per level (1.5x weaker).
- **Hard floor of 1.5 s between dashes**, whatever the build or class. The old
  floor was 0.35 s, which let a maxed Survivor dash almost non-stop.
- Card text updated.

## 24. Fewer cores
- End-of-run payout divided by **1.2** (`GameData.CORES_DIVISOR`).

## Not in this build (needs its own pass)
Items **16** (class-locked perks), **17** (weapon replacement prompt) and
**19** (new structures + structure upgrades) are systems, not numbers.
See the notes in chat - item 18 also has a contradiction that needs a decision.
