extends RefCounted
## ============================================================================
## EnvCity - the v4 city: ten baked, seamless bands, a moon, weather and the
## little lights that make it a place instead of a backdrop.
##
## This file is deliberately NOT an autoload and has NO class_name. Game.gd
## reaches it through load("res://scripts/EnvCity.gd") and checks the result for
## null, which means:
##
##   * if this script ever fails to compile, load() returns null, Game.gd falls
##     back to the flat v3 background and the run still starts;
##   * if anything in here throws at runtime, it throws inside a deferred call
##     that happens AFTER the player, the HUD and the camera already exist, so
##     the worst case is a plain sky - never a black screen.
##
## That is the whole lesson from the 4.0.0 build: scenery is allowed to fail,
## the game is not.
## ============================================================================

## name, world y of the image top row, parallax factor, z_index.
## Mirrors tools/env.py LAYERS 1:1 - tools/check.py fails the build if it drifts.
const LAYERS := [
	{"n": "sky", "y": -160.0, "f": 0.00, "z": -60},
	{"n": "far", "y": -110.0, "f": 0.20, "z": -50},
	{"n": "mid", "y": -92.0, "f": 0.40, "z": -46},
	{"n": "near", "y": -72.0, "f": 0.66, "z": -42},
	{"n": "fence", "y": -60.0, "f": 0.80, "z": -38},
	{"n": "fog", "y": -52.0, "f": 0.86, "z": -34},
	{"n": "curb_far", "y": -35.0, "f": 1.00, "z": -30},
	{"n": "road", "y": -22.0, "f": 1.00, "z": -28},
	{"n": "curb_near", "y": 72.0, "f": 1.00, "z": 120},
	{"n": "props_near", "y": 50.0, "f": 1.00, "z": 122},
]

## per theme: moon screen anchor / world y, weather kind, tint, light beams
const ENV := {
	"neon": {"moon_ax": 0.18, "moon_y": -86.0, "weather": "rain",
			"pcolor": "8f7ad8", "beams": false, "amount": 110},
	"blood": {"moon_ax": 0.72, "moon_y": -80.0, "weather": "ash",
			"pcolor": "ffb99a", "beams": false, "amount": 55},
	"toxic": {"moon_ax": 0.30, "moon_y": -84.0, "weather": "spore",
			"pcolor": "c6ff7a", "beams": false, "amount": 55},
	"cold": {"moon_ax": 0.80, "moon_y": -90.0, "weather": "snow",
			"pcolor": "ffffff", "beams": true, "amount": 90},
}

const WEATHER_MUL := [0.35, 0.7, 1.0]

var game = null
var moon: Sprite2D = null
var weather: CPUParticles2D = null
var twinkle: Array = []
var beams: Array = []
var built: int = 0
var t: float = 0.0


func env_dict() -> Dictionary:
	var d = ENV.get(GameData.theme_key(), null)
	if typeof(d) != TYPE_DICTIONARY:
		return ENV["neon"]
	return d


func weather_color() -> Color:
	## Stored as a hex string on purpose: a const Dictionary may only hold plain
	## constant expressions, so there is nothing here to argue about.
	return Color.html(str(env_dict().get("pcolor", "ffffff")))


func weather_amount() -> int:
	var base = int(env_dict().get("amount", 90))
	var q = clampi(Settings.idx("quality"), 0, WEATHER_MUL.size() - 1)
	return int(float(base) * float(WEATHER_MUL[q]))


# ---------------------------------------------------------------- build
func build(g) -> int:
	## Returns the number of bands actually created. 0 means "no art found" and
	## Game.gd keeps its flat sky - the run is unaffected either way.
	game = g
	if game == null or not is_instance_valid(game):
		return 0
	for spec in LAYERS:
		var key = str(spec["n"])
		var tex = Art.tex(GameData.env_path(key))
		if tex == null:
			push_warning("EnvCity: layer missing - " + key)
			continue
		var n = game._layer(tex, float(spec["f"]), float(spec["y"]), 1.0)
		if n == null:
			continue
		n.z_index = int(spec["z"])
		built += 1
		if key == "sky":
			_add_twinkle(n, 18, Color(1, 1, 1), -150.0, -96.0, 1.5)
		elif key == "mid":
			_add_twinkle(n, 14, Color(1.0, 0.95, 0.77), -88.0, -34.0, 3.0)
		elif key == "near":
			if bool(env_dict().get("beams", false)):
				_add_beams(n)
	_build_moon()
	_build_weather()
	return built


func _build_moon() -> void:
	var tex = Art.tex(GameData.env_path("moon"))
	if tex == null:
		return
	moon = Sprite2D.new()
	moon.texture = tex
	moon.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	moon.z_index = -58
	game.world.add_child(moon)


func _add_twinkle(holder: Node2D, count: int, col: Color, y0: float, y1: float,
		speed: float) -> void:
	## Points that pulse on their own phase. They are children of the parallax
	## holder, so they inherit its scroll and its wrap for free - no extra
	## bookkeeping and no chance of the lights drifting off the buildings.
	var tex = Art.fx_tex("spark")
	if tex == null:
		return
	var n = count
	if Settings.idx("quality") == 0:
		n = int(count / 2)
	var span = game.max_visible_w() + GameData.TILE_W * 2.0
	for i in range(n):
		var d = Sprite2D.new()
		d.texture = tex
		d.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
		d.modulate = col
		d.scale = Vector2(0.5, 0.5)
		d.position = Vector2(randf_range(0.0, span),
				randf_range(y0, y1) - holder.position.y)
		d.z_index = 1
		holder.add_child(d)
		twinkle.append({"node": d, "ph": randf_range(0.0, TAU), "sp": speed})


func _add_beams(holder: Node2D) -> void:
	for i in range(2):
		var p = Polygon2D.new()
		p.polygon = PackedVector2Array([Vector2(0, 0), Vector2(-9, -120), Vector2(9, -120)])
		p.color = Color(0.74, 0.88, 1.0, 0.10)
		p.position = Vector2(randf_range(40.0, GameData.TILE_W * 2.0), 0.0)
		p.z_index = 1
		holder.add_child(p)
		beams.append({"node": p, "ph": randf_range(0.0, TAU)})


func _build_weather() -> void:
	var amount = weather_amount()
	if amount <= 0:
		return
	var tex = Art.fx_tex("spark")
	if tex == null:
		return
	var p = CPUParticles2D.new()
	p.texture = tex
	p.amount = amount
	p.lifetime = 2.2
	p.preprocess = 1.2
	p.local_coords = false
	p.z_index = 130
	p.emission_shape = CPUParticles2D.EMISSION_SHAPE_RECTANGLE
	p.emission_rect_extents = Vector2(game.max_visible_w() * 0.6 + 40.0, 12.0)
	p.color = weather_color()
	p.gravity = Vector2(0.0, 0.0)
	var kind = str(env_dict().get("weather", "rain"))
	if kind == "rain":
		p.direction = Vector2(-0.34, 1.0)
		p.initial_velocity_min = 230.0
		p.initial_velocity_max = 300.0
		p.scale_amount_min = 0.4
		p.scale_amount_max = 0.8
		p.lifetime = 1.1
	elif kind == "snow":
		p.direction = Vector2(0.12, 1.0)
		p.initial_velocity_min = 22.0
		p.initial_velocity_max = 44.0
		p.spread = 22.0
		p.scale_amount_min = 0.5
		p.scale_amount_max = 1.0
		p.lifetime = 5.0
	elif kind == "ash":
		p.direction = Vector2(0.1, 1.0)
		p.initial_velocity_min = 12.0
		p.initial_velocity_max = 30.0
		p.spread = 40.0
		p.lifetime = 6.0
	else:
		p.direction = Vector2(0.2, -1.0)
		p.initial_velocity_min = 8.0
		p.initial_velocity_max = 22.0
		p.spread = 50.0
		p.lifetime = 7.0
	p.emitting = true
	weather = p
	game.add_child(p)


# ---------------------------------------------------------------- per frame
func tick(delta: float, cx: float) -> void:
	## Moon, city lights, searchlights and the weather emitter: a handful of
	## sin() calls on at most 34 nodes. It costs nothing and it is the whole
	## difference between a wallpaper and a place.
	if game == null or not is_instance_valid(game):
		return
	t += delta
	if moon != null and is_instance_valid(moon):
		var e = env_dict()
		var ax = (float(e.get("moon_ax", 0.2)) - 0.5) * 2.0
		moon.position = Vector2(cx + ax * game.visible_half_w() + sin(t * 0.05) * 3.0,
				float(e.get("moon_y", -86.0)))
	for item in twinkle:
		var n = item["node"]
		if n == null or not is_instance_valid(n):
			continue
		var v = sin(t * float(item["sp"]) + float(item["ph"]))
		n.modulate.a = 0.30 + 0.55 * maxf(0.0, v)
	for b in beams:
		var bn = b["node"]
		if bn == null or not is_instance_valid(bn):
			continue
		bn.rotation = sin(t * 0.25 + float(b["ph"])) * 0.5
	if weather != null and is_instance_valid(weather):
		var py = GameData.belt_mid()
		if game.player != null and is_instance_valid(game.player):
			py = game.player.global_position.y
		weather.global_position = Vector2(cx,
				GameData.cam_y(py) - game.visible_half_h() - 10.0)
