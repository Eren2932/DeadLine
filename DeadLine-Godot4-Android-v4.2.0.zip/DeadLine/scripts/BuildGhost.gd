extends Node2D
class_name BuildGhost
## Placement preview for build mode.
##
## Shows exactly where the structure will land, whether the spot is legal, the
## footprint, the reach of a turret / tesla / mine, and the blocked rings around
## everything already standing. No more blind tapping.

var game = null
var spot = Vector2.ZERO
var active = false
var kind = "wall"


func setup(p_game) -> void:
	game = p_game
	z_index = 60
	visible = false
	set_process(true)


func show_at(world_pos: Vector2) -> void:
	active = true
	visible = true
	spot = world_pos
	queue_redraw()


func hide_ghost() -> void:
	active = false
	visible = false
	queue_redraw()


func _process(_delta: float) -> void:
	if not active or game == null:
		return
	var k = str(game.build_kind)
	if k != kind:
		kind = k
		queue_redraw()


func _draw() -> void:
	if not active or game == null or not GameData.BUILDINGS.has(kind):
		return
	var d: Dictionary = GameData.BUILDINGS[kind]
	var ok: bool = game.build_valid_at(spot) and game.can_build(kind)
	var col: Color = Color(0.35, 0.95, 0.45, 0.9) if ok else Color(1.0, 0.3, 0.28, 0.9)

	# ---- the road strip you are allowed to build on
	var left = GameData.play_left() - global_position.x
	var right = GameData.play_right() - global_position.x
	var top = GameData.BAND_TOP - global_position.y
	var bot = GameData.BAND_BOT - global_position.y
	draw_line(Vector2(left, top), Vector2(right, top), Color(1, 1, 1, 0.10), 1.0)
	draw_line(Vector2(left, bot), Vector2(right, bot), Color(1, 1, 1, 0.10), 1.0)

	# ---- rings around what is already built (where you may NOT place)
	for s in game.get_structures():
		if s == null or not is_instance_valid(s) or s.dead:
			continue
		var p: Vector2 = s.global_position - global_position
		draw_arc(p, GameData.BUILD_SPACING, 0.0, TAU, 20, Color(1.0, 0.45, 0.3, 0.20), 1.0)

	var c: Vector2 = spot - global_position

	# ---- reach of the thing being placed
	var reach = float(d.get("range", 0.0))
	if reach <= 0.0:
		reach = float(d.get("aoe", 0.0))
	if reach > 0.0:
		draw_arc(c, reach, 0.0, TAU, 40, Color(col.r, col.g, col.b, 0.45), 1.0)
		draw_circle(c, reach, Color(col.r, col.g, col.b, 0.06))

	# ---- footprint / hitbox
	var box = Rect2(c + Vector2(-8, -11), Vector2(16, 12))
	draw_rect(box, Color(col.r, col.g, col.b, 0.22), true)
	draw_rect(box, col, false, 1.0)
	draw_arc(c, GameData.BUILD_SPACING, 0.0, TAU, 24, Color(col.r, col.g, col.b, 0.35), 1.0)
	draw_line(c + Vector2(-4, 0), c + Vector2(4, 0), col, 1.0)
	draw_line(c + Vector2(0, -4), c + Vector2(0, 4), col, 1.0)
