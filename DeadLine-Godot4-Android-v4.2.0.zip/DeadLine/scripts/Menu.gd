extends Node2D
## Start screen: animated background, main menu, loadout ("equip your gear"),
## settings, how-to-play and the profile stats. This is the game's main scene.

const VERSION_LINE := "DEAD LINE v4.1  -  Godot 4"
const MENU_STAGE := "res://scripts/MenuStage.gd"

var ui: CanvasLayer
var screens: Dictionary = {}
var current = "main"

var loadout_cards: Dictionary = {}
var picker_body: VBoxContainer
var picker_title: Label
var cores_label: Label
var class_title: Label
var class_desc: Label
var class_btn: Button

var _quit_armed_at = -9999
var _toast_label: Label = null

var bg_layers: Array = []
var actors: Array = []
var scroll_x = 0.0
var stage = null            # MenuStage instance, null if it failed to build


func _ready() -> void:
	randomize()
	Engine.time_scale = 1.0
	get_tree().paused = false
	_build_background()
	_build_ui()
	_show("main")
	# Switching the language rebuilds the whole shell in place, so every label
	# and button picks up the new strings without leaving the menu.
	var _loc = UI.loc_node()
	if _loc != null and _loc.has_signal("language_changed"):
		_loc.connect("language_changed", _on_language_changed)
	Music.play("menu", 1.5)
	# The app was killed while a run was live (Android reclaiming memory in the
	# background). Drop the player straight back into it instead of pretending
	# nothing happened. consume_live() clears the flag first, so a run that fails
	# to load can never turn this into a boot loop.
	if Save.has_run() and Save.consume_live():
		call_deferred("_resume_live_run")


func _resume_live_run() -> void:
	if not is_inside_tree():
		return
	Save.pending_continue = true
	Save.pending_checkpoint = false
	get_tree().change_scene_to_file("res://Game.tscn")


func _on_language_changed() -> void:
	## Deferred on purpose. This frees the whole menu UI, and it is fired from a
	## button that lives inside that very UI - tearing the tree down while the
	## button is still emitting is exactly how the app used to die on Android.
	call_deferred("_relabel_now")


func _relabel_now() -> void:
	var keep = current
	if ui != null and is_instance_valid(ui):
		remove_child(ui)
		ui.queue_free()
	screens.clear()
	loadout_cards.clear()
	picker_body = null
	picker_title = null
	cores_label = null
	_build_ui()
	_show(keep if screens.has(keep) else "main")


# ================================================================ background
func _build_background() -> void:
	## v4.1: the start screen is a real diorama of the CURRENT location, built by
	## MenuStage from the same baked bands, the same belt geometry and the same
	## arm rig the game uses. If that script is missing or throws, we fall back
	## to the old flat strips - the menu is never allowed to be a blank screen.
	var script = load(MENU_STAGE)
	if script != null:
		var st = script.new()
		if st != null and st.has_method("build"):
			if int(st.build(self)) > 0:
				stage = st
				return
	_build_background_flat()


func _build_background_flat() -> void:
	var vp = get_viewport_rect().size
	# A full bleed plate first: no aspect ratio can ever show raw clear colour.
	var plate = ColorRect.new()
	plate.color = GameData.theme_sky_color()
	plate.size = vp * 3.0
	plate.position = -vp
	plate.z_index = -40
	add_child(plate)
	_bg_layer(Art.tex(GameData.env_path("sky")), 0.0, vp.y * 0.18, 2.0)
	_bg_layer(Art.tex(GameData.env_path("far")), 0.15, vp.y * 0.40, 1.0)
	_bg_layer(Art.tex(GameData.env_path("mid")), 0.32, vp.y * 0.46, 1.0)
	_bg_layer(Art.tex(GameData.env_path("near")), 0.55, vp.y * 0.54, 1.0)
	_bg_layer(Art.tex(GameData.env_path("fence")), 0.72, vp.y * 0.60, 1.0)
	_bg_layer(Art.tex(GameData.env_path("road")), 1.0, vp.y * 0.66, 1.0)
	_bg_layer(Art.tex(GameData.env_path("curb_near")), 1.0, vp.y * 0.86, 1.0)

	var dim = ColorRect.new()
	dim.color = Color(0.02, 0.01, 0.03, 0.5)
	dim.size = vp * 2.0
	dim.position = -vp * 0.5
	dim.z_index = 20
	add_child(dim)

	# marching crowd, scaled by depth like the real horde
	var types = ["z_walker", "z_nurse", "z_runner", "z_worker", "z_cop", "z_brute", "z_hazmat"]
	for i in range(8):
		var t = str(types[i % types.size()])
		var frames = Art.char_frames(t)
		if frames == null:
			continue
		var a = AnimatedSprite2D.new()
		a.sprite_frames = frames
		a.animation = "run" if frames.has_animation("run") else "idle"
		a.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
		a.offset = Vector2(0, Art.char_feet_offset(t))
		a.speed_scale = randf_range(0.7, 1.3)
		a.play()
		a.scale = Vector2.ONE * randf_range(1.5, 2.1)
		a.position = Vector2(randf_range(vp.x * 0.15, vp.x * 1.1), vp.y * randf_range(0.70, 0.80))
		a.z_index = 15 + i
		add_child(a)
		actors.append({"node": a, "speed": randf_range(9.0, 18.0)})


func _bg_layer(tex: Texture2D, factor: float, y: float, v_scale: float) -> void:
	if tex == null:
		return
	var holder = Node2D.new()
	holder.position.y = y
	holder.z_index = int(-30 + factor * 20.0)
	add_child(holder)
	var vp = get_viewport_rect().size
	var tile = maxf(8.0, float(tex.get_width())) * 1.4
	var tiles = int(ceil(vp.x * 2.5 / tile)) + 3
	for i in range(tiles):
		var s = Sprite2D.new()
		s.texture = tex
		s.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
		s.centered = false
		s.position = Vector2(float(i) * tile, 0.0)
		s.scale = Vector2(1.4, v_scale * 1.4)
		holder.add_child(s)
	bg_layers.append({"node": holder, "factor": factor, "width": tile})


func _process(delta: float) -> void:
	if stage != null:
		stage.update(delta)
		return
	scroll_x += delta * 12.0
	for l in bg_layers:
		var n: Node2D = l["node"]
		var w: float = float(l["width"])
		n.position.x = -w - fmod(scroll_x * float(l["factor"]), w)
	var vp = get_viewport_rect().size
	for a in actors:
		var n: AnimatedSprite2D = a["node"]
		n.position.x -= float(a["speed"]) * delta
		if n.position.x < -40.0:
			n.position.x = vp.x + randf_range(20.0, 160.0)


# ================================================================ UI
func _build_ui() -> void:
	ui = CanvasLayer.new()
	ui.layer = 5
	add_child(ui)
	screens["main"] = _screen_main()
	screens["loadout"] = _screen_loadout()
	screens["settings"] = _screen_settings()
	screens["howto"] = _screen_howto()
	screens["picker"] = _screen_picker()
	for k in screens.keys():
		var s: Control = screens[k]
		s.visible = false
		ui.add_child(s)


const PANEL_HALF := 240.0


func _screen_base() -> Control:
	var c = Control.new()
	c.set_anchors_preset(Control.PRESET_FULL_RECT)
	return c


func _panel_box(top: float, bottom: float) -> VBoxContainer:
	var p = PanelContainer.new()
	p.add_theme_stylebox_override("panel", UI.style(Color(0.06, 0.055, 0.07, 0.94),
			UI.RED_DARK, 2, 3))
	p.set_anchors_preset(Control.PRESET_FULL_RECT)
	p.anchor_left = 0.5
	p.anchor_right = 0.5
	p.offset_left = -PANEL_HALF
	p.offset_right = PANEL_HALF
	p.offset_top = top
	p.offset_bottom = bottom
	var vb = VBoxContainer.new()
	vb.add_theme_constant_override("separation", 4)
	p.add_child(vb)
	p.set_meta("body", vb)
	return vb


func _screen_main() -> Control:
	var root = _screen_base()

	var title = UI.label("DEAD LINE", 30, UI.RED, HORIZONTAL_ALIGNMENT_CENTER)
	title.add_theme_constant_override("outline_size", 6)
	title.set_anchors_preset(Control.PRESET_TOP_WIDE)
	title.offset_top = 12
	title.offset_bottom = 52
	root.add_child(title)

	var sub = UI.label("ZOMBIE FRONTIER", 10, UI.BONE, HORIZONTAL_ALIGNMENT_CENTER)
	sub.set_anchors_preset(Control.PRESET_TOP_WIDE)
	sub.offset_top = 50
	sub.offset_bottom = 64
	root.add_child(sub)

	var skull = UI.sprite_rect(Art.ui_tex("skull"), Vector2(52, 52))
	skull.set_anchors_preset(Control.PRESET_CENTER_TOP)
	skull.offset_left = -160
	skull.offset_right = -108
	skull.offset_top = 92
	skull.offset_bottom = 144
	root.add_child(skull)

	var box = VBoxContainer.new()
	box.set_anchors_preset(Control.PRESET_CENTER)
	box.offset_left = -92
	box.offset_right = 92
	box.offset_top = -46
	box.offset_bottom = 104
	box.add_theme_constant_override("separation", 5)
	root.add_child(box)

	# ---- CONTINUE: only shows up when there really is a run to come back to
	if Save.has_run():
		var cont = UI.big_button("CONTINUE", UI.GREEN)
		cont.text = UI.tr_f("CONTINUE - WAVE %d", [Save.run_wave() + 1])
		cont.pressed.connect(_continue_game)
		box.add_child(cont)
		var newrun = UI.button("NEW RUN", 11, UI.RED, 28.0)
		newrun.pressed.connect(_start_game)
		box.add_child(newrun)
	else:
		var play = UI.big_button("PLAY", UI.RED)
		play.pressed.connect(_start_game)
		box.add_child(play)

	var gear = UI.button("LOADOUT", 11, UI.GOLD, 28.0)
	gear.pressed.connect(func() -> void: _show("loadout"))
	box.add_child(gear)

	var opts = UI.button("SETTINGS", 11, UI.BLUE, 28.0)
	opts.pressed.connect(func() -> void: _show("settings"))
	box.add_child(opts)

	var howto = UI.button("HOW TO PLAY", 11, UI.DIM, 28.0)
	howto.pressed.connect(func() -> void: _show("howto"))
	box.add_child(howto)

	var quit = UI.button("QUIT", 10, UI.RED_DARK, 24.0)
	quit.pressed.connect(func() -> void: get_tree().quit())
	box.add_child(quit)

	var stats = UI.label("", 8, UI.DIM, HORIZONTAL_ALIGNMENT_CENTER)
	stats.set_anchors_preset(Control.PRESET_BOTTOM_WIDE)
	stats.offset_top = -34
	stats.offset_bottom = -6
	stats.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	stats.text = _stats_line()
	root.add_child(stats)
	root.set_meta("stats", stats)
	return root


func _screen_loadout() -> Control:
	var root = _screen_base()
	var vb = _panel_box(16.0, -16.0)
	root.add_child(vb.get_parent())

	var head = HBoxContainer.new()
	head.add_child(UI.label("EQUIP YOUR GEAR", 13, UI.RED))
	var sp = Control.new()
	sp.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	head.add_child(sp)
	cores_label = UI.label("%d CORES" % Save.cores(), 9, UI.GOLD)
	head.add_child(cores_label)
	vb.add_child(head)

	var scroll = ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	vb.add_child(scroll)
	var list = VBoxContainer.new()
	list.add_theme_constant_override("separation", 3)
	list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.add_child(list)

	list.add_child(_loadout_card("primary", "PRIMARY"))
	list.add_child(_loadout_card("sidearm", "SIDEARM"))
	list.add_child(_loadout_card("melee", "MELEE"))
	list.add_child(_loadout_card("suit", "SUIT"))
	list.add_child(_loadout_card("pet", "COMPANION"))
	list.add_child(_class_card())

	var back = UI.button("BACK", 11, UI.RED, 28.0)
	back.pressed.connect(func() -> void: _show("main"))
	vb.add_child(back)
	return root


func _class_card() -> Control:
	## Class ranks: cores spent here make the equipped suit's skill hit harder,
	## come back faster and add permanent health. This is what turns the suits
	## into classes instead of five paint jobs.
	var card = UI.panel(UI.PANEL_SOFT, Color(0.26, 0.22, 0.2))
	var col = VBoxContainer.new()
	col.add_theme_constant_override("separation", 1)
	card.add_child(col)
	class_title = UI.label("", 9, UI.GOLD)
	col.add_child(class_title)
	class_desc = UI.label("", 6, UI.DIM)
	class_desc.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	col.add_child(class_desc)
	class_btn = UI.button("RANK UP", 8, UI.GREEN, 22.0)
	class_btn.pressed.connect(_rank_up)
	col.add_child(class_btn)
	return card


func _rank_up() -> void:
	var suit = str(Save.loadout_get("suit"))
	if Save.class_rank_up(suit):
		Audio.play("levelup", -8.0)
	else:
		Audio.play("empty", -8.0)
	_refresh_class_card()
	if cores_label != null:
		cores_label.text = UI.tr_f("%d CORES", [Save.cores()])


func _refresh_class_card() -> void:
	if class_title == null:
		return
	var suit = str(Save.loadout_get("suit"))
	var info: Dictionary = GameData.SUITS.get(suit, {})
	var rank = Save.class_rank(suit)
	class_title.text = UI.tr_f("CLASS: %s   RANK %d/%d", [UI.tr_ui(str(info.get("name", suit))),
			rank, GameData.CLASS_MAX_RANK])
	class_desc.text = UI.tr_ui(str(info.get("perk", ""))) + "\n" \
			+ UI.tr_f("SKILL POWER x%.2f   COOLDOWN %.0fs   BONUS HP +%d",
			[GameData.class_power(rank), GameData.suit_ability_cd(suit, rank),
			int(GameData.class_hp_bonus(rank))])
	if rank >= GameData.CLASS_MAX_RANK:
		class_btn.text = UI.tr_ui("MAX RANK")
		class_btn.disabled = true
	else:
		var price = GameData.class_rank_price(rank + 1)
		class_btn.text = UI.tr_f("RANK UP - %d CORES", [price])
		class_btn.disabled = Save.cores() < price


func _loadout_card(slot: String, title: String) -> Control:
	var card = UI.panel(UI.PANEL_SOFT, Color(0.24, 0.22, 0.26))
	var row = HBoxContainer.new()
	row.add_theme_constant_override("separation", 4)
	card.add_child(row)

	var icon = UI.sprite_rect(null, Vector2(42, 30))
	row.add_child(icon)

	var col = VBoxContainer.new()
	col.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	col.add_theme_constant_override("separation", 0)
	col.add_child(UI.label(title, 7, UI.DIM))
	var name_l = UI.label("", 9, UI.BONE)
	col.add_child(name_l)
	var desc_l = UI.label("", 6, UI.DIM)
	desc_l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	col.add_child(desc_l)
	row.add_child(col)

	var change = UI.button("CHANGE", 8, UI.GOLD, 22.0)
	change.custom_minimum_size = Vector2(54, 22)
	change.pressed.connect(func() -> void: _open_picker(slot, title))
	row.add_child(change)

	loadout_cards[slot] = {"icon": icon, "name": name_l, "desc": desc_l}
	return card


func _slot_items(slot: String) -> Array:
	match slot:
		"primary":
			return GameData.LOADOUT_PRIMARY_ORDER
		"sidearm":
			return GameData.LOADOUT_SIDEARM_ORDER
		"melee":
			return GameData.LOADOUT_MELEE_ORDER
		"suit":
			return GameData.SUIT_ORDER
		"pet":
			return GameData.PET_ORDER
		_:
			return []


func _item_price(slot: String, id: String) -> int:
	match slot:
		"primary":
			return int(GameData.LOADOUT_PRIMARY.get(id, 0))
		"sidearm":
			return int(GameData.LOADOUT_SIDEARM.get(id, 0))
		"melee":
			return int(GameData.LOADOUT_MELEE.get(id, 0))
		"suit":
			return int(GameData.SUITS.get(id, {}).get("price", 0))
		"pet":
			return int(GameData.PETS.get(id, {}).get("price", 0))
		_:
			return 0


func _stats_line() -> String:
	## Footer under the main menu. The stat line is translated, the version tag
	## is deliberately left as-is in every language.
	return UI.tr_f("BEST WAVE %d   KILLS %d   CORES %d", [Save.stat("best_wave"),
			Save.stat("total_kills"), Save.cores()]) + "\n" + VERSION_LINE


func _item_name(slot: String, id: String) -> String:
	if id == "none":
		return UI.tr_ui("None")
	if slot == "suit":
		return UI.tr_ui(str(GameData.SUITS.get(id, {}).get("name", id)))
	if slot == "pet":
		return UI.tr_ui(str(GameData.PETS.get(id, {}).get("name", id)))
	return UI.tr_ui(str(GameData.WEAPONS.get(id, {}).get("name", id)))


func _item_desc(slot: String, id: String) -> String:
	if id == "none":
		return UI.tr_ui("Empty slot.")
	if slot == "suit":
		var s: Dictionary = GameData.SUITS.get(id, {})
		return UI.tr_f("%s  (HP %+d, SPD x%.2f, ARM %d%%)", [UI.tr_ui(str(s.get("desc", ""))),
				int(s.get("hp", 0)), float(s.get("speed", 1.0)), int(float(s.get("armor", 0.0)) * 100.0)])
	if slot == "pet":
		return UI.tr_ui(str(GameData.PETS.get(id, {}).get("desc", "")))
	var w: Dictionary = GameData.WEAPONS.get(id, {})
	return UI.tr_f("DMG %d  RATE %.1f  %s", [int(w.get("dmg", 0)), float(w.get("rate", 1.0)),
			UI.tr_ui(str(w.get("desc", "")))])


func _item_tex(slot: String, id: String) -> Texture2D:
	if id == "none":
		return null
	if slot == "suit" or slot == "pet":
		var frames = Art.char_frames(id)
		if frames != null and frames.has_animation("pose"):
			return frames.get_frame_texture("pose", 0)
		if frames != null and frames.has_animation("idle"):
			return frames.get_frame_texture("idle", 0)
		return null
	return Art.weapon_tex(id)


func _screen_picker() -> Control:
	var root = _screen_base()
	var vb = _panel_box(16.0, -16.0)
	root.add_child(vb.get_parent())
	picker_title = UI.label("SELECT", 13, UI.RED)
	vb.add_child(picker_title)
	var scroll = ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	vb.add_child(scroll)
	picker_body = VBoxContainer.new()
	picker_body.add_theme_constant_override("separation", 2)
	picker_body.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.add_child(picker_body)
	var back = UI.button("BACK", 11, UI.RED, 28.0)
	back.pressed.connect(func() -> void: _show("loadout"))
	vb.add_child(back)
	return root


func _open_picker(slot: String, title: String) -> void:
	picker_title.text = UI.tr_f("%s  -  %d CORES", [UI.tr_ui(title), Save.cores()])
	for c in picker_body.get_children():
		c.queue_free()
	for id_v in _slot_items(slot):
		var id = str(id_v)
		var price = _item_price(slot, id)
		var owned = Save.is_unlocked(id) or price <= 0
		var equipped = Save.loadout_get(slot) == id
		var card = UI.panel(UI.PANEL_SOFT if not equipped else Color(0.12, 0.2, 0.12, 0.95),
				UI.GREEN if equipped else Color(0.24, 0.22, 0.26))
		var row = HBoxContainer.new()
		row.add_theme_constant_override("separation", 4)
		card.add_child(row)
		row.add_child(UI.sprite_rect(_item_tex(slot, id), Vector2(40, 26)))
		var col = VBoxContainer.new()
		col.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		col.add_theme_constant_override("separation", 0)
		col.add_child(UI.label(_item_name(slot, id), 9, UI.BONE if owned else UI.DIM))
		var d = UI.label(_item_desc(slot, id), 6, UI.DIM)
		d.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		col.add_child(d)
		row.add_child(col)
		var btn_text = "EQUIPPED" if equipped else ("EQUIP" if owned else UI.tr_f("%d C", [price]))
		var btn = UI.button(btn_text, 8, UI.GREEN if owned else UI.GOLD, 22.0)
		btn.custom_minimum_size = Vector2(56, 22)
		btn.disabled = equipped
		btn.pressed.connect(func() -> void:
			if Save.is_unlocked(id) or price <= 0:
				Save.loadout_set(slot, id)
				Audio.play("click", -8.0)
			elif Save.try_buy(id, price):
				Save.loadout_set(slot, id)
				Audio.play("coin", -6.0)
			else:
				Audio.play("empty", -8.0)
				picker_title.text = UI.tr_f("NOT ENOUGH CORES (%d)", [Save.cores()])
				return
			_refresh_loadout()
			_open_picker(slot, title))
		row.add_child(btn)
		picker_body.add_child(card)
	_show("picker")


func _refresh_loadout() -> void:
	for slot in loadout_cards.keys():
		var id = Save.loadout_get(str(slot))
		var c: Dictionary = loadout_cards[slot]
		(c["icon"] as TextureRect).texture = _item_tex(str(slot), id)
		(c["name"] as Label).text = _item_name(str(slot), id)
		(c["desc"] as Label).text = _item_desc(str(slot), id)
	_refresh_class_card()
	if cores_label != null:
		cores_label.text = UI.tr_f("%d CORES", [Save.cores()])


func _screen_settings() -> Control:
	var root = _screen_base()
	var vb = _panel_box(16.0, -16.0)
	root.add_child(vb.get_parent())
	vb.add_child(UI.label("SETTINGS", 13, UI.RED))
	var scroll = ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	vb.add_child(scroll)
	var sp = SettingsPanel.new()
	sp.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.add_child(sp)
	var back = UI.button("BACK", 11, UI.RED, 28.0)
	back.pressed.connect(func() -> void: _show("main"))
	vb.add_child(back)
	return root


func _screen_howto() -> Control:
	var root = _screen_base()
	var vb = _panel_box(16.0, -16.0)
	root.add_child(vb.get_parent())
	vb.add_child(UI.label("HOW TO PLAY", 13, UI.RED))
	var scroll = ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	vb.add_child(scroll)
	var body = VBoxContainer.new()
	body.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	body.add_theme_constant_override("separation", 3)
	scroll.add_child(body)
	# One entry per topic, not per visual line: a translated sentence is never
	# the same length as the English one, so the label wraps it itself.
	var lines = [
		"GOAL - survive endless waves of the dead. Every 5th wave sends a boss.",
		"SKL - your class skill. Every suit has its own, with its own cooldown. Rank it up with cores in LOADOUT.",
		"TYP - switches grenade type: frag, incendiary, shock, gas. New types unlock as the waves climb.",
		"SAVING - the run autosaves between waves, so CONTINUE picks it up exactly where you left off. From wave 15 the game also drops checkpoints you can fall back to after a death.",
		"MOVE - drag anywhere on the stick side of the screen; the stick appears under your thumb. Aim is automatic, the nearest zombie gets the lead.",
		"BUTTONS - DASH (dodge + Bulldozer damage), NADE, GUN (switch weapon), RLD (reload), BLD (build mode).",
		"BUILD - open BLD or the BUILD button between waves, pick a structure, then tap the ground. Barricades block the horde, spikes shred, sentries and tesla coils fight for you, mines wipe a whole group.",
		"SHOP - between waves you can buy weapons, ammo refills and medkits.",
		"LEVEL UP - every level offers 3 upgrade cards. Stack them into a build.",
		"CORES - earned every run, spent in LOADOUT to unlock guns, suits and pets.",
		"KEYBOARD (editor) - WASD move, E dash, Q swap, G nade, R reload, B build, 1-4 weapon slots, SPACE start wave, ESC pause.",
	]
	for l in lines:
		var lb = UI.label(str(l), 7, UI.BONE)
		lb.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		body.add_child(lb)
	var back = UI.button("BACK", 11, UI.RED, 28.0)
	back.pressed.connect(func() -> void: _show("main"))
	vb.add_child(back)
	return root


# ================================================================ flow
func _show(screen: String) -> void:
	current = screen
	for k in screens.keys():
		(screens[k] as Control).visible = str(k) == screen
	if screen == "loadout":
		_refresh_loadout()
	if screen == "main":
		var stats: Label = (screens["main"] as Control).get_meta("stats")
		stats.text = _stats_line()
	Audio.play("ui", -12.0)


func _start_game() -> void:
	## A brand new run: the old autosave is dropped on purpose, so "CONTINUE"
	## can never resurrect a run the player walked away from.
	Audio.play("click", -6.0)
	Save.pending_continue = false
	Save.pending_checkpoint = false
	Save.clear_run()
	get_tree().change_scene_to_file("res://Game.tscn")


func _continue_game() -> void:
	Audio.play("click", -6.0)
	Save.pending_continue = true
	Save.pending_checkpoint = false
	get_tree().change_scene_to_file("res://Game.tscn")


func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST:
		_on_back_request()


func _back_target() -> String:
	if current == "picker":
		return "loadout"
	return "main"


func _on_back_request() -> void:
	## In a sub screen: step back one level. On the main menu: one tap warns,
	## a second one within three seconds actually leaves. No more losing the app
	## to a stray edge swipe.
	if current != "main":
		_show(_back_target())
		return
	var now = Time.get_ticks_msec()
	if now - _quit_armed_at < 3000:
		Settings.flush()
		get_tree().quit()
		return
	_quit_armed_at = now
	_toast(UI.tr_ui("PRESS BACK AGAIN TO EXIT"))


func _toast(text: String) -> void:
	if ui == null or not is_instance_valid(ui):
		return
	if _toast_label != null and is_instance_valid(_toast_label):
		_toast_label.queue_free()
	var l = UI.label(text, 9, UI.GOLD, HORIZONTAL_ALIGNMENT_CENTER)
	l.set_anchors_preset(Control.PRESET_BOTTOM_WIDE)
	l.offset_top = -34.0
	l.offset_bottom = -20.0
	ui.add_child(l)
	_toast_label = l
	var tw = create_tween()
	tw.tween_interval(2.2)
	tw.tween_property(l, "modulate:a", 0.0, 0.6)
	tw.tween_callback(l.queue_free)


func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not (event as InputEventKey).echo:
		var k = (event as InputEventKey).keycode
		if k == KEY_ESCAPE and current != "main":
			_show("main")
		elif k == KEY_ENTER and current == "main":
			if Save.has_run():
				_continue_game()
			else:
				_start_game()
