extends Node
## Streaming soundtrack with crossfades.
##
## menu / boss are the short generated loops from tools/music.py.
## The battle theme is a full-length song (~4 min). A song that long cannot
## just restart from zero: the hard seam is very audible. So it gets a tail
## crossfade instead - a few seconds before the end a second player starts
## the same stream from the top and the two are faded through each other,
## which makes the loop sound like the song simply keeps going.

const TRACKS := {
	"menu": {
		"path": "res://music/menu.ogg",
	},
	"battle": {
		"path": "res://music/pixel_assault.ogg",
		# if the custom track is missing, fall back to the generated loop
		"fallback": "res://music/battle.ogg",
		"loop_xfade": 6.0,
		"loop_from": 0.0,
	},
	"boss": {
		"path": "res://music/boss.ogg",
	},
}

const QUIET_DB: float = -40.0

var _players: Array[AudioStreamPlayer] = []
var _active: int = 0
var _cur: String = ""
var _streams: Dictionary = {}
var _looping: bool = false
var _tw: Tween = null


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	for i in range(2):
		var p: AudioStreamPlayer = AudioStreamPlayer.new()
		p.bus = "Music"
		p.volume_db = QUIET_DB
		p.process_mode = Node.PROCESS_MODE_ALWAYS
		add_child(p)
		_players.append(p)


func _cfg(key: String) -> Dictionary:
	var v = TRACKS.get(key, {})
	if v is Dictionary:
		return v as Dictionary
	# tolerate a plain path string, just in case TRACKS is edited by hand
	return {"path": str(v)}


func _prepare(s: AudioStream) -> void:
	## Engine-side looping stays ON as a safety net: if the crossfade ever
	## misses its window (heavy frame spike), the track wraps instead of
	## going silent. The fading-out player is stopped anyway.
	if s is AudioStreamWAV:
		var wav: AudioStreamWAV = s as AudioStreamWAV
		wav.loop_mode = AudioStreamWAV.LOOP_FORWARD
		wav.loop_begin = 0
		wav.loop_end = -1
	elif "loop" in s:
		# ogg vorbis and mp3 streams both expose a plain bool "loop"
		s.set("loop", true)


func _stream(key: String) -> AudioStream:
	if _streams.has(key):
		return _streams[key]
	var cfg: Dictionary = _cfg(key)
	var s: AudioStream = null
	for candidate in [str(cfg.get("path", "")), str(cfg.get("fallback", ""))]:
		var path: String = str(candidate)
		if path.is_empty():
			continue
		if not ResourceLoader.exists(path):
			continue
		s = load(path) as AudioStream
		if s != null:
			break
	if s == null:
		push_warning("Music: missing track for key " + key)
	else:
		_prepare(s)
	_streams[key] = s
	return s


func current() -> String:
	return _cur


func _kill_tween() -> void:
	if _tw != null and _tw.is_valid():
		_tw.kill()
	_tw = null


func play(key: String, fade: float = 1.2) -> void:
	if key == _cur:
		return
	var s: AudioStream = _stream(key)
	if s == null:
		return
	_cur = key
	_looping = false
	_kill_tween()
	var old: AudioStreamPlayer = _players[_active]
	_active = 1 - _active
	var nxt: AudioStreamPlayer = _players[_active]
	nxt.stream = s
	nxt.volume_db = QUIET_DB
	nxt.play()
	var t: float = maxf(0.05, fade)
	_tw = create_tween()
	_tw.set_parallel(true)
	_tw.tween_property(nxt, "volume_db", 0.0, t)
	if old.playing:
		_tw.tween_property(old, "volume_db", QUIET_DB, t)
		_tw.chain().tween_callback(old.stop)


func stop(fade: float = 0.8) -> void:
	_cur = ""
	_looping = false
	_kill_tween()
	for p in _players:
		if p.playing:
			var tw: Tween = create_tween()
			tw.tween_property(p, "volume_db", QUIET_DB, maxf(0.05, fade))
			tw.tween_callback(p.stop)


func duck(amount_db: float = -10.0, time: float = 0.25) -> void:
	## Short volume dip, used for big explosions / boss spawns.
	## Skipped mid-loop-crossfade so it cannot fight the loop tween.
	if _looping:
		return
	var p: AudioStreamPlayer = _players[_active]
	if not p.playing:
		return
	var tw: Tween = create_tween()
	tw.tween_property(p, "volume_db", amount_db, time * 0.3)
	tw.tween_property(p, "volume_db", 0.0, time)


func _process(_delta: float) -> void:
	if _cur.is_empty() or _looping:
		return
	var cfg: Dictionary = _cfg(_cur)
	var xfade: float = float(cfg.get("loop_xfade", 0.0))
	if xfade <= 0.0:
		return
	var p: AudioStreamPlayer = _players[_active]
	if not p.playing or p.stream == null:
		return
	var total: float = p.stream.get_length()
	if total <= xfade + 1.0:
		return
	# compensate mix buffer + output latency so the fade starts on time
	var pos: float = p.get_playback_position() \
		+ AudioServer.get_time_since_last_mix() - AudioServer.get_output_latency()
	if pos >= total - xfade:
		_loop_crossfade(xfade, float(cfg.get("loop_from", 0.0)))


func _loop_crossfade(xfade: float, from_pos: float) -> void:
	var old: AudioStreamPlayer = _players[_active]
	var s: AudioStream = old.stream
	if s == null:
		return
	_looping = true
	_kill_tween()
	_active = 1 - _active
	var nxt: AudioStreamPlayer = _players[_active]
	nxt.stream = s
	nxt.volume_db = QUIET_DB
	nxt.play(maxf(0.0, from_pos))
	_tw = create_tween()
	_tw.set_parallel(true)
	_tw.tween_property(nxt, "volume_db", 0.0, xfade)
	_tw.tween_property(old, "volume_db", QUIET_DB, xfade)
	_tw.chain().tween_callback(_loop_done.bind(old))


func _loop_done(old: AudioStreamPlayer) -> void:
	if old != null and is_instance_valid(old):
		old.stop()
	_looping = false
