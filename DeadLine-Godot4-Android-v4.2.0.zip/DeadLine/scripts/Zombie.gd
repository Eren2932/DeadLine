extends CharacterBody2D
class_name Zombie
## One walker. Handles pathing along the band, attacking the player and the
## defence line, burning / chilling status, elites and boss scaling.
##
## v2.0: two-layer armour (percentage + flat) that weapon armour-piercing eats
## into, real aggro on player structures (melee AND ranged), boss stats driven
## by their own curve, and a distance based level-of-detail so a 70 body horde
## still runs on a cheap phone.

var game = null
var type = "z_walker"
var d: Dictionary = {}

var hp = 20.0
var max_hp = 20.0
var speed = 30.0
var dmg = 8.0
var rate = 1.0
var cash = 5
var xp = 2
var radius = 6.0
var body_h = 22.0
var base_scale: float = 1.0
var behavior = "walk"
var armor = 0.0
var armor_flat = 0.0
var elite = ""
var is_boss = false
var dead = false

var atk_cd = 0.0
var spit_cd = 1.5
var burn_time = 0.0
var burn_dps = 0.0
var chill_time = 0.0
var stun = 0.0
var gait_var = 1.0                 # per-zombie cadence so crowds never march in step
var knock_vel = Vector2.ZERO
var flash = 0.0
var base_tint = Color(1, 1, 1)
var blood_col = Color(0.62, 0.07, 0.09)
var target_struct = null
var retarget_cd = 0.0
var lane_y = 0.0
var far = false
var lod_skip = false
var swing_anim = 0.0               # seconds left of the attack animation
# ---- v4.1 boss / elite spine
var hit_cap = 0.0                  # max damage a SINGLE hit may deal (0 = no cap)
var phase = 0                      # rage phases already entered
var rage_guard = 0.0               # short damage-reduction window on a phase flip
var slam_cd = 3.0                  # boss ground slam
var is_champion = false            # buffed mini-boss on a normal wave

var spr: AnimatedSprite2D
var shadow: Sprite2D
var bar_bg: ColorRect
var bar_fg: ColorRect


func setup(p_game, p_type: String, hp_mul: float = 1.0, speed_mul: float = 1.0,
		elite_id: String = "", boss: bool = false, flat_armor: float = 0.0,
		dmg_mul: float = 1.0, boss_hp: float = 6.0, boss_dmg: float = 1.6,
		boss_flat: float = 0.0) -> void:
	game = p_game
	type = p_type
	d = GameData.ZOMBIES.get(type, GameData.ZOMBIES["z_walker"])
	behavior = str(d.get("behavior", "walk"))
	radius = float(d.get("radius", 6.0))
	armor = float(d.get("armor", 0.0))
	armor_flat = float(d.get("armor_flat", 0.0)) + maxf(0.0, flat_armor)
	cash = int(d.get("cash", 5))
	xp = int(d.get("xp", 2))
	dmg = float(d.get("dmg", 8.0)) * dmg_mul
	rate = float(d.get("rate", 1.0))
	speed = float(d.get("speed", 30.0)) * speed_mul
	max_hp = float(d.get("hp", 20.0)) * hp_mul
	is_boss = boss
	elite = elite_id

	if elite != "" and GameData.ELITES.has(elite):
		var e: Dictionary = GameData.ELITES[elite]
		max_hp *= float(e.get("hp", 1.0)) * GameData.elite_power_mul(_wave())
		speed *= float(e.get("speed", 1.0))
		armor = clampf(armor + float(e.get("armor", 0.0)), 0.0, 0.75)
		armor_flat += float(e.get("armor_flat", 0.0))
		cash = int(round(float(cash) * float(e.get("cash", 1.0))))
		xp = int(round(float(xp) * 1.5))
		var tint: Color = e.get("tint", Color(1, 1, 1))
		base_tint = tint
	if is_boss:
		max_hp *= maxf(1.0, boss_hp)
		dmg *= maxf(1.0, boss_dmg)
		armor = clampf(armor + 0.15, 0.0, 0.75)
		armor_flat += maxf(0.0, boss_flat)
		cash *= 8
		xp *= 8
		radius *= 1.4
	if is_champion:
		# mini-boss: a real wall on a normal wave, without the boss health bar
		max_hp *= 3.2
		dmg *= 1.35
		armor = clampf(armor + 0.10, 0.0, 0.75)
		cash *= 4
		xp *= 4
	hp = max_hp
	# ---- damage caps. A single hit can never delete a boss health bar, so the
	# fight always has a shape: burst gets you in, sustained DPS finishes it.
	if is_boss:
		hit_cap = max_hp * GameData.boss_hit_cap(_wave()) / maxf(0.35, Settings.diff_boss())
	elif is_champion:
		hit_cap = max_hp * 0.22
	elif elite != "":
		hit_cap = max_hp * GameData.elite_hit_cap()

	collision_layer = 2
	collision_mask = 2 | 4
	motion_mode = CharacterBody2D.MOTION_MODE_FLOATING

	var shape = CollisionShape2D.new()
	var circle = CircleShape2D.new()
	circle.radius = radius
	shape.shape = circle
	shape.position = Vector2(0, -radius - 2.0)
	add_child(shape)

	shadow = Sprite2D.new()
	shadow.texture = Art.fx_tex("smoke")
	shadow.modulate = Color(0, 0, 0, 0.28)
	shadow.scale = Vector2(0.9, 0.35) * (1.6 if is_boss else 1.0)
	shadow.z_index = -1
	add_child(shadow)

	spr = AnimatedSprite2D.new()
	spr.sprite_frames = Art.char_frames(type)
	spr.offset = Vector2(0, Art.char_feet_offset(type))
	spr.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	# The rig ships a real 8 frame walk cycle under the "run" name. The old code
	# looked for "walk", never found it and fell back to the 2 frame idle strip,
	# which is exactly why the horde used to slide around like cardboard.
	spr.animation = "run" if spr.sprite_frames.has_animation("run") else "idle"
	spr.play()
	# every corpse starts on a different foot at a slightly different cadence,
	# so a pack reads as a crowd instead of a chorus line
	gait_var = randf_range(0.88, 1.14)
	var fcount = spr.sprite_frames.get_frame_count(spr.animation)
	if fcount > 1:
		spr.frame = randi() % fcount
	spr.frame_progress = randf()
	add_child(spr)

	var info: Dictionary = Art.char_info(type)
	body_h = float(info.get("feet", 34)) * 0.82
	if is_boss:
		base_scale = 1.45
	elif elite != "":
		base_scale = 1.12
	scale = Vector2.ONE * base_scale * GameData.scale_at(global_position.y)
	spr.modulate = base_tint

	if is_boss or elite != "":
		bar_bg = ColorRect.new()
		bar_bg.color = Color(0, 0, 0, 0.65)
		bar_bg.size = Vector2(24, 3)
		bar_bg.position = Vector2(-12, -body_h - 12.0)
		add_child(bar_bg)
		bar_fg = ColorRect.new()
		bar_fg.color = Color(0.85, 0.2, 0.2) if is_boss else base_tint
		bar_fg.size = Vector2(24, 3)
		bar_fg.position = bar_bg.position
		add_child(bar_fg)

	z_index = 4
	lane_y = global_position.y
	retarget_cd = randf_range(0.0, 0.4)


func _wave() -> int:
	return int(game.wave) if game != null else 1


func hit_center() -> Vector2:
	return global_position + Vector2(0, -body_h * 0.55)


func head_pos() -> Vector2:
	return global_position + Vector2(0, -body_h * 0.95)


func threat() -> float:
	## Used by the auto-aim and by grenades to pick something worth hitting.
	var t = hp
	if is_boss:
		t *= 3.0
	elif elite != "":
		t *= 1.6
	return t


# ------------------------------------------------------------------ status
func ignite(seconds: float) -> void:
	## v4.1: burn is a chip effect again, not a boss melter. Bosses and elites
	## shrug most of it off, which is why Incendiary is a single card now.
	var resist = 0.35 if is_boss else (0.7 if elite != "" or is_champion else 1.0)
	burn_time = maxf(burn_time, seconds * resist)
	burn_dps = maxf(burn_dps, (4.0 + max_hp * 0.008) * resist)


func chill(seconds: float) -> void:
	## Slow got weaker across the board and bosses are barely slowed at all.
	var resist = 0.35 if is_boss else (0.65 if elite != "" or is_champion else 1.0)
	chill_time = maxf(chill_time, seconds * resist)


func stagger(seconds: float) -> void:
	## Nothing chain-stunlocks a boss any more: 0.35 s ceiling, halved.
	if is_boss:
		stun = maxf(stun, minf(seconds, 0.35) * 0.5)
		return
	if is_champion or elite != "":
		stun = maxf(stun, seconds * 0.6)
		return
	stun = maxf(stun, seconds)


# ------------------------------------------------------------------ damage
func take_percent_wound(frac: float, boss_frac: float, at: Vector2 = Vector2.ZERO,
		knock: Vector2 = Vector2.ZERO) -> void:
	## A wound measured in percent of the target's own health bar. Used by
	## mines. Deliberately bypasses armour, armour pierce and the boss per-hit
	## cap: the whole point is that the number is exactly what it says.
	if dead:
		return
	var pos = at if at != Vector2.ZERO else hit_center()
	var f = clampf(boss_frac if is_boss else frac, 0.0, 1.0)
	var final = max_hp * f
	if final <= 0.0:
		return
	hp -= final
	flash = 0.10
	if not is_boss:
		knock_vel += knock * (0.5 if elite != "" else 1.0) * 0.35
	else:
		knock_vel += knock * 0.06
	if not far:
		game.fx.damage_number(pos, final, true)
		game.fx.blood_mist(pos, (pos - global_position).normalized() * -1.0, 70.0, blood_col)
	if hp <= 0.0:
		die()


func take_hit(amount: float, knock: Vector2 = Vector2.ZERO, crit: bool = false,
		at: Vector2 = Vector2.ZERO, ap: float = 0.0) -> void:
	if dead:
		return
	var pos = at if at != Vector2.ZERO else hit_center()
	var head = pos.y < global_position.y - body_h * 0.78
	var pen = clampf(ap, 0.0, 1.0)
	var pct = clampf(armor * (1.0 - pen), 0.0, 0.80)
	var flat = maxf(0.0, armor_flat * (1.0 - pen))
	# Armour never fully negates a hit: 12% always gets through.
	var final = maxf(amount * (1.0 - pct) - flat, amount * 0.12)
	var pl = game.player if game != null else null
	if pl != null and is_instance_valid(pl):
		if is_boss or is_champion or elite != "":
			final *= pl.elite_dmg_mul()
		if head:
			final *= pl.head_dmg_mul()
	elif head:
		final *= 1.5
	if rage_guard > 0.0:
		# the phase flip is a telegraph, not a free damage window
		final *= 0.5
	if hit_cap > 0.0:
		final = minf(final, hit_cap)
	hp -= final
	flash = 0.10
	if not is_boss:
		knock_vel += knock * (0.5 if elite != "" else 1.0) * 0.35
	else:
		knock_vel += knock * 0.06
	if not far:
		game.fx.damage_number(pos, final, crit or head)
		game.fx.blood_mist(pos, (pos - global_position).normalized() * -1.0, 70.0, blood_col)
		if head and Settings.gore_level() > 0:
			game.fx.blood(pos, 4, blood_col, Vector2(0, -1), 90.0)
		Audio.play("headshot" if head else "hit", -14.0, randf_range(0.92, 1.12), 0.03)
	if hp <= 0.0:
		die(final)


func die(overkill: float = 0.0) -> void:
	if dead:
		return
	dead = true
	collision_layer = 0
	collision_mask = 0
	set_physics_process(false)
	if bar_bg != null:
		bar_bg.visible = false
		bar_fg.visible = false
	game.on_zombie_died(self, overkill)

	var gib = overkill > max_hp * 0.55 or overkill > 70.0
	if gib and Settings.gore_level() > 0 and not far:
		game.fx.gibs(hit_center(), 7, blood_col)
		game.fx.blood(hit_center(), 12, blood_col, Vector2.UP, 130.0)
		game.fx.splat(global_position)
		Audio.play("splat", -6.0, randf_range(0.9, 1.1))
		queue_free()
		return
	if gib:
		queue_free()
		return

	if Settings.gore_level() > 0 and not far:
		game.fx.splat(global_position)
		Audio.play("splat", -12.0, randf_range(0.95, 1.15))
	# ---- corpse: play the real death strip, let the body carry the momentum of
	# the shot that killed it, settle, then fade. Non-looping animations stop on
	# their last frame in Godot, so the heap stays a heap.
	if spr.sprite_frames.has_animation("death"):
		spr.animation = "death"
		spr.frame = 0
		spr.speed_scale = randf_range(0.9, 1.15)
		spr.play()
	if shadow != null:
		var stw = create_tween()
		stw.tween_property(shadow, "scale", Vector2(1.25, 0.55), 0.35)
	var slide = knock_vel * 0.09
	slide.x = clampf(slide.x, -14.0, 14.0)
	var tw = create_tween()
	tw.set_parallel(true)
	tw.tween_property(spr, "position", spr.position + slide + Vector2(0.0, 1.0), 0.4)			.set_ease(Tween.EASE_OUT).set_trans(Tween.TRANS_CUBIC)
	# Corpses are cheap but not free: when the field is packed they clear out
	# fast so a mid-fight pile never costs frames.
	var linger = 1.9 if game.get_zombies().size() < 40 else 0.7
	var seq = create_tween()
	seq.tween_interval(linger)
	seq.tween_property(spr, "modulate:a", 0.0, 0.9)
	if shadow != null:
		seq.parallel().tween_property(shadow, "modulate:a", 0.0, 0.9)
	seq.tween_callback(queue_free)


# ------------------------------------------------------------------ think
func _physics_process(delta: float) -> void:
	if dead or game == null:
		return

	# ---- level of detail: far away bodies think at half rate and skip effects
	far = absf(global_position.x - game.cam_center_x) > game.lod_dist
	if far:
		lod_skip = not lod_skip
		if lod_skip:
			return
		delta *= 2.0

	if flash > 0.0:
		flash -= delta
		spr.modulate = Color(1.6, 1.2, 1.2) if flash > 0.0 else base_tint
	if burn_time > 0.0:
		burn_time -= delta
		hp -= burn_dps * delta
		if not far and randf() < 0.35:
			game.fx.flame_puff(hit_center() + Vector2(randf_range(-3, 3), 0))
		spr.modulate = Color(1.5, 0.85, 0.5)
		if hp <= 0.0:
			die(10.0)
			return
	if chill_time > 0.0:
		chill_time -= delta
		spr.modulate = Color(0.7, 0.85, 1.3)
	if bar_fg != null:
		bar_fg.size.x = 24.0 * clampf(hp / max_hp, 0.0, 1.0)
	if rage_guard > 0.0:
		rage_guard -= delta
	if is_boss and phase < GameData.BOSS_PHASES.size():
		if hp <= max_hp * float(GameData.BOSS_PHASES[phase]):
			_enter_rage()

	var pl = game.player
	if pl == null or not is_instance_valid(pl):
		return

	var chill_factor = 0.86 if is_boss else (0.78 if elite != "" or is_champion else 0.70)
	var spd = speed * (chill_factor if chill_time > 0.0 else 1.0)
	if stun > 0.0:
		stun -= delta
		spd = 0.0

	var to_player: Vector2 = pl.global_position - global_position
	var dir_x: float = signf(to_player.x) if absf(to_player.x) > 2.0 else 0.0
	var want = Vector2(dir_x * spd, clampf(to_player.y - global_position.y, -1.0, 1.0) * spd * 0.35)

	atk_cd = maxf(0.0, atk_cd - delta)
	spit_cd = maxf(0.0, spit_cd - delta)
	retarget_cd = maxf(0.0, retarget_cd - delta)

	# ---- pick something of ours to chew on (cached, not every frame)
	if retarget_cd <= 0.0:
		retarget_cd = 0.35
		target_struct = game.structure_in_front(global_position, dir_x, 20.0)
		if target_struct == null and behavior != "spit":
			target_struct = game.nearest_structure(global_position, 34.0)
	if target_struct != null and (not is_instance_valid(target_struct) or target_struct.dead):
		target_struct = null

	if target_struct != null and absf(to_player.x) > 20.0:
		want.x = 0.0
		if atk_cd <= 0.0:
			atk_cd = 1.0 / maxf(0.2, rate)
			target_struct.take_structure_damage(dmg * 1.4, "melee")
			if not far:
				Audio.play("thud", -16.0, randf_range(0.9, 1.15), 0.05)
			_swing()

	# ---- behaviours
	match behavior:
		"spit":
			_tick_spit(pl, to_player, want)
			if spit_cd > 2.0:
				want.x *= 0.2
		"boom":
			if absf(to_player.x) < 22.0 and absf(to_player.y - global_position.y) < 18.0:
				_self_destruct()
				return
		"tank":
			if is_boss:
				slam_cd = maxf(0.0, slam_cd - delta)
				var near = absf(to_player.x) < 74.0 and absf(to_player.y - global_position.y) < 30.0
				if slam_cd <= 0.0 and near:
					_slam()
			if atk_cd <= 0.0 and absf(to_player.x) < 26.0:
				atk_cd = 1.0 / maxf(0.2, rate)
				pl.take_damage(dmg, global_position)
				game.shake(2.5)
				_swing()
		_:
			pass

	if behavior != "boom" and atk_cd <= 0.0 and absf(to_player.x) < radius + 12.0 \
			and absf(to_player.y - global_position.y) < GameData.hit_slack(global_position.y) * 2.0:
		atk_cd = 1.0 / maxf(0.2, rate)
		pl.take_damage(dmg, global_position)
		_swing()

	knock_vel = knock_vel.lerp(Vector2.ZERO, clampf(delta * 6.0, 0.0, 1.0))
	velocity = GameData.move_vec(want + knock_vel)
	move_and_slide()
	global_position.y = GameData.clamp_y(global_position.y)
	# perspective, applied after the clamp so it always matches the drawn curb
	scale = Vector2.ONE * base_scale * GameData.scale_at(global_position.y)
	global_position.x = clampf(global_position.x, -60.0, GameData.ARENA_W + 60.0)
	if dir_x != 0.0:
		spr.flip_h = dir_x < 0.0
	if shadow != null:
		shadow.position = Vector2(0, -1)
	_tick_anim(delta)


func _tick_anim(delta: float) -> void:
	## Legs move at the speed the body actually travels, and a swing plays the
	## real attack strip instead of just nudging the sprite sideways.
	if spr == null or spr.sprite_frames == null:
		return
	swing_anim = maxf(0.0, swing_anim - delta)
	var want = "run"
	if swing_anim > 0.0 and spr.sprite_frames.has_animation("attack"):
		want = "attack"
	elif velocity.length() < 4.0 and spr.sprite_frames.has_animation("idle"):
		want = "idle"
	elif not spr.sprite_frames.has_animation("run"):
		want = "idle"
	if spr.animation != want:
		spr.animation = want
		spr.frame = 0
		spr.play()
	if want == "run":
		# 8 frames at 12 fps carry the body 17.6 px, so this is the exact
		# scale that keeps the planted foot glued to the road: no sliding,
		# no moonwalk.
		spr.speed_scale = clampf(velocity.length() / 26.4, 0.42, 2.4) * gait_var
	elif want == "attack":
		spr.speed_scale = 1.0
	else:
		spr.speed_scale = 1.0


func _tick_spit(pl, to_player: Vector2, _want: Vector2) -> void:
	## Ranged zombies now shell the defence line too, not only the survivor.
	if spit_cd > 0.0:
		return
	var from = hit_center()
	var aim_at: Vector2 = pl.global_position + Vector2(0, -8)
	var acid_dmg = dmg * 0.9
	var st = game.nearest_structure(global_position, 150.0)
	if st != null and randf() < 0.55:
		aim_at = st.aggro_point()
		acid_dmg = dmg * 0.75
	var dist = absf(aim_at.x - from.x)
	if dist > 190.0 or dist < 34.0:
		return
	spit_cd = randf_range(2.4, 3.6)
	var aim: Vector2 = (aim_at - from).normalized()
	game.spawn_bullet(from, aim, {
		"kind": "acid", "tex": "acid", "dmg": acid_dmg, "speed": 165.0,
		"life": 2.4, "from_player": false, "knock": 0.0, "spin": 6.0,
		"dmg_type": "acid",
		"color": Color(0.75, 1.0, 0.5),
	})
	if not far:
		Audio.play("flame", -18.0, 1.5, 0.1)


func _enter_rage() -> void:
	## Boss rage phase: faster, harder, tougher, and it screams in fresh bodies.
	## This is what turns a boss from a health bar into a fight.
	phase += 1
	rage_guard = 1.1
	speed *= 1.17
	dmg *= 1.14
	rate *= 1.10
	armor = clampf(armor + 0.05, 0.0, 0.80)
	burn_time = 0.0
	chill_time = 0.0
	stun = 0.0
	knock_vel = Vector2.ZERO
	base_tint = Color(1.0, 0.72 - 0.12 * float(phase), 0.62 - 0.14 * float(phase))
	spr.modulate = base_tint
	if game != null:
		game.shake(6.0)
		game.hitstop(0.07)
		game.fx.explosion(hit_center(), 0.9)
		game.spawn_boss_adds(self, GameData.boss_adds(_wave()))
		if game.hud != null:
			game.hud.flash_banner(UI.tr_f("BOSS ENRAGED  -  PHASE %d", [phase + 1]), UI.RED)
	Audio.play("roar", -4.0, randf_range(0.9, 1.05))
	var tw = create_tween()
	tw.tween_property(self, "scale", scale * 1.06, 0.12)
	tw.tween_property(self, "scale", scale, 0.18)


func _slam() -> void:
	## Ground pound: a real reason to move instead of standing and holding fire.
	slam_cd = randf_range(4.2, 6.0) - 0.4 * float(phase)
	_swing()
	if game == null:
		return
	var at = global_position + Vector2(0, -4)
	game.explode(at, 74.0 + 6.0 * float(phase), dmg * 1.25, false, 1.6)
	game.kick(Vector2(0, 1), 4.0)
	Audio.play("thud", -4.0, 0.8)
	for z in game.zombies_near(at, 90.0):
		if z != self and not z.dead:
			z.stagger(0.4)


func _swing() -> void:
	swing_anim = 0.34
	if far:
		return
	var tw = create_tween()
	tw.tween_property(spr, "position", Vector2(4.0 * (-1.0 if spr.flip_h else 1.0), 0), 0.07)
	tw.tween_property(spr, "position", Vector2.ZERO, 0.12)


func _self_destruct() -> void:
	dead = true
	game.on_zombie_died(self, 0.0)
	game.explode(hit_center(), 52.0, dmg * 2.0, false, 1.1)
	game.fx.gibs(hit_center(), 9, Color(0.5, 0.75, 0.25))
	queue_free()
