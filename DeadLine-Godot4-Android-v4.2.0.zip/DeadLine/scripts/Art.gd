extends Node
## Loads the generated pixel-art manifest and builds cached textures / SpriteFrames.

const MANIFEST_PATH := "res://art/manifest.json"
const MANIFEST := preload("res://scripts/ArtManifest.gd")

var data: Dictionary = {}
var _tex_cache: Dictionary = {}
var _frames_cache: Dictionary = {}

const ANIM_FPS := {"idle": 4.5, "run": 12.0, "attack": 14.0, "death": 10.0, "pose": 4.0}
const ANIM_LOOP := {"idle": true, "run": true, "attack": false, "death": false, "pose": true}


func _ready() -> void:
	# Primary source: the generated GDScript constant (always present in exports).
	data = MANIFEST.DATA.duplicate(true)
	# Optional override: if art/manifest.json exists (editor / regenerated art), prefer it.
	if FileAccess.file_exists(MANIFEST_PATH):
		var f = FileAccess.open(MANIFEST_PATH, FileAccess.READ)
		if f != null:
			var parsed: Variant = JSON.parse_string(f.get_as_text())
			f.close()
			if typeof(parsed) == TYPE_DICTIONARY:
				data = parsed
	if data.is_empty():
		push_error("Art: manifest data is empty - regenerate art with tools/build.py")


func tex(path: String) -> Texture2D:
	if path.is_empty():
		return null
	if _tex_cache.has(path):
		return _tex_cache[path]
	var t: Texture2D = null
	if ResourceLoader.exists(path):
		t = load(path) as Texture2D
	else:
		push_warning("Art: missing texture " + path)
	_tex_cache[path] = t
	return t


func fx_tex(key: String) -> Texture2D:
	var d: Dictionary = data.get("fx", {})
	var v: Variant = d.get(key, "")
	if typeof(v) == TYPE_STRING:
		return tex(str(v))
	return null


func fx_list(key: String) -> Array:
	var d: Dictionary = data.get("fx", {})
	var v: Variant = d.get(key, [])
	var out: Array = []
	if typeof(v) == TYPE_ARRAY:
		for p in v:
			var t = tex(str(p))
			if t != null:
				out.append(t)
	return out


func fx_strip(key: String) -> Array:
	## Returns an Array[Texture2D] of frames for a strip entry (e.g. explosion, muzzle).
	var d: Dictionary = data.get("fx", {})
	var v: Variant = d.get(key, {})
	if typeof(v) != TYPE_DICTIONARY:
		return []
	return _slice(str(v.get("path", "")), int(v.get("frames", 1)), int(v.get("fw", 1)), int(v.get("fh", 1)))


func ui_tex(key: String) -> Texture2D:
	var d: Dictionary = data.get("ui", {})
	var v: Variant = d.get(key, "")
	if typeof(v) == TYPE_STRING:
		return tex(str(v))
	return null


func env_tex(key: String) -> Texture2D:
	var d: Dictionary = data.get("env", {})
	var v: Variant = d.get(key, "")
	if typeof(v) == TYPE_STRING:
		return tex(str(v))
	return null


func env_props() -> Array:
	var d: Dictionary = data.get("env", {})
	var v: Variant = d.get("props", [])
	var out: Array = []
	if typeof(v) == TYPE_ARRAY:
		for p in v:
			var t = tex(str(p))
			if t != null:
				out.append(t)
	return out


func weapon_info(id: String) -> Dictionary:
	var d: Dictionary = data.get("weapons", {})
	var v: Variant = d.get(id, {})
	if typeof(v) == TYPE_DICTIONARY:
		return v
	return {}


func weapon_tex(id: String) -> Texture2D:
	var info = weapon_info(id)
	return tex(str(info.get("path", "")))


func build_tex(kind: String, key: String = "path") -> Texture2D:
	var d: Dictionary = data.get("build", {})
	var v: Variant = d.get(kind, {})
	if typeof(v) == TYPE_DICTIONARY and v.has(key):
		return tex(str(v[key]))
	return null


func build_states(kind: String) -> Array:
	var d: Dictionary = data.get("build", {})
	var v: Variant = d.get(kind, {})
	var out: Array = []
	if typeof(v) == TYPE_DICTIONARY:
		var st: Variant = v.get("states", [])
		if typeof(st) == TYPE_ARRAY:
			for p in st:
				var t = tex(str(p))
				if t != null:
					out.append(t)
	return out


func char_info(name: String) -> Dictionary:
	var d: Dictionary = data.get("chars", {})
	var v: Variant = d.get(name, {})
	if typeof(v) == TYPE_DICTIONARY:
		return v
	return {}


func char_frames(name: String) -> SpriteFrames:
	if _frames_cache.has(name):
		return _frames_cache[name]
	var info = char_info(name)
	var sf = SpriteFrames.new()
	# SpriteFrames always ships with a "default" animation; remove after adding ours.
	for anim_name in ["idle", "run", "attack", "death", "pose"]:
		if not info.has(anim_name):
			continue
		var e: Dictionary = info[anim_name]
		var textures = _slice(str(e.get("path", "")), int(e.get("frames", 1)),
				int(e.get("fw", 1)), int(e.get("fh", 1)))
		if textures.is_empty():
			continue
		if not sf.has_animation(anim_name):
			sf.add_animation(anim_name)
		sf.set_animation_speed(anim_name, float(ANIM_FPS.get(anim_name, 8.0)))
		sf.set_animation_loop(anim_name, bool(ANIM_LOOP.get(anim_name, true)))
		for t in textures:
			sf.add_frame(anim_name, t)
	if not sf.has_animation("idle") and sf.has_animation("run"):
		sf.add_animation("idle")
		sf.set_animation_speed("idle", 5.0)
		sf.add_frame("idle", sf.get_frame_texture("run", 0))
	if not sf.has_animation("attack") and sf.has_animation("run"):
		sf.add_animation("attack")
		sf.set_animation_speed("attack", 12.0)
		sf.set_animation_loop("attack", false)
		sf.add_frame("attack", sf.get_frame_texture("run", 0))
	if sf.has_animation("default"):
		sf.remove_animation("default")
	_frames_cache[name] = sf
	return sf


func char_hands(name: String, anim_name: String) -> Array:
	## Per-frame hand (weapon grip) position for one animation, in image pixel
	## coordinates. Empty when the character has no rigged hands.
	var info = char_info(name)
	var v: Variant = info.get("hands", {})
	if typeof(v) != TYPE_DICTIONARY:
		return []
	var hands: Dictionary = v
	var lst: Variant = hands.get(anim_name, [])
	if typeof(lst) != TYPE_ARRAY:
		return []
	var out: Array = []
	for e in lst:
		if typeof(e) == TYPE_ARRAY and (e as Array).size() >= 2:
			out.append(Vector2(float(e[0]), float(e[1])))
	return out


func char_shoulders(name: String, anim_name: String) -> Array:
	## Per-frame shoulder pivot for one animation, in image pixel coordinates.
	## The v3 rig draws the survivors WITHOUT arms and hangs both arms off this
	## point, which is what welds the weapon to the hands.
	var info = char_info(name)
	var v: Variant = info.get("shoulders", {})
	if typeof(v) != TYPE_DICTIONARY:
		return []
	var sh: Dictionary = v
	var lst: Variant = sh.get(anim_name, [])
	if typeof(lst) != TYPE_ARRAY:
		return []
	var out: Array = []
	for e in lst:
		if typeof(e) == TYPE_ARRAY and (e as Array).size() >= 2:
			out.append(Vector2(float(e[0]), float(e[1])))
	return out


func char_has_rig(name: String) -> bool:
	## True when this character ships the armless body + limb pieces.
	var info = char_info(name)
	return typeof(info.get("limbs", null)) == TYPE_DICTIONARY \
			and not (info["limbs"] as Dictionary).is_empty()


func char_limb(name: String, key: String) -> Dictionary:
	## One arm piece: {"tex": Texture2D, "pivot": Vector2, "len": float}.
	## Keys: upper_front, fore_front, upper_back, fore_back.
	var info = char_info(name)
	var v: Variant = info.get("limbs", {})
	if typeof(v) != TYPE_DICTIONARY:
		return {}
	var limbs: Dictionary = v
	var e: Variant = limbs.get(key, null)
	if typeof(e) != TYPE_DICTIONARY:
		return {}
	var d: Dictionary = e
	var piv: Array = d.get("pivot", [0.0, 0.0])
	return {
		"tex": tex(str(d.get("path", ""))),
		"pivot": Vector2(float(piv[0]), float(piv[1])),
		"len": float(d.get("len", 5.0)),
	}


func char_arm_lengths(name: String) -> Vector2:
	## x = upper arm length, y = forearm length (pixels).
	var info = char_info(name)
	return Vector2(float(info.get("upper_len", 5.2)), float(info.get("fore_len", 5.6)))


func char_feet_offset(name: String) -> float:
	## Y offset for a centered sprite so that the character's feet sit on the node origin.
	var info = char_info(name)
	var h = float(info.get("h", 32))
	var feet = float(info.get("feet", h - 2))
	return h * 0.5 - feet


func weapon_point(id: String, key: String) -> Vector2:
	## Anchor point of a weapon sprite in weapon pixels: "grip" (rear hand),
	## "fore" (support hand) or "muzzle". Same table Player.gd rigs the arms
	## onto, exposed so the menu diorama can hold a gun exactly like the game.
	var info = weapon_info(id)
	var v: Variant = info.get(key, null)
	if typeof(v) == TYPE_ARRAY and (v as Array).size() >= 2:
		return Vector2(float(v[0]), float(v[1]))
	match key:
		"muzzle":
			return Vector2(maxf(4.0, float(info.get("w", 18)) - 2.0), 5.0)
		"fore":
			return Vector2(10.0, 7.0)
		_:
			return Vector2(4.0, 7.0)


func _slice(path: String, frames: int, fw: int, fh: int) -> Array:
	var out: Array = []
	var sheet = tex(path)
	if sheet == null or frames <= 0 or fw <= 0 or fh <= 0:
		return out
	for i in range(frames):
		var at = AtlasTexture.new()
		at.atlas = sheet
		at.region = Rect2(i * fw, 0, fw, fh)
		at.filter_clip = true
		out.append(at)
	return out
