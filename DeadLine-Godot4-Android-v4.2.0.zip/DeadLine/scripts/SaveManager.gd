extends Node
## Persistent profile: records, meta currency (Cores), unlocks, loadout and settings.
## Stored as JSON in user://deadline_save.json - safe to delete, regenerates with defaults.

const PATH := "user://deadline_save.json"
const RUN_PATH := "user://deadline_run.json"
const RUN_TMP := "user://deadline_run.tmp"
const VERSION := 3

const DEFAULT_LOADOUT := {
	"primary": "ak47",
	"sidearm": "pistol",
	"melee": "none",
	"suit": "player_soldier",
	"pet": "none",
}

var data: Dictionary = {
	"version": VERSION,
	"best_wave": 0,
	"best_kills": 0,
	"best_score": 0,
	"total_kills": 0,
	"total_cores": 0,
	"cores": 0,
	"runs": 0,
	"settings": {},
	"unlocked": ["ak47", "shotgun", "pistol", "none", "player_soldier"],
	"loadout": DEFAULT_LOADOUT.duplicate(true),
	"seen_intro": false,
	"class_rank": {},
}

## Set by the menu right before the game scene loads: tells Game to restore the
## autosave instead of starting a fresh run.
var pending_continue = false
## Set when the player takes the checkpoint offer on the death screen.
var pending_checkpoint = false
var _run_cache: Dictionary = {}
var _run_loaded = false


func _ready() -> void:
	load_game()


func load_game() -> void:
	if not FileAccess.file_exists(PATH):
		return
	var f = FileAccess.open(PATH, FileAccess.READ)
	if f == null:
		return
	var txt = f.get_as_text()
	f.close()
	var parsed: Variant = JSON.parse_string(txt)
	if typeof(parsed) != TYPE_DICTIONARY:
		return
	for k in (parsed as Dictionary).keys():
		if data.has(k):
			data[k] = (parsed as Dictionary)[k]
	# make sure nested structures always have every key
	var lo: Dictionary = data.get("loadout", {}) if typeof(data.get("loadout")) == TYPE_DICTIONARY else {}
	for k in DEFAULT_LOADOUT.keys():
		if not lo.has(k):
			lo[k] = DEFAULT_LOADOUT[k]
	data["loadout"] = lo
	if typeof(data.get("unlocked")) != TYPE_ARRAY:
		data["unlocked"] = ["ak47", "shotgun", "pistol", "none", "player_soldier"]
	data["version"] = VERSION


func save_game() -> void:
	## Temp file + swap, same as the run save. A phone that dies mid-write can
	## cost you the last change, never the whole profile (and with it every
	## setting, unlock and language choice).
	var tmp = PATH + ".tmp"
	var f = FileAccess.open(tmp, FileAccess.WRITE)
	if f == null:
		push_warning("Save: cannot write " + tmp)
		return
	f.store_string(JSON.stringify(data))
	f.close()
	var da = DirAccess.open("user://")
	if da == null:
		return
	if da.file_exists(PATH.get_file()):
		da.remove(PATH.get_file())
	da.rename(tmp.get_file(), PATH.get_file())


# ------------------------------------------------------------------ records
func report_run(wave: int, kills: int, score: int = 0) -> int:
	## Records a finished run and returns how many Cores were earned.
	data["runs"] = int(data.get("runs", 0)) + 1
	data["total_kills"] = int(data.get("total_kills", 0)) + kills
	if wave > int(data.get("best_wave", 0)):
		data["best_wave"] = wave
	if kills > int(data.get("best_kills", 0)):
		data["best_kills"] = kills
	if score > int(data.get("best_score", 0)):
		data["best_score"] = score
	var earned: int = GameData.cores_for_run(wave, kills)
	add_cores(earned)
	save_game()
	return earned


func stat(key: String) -> int:
	return int(data.get(key, 0))


# ------------------------------------------------------------------ cores / unlocks
func cores() -> int:
	return int(data.get("cores", 0))


func add_cores(amount: int) -> void:
	data["cores"] = maxi(0, cores() + amount)
	data["total_cores"] = int(data.get("total_cores", 0)) + maxi(0, amount)
	save_game()


func spend_cores(amount: int) -> bool:
	if cores() < amount:
		return false
	data["cores"] = cores() - amount
	save_game()
	return true


func unlocked_list() -> Array:
	var v: Variant = data.get("unlocked", [])
	return v if typeof(v) == TYPE_ARRAY else []


func is_unlocked(id: String) -> bool:
	if id == "none":
		return true
	return unlocked_list().has(id)


func unlock(id: String) -> void:
	var list = unlocked_list()
	if not list.has(id):
		list.append(id)
	data["unlocked"] = list
	save_game()


func try_buy(id: String, price: int) -> bool:
	if is_unlocked(id):
		return true
	if price <= 0:
		unlock(id)
		return true
	if not spend_cores(price):
		return false
	unlock(id)
	return true


# ------------------------------------------------------------------ loadout
func loadout() -> Dictionary:
	var v: Variant = data.get("loadout", {})
	if typeof(v) != TYPE_DICTIONARY:
		v = DEFAULT_LOADOUT.duplicate(true)
		data["loadout"] = v
	return v


func loadout_get(slot: String) -> String:
	return str(loadout().get(slot, DEFAULT_LOADOUT.get(slot, "none")))


func loadout_set(slot: String, id: String) -> void:
	var lo = loadout()
	lo[slot] = id
	data["loadout"] = lo
	save_game()


# ------------------------------------------------------------------ legacy flags
func get_flag(key: String, def: bool = true) -> bool:
	return bool(data.get(key, def))


func set_flag(key: String, value: bool) -> void:
	data[key] = value
	save_game()


# ------------------------------------------------------------------ class ranks
func class_rank(suit: String) -> int:
	var v: Variant = data.get("class_rank", {})
	if typeof(v) != TYPE_DICTIONARY:
		return 0
	return clampi(int((v as Dictionary).get(suit, 0)), 0, GameData.CLASS_MAX_RANK)


func class_rank_up(suit: String) -> bool:
	## Spends cores to push a class one rank up. Returns false when it is maxed
	## or the player cannot afford it, so the UI can just say no.
	var rank = class_rank(suit)
	if rank >= GameData.CLASS_MAX_RANK:
		return false
	var price = GameData.class_rank_price(rank + 1)
	if price < 0 or not spend_cores(price):
		return false
	var v: Variant = data.get("class_rank", {})
	var ranks: Dictionary = v if typeof(v) == TYPE_DICTIONARY else {}
	ranks[suit] = rank + 1
	data["class_rank"] = ranks
	save_game()
	return true


# ------------------------------------------------------------------ run saves
## A run save is a separate file from the profile on purpose: a corrupt or
## outdated run can be dropped without ever touching records, cores or unlocks.
func _run_file() -> Dictionary:
	if _run_loaded:
		return _run_cache
	_run_loaded = true
	_run_cache = {}
	if not FileAccess.file_exists(RUN_PATH):
		return _run_cache
	var f = FileAccess.open(RUN_PATH, FileAccess.READ)
	if f == null:
		return _run_cache
	var txt = f.get_as_text()
	f.close()
	var parsed: Variant = JSON.parse_string(txt)
	if typeof(parsed) != TYPE_DICTIONARY:
		return _run_cache
	var d: Dictionary = parsed
	if int(d.get("version", 0)) != GameData.RUN_SAVE_VERSION:
		# a save from an older build: drop it instead of loading half a state
		return _run_cache
	_run_cache = d
	return _run_cache


func _write_run(d: Dictionary) -> void:
	## Written to a temp file first, then swapped in. A phone that dies mid write
	## can never leave a half written run behind.
	var f = FileAccess.open(RUN_TMP, FileAccess.WRITE)
	if f == null:
		push_warning("Save: cannot write " + RUN_TMP)
		return
	f.store_string(JSON.stringify(d))
	f.close()
	var da = DirAccess.open("user://")
	if da != null:
		if da.file_exists(RUN_PATH):
			da.remove(RUN_PATH)
		da.rename(RUN_TMP, RUN_PATH)
	_run_cache = d
	_run_loaded = true


func set_run_live(v: bool) -> void:
	## "live" means: the player was inside this run when the process went away.
	## Used to come straight back into the game after Android kills a
	## backgrounded app, instead of dumping them on the main menu.
	var d = _run_file()
	if d.is_empty():
		return
	d["live"] = v
	_write_run(d)


func run_live() -> bool:
	return bool(_run_file().get("live", false))


func consume_live() -> bool:
	## Reads the flag and clears it in the same breath, so a run that somehow
	## fails to load can never turn into a boot loop.
	var live = run_live()
	if live:
		set_run_live(false)
	return live


func has_run() -> bool:
	var d = _run_file()
	return not d.is_empty() and int(d.get("wave", 0)) > 0


func run_data() -> Dictionary:
	return _run_file()


func run_wave() -> int:
	return int(_run_file().get("wave", 0))


func run_score() -> int:
	return int(_run_file().get("score", 0))


func run_suit() -> String:
	var pl: Variant = _run_file().get("player", {})
	if typeof(pl) != TYPE_DICTIONARY:
		return "player_soldier"
	return str((pl as Dictionary).get("suit", "player_soldier"))


func save_run(state: Dictionary) -> void:
	## Autosave between waves. Carries the previous checkpoint forward unless
	## this very save is a new one.
	var d = state.duplicate(true)
	d["version"] = GameData.RUN_SAVE_VERSION
	d["saved_at"] = int(Time.get_unix_time_from_system())
	if not d.has("checkpoint"):
		var old = _run_file()
		if old.has("checkpoint"):
			d["checkpoint"] = old["checkpoint"]
	_write_run(d)


func save_checkpoint(state: Dictionary) -> void:
	## Drops a fallback snapshot (wave 15, 20, 25 ...) inside the run save.
	var d = state.duplicate(true)
	d["version"] = GameData.RUN_SAVE_VERSION
	d["saved_at"] = int(Time.get_unix_time_from_system())
	d["checkpoint"] = state.duplicate(true)
	_write_run(d)


func has_checkpoint() -> bool:
	var v: Variant = _run_file().get("checkpoint", null)
	return typeof(v) == TYPE_DICTIONARY and int((v as Dictionary).get("wave", 0)) > 0


func checkpoint_data() -> Dictionary:
	var v: Variant = _run_file().get("checkpoint", null)
	return v if typeof(v) == TYPE_DICTIONARY else {}


func checkpoint_wave() -> int:
	return int(checkpoint_data().get("wave", 0))


func clear_run(keep_checkpoint: bool = false) -> void:
	## Called when a run really ends. Keeping the checkpoint lets the death
	## screen still offer a fallback right after the wipe.
	if keep_checkpoint and has_checkpoint():
		var cp = checkpoint_data().duplicate(true)
		_write_run({
			"version": GameData.RUN_SAVE_VERSION,
			"wave": 0,
			"checkpoint": cp,
			"saved_at": int(Time.get_unix_time_from_system()),
		})
		return
	_run_cache = {}
	_run_loaded = true
	var da = DirAccess.open("user://")
	if da != null and da.file_exists(RUN_PATH):
		da.remove(RUN_PATH)
