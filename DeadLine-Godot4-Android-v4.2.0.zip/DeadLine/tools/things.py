import math, random
from core import *

STEEL = (108, 112, 124, 255)
STEEL_D = (62, 66, 78, 255)
WOOD = (122, 76, 44, 255)
POLY = (54, 56, 62, 255)

def gun(L=18, H=11, body=POLY, barrel=STEEL, stock=None, mag=3, scope=False,
        drum=False, tube=False, muzzle_w=0, foregrip=False, accent=None, heavy=False):
    """Side-view gun facing right, drawn to HUMAN SCALE.

    The old generator built 30 px monsters for a 38 px tall survivor - a 1.4 m
    assault rifle. Every length here is measured against the rig instead:
    38 px = 1.8 m, so an AK at L=18 is a believable 0.85 m.

    Returns (img, muzzle_xy, grip_xy, fore_xy) where
        grip = trigger hand (rear), fore = support hand (front).
    Both are what the engine welds the arms to, so they must always sit on
    actual drawn metal.
    """
    im = new(L + 2, H)
    cy = H // 2
    x0 = 1                       # back of the stock
    rx0 = x0 + 2                 # receiver start
    rx1 = rx0 + max(4, int(round(L * 0.45)))   # receiver end / barrel start
    bx1 = L                      # muzzle
    th = 2 if heavy else 1       # barrel thickness

    # receiver
    rect(im, rx0, cy - 1, rx1, cy + 1, body)
    rect(im, rx0, cy - 1, rx1, cy - 1, light(body, 0.22))
    rect(im, rx0, cy + 1, rx1, cy + 1, dark(body, 0.25))
    # barrel
    rect(im, rx1, cy - th + 1, bx1, cy, barrel)
    if muzzle_w:
        rect(im, bx1 - max(1, muzzle_w // 2), cy - 1, bx1, cy + 1, STEEL_D)
    if tube:
        rect(im, rx1 - 2, cy - 2, bx1 - 1, cy - 2, dark(barrel, 0.1))
    if drum:
        disc(im, rx0 + 3, cy + 3, 2.4, STEEL_D)
        px(im, rx0 + 3, cy + 3, dark(STEEL_D, 0.35))
    if mag:
        rect(im, rx0 + 3, cy + 2, rx0 + 3 + max(0, min(2, mag // 3)), cy + 3, dark(body, 0.2))
    # trigger grip (the rear hand sits here)
    rect(im, rx0 + 1, cy + 2, rx0 + 2, cy + 4, dark(body, 0.38))
    px(im, rx0 + 2, cy + 4, dark(body, 0.5))
    if stock:
        rect(im, x0, cy - 1, rx0, cy + 2, stock)
        rect(im, x0, cy - 1, rx0, cy - 1, light(stock, 0.2))
    if scope:
        rect(im, rx0 + 2, cy - 3, rx0 + 6, cy - 2, STEEL_D)
        px(im, rx0 + 6, cy - 3, (150, 220, 255, 255))
    fore_x = min(bx1 - 1, rx1 - 1)
    if foregrip:
        rect(im, fore_x, cy + 2, fore_x, cy + 3, dark(body, 0.4))
    if accent:
        rect(im, rx0 + 1, cy, rx0 + 3, cy, accent)
    volumize(im, 0.2, 0.24)
    outline(im)
    return im, (bx1, cy), (rx0 + 2, cy + 2), (fore_x, cy + 2)

def chainsaw():
    im = new(22, 11)
    rect(im, 1, 3, 8, 7, (168, 32, 30, 255))
    rect(im, 1, 3, 8, 3, (214, 66, 60, 255))
    rect(im, 3, 1, 6, 2, (60, 60, 66, 255))
    rect(im, 8, 4, 20, 6, STEEL_D)
    for x in range(9, 21, 2):
        px(im, x, 3, (222, 226, 235, 255))
        px(im, x + 1, 7, (222, 226, 235, 255))
    volumize(im, 0.2, 0.2); outline(im)
    return im, (20, 5), (4, 7), (8, 6)

def katana():
    im = new(24, 10)
    rect(im, 1, 5, 5, 6, (48, 40, 44, 255))
    rect(im, 6, 4, 6, 7, (198, 160, 60, 255))
    rect(im, 7, 5, 22, 5, (226, 232, 244, 255))
    rect(im, 7, 6, 20, 6, (150, 160, 180, 255))
    volumize(im, 0.25, 0.2); outline(im)
    return im, (22, 5), (3, 6), (6, 6)

def turret_parts():
    base = new(20, 14)
    rect(base, 2, 8, 17, 12, (74, 78, 86, 255))
    rect(base, 2, 8, 17, 8, (110, 116, 126, 255))
    rect(base, 4, 5, 15, 8, (58, 62, 70, 255))
    rect(base, 7, 3, 12, 5, (86, 92, 100, 255))
    volumize(base); outline(base)
    gunp = new(22, 10)
    rect(gunp, 2, 3, 12, 7, (60, 64, 72, 255))
    rect(gunp, 12, 4, 20, 5, STEEL)
    rect(gunp, 12, 5, 20, 6, STEEL_D)
    rect(gunp, 4, 1, 9, 2, (44, 48, 54, 255))
    volumize(gunp); outline(gunp)
    return base, gunp

def barricade(dmg=0):
    im = new(22, 24)
    c = (146, 150, 158, 255)
    rect(im, 2, 6, 19, 22, c)
    rect(im, 2, 6, 19, 7, light(c, 0.25))
    for i in range(0, 18, 6):
        rect(im, 3 + i, 8, 6 + i, 11, (226, 200, 60, 255))
        rect(im, 3 + i, 12, 6 + i, 15, (36, 34, 38, 255))
    rect(im, 2, 20, 19, 22, dark(c, 0.3))
    rnd = random.Random(dmg + 3)
    for _ in range(dmg * 22):
        x = rnd.randint(2, 19); y = rnd.randint(6, 22)
        px(im, x, y, (0, 0, 0, 0) if rnd.random() < 0.5 else dark(c, 0.5))
    volumize(im); outline(im)
    return im

def sandbag():
    im = new(22, 16)
    c = (146, 132, 96, 255)
    for row, y in enumerate((11, 6)):
        for i in range(3 - row):
            x = 2 + i * 6 + row * 3
            rect(im, x, y, x + 5, y + 4, c if (i + row) % 2 == 0 else dark(c, 0.12))
    volumize(im); outline(im)
    return im

def spikes():
    im = new(24, 14)
    for i in range(4):
        x = 2 + i * 5
        for k in range(5):
            rect(im, x + k, 13 - (4 - abs(k - 2)) * 2, x + k, 13, (206, 210, 220, 255))
    rect(im, 1, 12, 22, 13, (70, 66, 62, 255))
    volumize(im); outline(im)
    return im

def tesla():
    im = new(18, 26)
    rect(im, 6, 14, 11, 24, (72, 68, 78, 255))
    disc(im, 8, 9, 5, (150, 156, 170, 255))
    disc(im, 8, 9, 3, (96, 210, 255, 255))
    disc(im, 8, 9, 1, (240, 255, 255, 255))
    volumize(im); outline(im)
    return im

def mine():
    im = new(14, 8)
    rect(im, 2, 4, 11, 6, (86, 92, 72, 255))
    rect(im, 5, 2, 8, 3, (200, 60, 50, 255))
    volumize(im); outline(im)
    return im

def crate():
    im = new(20, 18)
    c = (132, 92, 52, 255)
    rect(im, 2, 3, 17, 16, c)
    rect(im, 2, 3, 17, 4, light(c, 0.25))
    rect(im, 2, 9, 17, 10, dark(c, 0.25))
    limb(im, 3, 4, 16, 15, 1, dark(c, 0.3))
    volumize(im); outline(im)
    return im

def barrel_prop():
    im = new(16, 20)
    c = (168, 62, 46, 255)
    rect(im, 3, 2, 12, 18, c)
    rect(im, 3, 2, 12, 3, light(c, 0.3))
    rect(im, 3, 7, 12, 8, dark(c, 0.3))
    rect(im, 3, 13, 12, 14, dark(c, 0.3))
    volumize(im); outline(im)
    return im

def gravestone():
    im = new(16, 20)
    c = (128, 128, 134, 255)
    rect(im, 3, 5, 12, 19, c)
    disc(im, 7, 6, 4, c)
    rect(im, 6, 9, 9, 10, dark(c, 0.35))
    rect(im, 7, 8, 8, 13, dark(c, 0.35))
    volumize(im); outline(im)
    return im


def crossbow():
    """Side view tactical crossbow. Real silhouette: stock, rail, limbs, string.
    Returns (img, muzzle, grip, fore) like gun()."""
    im = new(20, 13)
    cy = 6
    rect(im, 3, cy - 1, 15, cy + 1, POLY)                  # rail / body
    rect(im, 3, cy - 1, 15, cy - 1, light(POLY, 0.22))
    rect(im, 1, cy, 4, cy + 3, WOOD)                       # stock
    rect(im, 4, cy + 2, 6, cy + 4, dark(POLY, 0.4))        # trigger grip
    px(im, 6, cy + 4, dark(POLY, 0.5))
    rect(im, 5, cy - 3, 9, cy - 2, STEEL_D)                # scope
    px(im, 9, cy - 3, (150, 220, 255, 255))
    for i in range(5):                                     # limbs
        px(im, 13 + i // 2, cy - 2 - i, STEEL)
        px(im, 13 + i // 2, cy + 2 + i, STEEL)
    for i in range(4):                                     # string
        px(im, 11, cy - 4 + i, (206, 200, 186, 255))
        px(im, 11, cy + 1 + i, (206, 200, 186, 255))
    rect(im, 12, cy, 18, cy, (196, 186, 160, 255))         # bolt
    px(im, 18, cy, STEEL)
    volumize(im, 0.2, 0.24)
    outline(im)
    return im, (18, cy), (6, cy + 2), (11, cy + 2)


def vignette(w=128, h=72):
    """Soft dark corner falloff used by the HUD and the menu diorama."""
    im = new(w, h)
    cx, cy = (w - 1) / 2.0, (h - 1) / 2.0
    for y in range(h):
        for x in range(w):
            dx, dy = (x - cx) / cx, (y - cy) / cy
            d = math.sqrt(dx * dx + dy * dy) / math.sqrt(2.0)
            a = max(0.0, (d - 0.42) / 0.58) ** 1.8
            if a > 0.004:
                im.putpixel((x, y), (4, 2, 6, min(255, int(a * 232))))
    return im


def nade_icon(kind="frag"):
    """12x12 grenade icon: HUD button + shop art. One per grenade type."""
    im = new(12, 12)
    shell = {"frag": (86, 104, 70, 255), "incend": (168, 74, 34, 255),
             "shock": (64, 92, 132, 255), "gas": (128, 132, 70, 255),
             "cryo": (72, 116, 140, 255), "sticky": (96, 78, 56, 255)}.get(kind,
             (86, 104, 70, 255))
    glow = {"frag": (176, 190, 150, 255), "incend": (246, 190, 90, 255),
            "shock": (120, 226, 255, 255), "gas": (188, 226, 120, 255),
            "cryo": (196, 240, 255, 255), "sticky": (236, 176, 90, 255)}.get(kind,
            (176, 190, 150, 255))
    disc(im, 6, 7, 3.6, shell)
    rect(im, 5, 2, 7, 3, (86, 86, 92, 255))
    rect(im, 7, 1, 9, 2, (150, 152, 160, 255))
    if kind == "frag":
        for y in (5, 7, 9):
            rect(im, 3, y, 9, y, dark(shell, 0.35))
    elif kind == "incend":
        rect(im, 4, 6, 8, 8, glow)
        px(im, 6, 5, (255, 240, 180, 255))
    elif kind == "shock":
        for p in ((5, 5), (6, 6), (5, 7), (6, 8), (7, 6)):
            px(im, p[0], p[1], glow)
    elif kind == "cryo":
        for p in ((6, 5), (6, 9), (4, 7), (8, 7), (5, 6), (7, 8)):
            px(im, p[0], p[1], glow)
    elif kind == "sticky":
        for p in ((4, 5), (8, 5), (5, 9), (7, 9), (6, 6)):
            px(im, p[0], p[1], glow)
    else:
        for p in ((4, 6), (8, 6), (6, 9), (4, 9), (8, 9)):
            px(im, p[0], p[1], glow)
    volumize(im, 0.22, 0.24)
    outline(im)
    return im
