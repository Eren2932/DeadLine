# DeadLine v4.1.1 - hotfix

## Fixed
- **Крашился запуск игры (`Invalid call. Nonexistent 'String' constructor.`).**
  В Godot 4 у типа `String` есть конструкторы только от `String`, `StringName`
  и `NodePath`. Любой `String(<int/float/bool/Variant>)` падает в рантайме -
  именно это и ловил smoke test на `boot game`.
  Все 151 вызов `String(...)` в 17 скриптах заменены на встроенную функцию
  `str(...)`, которая корректно приводит к строке значение любого типа.
  Поведение для строковых аргументов не изменилось.

## Notes
- Логика, типы и геймплей не тронуты: правка чисто механическая, 1 в 1.
- `tools/check.py` и `tools/lint.py`: 0 ошибок.
