extends Node
## Global options: audio, graphics, controls, difficulty.
## Values live in Save.data["settings"] so everything persists between runs.

signal changed(key: String)

const FLUSH_DELAY := 0.35
var _dirty = false
var _flush_in = 0.0

const DEFAULTS := {
	"vol_master": 0.9,
	"vol_music": 0.65,
	"vol_sfx": 0.9,
	"music_on": true,
	"sfx_on": true,
	"zoom": 1,          # 0 far, 1 normal, 2 close
	"gore": 2,          # 0 off, 1 normal, 2 maximum
	"shake": 2,         # 0 off, 1 light, 2 full
	"dmg_numbers": true,
	"quality": 2,       # 0 low, 1 medium, 2 high
	"joy_side": 0,      # 0 left stick, 1 right stick
	"autofire": true,
	"show_fps": false,
	"vibration": true,
	"difficulty": 0,    # 0 normal, 1 hard, 2 nightmare
	"env_theme": 0,     # 0 neon, 1 blood moon, 2 toxic, 3 dead cold
	"lang": -1,         # -1 auto-detect from the OS locale, else index in Loc.LANGS
}

const ZOOM_VALUES := [1.50, 1.90, 2.35]
const ZOOM_NAMES := ["FAR", "NORMAL", "CLOSE UP"]
const GORE_NAMES := ["CLEAN", "NORMAL", "MAXIMUM"]
const SHAKE_NAMES := ["OFF", "LIGHT", "FULL"]
const SHAKE_VALUES := [0.0, 0.5, 1.0]
const QUALITY_NAMES := ["LOW", "MEDIUM", "HIGH"]
const ENV_NAMES := ["NEON DECAY", "BLOOD MOON", "TOXIC HAZE", "DEAD COLD"]
const DIFF_NAMES := ["NORMAL", "HARD", "NIGHTMARE"]
const SIDE_NAMES := ["LEFT", "RIGHT"]

const MAX_ALIVE := [34, 56, 80]
const MAX_DECALS := [24, 60, 110]
const PARTICLE_MUL := [0.45, 0.75, 1.0]

const DIFF_HP := [1.0, 1.35, 1.8]
const DIFF_SPEED := [1.0, 1.07, 1.15]
const DIFF_COUNT := [1.0, 1.18, 1.38]
const DIFF_CASH := [1.0, 1.22, 1.45]
const DIFF_XP := [1.0, 1.15, 1.3]

var d: Dictionary = {}


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	_ensure_buses()
	d = DEFAULTS.duplicate(true)
	var stored: Variant = Save.data.get("settings", {})
	if typeof(stored) == TYPE_DICTIONARY:
		for k in (stored as Dictionary).keys():
			if d.has(k):
				d[k] = (stored as Dictionary)[k]
	apply_audio()


func _ensure_buses() -> void:
	for bus_name in ["Music", "SFX"]:
		if AudioServer.get_bus_index(bus_name) < 0:
			AudioServer.add_bus()
			var i = AudioServer.bus_count - 1
			AudioServer.set_bus_name(i, bus_name)
			AudioServer.set_bus_send(i, "Master")


# ------------------------------------------------------------------ access
func num(key: String) -> float:
	return float(d.get(key, DEFAULTS.get(key, 0.0)))


func idx(key: String) -> int:
	return int(d.get(key, DEFAULTS.get(key, 0)))


func on(key: String) -> bool:
	return bool(d.get(key, DEFAULTS.get(key, true)))


func set_v(key: String, value: Variant) -> void:
	d[key] = value
	Save.data["settings"] = d.duplicate(true)
	# Dragging a volume slider used to hammer the save file dozens of times a
	# second. On a phone that is an I/O storm and a very good way to get killed
	# by the OS mid-write, so writes are coalesced and flushed once things settle
	# (and always flushed on pause / exit, so nothing is ever lost).
	_dirty = true
	_flush_in = FLUSH_DELAY
	if key.begins_with("vol_") or key == "music_on" or key == "sfx_on":
		apply_audio()
	changed.emit(key)


func flush() -> void:
	if not _dirty:
		return
	_dirty = false
	_flush_in = 0.0
	Save.save_game()


func _process(delta: float) -> void:
	if not _dirty:
		return
	_flush_in -= delta
	if _flush_in <= 0.0:
		flush()


func _notification(what: int) -> void:
	if what == NOTIFICATION_APPLICATION_PAUSED \
			or what == NOTIFICATION_WM_WINDOW_FOCUS_OUT \
			or what == NOTIFICATION_WM_CLOSE_REQUEST \
			or what == NOTIFICATION_EXIT_TREE:
		flush()


func cycle(key: String, count: int, step: int = 1) -> void:
	set_v(key, posmod(idx(key) + step, count))


func toggle(key: String) -> void:
	set_v(key, not on(key))


# ------------------------------------------------------------------ derived
func apply_audio() -> void:
	var master = AudioServer.get_bus_index("Master")
	if master >= 0:
		AudioServer.set_bus_volume_db(master, linear_to_db(clampf(num("vol_master"), 0.0001, 1.0)))
	var music = AudioServer.get_bus_index("Music")
	if music >= 0:
		AudioServer.set_bus_volume_db(music, linear_to_db(clampf(num("vol_music"), 0.0001, 1.0)))
		AudioServer.set_bus_mute(music, not on("music_on"))
	var sfx = AudioServer.get_bus_index("SFX")
	if sfx >= 0:
		AudioServer.set_bus_volume_db(sfx, linear_to_db(clampf(num("vol_sfx"), 0.0001, 1.0)))
		AudioServer.set_bus_mute(sfx, not on("sfx_on"))


func zoom() -> float:
	return float(ZOOM_VALUES[clampi(idx("zoom"), 0, ZOOM_VALUES.size() - 1)])


func gore_level() -> int:
	return clampi(idx("gore"), 0, 2)


func blood_on() -> bool:
	return gore_level() > 0


func shake_mul() -> float:
	return float(SHAKE_VALUES[clampi(idx("shake"), 0, SHAKE_VALUES.size() - 1)])


func quality() -> int:
	return clampi(idx("quality"), 0, 2)


func max_alive() -> int:
	return int(MAX_ALIVE[quality()])


func max_decals() -> int:
	return int(float(MAX_DECALS[quality()]) * (0.0 if gore_level() == 0 else (0.6 if gore_level() == 1 else 1.0)))


func particle_mul() -> float:
	return float(PARTICLE_MUL[quality()]) * (0.5 if gore_level() == 1 else 1.0)


func diff() -> int:
	return clampi(idx("difficulty"), 0, 2)


func diff_hp() -> float:
	return float(DIFF_HP[diff()])


func diff_speed() -> float:
	return float(DIFF_SPEED[diff()])


func diff_count() -> float:
	return float(DIFF_COUNT[diff()])


func diff_cash() -> float:
	return float(DIFF_CASH[diff()])


func diff_xp() -> float:
	return float(DIFF_XP[diff()])


func vibrate(ms: int) -> void:
	if on("vibration"):
		Input.vibrate_handheld(ms)
