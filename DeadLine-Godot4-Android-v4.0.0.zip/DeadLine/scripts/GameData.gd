extends Node
## All static balance data of the game plus the curves that drive wave scaling,
## economy and progression. Pure data + pure functions, no node logic.
##
## v2.0 rebalance:
##  - weapons hit harder and carry an armour-penetration stat
##  - zombie growth is tamed, bosses scale on their own (much steeper) curve
##  - armour is now two-layered: percentage + flat, never fully negating damage
##  - structures are limited, decay over waves and cost real money
##  - XP is polynomial, not exponential, so late levels stay reachable

## Share of max HP restored on every level up (the survivor's own scaling).
const LEVEL_HEAL_FRACTION := 0.22

# ---------------------------------------------------------------- WEAPONS
# kind : bullet | pellet | rocket | grenade | flame | laser | tesla | melee
# ap   : armour penetration 0..1 (share of target armour ignored)
# unlock       : first wave the gun appears in the market
# unlock_level : player level required to buy it
const WEAPONS := {
	"pistol": {
		"name": "M1911", "kind": "bullet", "dmg": 16.0, "rate": 5.0, "mag": 12, "reload": 0.85,
		"spread": 1.5, "count": 1, "speed": 640.0, "pierce": 0, "knock": 30.0, "price": 0,
		"aoe": 0.0, "range": 320.0, "auto": true, "shake": 0.6, "desc": "Reliable sidearm.",
		"reserve": -1, "ammo_price": 0, "unlock": 1, "unlock_level": 1, "ap": 0.10
	},
	"uzi": {
		"name": "Uzi", "kind": "bullet", "dmg": 10.0, "rate": 12.5, "mag": 32, "reload": 1.1,
		"spread": 7.0, "count": 1, "speed": 580.0, "pierce": 0, "knock": 16.0, "price": 600,
		"aoe": 0.0, "range": 270.0, "auto": true, "shake": 0.4, "desc": "Spray and pray.",
		"reserve": 420, "ammo_price": 70, "unlock": 1, "unlock_level": 1, "ap": 0.05
	},
	"magnum": {
		"name": ".44 Magnum", "kind": "bullet", "dmg": 58.0, "rate": 2.0, "mag": 6, "reload": 1.35,
		"spread": 1.0, "count": 1, "speed": 740.0, "pierce": 1, "knock": 120.0, "price": 900,
		"aoe": 0.0, "range": 380.0, "auto": true, "shake": 1.6, "desc": "Punches through skulls.",
		"reserve": 90, "ammo_price": 95, "unlock": 2, "unlock_level": 1, "ap": 0.45
	},
	"shotgun": {
		"name": "Pump Shotgun", "kind": "pellet", "dmg": 16.0, "rate": 1.5, "mag": 6,
		"reload": 1.9, "spread": 14.0, "count": 7, "speed": 540.0, "pierce": 0, "knock": 150.0,
		"price": 1400, "aoe": 0.0, "range": 180.0, "auto": true, "shake": 2.2,
		"desc": "Turns a crowd into paste.",
		"reserve": 96, "ammo_price": 105, "unlock": 2, "unlock_level": 1, "ap": 0.10
	},
	"katana": {
		"name": "Katana", "kind": "melee", "dmg": 78.0, "rate": 3.6, "mag": 0, "reload": 0.0,
		"spread": 0.0, "count": 1, "speed": 0.0, "pierce": 99, "knock": 130.0, "price": 1000,
		"aoe": 0.0, "range": 42.0, "auto": true, "shake": 1.2, "desc": "Clean decapitations.",
		"reserve": 0, "ammo_price": 0, "unlock": 1, "unlock_level": 1, "ap": 0.45
	},
	"chainsaw": {
		"name": "Chainsaw", "kind": "melee", "dmg": 30.0, "rate": 9.0, "mag": 0, "reload": 0.0,
		"spread": 0.0, "count": 1, "speed": 0.0, "pierce": 99, "knock": 55.0, "price": 1300,
		"aoe": 0.0, "range": 36.0, "auto": true, "shake": 0.7, "desc": "Infinite fuel, infinite gore.",
		"reserve": 0, "ammo_price": 0, "unlock": 2, "unlock_level": 1, "ap": 0.30
	},
	"mp5": {
		"name": "MP5", "kind": "bullet", "dmg": 15.0, "rate": 10.5, "mag": 30, "reload": 1.3,
		"spread": 4.0, "count": 1, "speed": 660.0, "pierce": 0, "knock": 22.0, "price": 1200,
		"aoe": 0.0, "range": 330.0, "auto": true, "shake": 0.5, "desc": "Controlled bursts.",
		"reserve": 420, "ammo_price": 95, "unlock": 3, "unlock_level": 2, "ap": 0.12
	},
	"ak47": {
		"name": "AK-47", "kind": "bullet", "dmg": 27.0, "rate": 8.0, "mag": 30, "reload": 1.6,
		"spread": 5.0, "count": 1, "speed": 720.0, "pierce": 1, "knock": 38.0, "price": 2000,
		"aoe": 0.0, "range": 370.0, "auto": true, "shake": 0.9, "desc": "Loud, brutal, perfect.",
		"reserve": 400, "ammo_price": 120, "unlock": 4, "unlock_level": 3, "ap": 0.25
	},
	"m4": {
		"name": "M4A1", "kind": "bullet", "dmg": 23.0, "rate": 11.0, "mag": 30, "reload": 1.45,
		"spread": 2.5, "count": 1, "speed": 780.0, "pierce": 1, "knock": 30.0, "price": 2500,
		"aoe": 0.0, "range": 410.0, "auto": true, "shake": 0.7, "desc": "Accurate full auto.",
		"reserve": 420, "ammo_price": 130, "unlock": 5, "unlock_level": 4, "ap": 0.22
	},
	"flamer": {
		"name": "Flamethrower", "kind": "flame", "dmg": 8.0, "rate": 18.0, "mag": 240,
		"reload": 2.4, "spread": 11.0, "count": 1, "speed": 200.0, "pierce": 99, "knock": 4.0,
		"price": 3000, "aoe": 0.0, "range": 104.0, "auto": true, "shake": 0.3,
		"desc": "Burns the whole horde.",
		"reserve": 1600, "ammo_price": 170, "unlock": 6, "unlock_level": 5, "ap": 0.15
	},
	"sniper": {
		"name": "Barrett", "kind": "bullet", "dmg": 190.0, "rate": 1.2, "mag": 5, "reload": 1.8,
		"spread": 0.3, "count": 1, "speed": 1500.0, "pierce": 4, "knock": 200.0, "price": 3400,
		"aoe": 0.0, "range": 660.0, "auto": true, "shake": 2.6, "desc": "Line them up.",
		"reserve": 80, "ammo_price": 190, "unlock": 6, "unlock_level": 6, "ap": 0.60
	},
	"lmg": {
		"name": "M249 SAW", "kind": "bullet", "dmg": 22.0, "rate": 13.0, "mag": 100,
		"reload": 3.2, "spread": 6.0, "count": 1, "speed": 740.0, "pierce": 2, "knock": 30.0,
		"price": 4000, "aoe": 0.0, "range": 390.0, "auto": true, "shake": 0.8,
		"desc": "Belt-fed wall of lead.",
		"reserve": 800, "ammo_price": 210, "unlock": 7, "unlock_level": 6, "ap": 0.25
	},
	"autoshotgun": {
		"name": "AA-12", "kind": "pellet", "dmg": 14.0, "rate": 3.4, "mag": 12, "reload": 2.2,
		"spread": 16.0, "count": 6, "speed": 540.0, "pierce": 0, "knock": 120.0, "price": 3600,
		"aoe": 0.0, "range": 190.0, "auto": true, "shake": 1.8, "desc": "Automatic meat grinder.",
		"reserve": 180, "ammo_price": 175, "unlock": 8, "unlock_level": 8, "ap": 0.15
	},
	"grenadier": {
		"name": "Grenade MGL", "kind": "grenade", "dmg": 80.0, "rate": 1.4, "mag": 6,
		"reload": 2.4, "spread": 2.0, "count": 1, "speed": 320.0, "pierce": 0, "knock": 170.0,
		"price": 4400, "aoe": 70.0, "range": 400.0, "auto": true, "shake": 2.8,
		"desc": "Lobs death over the wall.",
		"reserve": 54, "ammo_price": 280, "unlock": 9, "unlock_level": 8, "ap": 0.40
	},
	"laser": {
		"name": "Laser Rifle", "kind": "laser", "dmg": 36.0, "rate": 7.0, "mag": 60,
		"reload": 1.7, "spread": 0.8, "count": 1, "speed": 0.0, "pierce": 2, "knock": 18.0,
		"price": 4800, "aoe": 0.0, "range": 470.0, "auto": true, "shake": 0.5,
		"desc": "Instant hit beams.",
		"reserve": 520, "ammo_price": 230, "unlock": 10, "unlock_level": 9, "ap": 0.35
	},
	"rpg": {
		"name": "RPG-7", "kind": "rocket", "dmg": 130.0, "rate": 0.75, "mag": 1, "reload": 1.9,
		"spread": 0.5, "count": 1, "speed": 380.0, "pierce": 0, "knock": 230.0, "price": 5400,
		"aoe": 84.0, "range": 470.0, "auto": true, "shake": 3.6, "desc": "Body parts everywhere.",
		"reserve": 24, "ammo_price": 320, "unlock": 11, "unlock_level": 10, "ap": 0.50
	},
	"minigun": {
		"name": "Minigun", "kind": "bullet", "dmg": 17.0, "rate": 20.0, "mag": 200,
		"reload": 3.6, "spread": 8.0, "count": 1, "speed": 740.0, "pierce": 1, "knock": 22.0,
		"price": 6000, "aoe": 0.0, "range": 390.0, "auto": true, "shake": 0.6,
		"desc": "Never stops screaming.",
		"reserve": 1600, "ammo_price": 260, "unlock": 12, "unlock_level": 12, "ap": 0.20
	},
	"tesla": {
		"name": "Tesla Gun", "kind": "tesla", "dmg": 44.0, "rate": 3.4, "mag": 40, "reload": 1.9,
		"spread": 0.0, "count": 4, "speed": 0.0, "pierce": 0, "knock": 36.0, "price": 5600,
		"aoe": 0.0, "range": 250.0, "auto": true, "shake": 1.0, "desc": "Chains between bodies.",
		"reserve": 340, "ammo_price": 270, "unlock": 12, "unlock_level": 11, "ap": 0.30
	},
	"gauss": {
		"name": "Gauss Rifle", "kind": "laser", "dmg": 150.0, "rate": 2.6, "mag": 8,
		"reload": 2.0, "spread": 0.2, "count": 1, "speed": 0.0, "pierce": 3, "knock": 170.0,
		"price": 7200, "aoe": 0.0, "range": 640.0, "auto": true, "shake": 2.4,
		"desc": "Magnetic slug, punches rows.",
		"reserve": 80, "ammo_price": 300, "unlock": 13, "unlock_level": 15, "ap": 0.75
	},
	"railgun": {
		"name": "Railgun", "kind": "laser", "dmg": 420.0, "rate": 0.85, "mag": 4, "reload": 2.1,
		"spread": 0.0, "count": 1, "speed": 0.0, "pierce": 99, "knock": 240.0, "price": 9000,
		"aoe": 0.0, "range": 720.0, "auto": true, "shake": 3.4, "desc": "Deletes a whole row.",
		"reserve": 44, "ammo_price": 340, "unlock": 18, "unlock_level": 22, "ap": 0.90
	},
}

const SELL_REFUND := 0.5
## Cash cost of one full medkit and of a single grenade in the black market.
const MEDKIT_PRICE := 190
const GRENADE_PRICE := 80

const SHOP_ORDER := ["uzi", "magnum", "katana", "chainsaw", "shotgun", "mp5", "ak47", "m4",
	"flamer", "lmg", "sniper", "autoshotgun", "grenadier", "laser", "rpg", "tesla", "gauss",
	"minigun", "railgun"]

# ---------------------------------------------------------------- ZOMBIES
# behavior   : walk | run | crawl | tank | spit | boom
# armor      : percentage reduction 0..0.8
# armor_flat : flat reduction applied after the percentage
const ZOMBIES := {
	"z_walker": {"name": "Walker", "hp": 36.0, "speed": 27.0, "dmg": 8.0, "rate": 1.1,
		"cash": 4, "xp": 2, "radius": 6.0, "behavior": "walk", "weight": 40, "min_wave": 1,
		"armor": 0.0, "armor_flat": 0.0},
	"z_nurse": {"name": "Nurse", "hp": 30.0, "speed": 33.0, "dmg": 7.0, "rate": 1.3,
		"cash": 4, "xp": 2, "radius": 6.0, "behavior": "walk", "weight": 18, "min_wave": 2,
		"armor": 0.0, "armor_flat": 0.0},
	"z_worker": {"name": "Worker", "hp": 52.0, "speed": 24.0, "dmg": 11.0, "rate": 1.0,
		"cash": 6, "xp": 3, "radius": 7.0, "behavior": "walk", "weight": 20, "min_wave": 3,
		"armor": 0.05, "armor_flat": 1.0},
	"z_runner": {"name": "Runner", "hp": 28.0, "speed": 66.0, "dmg": 10.0, "rate": 1.6,
		"cash": 7, "xp": 4, "radius": 6.0, "behavior": "run", "weight": 22, "min_wave": 4,
		"armor": 0.0, "armor_flat": 0.0},
	"z_crawler": {"name": "Crawler", "hp": 22.0, "speed": 50.0, "dmg": 7.0, "rate": 1.8,
		"cash": 6, "xp": 3, "radius": 6.0, "behavior": "crawl", "weight": 16, "min_wave": 5,
		"armor": 0.0, "armor_flat": 0.0},
	"z_spitter": {"name": "Spitter", "hp": 44.0, "speed": 21.0, "dmg": 12.0, "rate": 1.9,
		"cash": 10, "xp": 6, "radius": 7.0, "behavior": "spit", "weight": 12, "min_wave": 7,
		"armor": 0.0, "armor_flat": 0.0},
	"z_bloater": {"name": "Bloater", "hp": 110.0, "speed": 18.0, "dmg": 14.0, "rate": 1.0,
		"cash": 13, "xp": 8, "radius": 9.0, "behavior": "boom", "weight": 10, "min_wave": 8,
		"armor": 0.0, "armor_flat": 2.0},
	"z_cop": {"name": "Riot Cop", "hp": 130.0, "speed": 25.0, "dmg": 17.0, "rate": 1.0,
		"cash": 12, "xp": 7, "radius": 7.0, "behavior": "walk", "weight": 13, "min_wave": 6,
		"armor": 0.30, "armor_flat": 5.0},
	"z_hazmat": {"name": "Hazmat", "hp": 96.0, "speed": 30.0, "dmg": 13.0, "rate": 1.5,
		"cash": 11, "xp": 7, "radius": 7.0, "behavior": "spit", "weight": 11, "min_wave": 9,
		"armor": 0.10, "armor_flat": 2.0, "toxic": true},
	"z_brute": {"name": "Brute", "hp": 380.0, "speed": 21.0, "dmg": 30.0, "rate": 0.9,
		"cash": 42, "xp": 26, "radius": 12.0, "behavior": "tank", "weight": 5, "min_wave": 10,
		"armor": 0.25, "armor_flat": 9.0},
}

const BOSS_TYPE := "z_brute"

# ---------------------------------------------------------------- BUILDINGS
# hp    : -1 means indestructible (mines)
# life  : how many waves the structure survives before it wears out
# limit : how many of this kind may stand on the field at once
# resist: damage type -> reduction 0..1 ("melee", "acid", "blast")
const BUILDINGS := {
	"wall": {"name": "Barricade", "price": 150, "hp": 900.0, "life": 6, "limit": 8,
		"solid": true, "resist": {"acid": 0.65, "blast": 0.35},
		"desc": "Tough roadblock. Soaks the horde."},
	"sandbag": {"name": "Sandbags", "price": 95, "hp": 520.0, "life": 5, "limit": 8,
		"solid": true, "resist": {"acid": 0.45, "blast": 0.5},
		"desc": "Cheap cover, slows them down."},
	"spikes": {"name": "Spikes", "price": 170, "hp": 260.0, "life": 4, "limit": 6,
		"dps": 34.0, "solid": false, "resist": {"acid": 0.3},
		"desc": "Shreds anything walking over."},
	"mine": {"name": "Mine", "price": 120, "hp": -1.0, "life": 8, "limit": 8,
		"dmg": 260.0, "aoe": 78.0, "solid": false, "resist": {},
		"desc": "Cannot be destroyed. One big splash."},
	"turret": {"name": "Sentry", "price": 900, "hp": 150.0, "life": 3, "limit": 3,
		"dmg": 9.0, "rate": 2.2, "range": 132.0, "knock": 6.0, "solid": false,
		"resist": {"acid": 0.15},
		"desc": "Short range auto-gun. Fragile, wears out."},
	"tesla": {"name": "Tesla Coil", "price": 1100, "hp": 120.0, "life": 3, "limit": 2,
		"dmg": 18.0, "rate": 0.9, "range": 96.0, "chain": 3, "knock": 0.0, "solid": false,
		"resist": {"acid": 0.15},
		"desc": "Zaps 3 targets. Very fragile."},
}

const BUILD_ORDER := ["wall", "sandbag", "spikes", "mine", "turret", "tesla"]

## Minimum gap between two structures, in world pixels.
const BUILD_SPACING := 20.0
## Total number of structures allowed on the field.
const BUILD_TOTAL_LIMIT := 22

# ---------------------------------------------------------------- UPGRADES
# tier: 1 common, 2 strong, 3 rare. Rare cards only start rolling later on.
const UPGRADES := [
	{"id": "dmg", "name": "Hollow Points", "desc": "+18% weapon damage", "max": 15, "tier": 1},
	{"id": "rate", "name": "Trigger Finger", "desc": "+12% fire rate", "max": 10, "tier": 1},
	{"id": "speed", "name": "Combat Boots", "desc": "+8% move speed", "max": 8, "tier": 1},
	{"id": "hp", "name": "Field Rations", "desc": "+30 max HP (and heal)", "max": 15, "tier": 1},
	{"id": "armor", "name": "Kevlar Plate", "desc": "-7% damage taken, +2 flat armour",
		"max": 8, "tier": 1},
	{"id": "reload", "name": "Quick Hands", "desc": "-15% reload time", "max": 6, "tier": 1},
	{"id": "mag", "name": "Extended Mags", "desc": "+30% magazine and reserve", "max": 6,
		"tier": 1},
	{"id": "crit", "name": "Weak Spots", "desc": "+8% crit chance", "max": 8, "tier": 1},
	{"id": "critdmg", "name": "Skull Cracker", "desc": "+50% crit damage", "max": 6, "tier": 2},
	{"id": "pierce", "name": "AP Rounds", "desc": "+1 pierce, +8% armour pierce", "max": 6,
		"tier": 2},
	{"id": "knock", "name": "Stopping Power", "desc": "+40% knockback", "max": 4, "tier": 1},
	{"id": "lifesteal", "name": "Adrenaline", "desc": "+2 HP per kill", "max": 5, "tier": 2},
	{"id": "regen", "name": "Field Medic", "desc": "+1.5 HP / sec regen", "max": 5, "tier": 2},
	{"id": "greed", "name": "Looter", "desc": "+20% cash from kills", "max": 6, "tier": 1},
	{"id": "xp", "name": "Fast Learner", "desc": "+25% XP gained", "max": 6, "tier": 1},
	{"id": "explosive", "name": "Explosive Rounds", "desc": "+12% chance of a small blast",
		"max": 5, "tier": 2},
	{"id": "burn", "name": "Incendiary", "desc": "Bullets set zombies on fire", "max": 4,
		"tier": 2},
	{"id": "dash", "name": "Sprint Boost", "desc": "-20% dash cooldown, longer dash", "max": 5,
		"tier": 1},
	{"id": "dashkill", "name": "Bulldozer", "desc": "Dash deals heavy damage", "max": 4,
		"tier": 2},
	{"id": "scav", "name": "Scavenger", "desc": "+50% pickup drop rate, +ammo drops", "max": 4,
		"tier": 1},
	{"id": "nadedmg", "name": "Demolition", "desc": "+35% grenade damage and radius", "max": 5,
		"tier": 2},
	{"id": "turretdmg", "name": "Gun Nut", "desc": "+25% structure damage", "max": 6, "tier": 1},
	{"id": "turretrate", "name": "Cooling Fins", "desc": "+20% structure fire rate", "max": 5,
		"tier": 2},
	{"id": "structhp", "name": "Reinforced Steel", "desc": "+35% structure HP", "max": 5,
		"tier": 1},
	{"id": "structlife", "name": "Field Repairs", "desc": "+1 wave of structure lifetime",
		"max": 4, "tier": 2},
	{"id": "spikedmg", "name": "Rusty Spikes", "desc": "+60% spike damage", "max": 5, "tier": 1},
	{"id": "multishot", "name": "Double Tap", "desc": "+1 projectile per shot", "max": 3,
		"tier": 3},
	{"id": "slow", "name": "Cryo Rounds", "desc": "Hits chill zombies", "max": 3, "tier": 2},
	{"id": "grenades", "name": "Bandolier", "desc": "+2 grenades per wave", "max": 5, "tier": 1},
	{"id": "dog", "name": "Loyal Dog", "desc": "A dog fights beside you", "max": 3, "tier": 2},
	{"id": "tiger", "name": "War Tiger", "desc": "A tiger mauls the horde", "max": 2, "tier": 3},
	{"id": "magnet", "name": "Magnet", "desc": "Auto-collect drops, +10% cash", "max": 2,
		"tier": 1},
]

# ---------------------------------------------------------------- ARENA
const ARENA_W := 2600.0
const BAND_TOP := -22.0   # World.BELT_TOP - the far curb
const BAND_BOT := 72.0    # World.BELT_BOT - the near curb
## The playable strip of road. Outside of it there is only fence, so the player
## and the horde are kept inside these bounds.
const EDGE_MARGIN := 56.0


func play_left() -> float:
	return EDGE_MARGIN


func play_right() -> float:
	return ARENA_W - EDGE_MARGIN


# ---------------------------------------------------------------- WAVE CURVES
func wave_count(w: int) -> int:
	## Bodies per wave. Capped so late waves get harder through quality, not
	## through an unplayable pile of walkers.
	var x = float(maxi(1, w))
	return mini(int(round(8.0 + x * 1.6 + pow(x, 1.25) * 0.4)), 70)


func wave_hp_mul(w: int) -> float:
	var x = float(maxi(1, w))
	return 1.0 + (x - 1.0) * 0.105 + pow(x, 1.85) * 0.0026


func wave_speed_mul(w: int) -> float:
	return minf(1.0 + float(maxi(1, w) - 1) * 0.012, 1.5)


func wave_armor(w: int) -> float:
	## Flat armour every zombie gains as the run goes on.
	return minf(0.5 + float(maxi(1, w)) * 0.11, 9.0)


func wave_dmg_mul(w: int) -> float:
	return 1.0 + float(maxi(1, w) - 1) * 0.035


func spawn_interval(w: int) -> float:
	return clampf(1.25 - float(maxi(1, w)) * 0.022, 0.30, 1.25)


func boss_hp_mul(w: int) -> float:
	## Bosses live on their own curve so a boss is ALWAYS far above the trash
	## of the same wave, no matter how many elites are rolling around.
	return 4.0 + float(maxi(1, w)) * 0.13


func boss_dmg_mul(w: int) -> float:
	return 1.6 + float(maxi(1, w)) * 0.012


func boss_armor(w: int) -> float:
	return 12.0 + float(maxi(1, w)) * 0.35


func is_boss_wave(w: int) -> bool:
	return w % 5 == 0


func wave_reward(w: int) -> int:
	var x = float(maxi(1, w))
	return int(round(90.0 + x * 16.0 + pow(x, 1.2) * 1.5))


func cash_wave_mul(w: int) -> float:
	## Kill money grows slowly, prices do not, so cash never turns into confetti.
	return 1.0 + float(maxi(1, w)) * 0.022


func xp_wave_mul(w: int) -> float:
	return 1.0 + float(maxi(1, w)) * 0.06


func xp_to_next(level: int) -> int:
	## Polynomial, not exponential: level 66 needs ~2k XP, not 90 million.
	var x = float(maxi(1, level))
	return int(round(20.0 + x * 14.0 + pow(x, 1.5) * 2.2))


func player_hp_bonus(level: int) -> float:
	## Max HP earned purely by levelling. Slightly super-linear so late waves,
	## where a brute swipe hits for hundreds, stay survivable.
	var x = float(maxi(1, level) - 1)
	return x * 7.0 + pow(x, 1.35) * 0.9


func player_armor_flat(level: int) -> float:
	## A little flat plating per level. Trims the chip damage from big swarms
	## without ever making the survivor immune (armour is capped elsewhere).
	return 0.35 * float(maxi(1, level) - 1)


func player_power(level: int) -> float:
	## Baseline damage scaling every weapon gets from the survivor's level, so
	## a wave 60 AK still matters even without perfect upgrade rolls.
	return 1.0 + 0.042 * float(maxi(1, level) - 1)


func elite_chance(w: int) -> float:
	if w < 6:
		return 0.0
	return minf(0.05 + float(w - 6) * 0.014, 0.32)


# ---------------------------------------------------------------- DROPS
## Pickups that fall off dead zombies during the fight.
const DROPS := [
	{"id": "medkit", "weight": 32},
	{"id": "ammo", "weight": 34},
	{"id": "cash", "weight": 22},
	{"id": "nades", "weight": 12},
]


func drop_chance(w: int) -> float:
	## Deeper waves drop more often - that is the only way ammo keeps up.
	return clampf(0.075 + float(maxi(1, w)) * 0.0028, 0.075, 0.17)


# ---------------------------------------------------------------- AIRDROPS
const CRATE_LOOT := [
	{"id": "ammo", "name": "AMMO REFILL", "weight": 30},
	{"id": "heal", "name": "MEDKIT", "weight": 24},
	{"id": "cash", "name": "CASH STASH", "weight": 18},
	{"id": "nades", "name": "GRENADES", "weight": 16},
	{"id": "rage", "name": "ADRENALINE", "weight": 10},
	{"id": "weapon", "name": "WEAPON CRATE", "weight": 8},
]

# ---------------------------------------------------------------- WAVE FLOW
## Seconds of calm before the very first wave and between two waves. The clock
## is frozen while the shop or the build bar is open, so nobody gets jumped.
const PREP_TIME_FIRST := 20.0
const INTERMISSION_TIME := 30.0

# ---------------------------------------------------------------- WAVE EVENTS
const EVENTS := [
	{"id": "none", "name": "", "weight": 42},
	{"id": "horde", "name": "HORDE RUSH", "desc": "Twice the bodies, weaker skulls", "weight": 12},
	{"id": "runners", "name": "RUNNER PACK", "desc": "Everything sprints", "weight": 12},
	{"id": "elites", "name": "ELITE SQUAD", "desc": "Armoured mutations everywhere", "weight": 10},
	{"id": "fog", "name": "TOXIC FOG", "desc": "Low visibility, spitters hunt you", "weight": 8},
	{"id": "night", "name": "BLACKOUT", "desc": "Lights out. Muzzle flash only", "weight": 8},
	{"id": "bounty", "name": "BOUNTY RUN", "desc": "Double cash from every kill", "weight": 8},
]

## Elite mutations rolled per zombie in later waves.
const ELITES := {
	"armored": {"name": "Armoured", "hp": 2.0, "speed": 0.85, "armor": 0.35, "armor_flat": 6.0,
		"cash": 2.0, "tint": Color(0.62, 0.72, 1.0)},
	"frenzied": {"name": "Frenzied", "hp": 1.2, "speed": 1.5, "armor": 0.0, "armor_flat": 0.0,
		"cash": 1.8, "tint": Color(1.0, 0.55, 0.45)},
	"toxic": {"name": "Toxic", "hp": 1.5, "speed": 1.0, "armor": 0.1, "armor_flat": 2.0,
		"cash": 2.0, "tint": Color(0.6, 1.0, 0.55)},
}
const ELITE_ORDER := ["armored", "frenzied", "toxic"]

# ---------------------------------------------------------------- LOADOUT / META
## Suits change the base body: HP, speed, armour, regen. Prices are in Cores.
const SUITS := {
	"player_soldier": {"name": "Soldier", "hp": 0.0, "speed": 1.0, "armor": 0.0, "regen": 0.0,
		"price": 0, "desc": "Balanced army standard.",
		"ability": "resupply", "cd": 26.0, "rate": 1.10,
		"perk": "+10% fire rate. SKILL: instant reload and a full ammo drop."},
	"player_swat": {"name": "SWAT", "hp": 25.0, "speed": 1.0, "armor": 0.10, "regen": 0.0,
		"price": 20, "desc": "Extra plates, same speed.",
		"ability": "flashbang", "cd": 20.0, "rate": 1.0,
		"perk": "+10% armour. SKILL: flashbang stuns everything close."},
	"player_survivor": {"name": "Survivor", "hp": -15.0, "speed": 1.14, "armor": 0.0,
		"regen": 0.0, "price": 12, "desc": "Fragile but fast.",
		"ability": "adrenaline", "cd": 22.0, "rate": 1.0, "dash": 0.75,
		"perk": "Faster dash. SKILL: adrenaline rush - damage, speed, fire rate."},
	"player_medic": {"name": "Medic", "hp": 10.0, "speed": 1.04, "armor": 0.0, "regen": 1.5,
		"price": 26, "desc": "Regenerates health slowly.",
		"ability": "fieldkit", "cd": 24.0, "rate": 1.0,
		"perk": "Constant regen. SKILL: field kit heals you and your pets."},
	"player_juggernaut": {"name": "Juggernaut", "hp": 70.0, "speed": 0.87, "armor": 0.20,
		"regen": 0.0, "price": 40, "desc": "A walking bunker.",
		"ability": "ironskin", "cd": 28.0, "rate": 1.0,
		"perk": "Heavy plating. SKILL: iron skin - shrug off everything and stomp."},
}

## Class ranks bought with cores. Each rank makes the class skill stronger and
## its cooldown shorter, and adds a little permanent health.
const CLASS_MAX_RANK := 5
const CLASS_RANK_PRICE := [0, 12, 20, 32, 48, 70]

const SUIT_ORDER := ["player_soldier", "player_swat", "player_survivor", "player_medic",
	"player_juggernaut"]

const PETS := {
	"none": {"name": "No Pet", "price": 0, "desc": "Fight alone."},
	"pet_dog": {"name": "Guard Dog", "price": 18, "desc": "Fast, bites nonstop."},
	"pet_tiger": {"name": "War Tiger", "price": 45, "desc": "Mauls whole groups."},
}

const PET_ORDER := ["none", "pet_dog", "pet_tiger"]

const LOADOUT_PRIMARY := {
	"ak47": 0, "shotgun": 0, "mp5": 8, "m4": 14, "lmg": 22, "flamer": 20, "autoshotgun": 26,
	"sniper": 24, "minigun": 34, "rpg": 36, "grenadier": 30, "laser": 32, "tesla": 34,
	"gauss": 44, "railgun": 55,
}
const LOADOUT_PRIMARY_ORDER := ["ak47", "shotgun", "mp5", "m4", "lmg", "flamer", "autoshotgun",
	"sniper", "grenadier", "laser", "tesla", "minigun", "rpg", "gauss", "railgun"]

const LOADOUT_SIDEARM := {"pistol": 0, "uzi": 6, "magnum": 12, "mp5": 16}
const LOADOUT_SIDEARM_ORDER := ["pistol", "uzi", "magnum", "mp5"]

const LOADOUT_MELEE := {"none": 0, "katana": 10, "chainsaw": 16}
const LOADOUT_MELEE_ORDER := ["none", "katana", "chainsaw"]



# ---------------------------------------------------------------- GRENADES
## Four throwables, each with its own job. The pool is per type, so hoarding
## shock grenades for a brute wave is a real decision.
const GRENADES := {
	"frag": {"name": "Frag Grenade", "icon": "nade_frag", "color": Color(0.72, 0.86, 0.6),
		"dmg": 1.0, "aoe": 78.0, "unlock": 1, "price": 30, "max": 9,
		"desc": "Big instant blast."},
	"incend": {"name": "Incendiary Grenade", "icon": "nade_incend", "color": Color(1.0, 0.62, 0.25),
		"dmg": 0.45, "aoe": 66.0, "unlock": 3, "price": 40, "max": 7,
		"hazard": "fire", "haz_time": 6.0, "haz_dps": 30.0, "haz_radius": 54.0,
		"desc": "Sets the ground on fire."},
	"shock": {"name": "Shock Charge", "icon": "nade_shock", "color": Color(0.5, 0.88, 1.0),
		"dmg": 0.55, "aoe": 62.0, "unlock": 6, "price": 45, "max": 6,
		"chain": 7, "stun": 2.2,
		"desc": "Chains lightning and stuns."},
	"gas": {"name": "Gas Canister", "icon": "nade_gas", "color": Color(0.76, 0.9, 0.45),
		"dmg": 0.25, "aoe": 52.0, "unlock": 9, "price": 38, "max": 7,
		"hazard": "gas", "haz_time": 8.0, "haz_dps": 16.0, "haz_radius": 62.0,
		"slow": true, "desc": "Corrosive cloud, slows and melts."},
}
const GRENADE_ORDER := ["frag", "incend", "shock", "gas"]

# ---------------------------------------------------------------- SAVING
## A run is autosaved between waves. From CHECKPOINT_FROM on, every
## CHECKPOINT_EVERY waves also drops a checkpoint you can fall back to after a
## death instead of losing a 40 wave run.
const CHECKPOINT_FROM := 15
const CHECKPOINT_EVERY := 5
const RUN_SAVE_VERSION := 3


func grenade(id: String) -> Dictionary:
	return GRENADES.get(id, GRENADES["frag"])


func grenade_unlocked(id: String, wave: int) -> bool:
	return wave + 1 >= int(grenade(id).get("unlock", 1))


func checkpoint_wave_for(wave: int) -> int:
	## The checkpoint a run at this wave falls back to (0 = none yet).
	if wave < CHECKPOINT_FROM:
		return 0
	return int(floor(float(wave) / float(CHECKPOINT_EVERY))) * CHECKPOINT_EVERY


func class_rank_price(rank: int) -> int:
	if rank < 0 or rank >= CLASS_RANK_PRICE.size():
		return -1
	return int(CLASS_RANK_PRICE[rank])


func class_power(rank: int) -> float:
	return 1.0 + 0.18 * float(maxi(0, rank))


func class_cd_mul(rank: int) -> float:
	return maxf(0.5, 1.0 - 0.07 * float(maxi(0, rank)))


func class_hp_bonus(rank: int) -> float:
	return 8.0 * float(maxi(0, rank))


func suit_ability(suit: String) -> String:
	return String(SUITS.get(suit, SUITS["player_soldier"]).get("ability", "resupply"))


func suit_ability_cd(suit: String, rank: int) -> float:
	var base = float(SUITS.get(suit, SUITS["player_soldier"]).get("cd", 24.0))
	return maxf(4.0, base * class_cd_mul(rank))


## Cores awarded at the end of a run.
func cores_for_run(wave: int, kills: int) -> int:
	return int(floor(float(wave) * 1.6 + float(kills) / 18.0))


# ---------------------------------------------------------------- LOOKUPS
func weapon(id: String) -> Dictionary:
	return WEAPONS.get(id, WEAPONS["pistol"])


func building(kind: String) -> Dictionary:
	return BUILDINGS.get(kind, BUILDINGS["wall"])


func structure_limit(kind: String) -> int:
	return int(building(kind).get("limit", 4))


func structure_life(kind: String) -> int:
	return int(building(kind).get("life", 4))


func structure_resist(kind: String, dmg_type: String) -> float:
	var r: Dictionary = building(kind).get("resist", {})
	return clampf(float(r.get(dmg_type, 0.0)), 0.0, 0.95)
