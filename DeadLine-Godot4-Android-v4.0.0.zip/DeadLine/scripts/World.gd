extends Node
## ============================================================================
## World - the single source of truth for the v4 "belt" geometry.
##
## Everything vertical in the game asks this file instead of hard-coding a
## number. That is the whole point: the band, the art, the camera, the spawns
## and the scale of every actor are derived from five constants, so the space
## can be retuned in one place and nothing drifts out of sync.
##
##   HORIZON_Y  -34   fence foot, far edge of the world
##   BELT_TOP   -22   depth 0.0 - the FAR curb, drawn, not an invisible wall
##   BELT_BOT    72   depth 1.0 - the NEAR curb, likewise drawn
##   BELT_H      94   playable depth in world pixels (v3 had 78)
##
## ENABLED is the kill switch. Set it to false and the game falls back to flat
## v3 behaviour (no depth scale, no new layers, no camera compression) without
## touching a single call site - that is the lesson from the build that shipped
## a frozen first frame.
## ============================================================================

const ENABLED := true

const HORIZON_Y := -34.0
const CURB_H := 12.0
const BELT_TOP := -22.0
const BELT_BOT := 72.0
const BELT_H := 94.0
const NEAR_WALK_Y := 96.0

# v3 band, kept so ENABLED = false is a real fallback and not a guess
const V3_TOP := -44.0
const V3_BOT := 34.0

# how much smaller an actor is at the far curb / bigger at the near one
const SCALE_FAR := 0.88
const SCALE_NEAR := 1.10
# walking "into" the screen is slower than walking along it, which is what
# makes a 94 px band feel like depth instead of like a taller room
const DEPTH_SPEED := 0.62

const CAM_LIFT := 16.0
# the camera only travels 45% of the depth the player does: without this the
# horizon slides a full 94 px every time you cross the road and the whole city
# looks like it is bobbing
const CAM_COMPRESS := 0.45

const TILE_W := 320.0
const THEMES := ["neon", "blood", "toxic", "cold"]
const THEME_NAMES := ["NEON DECAY", "BLOOD MOON", "TOXIC HAZE", "DEAD COLD"]

## name, world y of the image top row, parallax factor, z_index.
## Mirrors tools/env.py LAYERS 1:1 - tools/check.py fails the build if it drifts.
const LAYERS := [
	{"n": "sky", "y": -160.0, "f": 0.00, "z": -60},
	{"n": "far", "y": -110.0, "f": 0.20, "z": -50},
	{"n": "mid", "y": -92.0, "f": 0.40, "z": -46},
	{"n": "near", "y": -72.0, "f": 0.66, "z": -42},
	{"n": "fence", "y": -60.0, "f": 0.80, "z": -38},
	{"n": "fog", "y": -52.0, "f": 0.86, "z": -34},
	{"n": "curb_far", "y": -35.0, "f": 1.00, "z": -30},
	{"n": "road", "y": -22.0, "f": 1.00, "z": -28},
	{"n": "curb_near", "y": 72.0, "f": 1.00, "z": 120},
	{"n": "props_near", "y": 50.0, "f": 1.00, "z": 122},
]

## per theme: moon screen anchor / world y, weather kind, tint, light beams
const ENV := {
	"neon": {"moon_ax": 0.18, "moon_y": -86.0, "weather": "rain",
			"pcolor": "8f7ad8", "beams": false, "amount": 110},
	"blood": {"moon_ax": 0.72, "moon_y": -80.0, "weather": "ash",
			"pcolor": "ffb99a", "beams": false, "amount": 55},
	"toxic": {"moon_ax": 0.30, "moon_y": -84.0, "weather": "spore",
			"pcolor": "c6ff7a", "beams": false, "amount": 55},
	"cold": {"moon_ax": 0.80, "moon_y": -90.0, "weather": "snow",
			"pcolor": "ffffff", "beams": true, "amount": 90},
}


# ---------------------------------------------------------------- band limits
func top() -> float:
	return BELT_TOP if ENABLED else V3_TOP


func bot() -> float:
	return BELT_BOT if ENABLED else V3_BOT


func height() -> float:
	return bot() - top()


func mid_y() -> float:
	return (top() + bot()) * 0.5


func clamp_y(y: float) -> float:
	return clampf(y, top(), bot())


# ---------------------------------------------------------------- depth
func depth_of(y: float) -> float:
	## 0.0 at the far curb, 1.0 at the near one. Never leaves 0..1.
	return clampf((y - top()) / maxf(1.0, height()), 0.0, 1.0)


func y_of(depth: float) -> float:
	return top() + clampf(depth, 0.0, 1.0) * height()


func scale_at(y: float) -> float:
	if not ENABLED:
		return 1.0
	return lerpf(SCALE_FAR, SCALE_NEAR, depth_of(y))


func scale_vec(y: float) -> Vector2:
	return Vector2.ONE * scale_at(y)


func z_at(y: float) -> int:
	## Only used by things that live outside the y-sorted entity node.
	return int(round(depth_of(y) * 100.0))


func hit_slack(y: float) -> float:
	## Vertical hit tolerance follows the actor's on-screen size, so a hit at
	## the near curb is not stricter than one at the far curb.
	return 8.0 * scale_at(y)


func move_vec(input: Vector2) -> Vector2:
	## Horizontal is full speed, depth is slower. One place, so the player, the
	## ally and the pet can never disagree about it.
	if not ENABLED:
		return input
	return Vector2(input.x, input.y * DEPTH_SPEED)


func spawn_y(bias: float = 0.5, spread: float = 1.0) -> float:
	## Spawns are pushed towards the far side by default: a zombie that appears
	## on the near curb is already in your face and reads as unfair.
	var half = clampf(spread, 0.0, 1.0) * 0.5
	var d = clampf(bias, 0.0, 1.0) + randf_range(-half, half)
	return y_of(clampf(d, 0.02, 0.98))


# ---------------------------------------------------------------- camera
func cam_y(player_y: float) -> float:
	if not ENABLED:
		return player_y - CAM_LIFT
	return mid_y() + (player_y - mid_y()) * CAM_COMPRESS - CAM_LIFT


# ---------------------------------------------------------------- art
func theme_index() -> int:
	return clampi(Settings.idx("env_theme"), 0, THEMES.size() - 1)


func theme() -> String:
	return String(THEMES[theme_index()])


func theme_name() -> String:
	return String(THEME_NAMES[theme_index()])


func env_dict() -> Dictionary:
	var d: Variant = ENV.get(theme(), null)
	if d == null:
		return ENV["neon"]
	return d


func weather_color() -> Color:
	## Stored as a hex string on purpose: a const Dictionary may only hold plain
	## constant expressions, and this way there is nothing to argue about.
	return Color.html(String(env_dict().get("pcolor", "ffffff")))


const WEATHER_MUL := [0.35, 0.7, 1.0]


func weather_amount() -> int:
	var base = int(env_dict().get("amount", 90))
	var q = clampi(Settings.idx("quality"), 0, WEATHER_MUL.size() - 1)
	return int(base * float(WEATHER_MUL[q]))


func env_path(layer: String, theme_key: String = "") -> String:
	var k = theme_key if theme_key != "" else theme()
	return "res://art/env/%s/%s.png" % [k, layer]
