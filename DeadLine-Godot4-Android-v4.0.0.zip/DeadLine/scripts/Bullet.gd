extends Node2D
class_name Bullet
## Projectile with SWEPT (continuous) collision - it can never tunnel through a
## zombie, no matter how fast it flies. That was the old "damage sometimes does
## not register" bug: Area2D overlap tests only sample once per physics frame.
##
## Collision is resolved against the game's zombie grid, so it stays cheap even
## with 80 zombies and hundreds of bullets alive.

const SUBSTEP := 3.0        # px between collision samples
const GRAVITY_GRENADE := 0.0

var game = null
var spr: Sprite2D

var vel = Vector2.ZERO
var kind = "bullet"
var dmg = 10.0
var pierce = 0
var knock = 30.0
var aoe = 0.0
var life = 1.0
var from_player = true
var radius = 2.5
var crit_chance = 0.0
var crit_mul = 2.0
var burn = 0.0
var slow = 0.0
var hazard = ""                    # "fire" / "gas": ground left behind on impact
var haz_time = 0.0
var haz_dps = 0.0
var haz_radius = 0.0
var chain_hits = 0                 # shock grenade: arcs to nearby zombies
var chain_stun = 0.0
var explosive = 0.0
var homing = 0.0
var ap = 0.0
var dmg_type = "hit"
var alive = false

var _hits: Dictionary = {}
var _fuse = 0.0
var _spin = 0.0


func _ready() -> void:
	spr = Sprite2D.new()
	spr.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	add_child(spr)
	z_index = 8
	visible = false
	set_physics_process(false)


func launch(p_game, pos: Vector2, dir: Vector2, cfg: Dictionary) -> void:
	game = p_game
	global_position = pos
	kind = String(cfg.get("kind", "bullet"))
	dmg = float(cfg.get("dmg", 10.0))
	pierce = int(cfg.get("pierce", 0))
	knock = float(cfg.get("knock", 30.0))
	aoe = float(cfg.get("aoe", 0.0))
	life = float(cfg.get("life", 1.0))
	from_player = bool(cfg.get("from_player", true))
	crit_chance = float(cfg.get("crit", 0.0))
	crit_mul = float(cfg.get("crit_mul", 2.0))
	burn = float(cfg.get("burn", 0.0))
	slow = float(cfg.get("slow", 0.0))
	hazard = String(cfg.get("hazard", ""))
	haz_time = float(cfg.get("haz_time", 0.0))
	haz_dps = float(cfg.get("haz_dps", 0.0))
	haz_radius = float(cfg.get("haz_radius", 54.0))
	chain_hits = int(cfg.get("chain", 0))
	chain_stun = float(cfg.get("stun", 0.0))
	explosive = float(cfg.get("explosive", 0.0))
	homing = float(cfg.get("homing", 0.0))
	ap = float(cfg.get("ap", 0.0))
	dmg_type = String(cfg.get("dmg_type", "hit"))
	var speed = float(cfg.get("speed", 600.0))
	vel = dir.normalized() * speed
	_hits.clear()
	_fuse = float(cfg.get("fuse", 0.0))
	_spin = float(cfg.get("spin", 0.0))

	var tex_key = String(cfg.get("tex", "bullet"))
	spr.texture = Art.fx_tex(tex_key)
	spr.rotation = vel.angle()
	spr.scale = Vector2.ONE * float(cfg.get("scale", 1.0))
	var tint: Color = cfg.get("color", Color(1, 1, 1))
	spr.modulate = tint

	match kind:
		"pellet":
			radius = 2.5
		"rocket":
			radius = 4.5
		"grenade":
			radius = 4.0
		"flame":
			radius = 7.0
		"acid":
			radius = 3.5
		_:
			radius = 3.0
	radius = float(cfg.get("radius", radius))

	alive = true
	visible = true
	set_physics_process(true)


func despawn() -> void:
	if not alive:
		return
	alive = false
	visible = false
	set_physics_process(false)
	if game != null:
		game.recycle_bullet(self)


func _physics_process(delta: float) -> void:
	if not alive or game == null:
		return
	life -= delta
	if life <= 0.0:
		if kind == "grenade" or kind == "rocket":
			_boom()
		else:
			despawn()
		return

	if kind == "grenade":
		vel.y += 90.0 * delta        # slight lob so grenades arc over walls
	if homing > 0.001 and from_player:
		var t = game.nearest_zombie(global_position, 160.0)
		if t != null:
			var want: Vector2 = (t.hit_center() - global_position).normalized() * vel.length()
			vel = vel.lerp(want, clampf(homing * delta * 6.0, 0.0, 1.0))

	if _spin != 0.0:
		spr.rotation += _spin * delta
	else:
		spr.rotation = vel.angle()

	# ---------------- swept movement
	var step = vel * delta
	var dist = step.length()
	if dist <= 0.0001:
		return
	var steps = clampi(int(ceil(dist / SUBSTEP)), 1, 24)
	var inc = step / float(steps)
	for i in range(steps):
		global_position += inc
		if _check_hits():
			return
		if _out_of_bounds():
			if kind == "rocket" or kind == "grenade":
				_boom()
			else:
				if kind != "flame":
					game.fx.impact(global_position, -inc.normalized())
				despawn()
			return


func _out_of_bounds() -> bool:
	if global_position.x < -80.0 or global_position.x > GameData.ARENA_W + 80.0:
		return true
	return global_position.y > GameData.BAND_BOT + 26.0 or global_position.y < GameData.BAND_TOP - 90.0


func _check_hits() -> bool:
	if from_player:
		var list: Array = game.zombies_near(global_position, radius + 16.0)
		for z in list:
			if z == null or not is_instance_valid(z) or z.dead:
				continue
			if _hits.has(z.get_instance_id()):
				continue
			if not _overlaps(z.global_position, z.radius, z.body_h):
				continue
			_hits[z.get_instance_id()] = true
			_apply_to_zombie(z)
			if aoe > 0.0:
				_boom()
				return true
			if pierce <= 0:
				despawn()
				return true
			pierce -= 1
		return false

	# ---- enemy projectile
	var pl = game.player
	if pl != null and is_instance_valid(pl) and not pl.dead:
		if _overlaps(pl.global_position, 6.0, 20.0):
			pl.take_damage(dmg, global_position)
			if kind == "acid":
				game.fx.acid_pool(global_position + Vector2(0, 2))
			despawn()
			return true
	for s in game.get_structures():
		if s == null or not is_instance_valid(s) or s.dead:
			continue
		if _overlaps(s.global_position, 9.0, 16.0):
			s.take_structure_damage(dmg, dmg_type)
			game.fx.impact(global_position, -vel.normalized())
			despawn()
			return true
	return false


func _overlaps(base: Vector2, r: float, h: float) -> bool:
	## Capsule-ish test: base is at the feet, body rises h pixels above it.
	var dx: float = absf(global_position.x - base.x)
	if dx > r + radius:
		return false
	var top: float = base.y - h - radius
	var bottom: float = base.y + 4.0 + radius
	return global_position.y >= top and global_position.y <= bottom


func _apply_to_zombie(z) -> void:
	var crit = randf() < crit_chance
	var final_dmg = dmg * (crit_mul if crit else 1.0)
	var at: Vector2 = Vector2(global_position.x, global_position.y)
	z.take_hit(final_dmg, vel.normalized() * knock, crit, at, ap)
	if burn > 0.0:
		z.ignite(burn)
	if slow > 0.0:
		z.chill(slow)
	if explosive > 0.0 and randf() < explosive:
		game.explode(at, 42.0, final_dmg * 0.6, true, 0.7, maxf(ap, 0.35))


func _boom() -> void:
	if aoe > 0.0:
		game.explode(global_position, aoe, dmg, from_player, aoe / 60.0, maxf(ap, 0.35))
	else:
		game.fx.impact(global_position, -vel.normalized())
	# ---- grenade payloads: each type leaves its own mark on the battlefield
	if hazard != "" and haz_time > 0.0:
		var ground = Vector2(global_position.x,
				clampf(global_position.y, GameData.BAND_TOP, GameData.BAND_BOT))
		game.spawn_hazard(ground, hazard, haz_radius, haz_dps, haz_time, slow > 0.0)
	if chain_hits > 0:
		game.chain_lightning(global_position, chain_hits, dmg * 0.55, 150.0, true, ap)
		for z in game.zombies_near(global_position, aoe + 40.0):
			if not z.dead and chain_stun > 0.0:
				z.stagger(chain_stun)
	despawn()
