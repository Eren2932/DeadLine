extends Node
## Tiny pooled SFX player. All sounds are generated .wav files in res://sfx/.

const SOUNDS := {
	"shot": "res://sfx/shot.wav",
	"shot_big": "res://sfx/shot_big.wav",
	"shotgun": "res://sfx/shotgun.wav",
	"laser": "res://sfx/laser.wav",
	"zap": "res://sfx/zap.wav",
	"flame": "res://sfx/flame.wav",
	"explosion": "res://sfx/explosion.wav",
	"hit": "res://sfx/hit.wav",
	"splat": "res://sfx/splat.wav",
	"groan": "res://sfx/groan.wav",
	"reload": "res://sfx/reload.wav",
	"click": "res://sfx/click.wav",
	"levelup": "res://sfx/levelup.wav",
	"hurt": "res://sfx/hurt.wav",
	"build": "res://sfx/build.wav",
	"saw": "res://sfx/saw.wav",
	"roar": "res://sfx/roar.wav",
	"siren": "res://sfx/siren.wav",
	"crate": "res://sfx/crate.wav",
	"ui": "res://sfx/ui.wav",
	"empty": "res://sfx/empty.wav",
	"heal": "res://sfx/heal.wav",
	"coin": "res://sfx/coin.wav",
	"dash": "res://sfx/dash.wav",
	"thud": "res://sfx/thud.wav",
	"headshot": "res://sfx/headshot.wav",
	"whoosh": "res://sfx/whoosh.wav",
	"horn": "res://sfx/horn.wav",
}

const POOL_SIZE := 20

var _streams: Dictionary = {}
var _players: Array[AudioStreamPlayer] = []
var _next = 0
var _last_time: Dictionary = {}


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	for key in SOUNDS.keys():
		var p: String = SOUNDS[key]
		if ResourceLoader.exists(p):
			_streams[key] = load(p)
	for i in range(POOL_SIZE):
		var pl = AudioStreamPlayer.new()
		pl.bus = "SFX"
		pl.process_mode = Node.PROCESS_MODE_ALWAYS
		add_child(pl)
		_players.append(pl)


func play(key: String, volume_db: float = -6.0, pitch: float = 1.0, min_gap: float = 0.03) -> void:
	if not Settings.on("sfx_on"):
		return
	if not _streams.has(key):
		return
	var now = float(Time.get_ticks_msec()) * 0.001
	if now - float(_last_time.get(key, -99.0)) < min_gap:
		return
	_last_time[key] = now
	var pl: AudioStreamPlayer = _players[_next]
	_next = (_next + 1) % _players.size()
	pl.stream = _streams[key]
	pl.volume_db = volume_db
	pl.pitch_scale = clampf(pitch, 0.4, 2.4)
	pl.play()
