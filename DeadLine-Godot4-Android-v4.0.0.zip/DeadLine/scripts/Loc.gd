extends Node
## Runtime localization.
##
## Design notes
## ------------
## Keys are the English source strings themselves. That keeps every call site
## readable ("Loc.t(\"SHOP\")" instead of "Loc.t(\"hud.shop\")"), makes a missing
## entry degrade gracefully to plain English instead of showing a raw key, and
## lets the data tables in GameData stay exactly as they are - names and
## descriptions are translated at display time.
##
## Adding a language: append its code to LANGS + label to LANG_LABELS and add
## one more string to every row of TABLE (rows are ordered like LANGS minus the
## English source, i.e. index 0 of a row is LANGS[1]).

signal language_changed

## Language codes. Index 0 is the source language and needs no table entries.
const LANGS := ["en", "ru", "es", "pt"]
const LANG_LABELS := ["ENGLISH", "\u0420\u0423\u0421\u0421\u041a\u0418\u0419", "ESPA\u00d1OL", "PORTUGU\u00caS"]

## OS locale prefix -> index in LANGS.
const LOCALE_MAP := {
	"ru": 1, "uk": 1, "be": 1, "kk": 1, "ky": 1, "uz": 1, "az": 1, "hy": 1, "mo": 1,
	"es": 2, "ca": 2, "gl": 2,
	"pt": 3,
}

var lang_index = 0


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	var stored = Settings.idx("lang")
	var fresh = stored < 0 or stored >= LANGS.size()
	if fresh:
		stored = detect_index()
	# Applied first, stored second: if the disk write ever fails the player still
	# gets the right language instead of silently falling back to English.
	lang_index = stored
	_ensure_glyph_coverage()
	if fresh:
		Settings.set_v("lang", stored)


# ------------------------------------------------------------------ language
func detect_index() -> int:
	## First run: follow the phone. Falls back to English.
	var loc = OS.get_locale().to_lower().replace("-", "_")
	var head_code = loc.split("_")[0]
	if LOCALE_MAP.has(head_code):
		return int(LOCALE_MAP[head_code])
	return 0


func code() -> String:
	return String(LANGS[clampi(lang_index, 0, LANGS.size() - 1)])


func label() -> String:
	return String(LANG_LABELS[clampi(lang_index, 0, LANG_LABELS.size() - 1)])


func label_of(i: int) -> String:
	return String(LANG_LABELS[clampi(i, 0, LANG_LABELS.size() - 1)])


func count() -> int:
	return LANGS.size()


func set_index(i: int) -> void:
	var v = clampi(i, 0, LANGS.size() - 1)
	if v == lang_index:
		return
	lang_index = v
	Settings.set_v("lang", v)
	language_changed.emit()


func cycle(step: int = 1) -> void:
	set_index(int(posmod(lang_index + step, LANGS.size())))


# ------------------------------------------------------------------ lookup
func t(src: String) -> String:
	## Translate one source string. Unknown strings pass through untouched.
	if lang_index <= 0:
		return src
	var v: Variant = TABLE.get(src, null)
	if typeof(v) != TYPE_ARRAY:
		return src
	var row: Array = v
	var i = lang_index - 1
	if i < 0 or i >= row.size():
		return src
	var out = String(row[i])
	return src if out == "" else out


func f(src: String, args: Array) -> String:
	## Translate, then format. Every translation keeps the same placeholders in
	## the same order as the English source, so this is always safe.
	return t(src) % args


func has(src: String) -> bool:
	return TABLE.has(src)


# ------------------------------------------------------------------ fonts
func _ensure_glyph_coverage() -> void:
	## The bundled UI font covers Latin and Cyrillic, but if a build ever ships
	## with a stripped font we chain a system face in as a fallback instead of
	## rendering a wall of empty boxes.
	var base: Font = ThemeDB.fallback_font
	if base == null:
		return
	if base.has_char(0x0416) and base.has_char(0x00d1):
		return
	var sys = SystemFont.new()
	sys.font_names = PackedStringArray(["Roboto", "Noto Sans", "DejaVu Sans",
			"Liberation Sans", "Arial", "sans-serif"])
	if sys.get_face_count() <= 0:
		return
	var fb: Array[Font] = base.fallbacks
	fb.append(sys)
	base.fallbacks = fb


# ------------------------------------------------------------------ table
const TABLE := {
	"DEAD LINE": ["DEAD LINE", "DEAD LINE", "DEAD LINE"],
	"ZOMBIE FRONTIER": ["ЗОМБИ-ФРОНТИР", "FRONTERA ZOMBI", "FRONTEIRA ZUMBI"],
	"PLAY": ["ИГРАТЬ", "JUGAR", "JOGAR"],
	"LOADOUT": ["СНАРЯЖЕНИЕ", "EQUIPO", "EQUIPAMENTO"],
	"SETTINGS": ["НАСТРОЙКИ", "AJUSTES", "AJUSTES"],
	"HOW TO PLAY": ["КАК ИГРАТЬ", "CÓMO JUGAR", "COMO JOGAR"],
	"QUIT": ["ВЫХОД", "SALIR", "SAIR"],
	"BACK": ["НАЗАД", "ATRÁS", "VOLTAR"],
	"CHANGE": ["СМЕНИТЬ", "CAMBIAR", "TROCAR"],
	"EQUIP": ["НАДЕТЬ", "EQUIPAR", "EQUIPAR"],
	"EQUIPPED": ["НАДЕТО", "EQUIPADO", "EQUIPADO"],
	"SELECT": ["ВЫБРАТЬ", "ELEGIR", "ESCOLHER"],
	"EQUIP YOUR GEAR": ["СОБЕРИ СНАРЯЖЕНИЕ", "PREPARA TU EQUIPO", "MONTE SEU EQUIPAMENTO"],
	"Empty slot.": ["Пустой слот.", "Ranura vacía.", "Slot vazio."],
	"None": ["Нет", "Ninguno", "Nenhum"],
	"MELEE": ["БЛИЖНИЙ БОЙ", "CUERPO A CUERPO", "CORPO A CORPO"],
	"PRIMARY": ["ОСНОВНОЕ", "PRINCIPAL", "PRINCIPAL"],
	"SIDEARM": ["ПИСТОЛЕТ", "SECUNDARIA", "SECUNDÁRIA"],
	"SUIT": ["КОСТЮМ", "TRAJE", "TRAJE"],
	"COMPANION": ["ПИТОМЕЦ", "COMPAÑERO", "COMPANHEIRO"],
	"LANGUAGE": ["ЯЗЫК", "IDIOMA", "IDIOMA"],
	"%d CORES": ["%d ЯДЕР", "%d NÚCLEOS", "%d NÚCLEOS"],
	"%d C": ["%d Я", "%d N", "%d N"],
	"%s  -  %d CORES": ["%s  -  %d ЯДЕР", "%s  -  %d NÚCLEOS", "%s  -  %d NÚCLEOS"],
	"NOT ENOUGH CORES (%d)": ["НЕ ХВАТАЕТ ЯДЕР (%d)", "FALTAN NÚCLEOS (%d)", "NÚCLEOS INSUFICIENTES (%d)"],
	"%s  (HP %+d, SPD x%.2f, ARM %d%%)": ["%s  (ХП %+d, СКР x%.2f, БРН %d%%)", "%s  (PS %+d, VEL x%.2f, BLD %d%%)", "%s  (PV %+d, VEL x%.2f, BLD %d%%)"],
	"DMG %d  RATE %.1f  %s": ["УРН %d  СКОР %.1f  %s", "DÑO %d  CAD %.1f  %s", "DANO %d  CAD %.1f  %s"],
	"MAG %d": ["МАГ %d", "CARG %d", "PENTE %d"],
	"INFINITE": ["БЕСКОНЕЧНО", "INFINITO", "INFINITO"],
	"GOAL - survive endless waves of the dead. Every 5th wave sends a boss.": ["ЦЕЛЬ - выстоять в бесконечных волнах мертвецов. Каждая 5-я волна присылает боссa.", "OBJETIVO - sobrevive a oleadas infinitas de muertos. Cada 5.ª oleada trae un jefe.", "OBJETIVO - sobreviva a ondas infinitas de mortos. Cada 5.ª onda traz um chefe."],
	"MOVE - drag anywhere on the stick side of the screen; the stick appears under your thumb. Aim is automatic, the nearest zombie gets the lead.": ["ДВИЖЕНИЕ - тяни в любом месте на стороне стика: стик появится прямо под пальцем. Прицел автоматический, свинец летит в ближайшего зомби.", "MOVIMIENTO - arrastra en cualquier punto del lado del joystick; aparece bajo tu pulgar. La puntería es automática: el zombi más cercano recibe el plomo.", "MOVIMENTO - arraste em qualquer ponto do lado do analógico; ele aparece sob o seu dedo. A mira é automática: o zumbi mais próximo leva o chumbo."],
	"BUTTONS - DASH (dodge + Bulldozer damage), NADE, GUN (switch weapon), RLD (reload), BLD (build mode).": ["КНОПКИ - DASH (рывок + урон от Бульдозера), NADE (граната), GUN (смена оружия), RLD (перезарядка), BLD (режим стройки).", "BOTONES - DASH (esquiva + daño de Bulldozer), NADE (granada), GUN (cambiar arma), RLD (recargar), BLD (modo construcción).", "BOTÕES - DASH (esquiva + dano do Bulldozer), NADE (granada), GUN (trocar arma), RLD (recarregar), BLD (modo construção)."],
	"BUILD - open BLD or the BUILD button between waves, pick a structure, then tap the ground. Barricades block the horde, spikes shred, sentries and tesla coils fight for you, mines wipe a whole group.": ["СТРОЙКА - между волнами жми BLD или BUILD, выбери постройку и тапни по земле. Баррикады держат орду, шипы рвут, турели и катушки Теслы стреляют за тебя, мины выносят целую пачку.", "CONSTRUCCIÓN - entre oleadas abre BLD o el botón BUILD, elige una estructura y toca el suelo. Las barricadas frenan a la horda, los pinchos desgarran, las torretas y bobinas Tesla luchan por ti, las minas borran a un grupo entero.", "CONSTRUÇÃO - entre as ondas abra BLD ou o botão BUILD, escolha uma estrutura e toque no chão. Barricadas travam a horda, espinhos rasgam, torres e bobinas Tesla lutam por você, minas apagam um grupo inteiro."],
	"SHOP - between waves you can buy weapons, ammo refills and medkits.": ["МАГАЗИН - между волнами можно купить оружие, патроны и аптечки.", "TIENDA - entre oleadas puedes comprar armas, munición y botiquines.", "LOJA - entre as ondas você pode comprar armas, munição e kits médicos."],
	"LEVEL UP - every level offers 3 upgrade cards. Stack them into a build.": ["УРОВЕНЬ - на каждом уровне дают 3 карты улучшений. Собирай из них свою сборку.", "SUBIR DE NIVEL - cada nivel ofrece 3 cartas de mejora. Combínalas en una build.", "SUBIR DE NÍVEL - cada nível oferece 3 cartas de melhoria. Combine-as em uma build."],
	"CORES - earned every run, spent in LOADOUT to unlock guns, suits and pets.": ["ЯДРА - копятся за каждый забег, тратятся в СНАРЯЖЕНИИ на оружие, костюмы и питомцев.", "NÚCLEOS - se ganan en cada partida y se gastan en EQUIPO para desbloquear armas, trajes y mascotas.", "NÚCLEOS - ganhos em cada partida e gastos em EQUIPAMENTO para liberar armas, trajes e mascotes."],
	"KEYBOARD (editor) - WASD move, E dash, Q swap, G nade, R reload, B build, 1-4 weapon slots, SPACE start wave, ESC pause.": ["КЛАВИАТУРА (редактор) - WASD движение, E рывок, Q смена оружия, G граната, R перезарядка, B стройка, 1-4 слоты, SPACE старт волны, ESC пауза.", "TECLADO (editor) - WASD moverse, E dash, Q cambiar, G granada, R recargar, B construir, 1-4 ranuras, ESPACIO iniciar oleada, ESC pausa.", "TECLADO (editor) - WASD mover, E dash, Q trocar, G granada, R recarregar, B construir, 1-4 slots, ESPAÇO iniciar onda, ESC pausa."],
	"BEST WAVE %d   KILLS %d   CORES %d": ["ЛУЧШАЯ ВОЛНА %d   УБИЙСТВ %d   ЯДЕР %d", "MEJOR OLEADA %d   BAJAS %d   NÚCLEOS %d", "MELHOR ONDA %d   ABATES %d   NÚCLEOS %d"],
	"WAVE %d": ["ВОЛНА %d", "OLEADA %d", "ONDA %d"],
	"WAVE 1": ["ВОЛНА 1", "OLEADA 1", "ONDA 1"],
	"SCORE %d": ["ОЧКИ %d", "PUNTOS %d", "PONTOS %d"],
	"SCORE 0": ["ОЧКИ 0", "PUNTOS 0", "PONTOS 0"],
	"LEFT %d": ["ОСТАЛОСЬ %d", "QUEDAN %d", "RESTAM %d"],
	"BOSS": ["БОСС", "JEFE", "CHEFE"],
	"BRUTE": ["ГРОМИЛА", "BRUTO", "BRUTO"],
	"BUILD": ["СТРОЙКА", "CONSTRUIR", "CONSTRUIR"],
	"SHOP": ["МАГАЗИН", "TIENDA", "LOJA"],
	"CLOSE": ["ЗАКРЫТЬ", "CERRAR", "FECHAR"],
	"MENU": ["МЕНЮ", "MENÚ", "MENU"],
	"MAIN MENU": ["ГЛАВНОЕ МЕНЮ", "MENÚ PRINCIPAL", "MENU PRINCIPAL"],
	"RESTART": ["ЗАНОВО", "REINICIAR", "REINICIAR"],
	"RESUME": ["ПРОДОЛЖИТЬ", "CONTINUAR", "CONTINUAR"],
	"RETRY": ["ЕЩЁ РАЗ", "OTRA VEZ", "TENTAR DE NOVO"],
	"PAUSED": ["ПАУЗА", "EN PAUSA", "EM PAUSA"],
	"YOU DIED": ["ТЫ ПОГИБ", "HAS MUERTO", "VOCÊ MORREU"],
	"LEVEL UP - PICK ONE": ["НОВЫЙ УРОВЕНЬ - ВЫБЕРИ ОДНО", "SUBISTE DE NIVEL - ELIGE UNA", "SUBIU DE NÍVEL - ESCOLHA UMA"],
	"BLACK MARKET": ["ЧЁРНЫЙ РЫНОК", "MERCADO NEGRO", "MERCADO NEGRO"],
	"PICK A STRUCTURE": ["ВЫБЕРИ ПОСТРОЙКУ", "ELIGE UNA ESTRUCTURA", "ESCOLHA UMA ESTRUTURA"],
	"PLACING: %s   $%d   %d LEFT   LASTS %d WAVES": ["СТАВИМ: %s   $%d   ОСТАЛОСЬ %d   ХВАТИТ НА %d ВОЛН", "COLOCANDO: %s   $%d   QUEDAN %d   DURA %d OLEADAS", "COLOCANDO: %s   $%d   RESTAM %d   DURA %d ONDAS"],
	"DRAG ON THE GROUND": ["ТЯНИ ПО ЗЕМЛЕ", "ARRASTRA POR EL SUELO", "ARRASTE PELO CHÃO"],
	"DRAG ON THE GROUND TO PLACE": ["ТЯНИ ПО ЗЕМЛЕ, ЧТОБЫ ПОСТАВИТЬ", "ARRASTRA POR EL SUELO PARA COLOCAR", "ARRASTE PELO CHÃO PARA COLOCAR"],
	"NEXT WAVE IN %ds": ["СЛЕДУЮЩАЯ ВОЛНА ЧЕРЕЗ %dс", "SIGUIENTE OLEADA EN %ds", "PRÓXIMA ONDA EM %ds"],
	"TIMER PAUSED - NEXT WAVE IN %ds": ["ТАЙМЕР НА ПАУЗЕ - ВОЛНА ЧЕРЕЗ %dс", "TEMPORIZADOR EN PAUSA - OLEADA EN %ds", "TEMPORIZADOR EM PAUSA - ONDA EM %ds"],
	"START NOW": ["НАЧАТЬ СЕЙЧАС", "EMPEZAR YA", "COMEÇAR AGORA"],
	"%d STRUCTURES WEAR OUT AFTER THIS WAVE": ["%d ПОСТРОЕК РАЗВАЛИТСЯ ПОСЛЕ ЭТОЙ ВОЛНЫ", "%d ESTRUCTURAS SE DESGASTAN TRAS ESTA OLEADA", "%d ESTRUTURAS VÃO SE DESGASTAR APÓS ESTA ONDA"],
	"HP FULL": ["ХП ПОЛНОЕ", "PS AL MÁXIMO", "PV NO MÁXIMO"],
	"AMMO FULL": ["ПАТРОНЫ ПОЛНЫЕ", "MUNICIÓN LLENA", "MUNIÇÃO CHEIA"],
	"AMMO %d / %d": ["ПАТРОНЫ %d / %d", "MUNICIÓN %d / %d", "MUNIÇÃO %d / %d"],
	"AMMO $%d": ["ПАТРОНЫ $%d", "MUNICIÓN $%d", "MUNIÇÃO $%d"],
	"AMMO oo  (infinite)": ["ПАТРОНЫ oo  (бесконечно)", "MUNICIÓN oo  (infinita)", "MUNIÇÃO oo  (infinita)"],
	"MEDKIT $%d": ["АПТЕЧКА $%d", "BOTIQUÍN $%d", "KIT MÉDICO $%d"],
	"GRENADE $%d": ["ГРАНАТА $%d", "GRANADA $%d", "GRANADA $%d"],
	"GRENADE": ["ГРАНАТА", "GRANADA", "GRANADA"],
	"NADES %d": ["ГРАНАТЫ %d", "GRANADAS %d", "GRANADAS %d"],
	"REFILL $%d": ["ПОПОЛНИТЬ $%d", "RELLENAR $%d", "REABASTECER $%d"],
	"REFILL ALL": ["ПОПОЛНИТЬ ВСЁ", "RELLENAR TODO", "REABASTECER TUDO"],
	"SELL $%d": ["ПРОДАТЬ $%d", "VENDER $%d", "VENDER $%d"],
	"LOCK": ["ЗАКРЫТО", "BLOQUEADO", "BLOQUEADO"],
	"UNLOCKS AT %s": ["ОТКРОЕТСЯ НА %s", "SE DESBLOQUEA EN %s", "LIBERA EM %s"],
	"MELEE - never runs dry": ["БЛИЖНИЙ БОЙ - патроны не нужны", "CUERPO A CUERPO - nunca se agota", "CORPO A CORPO - nunca acaba"],
	"%s  MELEE": ["%s  БЛИЖНИЙ БОЙ", "%s  C. A CUERPO", "%s  CORPO A CORPO"],
	"%s  %d / oo": ["%s  %d / \u221e", "%s  %d / \u221e", "%s  %d / \u221e"],
	"%s  NO AMMO": ["%s  НЕТ ПАТРОНОВ", "%s  SIN MUNICIÓN", "%s  SEM MUNIÇÃO"],
	"%s  RELOADING": ["%s  ПЕРЕЗАРЯДКА", "%s  RECARGANDO", "%s  RECARREGANDO"],
	"DMG %d  RATE %.1f  MAG %d": ["УРН %d  СКОР %.1f  МАГ %d", "DÑO %d  CAD %.1f  CARG %d", "DANO %d  CAD %.1f  PENTE %d"],
	"%d kills  LV%d": ["%d убийств  УР%d", "%d bajas  NV%d", "%d abates  NV%d"],
	"0 kills  LV1": ["0 убийств  УР1", "0 bajas  NV1", "0 abates  NV1"],
	"BEST WAVE        %d": ["ЛУЧШАЯ ВОЛНА     %d", "MEJOR OLEADA     %d", "MELHOR ONDA      %d"],
	"CORES EARNED     +%d": ["ПОЛУЧЕНО ЯДЕР    +%d", "NÚCLEOS GANADOS  +%d", "NÚCLEOS GANHOS   +%d"],
	"TOTAL CORES      %d": ["ВСЕГО ЯДЕР       %d", "NÚCLEOS TOTALES  %d", "NÚCLEOS TOTAIS   %d"],
	"WAVE REACHED     %d": ["ДОСТИГНУТА ВОЛНА %d", "OLEADA ALCANZADA %d", "ONDA ALCANÇADA   %d"],
	"ZOMBIES KILLED   %d": ["УБИТО ЗОМБИ      %d", "ZOMBIS ELIMINADOS %d", "ZUMBIS ELIMINADOS %d"],
	"SCORE            %d": ["ОЧКИ             %d", "PUNTOS           %d", "PONTOS           %d"],
	"%d FPS  %d Z": ["%d FPS  %d З", "%d FPS  %d Z", "%d FPS  %d Z"],
	"LEVEL %d": ["УРОВЕНЬ %d", "NIVEL %d", "NÍVEL %d"],
	"LVL %d": ["УР %d", "NV %d", "NV %d"],
	"%dw": ["%dв", "%do", "%do"],
	"FIRE": ["ОГОНЬ", "FUEGO", "FOGO"],
	"DASH": ["РЫВОК", "DASH", "DASH"],
	"NADE": ["ГРАНАТА", "GRAN", "GRAN"],
	"GUN": ["ОРУЖИЕ", "ARMA", "ARMA"],
	"RLD": ["ПРЗР", "RECG", "RECG"],
	"BLD": ["СТРЙ", "CONS", "CONS"],
	"HOLD THE LINE": ["ДЕРЖИ ЛИНИЮ", "AGUANTA LA LÍNEA", "SEGURE A LINHA"],
	"WAVE %d CLEARED  +$%d": ["ВОЛНА %d ЗАЧИЩЕНА  +$%d", "OLEADA %d SUPERADA  +$%d", "ONDA %d LIMPA  +$%d"],
	"BOSS INCOMING": ["БОСС НА ПОДХОДЕ", "JEFE EN CAMINO", "CHEFE CHEGANDO"],
	"BOSS DOWN": ["БОСС ПОВЕРЖЕН", "JEFE ABATIDO", "CHEFE ABATIDO"],
	"AIRDROP INBOUND": ["СБРОС С ВОЗДУХА", "SUMINISTRO EN CAMINO", "SUPRIMENTO CHEGANDO"],
	"%s ACQUIRED": ["%s ПОЛУЧЕНО", "%s CONSEGUIDA", "%s ADQUIRIDA"],
	"SOLD  +$%d": ["ПРОДАНО  +$%d", "VENDIDO  +$%d", "VENDIDO  +$%d"],
	"ALREADY OWNED": ["УЖЕ КУПЛЕНО", "YA LA TIENES", "JÁ POSSUI"],
	"LOCKED - NEEDS %s": ["ЗАКРЫТО - НУЖНО %s", "BLOQUEADO - REQUIERE %s", "BLOQUEADO - EXIGE %s"],
	"SELL A WEAPON FIRST": ["СНАЧАЛА ПРОДАЙ ОРУЖИЕ", "VENDE UN ARMA PRIMERO", "VENDA UMA ARMA PRIMEIRO"],
	"NOT ENOUGH CASH": ["НЕ ХВАТАЕТ ДЕНЕГ", "DINERO INSUFICIENTE", "DINHEIRO INSUFICIENTE"],
	"YOU NEED A GUN": ["НУЖЕН ХОТЬ ОДИН СТВОЛ", "NECESITAS UN ARMA", "VOCÊ PRECISA DE UMA ARMA"],
	"AMMO IS FULL": ["ПАТРОНЫ И ТАК ПОЛНЫЕ", "LA MUNICIÓN ESTÁ LLENA", "A MUNIÇÃO ESTÁ CHEIA"],
	"ALREADY AT FULL HP": ["ЗДОРОВЬЕ УЖЕ ПОЛНОЕ", "YA TIENES PS COMPLETOS", "PV JÁ ESTÁ CHEIO"],
	"FIELD IS FULL": ["НА ПОЛЕ НЕТ МЕСТА", "EL CAMPO ESTÁ LLENO", "O CAMPO ESTÁ CHEIO"],
	"LIMIT %d REACHED": ["ЛИМИТ %d ДОСТИГНУТ", "LÍMITE %d ALCANZADO", "LIMITE %d ALCANÇADO"],
	"TOO CLOSE": ["СЛИШКОМ БЛИЗКО", "DEMASIADO CERCA", "MUITO PERTO"],
	"OUT OF AMMO - SWAPPING": ["ПАТРОНЫ КОНЧИЛИСЬ - МЕНЯЮ", "SIN MUNICIÓN - CAMBIANDO", "SEM MUNIÇÃO - TROCANDO"],
	"+AMMO": ["+ПАТРОНЫ", "+MUNICIÓN", "+MUNIÇÃO"],
	"+%d HP": ["+%d ХП", "+%d PS", "+%d PV"],
	"+3 GRENADES": ["+3 ГРАНАТЫ", "+3 GRANADAS", "+3 GRANADAS"],
	"x%d COMBO": ["x%d КОМБО", "x%d COMBO", "x%d COMBO"],
	"AUDIO": ["ЗВУК", "AUDIO", "ÁUDIO"],
	"GRAPHICS": ["ГРАФИКА", "GRÁFICOS", "GRÁFICOS"],
	"CONTROLS & GAME": ["УПРАВЛЕНИЕ И ИГРА", "CONTROLES Y JUEGO", "CONTROLES E JOGO"],
	"MASTER": ["ОБЩАЯ", "GENERAL", "GERAL"],
	"MUSIC": ["МУЗЫКА", "MÚSICA", "MÚSICA"],
	"SOUND FX": ["ЭФФЕКТЫ", "EFECTOS", "EFEITOS"],
	"MUSIC ON": ["МУЗЫКА ВКЛ", "MÚSICA ACT.", "MÚSICA LIG."],
	"SFX": ["ЭФФЕКТЫ ВКЛ", "EFECTOS ACT.", "EFEITOS LIG."],
	"QUALITY": ["КАЧЕСТВО", "CALIDAD", "QUALIDADE"],
	"BLOOD": ["КРОВЬ", "SANGRE", "SANGUE"],
	"SCREEN SHAKE": ["ТРЯСКА ЭКРАНА", "SACUDIDA", "TREMOR DE TELA"],
	"DAMAGE NUMBERS": ["ЦИФРЫ УРОНА", "NÚMEROS DE DAÑO", "NÚMEROS DE DANO"],
	"SHOW FPS": ["ПОКАЗАТЬ FPS", "MOSTRAR FPS", "MOSTRAR FPS"],
	"CAMERA": ["КАМЕРА", "CÁMARA", "CÂMERA"],
	"STICK SIDE": ["СТОРОНА СТИКА", "LADO DEL JOYSTICK", "LADO DO ANALÓGICO"],
	"AUTO FIRE": ["АВТООГОНЬ", "FUEGO AUTO", "TIRO AUTO"],
	"VIBRATION": ["ВИБРАЦИЯ", "VIBRACIÓN", "VIBRAÇÃO"],
	"DIFFICULTY": ["СЛОЖНОСТЬ", "DIFICULTAD", "DIFICULDADE"],
	"ON": ["ВКЛ", "SÍ", "SIM"],
	"OFF": ["ВЫКЛ", "NO", "NÃO"],
	"FAR": ["ДАЛЕКО", "LEJOS", "LONGE"],
	"NORMAL": ["НОРМА", "NORMAL", "NORMAL"],
	"CLOSE UP": ["БЛИЗКО", "CERCA", "PERTO"],
	"CLEAN": ["ЧИСТО", "LIMPIO", "LIMPO"],
	"MAXIMUM": ["МАКСИМУМ", "MÁXIMO", "MÁXIMO"],
	"LIGHT": ["СЛАБО", "SUAVE", "LEVE"],
	"FULL": ["ПОЛНО", "COMPLETO", "COMPLETO"],
	"LOW": ["НИЗКОЕ", "BAJA", "BAIXA"],
	"MEDIUM": ["СРЕДНЕЕ", "MEDIA", "MÉDIA"],
	"HIGH": ["ВЫСОКОЕ", "ALTA", "ALTA"],
	"HARD": ["СЛОЖНО", "DIFÍCIL", "DIFÍCIL"],
	"NIGHTMARE": ["КОШМАР", "PESADILLA", "PESADELO"],
	"LEFT": ["СЛЕВА", "IZQUIERDA", "ESQUERDA"],
	"RIGHT": ["СПРАВА", "DERECHA", "DIREITA"],
	"M1911": ["M1911", "M1911", "M1911"],
	"Reliable sidearm.": ["Надёжный пистолет.", "Pistola fiable.", "Pistola confiável."],
	"Uzi": ["Узи", "Uzi", "Uzi"],
	"Spray and pray.": ["Поливай и молись.", "Dispara y reza.", "Atire e reze."],
	".44 Magnum": [".44 Магнум", ".44 Magnum", ".44 Magnum"],
	"Punches through skulls.": ["Пробивает череп навылет.", "Atraviesa cráneos.", "Atravessa crânios."],
	"Pump Shotgun": ["Помповый дробовик", "Escopeta de bombeo", "Escopeta de bombeamento"],
	"Turns a crowd into paste.": ["Превращает толпу в фарш.", "Convierte a la multitud en papilla.", "Transforma a multidão em pasta."],
	"Katana": ["Катана", "Katana", "Katana"],
	"Clean decapitations.": ["Чистые обезглавливания.", "Decapitaciones limpias.", "Decapitações limpas."],
	"Chainsaw": ["Бензопила", "Motosierra", "Motosserra"],
	"Infinite fuel, infinite gore.": ["Бесконечный бензин, бесконечное мясо.", "Combustible infinito, sangre infinita.", "Combustível infinito, sangue infinito."],
	"MP5": ["MP5", "MP5", "MP5"],
	"Controlled bursts.": ["Контролируемые очереди.", "Ráfagas controladas.", "Rajadas controladas."],
	"AK-47": ["АК-47", "AK-47", "AK-47"],
	"Loud, brutal, perfect.": ["Громкий, злой, идеальный.", "Ruidoso, brutal, perfecto.", "Barulhento, brutal, perfeito."],
	"M4A1": ["M4A1", "M4A1", "M4A1"],
	"Accurate full auto.": ["Точная автоматика.", "Automático y preciso.", "Automático e preciso."],
	"Flamethrower": ["Огнемёт", "Lanzallamas", "Lança-chamas"],
	"Burns the whole horde.": ["Жжёт всю орду.", "Quema a toda la horda.", "Queima a horda inteira."],
	"Barrett": ["Барретт", "Barrett", "Barrett"],
	"Line them up.": ["Ставь их в линию.", "Ponlos en fila.", "Alinhe todos."],
	"M249 SAW": ["M249 SAW", "M249 SAW", "M249 SAW"],
	"Belt-fed wall of lead.": ["Ленточная стена свинца.", "Muro de plomo con cinta.", "Muro de chumbo em fita."],
	"AA-12": ["AA-12", "AA-12", "AA-12"],
	"Automatic meat grinder.": ["Автоматическая мясорубка.", "Picadora automática.", "Moedor de carne automático."],
	"Grenade MGL": ["Гранатомёт MGL", "Lanzagranadas MGL", "Lança-granadas MGL"],
	"Lobs death over the wall.": ["Забрасывает смерть за стену.", "Lanza muerte sobre el muro.", "Joga morte por cima do muro."],
	"Laser Rifle": ["Лазерная винтовка", "Rifle láser", "Rifle laser"],
	"Instant hit beams.": ["Мгновенные лучи.", "Rayos instantáneos.", "Feixes instantâneos."],
	"RPG-7": ["РПГ-7", "RPG-7", "RPG-7"],
	"Body parts everywhere.": ["Части тел по всей дороге.", "Trozos de cuerpo por todas partes.", "Pedaços de corpo por todo lado."],
	"Minigun": ["Миниган", "Minigun", "Minigun"],
	"Never stops screaming.": ["Не замолкает никогда.", "Nunca deja de rugir.", "Nunca para de rugir."],
	"Tesla Gun": ["Тесла-пушка", "Cañón Tesla", "Canhão Tesla"],
	"Chains between bodies.": ["Прыгает между телами.", "Salta entre cuerpos.", "Salta entre corpos."],
	"Gauss Rifle": ["Гаусс-винтовка", "Rifle Gauss", "Rifle Gauss"],
	"Magnetic slug, punches rows.": ["Магнитная пуля, пробивает шеренги.", "Bala magnética, perfora filas.", "Bala magnética, perfura fileiras."],
	"Railgun": ["Рельсотрон", "Cañón de riel", "Canhão de trilho"],
	"Deletes a whole row.": ["Стирает целый ряд.", "Borra una fila entera.", "Apaga uma fileira inteira."],
	"Walker": ["Ходок", "Caminante", "Andarilho"],
	"Nurse": ["Медсестра", "Enfermera", "Enfermeira"],
	"Worker": ["Рабочий", "Obrero", "Operário"],
	"Runner": ["Бегун", "Corredor", "Corredor"],
	"Crawler": ["Ползун", "Reptador", "Rastejante"],
	"Spitter": ["Плевун", "Escupidor", "Cuspidor"],
	"Bloater": ["Пузырь", "Hinchado", "Inflado"],
	"Riot Cop": ["Спецназовец", "Antidisturbios", "Policial de choque"],
	"Hazmat": ["Химзащита", "Traje NBQ", "Traje NBQ"],
	"Brute": ["Громила", "Bruto", "Bruto"],
	"Barricade": ["Баррикада", "Barricada", "Barricada"],
	"Tough roadblock. Soaks the horde.": ["Крепкий блок. Держит орду.", "Bloqueo resistente. Absorbe a la horda.", "Bloqueio resistente. Absorve a horda."],
	"Sandbags": ["Мешки с песком", "Sacos de arena", "Sacos de areia"],
	"Cheap cover, slows them down.": ["Дешёвое укрытие, тормозит их.", "Cobertura barata, los frena.", "Cobertura barata, freia todos."],
	"Spikes": ["Шипы", "Pinchos", "Espinhos"],
	"Shreds anything walking over.": ["Рвёт всех, кто наступит.", "Destroza a quien pise.", "Rasga quem pisar."],
	"Mine": ["Мина", "Mina", "Mina"],
	"Cannot be destroyed. One big splash.": ["Не ломается. Один мощный взрыв.", "Indestructible. Una gran explosión.", "Indestrutível. Uma grande explosão."],
	"Sentry": ["Турель", "Torreta", "Torre"],
	"Short range auto-gun. Fragile, wears out.": ["Автопушка малой дальности. Хрупкая, изнашивается.", "Ametralladora automática de corto alcance. Frágil, se desgasta.", "Metralhadora automática de curto alcance. Frágil, se desgasta."],
	"Tesla Coil": ["Катушка Теслы", "Bobina Tesla", "Bobina Tesla"],
	"Zaps 3 targets. Very fragile.": ["Бьёт 3 цели. Очень хрупкая.", "Electrocuta 3 objetivos. Muy frágil.", "Eletrocuta 3 alvos. Muito frágil."],
	"Hollow Points": ["Экспансивные пули", "Puntas huecas", "Pontas ocas"],
	"+18% weapon damage": ["+18% урона оружия", "+18% daño de arma", "+18% dano de arma"],
	"Trigger Finger": ["Быстрый палец", "Dedo rápido", "Dedo rápido"],
	"+12% fire rate": ["+12% скорострельности", "+12% cadencia", "+12% cadência"],
	"Combat Boots": ["Боевые ботинки", "Botas de combate", "Botas de combate"],
	"+8% move speed": ["+8% скорости", "+8% velocidad", "+8% velocidade"],
	"Field Rations": ["Полевой рацион", "Raciones de campaña", "Rações de campo"],
	"+30 max HP (and heal)": ["+30 к макс. ХП (и лечение)", "+30 PS máximos (y cura)", "+30 PV máximos (e cura)"],
	"Kevlar Plate": ["Кевларовая плита", "Placa de kevlar", "Placa de kevlar"],
	"-7% damage taken, +2 flat armour": ["-7% получаемого урона, +2 брони", "-7% daño recibido, +2 blindaje", "-7% dano recebido, +2 blindagem"],
	"Quick Hands": ["Быстрые руки", "Manos rápidas", "Mãos rápidas"],
	"-15% reload time": ["-15% времени перезарядки", "-15% tiempo de recarga", "-15% tempo de recarga"],
	"Extended Mags": ["Удлинённые магазины", "Cargadores ampliados", "Pentes ampliados"],
	"+30% magazine and reserve": ["+30% магазина и запаса", "+30% cargador y reserva", "+30% pente e reserva"],
	"Weak Spots": ["Слабые места", "Puntos débiles", "Pontos fracos"],
	"+8% crit chance": ["+8% шанса крита", "+8% prob. crítico", "+8% chance de crítico"],
	"Skull Cracker": ["Дробитель черепов", "Rompecráneos", "Quebra-crânios"],
	"+50% crit damage": ["+50% урона крита", "+50% daño crítico", "+50% dano crítico"],
	"AP Rounds": ["Бронебойные", "Balas AP", "Balas AP"],
	"+1 pierce, +8% armour pierce": ["+1 пробитие, +8% пробития брони", "+1 perforación, +8% penetración", "+1 perfuração, +8% penetração"],
	"Stopping Power": ["Останавливающая сила", "Poder de parada", "Poder de parada"],
	"+40% knockback": ["+40% отбрасывания", "+40% retroceso", "+40% recuo"],
	"Adrenaline": ["Адреналин", "Adrenalina", "Adrenalina"],
	"+2 HP per kill": ["+2 ХП за убийство", "+2 PS por baja", "+2 PV por abate"],
	"Field Medic": ["Полевой медик", "Médico de campaña", "Médico de campo"],
	"+1.5 HP / sec regen": ["+1.5 ХП/сек регена", "+1.5 PS/s de regeneración", "+1,5 PV/s de regeneração"],
	"Looter": ["Мародёр", "Saqueador", "Saqueador"],
	"+20% cash from kills": ["+20% денег за убийства", "+20% dinero por bajas", "+20% dinheiro por abates"],
	"Fast Learner": ["Быстрый ученик", "Aprendiz rápido", "Aprendiz rápido"],
	"+25% XP gained": ["+25% получаемого опыта", "+25% EXP obtenida", "+25% XP obtida"],
	"Explosive Rounds": ["Разрывные патроны", "Balas explosivas", "Balas explosivas"],
	"+12% chance of a small blast": ["+12% шанса небольшого взрыва", "+12% prob. de pequeña explosión", "+12% chance de pequena explosão"],
	"Incendiary": ["Зажигательные", "Incendiarias", "Incendiárias"],
	"Bullets set zombies on fire": ["Пули поджигают зомби", "Las balas incendian zombis", "As balas incendeiam zumbis"],
	"Sprint Boost": ["Ускорение", "Impulso de sprint", "Impulso de corrida"],
	"-20% dash cooldown, longer dash": ["-20% откат рывка, рывок дальше", "-20% enfriamiento del dash, dash más largo", "-20% recarga do dash, dash mais longo"],
	"Bulldozer": ["Бульдозер", "Bulldozer", "Bulldozer"],
	"Dash deals heavy damage": ["Рывок наносит тяжёлый урон", "El dash causa mucho daño", "O dash causa muito dano"],
	"Scavenger": ["Собиратель", "Rebuscador", "Catador"],
	"+50% pickup drop rate, +ammo drops": ["+50% шанса выпадения, +дроп патронов", "+50% prob. de botín, +munición", "+50% chance de itens, +munição"],
	"Demolition": ["Подрывник", "Demolición", "Demolição"],
	"+35% grenade damage and radius": ["+35% урона и радиуса гранат", "+35% daño y radio de granadas", "+35% dano e raio das granadas"],
	"Gun Nut": ["Оружейный маньяк", "Fanático de armas", "Fanático por armas"],
	"+25% structure damage": ["+25% урона построек", "+25% daño de estructuras", "+25% dano das estruturas"],
	"Cooling Fins": ["Радиаторы", "Aletas de refrigeración", "Aletas de resfriamento"],
	"+20% structure fire rate": ["+20% скорострельности построек", "+20% cadencia de estructuras", "+20% cadência das estruturas"],
	"Reinforced Steel": ["Усиленная сталь", "Acero reforzado", "Aço reforçado"],
	"+35% structure HP": ["+35% ХП построек", "+35% PS de estructuras", "+35% PV das estruturas"],
	"Field Repairs": ["Полевой ремонт", "Reparaciones de campo", "Reparos de campo"],
	"+1 wave of structure lifetime": ["+1 волна срока службы построек", "+1 oleada de vida útil", "+1 onda de vida útil"],
	"Rusty Spikes": ["Ржавые шипы", "Pinchos oxidados", "Espinhos enferrujados"],
	"+60% spike damage": ["+60% урона шипов", "+60% daño de pinchos", "+60% dano dos espinhos"],
	"Double Tap": ["Двойной выстрел", "Doble disparo", "Tiro duplo"],
	"+1 projectile per shot": ["+1 снаряд за выстрел", "+1 proyectil por disparo", "+1 projétil por tiro"],
	"Cryo Rounds": ["Криопатроны", "Balas criogénicas", "Balas criogênicas"],
	"Hits chill zombies": ["Попадания замедляют зомби", "Los impactos congelan zombis", "Os acertos congelam zumbis"],
	"Bandolier": ["Патронташ", "Bandolera", "Bandoleira"],
	"+2 grenades per wave": ["+2 гранаты за волну", "+2 granadas por oleada", "+2 granadas por onda"],
	"Loyal Dog": ["Верный пёс", "Perro leal", "Cão leal"],
	"A dog fights beside you": ["Пёс дерётся рядом с тобой", "Un perro lucha a tu lado", "Um cão luta ao seu lado"],
	"War Tiger": ["Боевой тигр", "Tigre de guerra", "Tigre de guerra"],
	"A tiger mauls the horde": ["Тигр рвёт орду", "Un tigre destroza la horda", "Um tigre destroça a horda"],
	"Magnet": ["Магнит", "Imán", "Ímã"],
	"Auto-collect drops, +10% cash": ["Автосбор лута, +10% денег", "Recoge botín solo, +10% dinero", "Coleta automática, +10% dinheiro"],
	"AMMO REFILL": ["ПАТРОНЫ", "MUNICIÓN", "MUNIÇÃO"],
	"MEDKIT": ["АПТЕЧКА", "BOTIQUÍN", "KIT MÉDICO"],
	"CASH STASH": ["ЗАНАЧКА", "ALIJO DE DINERO", "DINHEIRO ESCONDIDO"],
	"GRENADES": ["ГРАНАТЫ", "GRANADAS", "GRANADAS"],
	"ADRENALINE": ["АДРЕНАЛИН", "ADRENALINA", "ADRENALINA"],
	"WEAPON CRATE": ["ЯЩИК С ОРУЖИЕМ", "CAJA DE ARMAS", "CAIXA DE ARMAS"],
	"HORDE RUSH": ["НАПЛЫВ ОРДЫ", "AVALANCHA", "AVALANCHE"],
	"Twice the bodies, weaker skulls": ["Вдвое больше тел, черепа слабее", "El doble de cuerpos, cráneos más débiles", "O dobro de corpos, crânios mais fracos"],
	"RUNNER PACK": ["СТАЯ БЕГУНОВ", "MANADA DE CORREDORES", "MATILHA DE CORREDORES"],
	"Everything sprints": ["Все бегут", "Todo corre", "Tudo corre"],
	"ELITE SQUAD": ["ЭЛИТНЫЙ ОТРЯД", "ESCUADRÓN DE ÉLITE", "ESQUADRÃO DE ELITE"],
	"Armoured mutations everywhere": ["Всюду бронированные мутации", "Mutaciones blindadas por todas partes", "Mutações blindadas por todo lado"],
	"TOXIC FOG": ["ТОКСИЧНЫЙ ТУМАН", "NIEBLA TÓXICA", "NÉVOA TÓXICA"],
	"Low visibility, spitters hunt you": ["Плохая видимость, плевуны охотятся", "Poca visibilidad, los escupidores te cazan", "Pouca visibilidade, cuspidores te caçam"],
	"BLACKOUT": ["БЛЭКАУТ", "APAGÓN", "APAGÃO"],
	"Lights out. Muzzle flash only": ["Свет вырубило. Только вспышки", "Sin luz. Solo fogonazos", "Sem luz. Só clarões"],
	"BOUNTY RUN": ["ОХОТА ЗА НАГРАДОЙ", "CAZA DE RECOMPENSAS", "CAÇA ÀS RECOMPENSAS"],
	"Double cash from every kill": ["Двойные деньги за каждое убийство", "Doble dinero por cada baja", "Dinheiro em dobro por abate"],
	"Armoured": ["Бронированный", "Blindado", "Blindado"],
	"Frenzied": ["Бешеный", "Frenético", "Frenético"],
	"Toxic": ["Токсичный", "Tóxico", "Tóxico"],
	"Soldier": ["Солдат", "Soldado", "Soldado"],
	"Balanced army standard.": ["Сбалансированный армейский стандарт.", "Estándar militar equilibrado.", "Padrão militar equilibrado."],
	"SWAT": ["СПЕЦНАЗ", "SWAT", "SWAT"],
	"Extra plates, same speed.": ["Больше брони, та же скорость.", "Más placas, la misma velocidad.", "Mais placas, mesma velocidade."],
	"Survivor": ["Выживший", "Superviviente", "Sobrevivente"],
	"Fragile but fast.": ["Хрупкий, но быстрый.", "Frágil pero rápido.", "Frágil, mas rápido."],
	"Medic": ["Медик", "Médico", "Médico"],
	"Regenerates health slowly.": ["Медленно восстанавливает здоровье.", "Regenera salud lentamente.", "Regenera vida lentamente."],
	"Juggernaut": ["Джаггернаут", "Juggernaut", "Juggernaut"],
	"A walking bunker.": ["Ходячий бункер.", "Un búnker andante.", "Um bunker ambulante."],
	"No Pet": ["Без питомца", "Sin mascota", "Sem mascote"],
	"Fight alone.": ["Дерись один.", "Lucha solo.", "Lute sozinho."],
	"Guard Dog": ["Сторожевой пёс", "Perro guardián", "Cão de guarda"],
	"Fast, bites nonstop.": ["Быстрый, кусает без остановки.", "Rápido, muerde sin parar.", "Rápido, morde sem parar."],
	"Mauls whole groups.": ["Рвёт целые группы.", "Destroza grupos enteros.", "Destroça grupos inteiros."],
	"CONTINUE": ["ПРОДОЛЖИТЬ", "CONTINUAR", "CONTINUAR"],
	"CONTINUE - WAVE %d": ["ПРОДОЛЖИТЬ — ВОЛНА %d", "CONTINUAR - OLEADA %d", "CONTINUAR - ONDA %d"],
	"NEW RUN": ["НОВАЯ ИГРА", "PARTIDA NUEVA", "NOVA PARTIDA"],
	"SAVE & EXIT": ["СОХРАНИТЬ И ВЫЙТИ", "GUARDAR Y SALIR", "SALVAR E SAIR"],
	"PRESS BACK AGAIN TO EXIT": ["НАЖМИ НАЗАД ЕЩЁ РАЗ ДЛЯ ВЫХОДА",
			"PULSA ATRÁS OTRA VEZ PARA SALIR", "TOQUE VOLTAR NOVAMENTE PARA SAIR"],
	"SAVED": ["СОХРАНЕНО", "GUARDADO", "SALVO"],
	"CHECKPOINT - WAVE %d": ["ЧЕКПОИНТ — ВОЛНА %d", "PUNTO DE CONTROL - OLEADA %d", "CHECKPOINT - ONDA %d"],
	"RUN RESTORED - WAVE %d": ["ИГРА ВОССТАНОВЛЕНА — ВОЛНА %d", "PARTIDA RESTAURADA - OLEADA %d", "PARTIDA RESTAURADA - ONDA %d"],
	"CONTINUE FROM CHECKPOINT": ["ПРОДОЛЖИТЬ С ЧЕКПОИНТА", "SEGUIR DESDE EL PUNTO DE CONTROL", "CONTINUAR DO CHECKPOINT"],
	"CONTINUE FROM WAVE %d": ["ПРОДОЛЖИТЬ С ВОЛНЫ %d", "SEGUIR DESDE LA OLEADA %d", "CONTINUAR DA ONDA %d"],
	"Frag Grenade": ["Осколочная", "Granada de fragmentación", "Granada de fragmentação"],
	"Incendiary Grenade": ["Зажигательная", "Incendiaria", "Incendiária"],
	"Shock Charge": ["Шоковый заряд", "Carga de choque", "Carga de choque"],
	"Gas Canister": ["Газовый баллон", "Bidón de gas", "Cilindro de gás"],
	"Big instant blast.": ["Мощный мгновенный взрыв.", "Explosión instantánea potente.", "Explosão instantânea forte."],
	"Sets the ground on fire.": ["Поджигает землю.", "Incendia el suelo.", "Incendeia o chão."],
	"Chains lightning and stuns.": ["Цепная молния и оглушение.", "Cadena de rayos y aturde.", "Corrente de raios e atordoa."],
	"Corrosive cloud, slows and melts.": ["Едкое облако: замедляет и разъедает.", "Nube corrosiva: ralentiza y derrite.", "Nuvem corrosiva: reduz e derrete."],
	"NO GRENADES": ["НЕТ ГРАНАТ", "SIN GRANADAS", "SEM GRANADAS"],
	"GRENADE POUCH IS FULL": ["СУМКА ДЛЯ ГРАНАТ ПОЛНА", "LA BOLSA ESTÁ LLENA", "A BOLSA ESTÁ CHEIA"],
	"UNLOCKS ON WAVE %d": ["ОТКРОЕТСЯ НА ВОЛНЕ %d", "SE DESBLOQUEA EN LA OLEADA %d", "LIBERA NA ONDA %d"],
	"SKL": ["НАВЫК", "HAB", "HAB"],
	"TYP": ["ТИП", "TIPO", "TIPO"],
	"RESUPPLY": ["ПОПОЛНЕНИЕ", "REABASTECIMIENTO", "REABASTECIMENTO"],
	"FLASHBANG": ["СВЕТОШУМОВАЯ", "GRANADA CEGADORA", "GRANADA DE LUZ"],
	"FIELD KIT": ["ПОЛЕВАЯ АПТЕЧКА", "BOTIQUÍN", "KIT DE CAMPO"],
	"IRON SKIN": ["ЖЕЛЕЗНАЯ КОЖА", "PIEL DE HIERRO", "PELE DE FERRO"],
	"MAX RANK": ["МАКС. РАНГ", "RANGO MÁXIMO", "RANQUE MÁXIMO"],
	"RANK UP - %d CORES": ["ПОВЫСИТЬ РАНГ — %d ЯДЕР", "SUBIR RANGO - %d NÚCLEOS", "SUBIR RANQUE - %d NÚCLEOS"],
	"CLASS: %s   RANK %d/%d": ["КЛАСС: %s   РАНГ %d/%d", "CLASE: %s   RANGO %d/%d", "CLASSE: %s   RANQUE %d/%d"],
	"SKILL POWER x%.2f   COOLDOWN %.0fs   BONUS HP +%d": ["СИЛА НАВЫКА x%.2f   ПЕРЕЗАРЯДКА %.0fс   БОНУС HP +%d", "PODER x%.2f   ENFRIAMIENTO %.0fs   VIDA EXTRA +%d", "PODER x%.2f   RECARGA %.0fs   VIDA EXTRA +%d"],
	"+10% fire rate. SKILL: instant reload and a full ammo drop.": ["+10% скорости стрельбы. НАВЫК: мгновенная перезарядка и ящик патронов.", "+10% cadencia. HABILIDAD: recarga instantánea y munición.", "+10% cadência. HABILIDADE: recarga instantânea e munição."],
	"+10% armour. SKILL: flashbang stuns everything close.": ["+10% брони. НАВЫК: светошумовая оглушает всех рядом.", "+10% armadura. HABILIDAD: cegadora que aturde alrededor.", "+10% armadura. HABILIDADE: granada de luz atordoa em volta."],
	"Faster dash. SKILL: adrenaline rush - damage, speed, fire rate.": ["Быстрый рывок. НАВЫК: адреналин — урон, скорость, темп стрельбы.", "Esquiva rápida. HABILIDAD: adrenalina - daño y velocidad.", "Esquiva rápida. HABILIDADE: adrenalina - dano e velocidade."],
	"Constant regen. SKILL: field kit heals you and your pets.": ["Постоянная регенерация. НАВЫК: аптечка лечит тебя и укрепления.", "Regeneración constante. HABILIDAD: botiquín te cura y repara.", "Regeneração constante. HABILIDADE: kit cura e repara."],
	"Heavy plating. SKILL: iron skin - shrug off everything and stomp.": ["Тяжёлая броня. НАВЫК: железная кожа — держишь всё и топчешь.", "Blindaje pesado. HABILIDAD: piel de hierro y pisotón.", "Blindagem pesada. HABILIDADE: pele de ferro e pisão."],
	"SKL - your class skill. Every suit has its own, with its own cooldown. Rank it up with cores in LOADOUT.": ["НАВЫК — способность класса. У каждого костюма своя, со своей перезарядкой. Ранг повышается за Ядра в СНАРЯЖЕНИИ.", "HAB - la habilidad de tu clase. Cada traje tiene la suya y su enfriamiento. Sube de rango con núcleos en EQUIPO.", "HAB - a habilidade da sua classe. Cada traje tem a sua e seu tempo de recarga. Suba de ranque com núcleos em EQUIPAMENTO."],
	"TYP - switches grenade type: frag, incendiary, shock, gas. New types unlock as the waves climb.": ["ТИП — переключает гранаты: осколочная, зажигательная, шоковая, газовая. Новые типы открываются с волнами.", "TIPO - cambia la granada: fragmentación, incendiaria, choque, gas. Se desbloquean con las oleadas.", "TIPO - troca a granada: fragmentação, incendiária, choque, gás. Liberam com as ondas."],
	"SAVING - the run autosaves between waves, so CONTINUE picks it up exactly where you left off. From wave 15 the game also drops checkpoints you can fall back to after a death.": ["СОХРАНЕНИЕ — игра автосохраняется между волнами, и ПРОДОЛЖИТЬ вернёт тебя точно туда, где ты вышел. С 15-й волны ставятся чекпоинты, с которых можно продолжить после смерти.", "GUARDADO - la partida se guarda entre oleadas y CONTINUAR te devuelve al mismo punto. Desde la oleada 15 hay puntos de control tras morir.", "SALVAMENTO - a partida salva entre ondas e CONTINUAR volta no mesmo ponto. Da onda 15 em diante há checkpoints após morrer."],
}
