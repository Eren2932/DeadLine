# DEAD LINE v2.1 - Localization, animation & game feel

## Localization (issue 23, closed)
- Full 4-language support: English, Russian, Spanish, Portuguese (BR).
- 321 translated strings. Keys are the English source strings, so a missing
  entry falls back to readable English instead of showing a raw key like
  `hud.shop`.
- Language is auto-detected from the phone locale on first launch (RU covers
  ru/uk/be/kk/ky/uz/az/hy, ES covers es/ca/gl, PT covers pt) and can be changed
  in SETTINGS -> LANGUAGE.
- Every widget created through the `UI` factory stores its English source in
  meta, so `UI.retranslate()` can relabel a live tree. The menu rebuilds itself
  on `Loc.language_changed`; the in-game HUD relabels in place (no restart).
- Placeholders (`%d`, `%s`, `%.1f`) validated across all 4 languages - order and
  count match the English source in every row.
- Glyph safety: if a build ever ships with a stripped UI font, a system face
  (Roboto / Noto / DejaVu) is chained in as a fallback so Cyrillic never turns
  into empty boxes.
- HOW TO PLAY is now one entry per topic instead of one per visual line, and the
  labels word-wrap - translated sentences are never the same length as English.

## Structure lifetime readout (your note)
- The build bar now says `LASTS n WAVES` - how long the structure you are about
  to place will live, Field Repairs included - instead of the raw base number.
- A placed structure shows its own remaining waves, colour-coded: green 3+,
  gold 2, red "dies after this wave".
- New warning line in the intermission card: `n STRUCTURES WEAR OUT AFTER THIS
  WAVE`, so nothing vanishes without notice.

## Death & corpses
- Death plays the real 6-frame death strip (staggers, buckles, folds), stops on
  its last frame and stays a corpse.
- The body carries the momentum of the shot that killed it, the shadow flattens,
  then the corpse settles and fades.
- Corpses linger ~1.9s normally but clear in 0.7s when 40+ zombies are alive, so
  a big pile never costs frames.
- Overkill still gibs instantly (unchanged).

## Camera feel
- Shake is rebuilt as trauma-based: 0..1 value with exponential decay, three
  mixed frequencies (never a flat buzz), quadratic falloff for a soft tail.
- New `kick(dir, amount)`: the camera is thrown *away* from the impact. Used by
  explosions and by player hits, so a hit from the left feels like one.
- Sub-degree camera roll and a zoom punch on blasts.
- All of it still respects SETTINGS -> SCREEN SHAKE (OFF / LIGHT / FULL); at OFF
  the camera is completely still.

## Haptics
- Kills are collected in a 0.32s window: one buzz covers a whole grenade wipe
  instead of machine-gunning the motor. Length scales with the body count
  (22-130 ms, 3 kills minimum).
- Explosions buzz proportionally to how many zombies were caught, and add a
  bigger camera kick + zoom punch the denser the crowd.
- Boss kill: hitstop, hard directional kick, zoom punch, 150 ms buzz.
- Player hits: 45 ms for a scratch, 95 ms for a real hit.
- Honours SETTINGS -> VIBRATION.

## Tooling
- `tools/lint.py` knows `SystemFont` / `FontVariation`.
- `tools/check.py` no longer reads comments as cross-file references.
- Both linters: 0 errors, 0 warnings on 21 files / 20 scripts.

## Version
- `config/version = 2.1.0` (the Android workflow picks the highest version).
