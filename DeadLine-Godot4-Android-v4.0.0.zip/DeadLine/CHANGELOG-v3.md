# DEAD LINE v3.0 - Weapon rig, zombie gait, saves, grenades, classes

## 1. The gun is now welded into the hands (your main complaint)

What was wrong, precisely:

- Every weapon was drawn far too big for the rig. The survivor is 38 px tall
  (1.8 m), and the AK sprite was 30 px long - a 1.4 m rifle. That alone made it
  read as a plank hanging off the character.
- The arms were baked into the body sheets, so the gun could never line up with
  them: only ONE hand point was exported and the front hand did not exist.
- Aim was measured from `muzzle_pos()`, and `muzzle_pos()` is derived from the
  aim direction. That is a feedback loop, and it re-picked the nearest zombie
  every single frame. That was the jitter you saw.

What it is now - a real rig, v3:

- Body sheets are generated WITHOUT arms and every frame exports its shoulder
  pivot (snapped to whole pixels, so nothing shimmers).
- Both arms are live two-bone IK in the engine (`solve_ik`), rigged straight
  onto the weapon's grip (trigger hand) and foregrip (support hand). Every
  weapon exports `grip`, `fore` and `muzzle` anchors, and all three sit on drawn
  metal, so a hand can never float next to the gun.
- Draw order: back arm -> weapon -> front arm. The gun sits INSIDE the hands
  instead of on top of the survivor's head.
- If a weapon is longer than the arm can reach, the support hand slides back
  along the handguard instead of detaching. No stretched arms, ever.
- Weapon lengths redrawn to human scale: pistol 8 px, MP5 14, AK/M4 18,
  shotgun 19, sniper/railgun/RPG/gauss 22, minigun 20.
- Full hold state machine, all interpolated, no animation pops:
  - aiming: the weapon tracks the target, clamped to +/-35 degrees of pitch so
    the side view stays readable;
  - firing: the hands are shoved back along the barrel axis and the muzzle
    climbs, then settles (`recoil` + `recoil_rot`);
  - reloading: the weapon tilts down and the support hand leaves the handguard,
    slaps a mag in and comes back, synced to the real reload progress;
  - at ease: 1.35 s with nothing to shoot and the gun is lowered to the hip -
    exactly the "lets go of it when not shooting" you asked for;
  - melee: the front arm swings the blade through the arc, both hands stay on
    the grip.
- Aim itself is fixed: it is measured from the SHOULDER, the target is sticky
  for 0.32 s, and the direction is rate-limited to 13 rad/s. No more twitching
  between three zombies.
- The whole hold is solved in right-facing space inside one mirrored container,
  so flipping direction cannot produce an upside-down gun.
- Menus and the shop use a new posed sheet (`pose`) that does have arms, since
  the in-game sheets are armless by design.

## 2. Zombie walk - no more moonwalk

- Real gait cycle: 66% stance, the planted foot pinned to the road, and
  `speed_scale` tied to actual velocity (8 frames at 12 fps move the body
  17.6 px, so the foot no longer slides).
- Shamble is modelled instead of faked: dragged leg scuffs along the ground
  without lifting, knee never straightens and turns out, hip drops on the bad
  side, torso lists, one forward lurch per stride, head lolls on a slack neck.
- Legs are readable now: front leg lit, back leg heavily shaded, separate boot
  shades, stride raised from 7.2 to 8.8 px.
- Crowds no longer march in lockstep: every zombie spawns on a random frame at
  a random cadence (0.88x - 1.14x).

## 3. Saving - done the way this genre does it

- Autosave between every wave, written to a temp file then swapped in, so a
  phone that dies mid-write can never leave a corrupt save.
- Run saves live in their own file (`deadline_run.json`), separate from the
  profile, so a broken or outdated run can be dropped without touching records,
  cores or unlocks. A save from an older build is discarded instead of loaded
  half-way.
- A save carries the whole run: wave, cash, kills, score, run time, the
  survivor (HP, level, XP, all upgrades, every weapon with its mag and reserve,
  grenades per type, position, skill cooldown), every structure with its HP and
  remaining waves, and every companion.
- MAIN MENU shows CONTINUE - WAVE n when a run exists, plus NEW RUN (which
  wipes it on purpose, so CONTINUE can never resurrect an abandoned run).
- Checkpoints from wave 15, then every 5 waves (15, 20, 25 ...). On death the
  game-over screen offers CONTINUE FROM WAVE n instead of throwing a 40 wave
  run away.
- SAVE & EXIT in the pause menu, pause during prep also autosaves, and a quiet
  "SAVED" pip in the corner confirms it landed.

## 4. Grenade types (issue 21, closed)

Four throwables with their own pools, prices, icons and unlock waves:

- FRAG (wave 1) - big instant blast.
- INCENDIARY (wave 3) - leaves burning ground: 6 s, 30 dps, keeps igniting.
- SHOCK (wave 6) - chains lightning to 7 targets and stuns for 2.2 s.
- GAS (wave 9) - corrosive cloud for 8 s that slows and melts.

Ground hazards are ticked by the game loop as plain data (no node spam), with
flame puffs and gas smoke. New TYP button (keyboard T) cycles types, the throw
button shows the live icon and count, and the shop sells the selected type.

## 5. Character classes (issue 11, closed)

Every suit now has an identity, not just stats. One SKILL button (keyboard F)
with a cooldown ring:

- Soldier - +10% fire rate. RESUPPLY: instant reload, half a reserve refill,
  spare frags.
- SWAT - +10% armour. FLASHBANG: stuns and damages everything within 130 px.
- Survivor - faster dash. ADRENALINE: rage window, dash reset, brief invuln.
- Medic - constant regen. FIELD KIT: heals 40% and repairs nearby structures,
  giving them one more wave of life.
- Juggernaut - heavy plating. IRON SKIN: 4+ s at 15% incoming damage plus a
  knockback stomp.

Class ranks are bought with cores in LOADOUT: 5 ranks, each +18% skill power,
-7% cooldown and +8 max HP.

## Housekeeping

- 4 languages updated (EN/RU/ES/PT): 38 new rows, placeholders verified.
- `tools/lint.py` and `tools/check.py`: 0 errors, 0 warnings.
- Art regenerated: 162 files, 17 characters, 20 weapons.
- Version bumped to 3.0.0.
