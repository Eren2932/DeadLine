from PIL import Image
import math, random, json, os

OUT = os.environ.get("ART_OUT", os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "art"))
os.makedirs(OUT, exist_ok=True)
OUTLINE = (14, 10, 14, 255)

def new(w, h):
    return Image.new("RGBA", (w, h), (0, 0, 0, 0))

def px(im, x, y, c):
    x = int(round(x)); y = int(round(y))
    if 0 <= x < im.width and 0 <= y < im.height:
        im.putpixel((x, y), c)

def get(im, x, y):
    x = int(x); y = int(y)
    if 0 <= x < im.width and 0 <= y < im.height:
        return im.getpixel((x, y))
    return (0, 0, 0, 0)

def rect(im, x0, y0, x1, y1, c):
    if x1 < x0: x0, x1 = x1, x0
    if y1 < y0: y0, y1 = y1, y0
    for y in range(int(y0), int(y1) + 1):
        for x in range(int(x0), int(x1) + 1):
            px(im, x, y, c)

def hline(im, x0, x1, y, c):
    rect(im, x0, y, x1, y, c)

def vline(im, x, y0, y1, c):
    rect(im, x, y0, x, y1, c)

def disc(im, cx, cy, r, c):
    for y in range(int(cy - r), int(cy + r) + 1):
        for x in range(int(cx - r), int(cx + r) + 1):
            if (x - cx) ** 2 + (y - cy) ** 2 <= r * r + r * 0.35:
                px(im, x, y, c)

def limb(im, x0, y0, x1, y1, w, c):
    n = int(max(abs(x1 - x0), abs(y1 - y0)) * 2) + 1
    r = (w - 1) / 2.0
    for i in range(n + 1):
        t = i / float(n)
        x = x0 + (x1 - x0) * t
        y = y0 + (y1 - y0) * t
        if w <= 1:
            px(im, x, y, c)
        else:
            for dy in range(int(-r - 0.5), int(r + 1.5)):
                for dx in range(int(-r - 0.5), int(r + 1.5)):
                    if dx * dx + dy * dy <= r * r + 0.6:
                        px(im, x + dx, y + dy, c)

def mix(c, o, a):
    return (int(c[0] + (o[0] - c[0]) * a), int(c[1] + (o[1] - c[1]) * a),
            int(c[2] + (o[2] - c[2]) * a), 255)

def light(c, a=0.30):
    return mix(c, (255, 250, 235), a)

def dark(c, a=0.32):
    return mix(c, (26, 14, 26), a)

def volumize(im, up=0.26, down=0.28):
    src = im.copy()
    w, h = im.size
    for y in range(h):
        for x in range(w):
            c = src.getpixel((x, y))
            if c[3] == 0:
                continue
            tl = src.getpixel((x - 1, y - 1)) if x > 0 and y > 0 else (0, 0, 0, 0)
            br = src.getpixel((x + 1, y + 1)) if x < w - 1 and y < h - 1 else (0, 0, 0, 0)
            if tl[3] == 0:
                im.putpixel((x, y), light(c, up))
            elif br[3] == 0:
                im.putpixel((x, y), dark(c, down))

def outline(im, col=OUTLINE):
    src = im.copy()
    w, h = im.size
    for y in range(h):
        for x in range(w):
            if src.getpixel((x, y))[3] != 0:
                continue
            hit = False
            for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                nx, ny = x + dx, y + dy
                if 0 <= nx < w and 0 <= ny < h and src.getpixel((nx, ny))[3] != 0:
                    hit = True; break
            if hit:
                im.putpixel((x, y), col)

def save(im, name, scale=1):
    if scale != 1:
        im = im.resize((im.width * scale, im.height * scale), Image.NEAREST)
    im.save(os.path.join(OUT, name))

def strip(frames, name, scale=1):
    fw, fh = frames[0].size
    sheet = new(fw * len(frames), fh)
    for i, f in enumerate(frames):
        sheet.alpha_composite(f, (i * fw, 0))
    save(sheet, name, scale)
    return {"path": "res://art/" + name, "frames": len(frames), "fw": fw * scale, "fh": fh * scale}
