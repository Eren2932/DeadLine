"""Composites the baked layers exactly the way Game.gd will draw them, so a
geometry mistake is visible on the desk instead of on the phone.

    python3 tools/envpreview.py            all 4 themes, PNG
    python3 tools/envpreview.py --gif      + animated GIF of every theme
    python3 tools/envpreview.py --guides   + belt guide lines and labels
"""
import os, sys, math, json, random
from PIL import Image

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import env as E

ROOT = E.ROOT
OUT = E.OUT
ZOOM = 1.5                      # Settings.ZOOM_VALUES[0]: the widest view
VW, VH = int(640 / ZOOM), int(360 / ZOOM)      # 426 x 240 world pixels
CAM_Y = 9                       # player at depth 0.5 (y=25) minus camera lift 16


def load(theme):
    d = {}
    for name in list(E.LAYERS) + ["moon"]:
        d[name] = Image.open(os.path.join(OUT, theme, name + ".png")).convert("RGBA")
    return d


def sil(canvas, x, y, h, col, dark):
    """Crude survivor/zombie silhouette - only there to prove scale and sorting."""
    w = max(3, int(h * 0.30))
    head = max(2, int(h * 0.22))
    d = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    p = d.load()
    for j in range(h):
        for i in range(w):
            if j < head:
                if abs(i - w / 2.0) < head * 0.42:
                    p[i, j] = col
            elif j < h * 0.68:
                p[i, j] = col if i else dark
            else:
                if i < w * 0.4 or i > w * 0.6:
                    p[i, j] = dark
    sh = Image.new("RGBA", (w + 6, 4), (0, 0, 0, 0))
    q = sh.load()
    for j in range(4):
        for i in range(w + 6):
            if ((i - (w + 6) / 2.0) / ((w + 6) / 2.0)) ** 2 + ((j - 2) / 2.0) ** 2 <= 1.0:
                q[i, j] = (0, 0, 0, 90)
    canvas.alpha_composite(sh, (int(x - (w + 6) / 2), int(y - 2)))
    canvas.alpha_composite(d, (int(x - w / 2), int(y - h)))


def frame(theme, imgs, cx, t, guides=False, actors=True):
    idx = E.LAYERS
    cv = Image.new("RGBA", (VW, VH), (0, 0, 0, 255))
    x0 = cx - VW / 2.0
    y0 = CAM_Y - VH / 2.0

    order = sorted(list(idx.items()), key=lambda kv: kv[1][3])
    drawn_actors = False
    for name, (h, ay, f, z) in order:
        if actors and not drawn_actors and z > 0:
            # entities live between the road and the foreground props
            _actors(cv, theme, x0, y0, t)
            drawn_actors = True
        im = imgs[name]
        shift = -((cx * (1.0 - f)) % E.TILE_W)
        sy = int(ay - y0)
        for k in range(-1, VW // E.TILE_W + 2):
            px = int(shift + k * E.TILE_W)
            if px > VW or px + E.TILE_W < 0:
                continue
            _paste(cv, im, px, sy)
        if name == "sky":
            th = E.THEMES[theme]
            mw = imgs["moon"].width
            mx = int(VW * th["moon_ax"] - mw / 2 + math.sin(t * 0.05) * 3)
            _paste(cv, imgs["moon"], mx, int(th["moon_y"] - y0 - imgs["moon"].height / 2))
            _stars(cv, theme, cx, t, x0, y0)
        if name == "mid":
            _windows(cv, theme, cx, t, x0, y0)
        if name == "near" and E.THEMES[theme]["beams"]:
            _beams(cv, theme, cx, t, x0, y0)
    if actors and not drawn_actors:
        _actors(cv, theme, x0, y0, t)
    _weather(cv, theme, t)
    if guides:
        _guides(cv, y0)
    return cv.convert("RGB").resize((640, 360), Image.NEAREST)


def _paste(cv, im, x, y):
    if x + im.width <= 0 or x >= cv.width or y + im.height <= 0 or y >= cv.height:
        return
    cv.alpha_composite(im, (x, y))


def _stars(cv, theme, cx, t, x0, y0):
    r = random.Random(7)
    for i in range(16):
        sx = r.randrange(0, VW)
        sy = r.randrange(0, 60)
        ph = r.random() * 6.28
        a = 0.6 + 0.4 * math.sin(t * 1.5 + ph)
        cv.alpha_composite(Image.new("RGBA", (1, 1), (255, 255, 255, int(200 * a))), (sx, sy))


def _windows(cv, theme, cx, t, x0, y0):
    r = random.Random(21)
    for i in range(14):
        wx = r.randrange(0, E.TILE_W)
        wy = r.randrange(-120, -50)
        ph = r.random() * 6.28
        sp = 0.5 + r.random() * 2.0
        if math.sin(t * sp * 3 + ph) > 0.75:
            f = E.LAYERS["mid"][2]
            sx = int((wx + cx * (1.0 - f)) % E.TILE_W - (cx * (1.0 - f)) % E.TILE_W + wx * 0)
            sx = int((wx - (cx * (1.0 - f)) % E.TILE_W) % E.TILE_W)
            cv.alpha_composite(Image.new("RGBA", (1, 1), (255, 243, 196, 150)),
                               (sx, int(wy - y0)))


def _beams(cv, theme, cx, t, x0, y0):
    for i, bx in enumerate((60, 300)):
        a = math.sin(t * 0.25 + i * 2) * 0.5
        base = (int(bx - (cx * 0.34) % E.TILE_W), int(E.HORIZON_Y - y0))
        beam = Image.new("RGBA", (VW, VH), (0, 0, 0, 0))
        p = beam.load()
        for j in range(0, 150):
            wdt = 2 + j * 0.14
            for i2 in range(int(-wdt), int(wdt) + 1):
                x = int(base[0] + i2 + math.tan(a) * j)
                y = int(base[1] - j)
                if 0 <= x < VW and 0 <= y < VH:
                    p[x, y] = (190, 225, 255, int(46 * (1.0 - j / 150.0)))
        cv.alpha_composite(beam)


def _actors(cv, theme, x0, y0, t):
    """Player at mid depth, three zombies at three depths - the whole point of
    the belt is that these four read as being at different distances."""
    import env as EE
    def put(depth, wx, col, dark, base_h):
        y = EE.BELT_TOP + depth * EE.BELT_H
        s = 0.88 + (1.10 - 0.88) * depth
        sil(cv, wx - x0, y - y0, int(base_h * s), col, dark)
    put(0.06, x0 + 90, (74, 96, 74, 255), (44, 58, 44, 255), 34)
    put(0.34, x0 + 250, (86, 84, 70, 255), (52, 50, 42, 255), 34)
    put(0.52, x0 + 170, (196, 188, 170, 255), (120, 112, 100, 255), 38)   # player
    put(0.88, x0 + 330, (92, 70, 70, 255), (56, 42, 42, 255), 34)


def _weather(cv, theme, t):
    th = E.THEMES[theme]
    kind = th["particle"]
    col = E.hx(th["pcolor"])
    r = random.Random(99)
    n = 110 if kind == "rain" else (90 if kind == "snow" else 55)
    lay = Image.new("RGBA", (VW, VH), (0, 0, 0, 0))
    p = lay.load()
    for i in range(n):
        bx, by, sp = r.random() * VW, r.random() * VH, 0.4 + r.random() * 1.2
        ph = r.random() * 6.28
        if kind == "rain":
            x = (bx - t * 140 * sp) % VW
            y = (by + t * 260 * sp) % VH
            for k in range(6):
                xx, yy = int(x - k * 0.34), int(y + k)
                if 0 <= xx < VW and 0 <= yy < VH:
                    p[xx, yy] = (col[0], col[1], col[2], 90)
        elif kind == "snow":
            x = (bx + math.sin(t * 0.6 + ph) * 8 + t * 10 * sp) % VW
            y = (by + t * 22 * sp) % VH
            p[int(x), int(y)] = (col[0], col[1], col[2], int(140 + 80 * math.sin(t + ph)))
        else:
            x = (bx + math.sin(t * 0.4 + ph) * 10 + t * 6 * sp) % VW
            y = (by - t * 14 * sp) % VH
            p[int(x), int(y)] = (col[0], col[1], col[2], int(70 + 80 * abs(math.sin(t * 0.8 + ph))))
    cv.alpha_composite(lay)


def _guides(cv, y0):
    p = cv.load()
    marks = [(E.HORIZON_Y, (255, 200, 60)), (E.BELT_TOP, (60, 255, 120)),
             (E.BELT_BOT, (60, 255, 120)), (96, (80, 160, 255))]
    for wy, c in marks:
        y = int(wy - y0)
        if 0 <= y < VH:
            for x in range(0, VW, 4):
                p[x, y] = (c[0], c[1], c[2], 255)


def main():
    gif = "--gif" in sys.argv
    guides = "--guides" in sys.argv
    for theme in E.THEMES:
        imgs = load(theme)
        frame(theme, imgs, 500.0, 0.0, guides).save(
            os.path.join(OUT, "preview_%s.png" % theme))
        print("preview_%s.png" % theme)
        if gif:
            frames = []
            for i in range(36):
                t = i / 12.0
                frames.append(frame(theme, imgs, 500.0 + t * 34.0, t, guides))
            frames[0].save(os.path.join(OUT, "preview_%s.gif" % theme),
                           save_all=True, append_images=frames[1:],
                           duration=83, loop=0, optimize=True)
            print("preview_%s.gif" % theme)


if __name__ == "__main__":
    main()
