import numpy as np, wave, os, math
SR = 22050
OUT = os.environ.get("SFX_OUT", os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "sfx"))
os.makedirs(OUT, exist_ok=True)
rng = np.random.default_rng(4)

def w(name, data, gain=0.9):
    d = np.asarray(data, dtype=np.float64)
    m = np.max(np.abs(d)) or 1.0
    d = d / m * gain
    pcm = (d * 32000).astype("<i2")
    f = wave.open(os.path.join(OUT, name + ".wav"), "wb")
    f.setnchannels(1); f.setsampwidth(2); f.setframerate(SR)
    f.writeframes(pcm.tobytes()); f.close()

def t(dur): return np.arange(int(SR * dur)) / SR
def env(n, a=0.002, d=0.2, p=1.6):
    e = np.ones(n)
    at = int(SR * a)
    if at > 0: e[:at] = np.linspace(0, 1, at)
    dec = np.linspace(1, 0, n - at) ** p
    e[at:] = dec
    return e
def noise(n): return rng.normal(0, 1, n)
def lp(x, a=0.25):
    y = np.zeros_like(x); acc = 0.0
    for i in range(len(x)):
        acc += a * (x[i] - acc); y[i] = acc
    return y
def hp(x, a=0.25): return x - lp(x, a)

# gunshot
n = int(SR * 0.16)
body = lp(noise(n), 0.45) * env(n, 0.001, 0.16, 2.4)
tone = np.sin(2 * np.pi * 140 * t(0.16)) * env(n, 0.001, 0.16, 3.0) * 0.5
w("shot", body + tone)

n = int(SR * 0.3)
w("shot_big", lp(noise(n), 0.28) * env(n, 0.001, 0.3, 2.0)
   + np.sin(2 * np.pi * 80 * t(0.3)) * env(n, 0.001, 0.3, 2.4) * 0.7)

n = int(SR * 0.36)
w("shotgun", lp(noise(n), 0.5) * env(n, 0.001, 0.36, 1.6)
   + lp(noise(n), 0.12) * env(n, 0.001, 0.36, 1.2) * 0.8)

n = int(SR * 0.24)
f = np.linspace(1800, 260, n)
w("laser", np.sin(2 * np.pi * np.cumsum(f) / SR) * env(n, 0.001, 0.24, 2.2))

n = int(SR * 0.3)
buzz = np.sign(np.sin(2 * np.pi * 90 * t(0.3))) * 0.4 + hp(noise(n), 0.5) * 0.8
w("zap", buzz * env(n, 0.001, 0.3, 2.0))

n = int(SR * 0.5)
w("flame", (lp(noise(n), 0.06) * 1.4 + hp(noise(n), 0.7) * 0.3) * env(n, 0.05, 0.5, 1.0))

n = int(SR * 0.9)
rumble = np.sin(2 * np.pi * np.linspace(120, 32, n) * t(0.9)) * env(n, 0.002, 0.9, 1.4)
w("explosion", lp(noise(n), 0.1) * env(n, 0.001, 0.9, 1.6) * 1.2 + rumble)

n = int(SR * 0.1)
w("hit", lp(noise(n), 0.35) * env(n, 0.001, 0.1, 3.0)
   + np.sin(2 * np.pi * 220 * t(0.1)) * env(n, 0.001, 0.1, 4.0) * 0.6)

n = int(SR * 0.22)
w("splat", lp(noise(n), 0.16) * env(n, 0.004, 0.22, 1.4)
   + np.sin(2 * np.pi * np.linspace(300, 90, n) * t(0.22)) * env(n, 0.01, 0.22, 2.0) * 0.4)

n = int(SR * 0.8)
base = np.linspace(96, 70, n)
gr = (np.sin(2 * np.pi * np.cumsum(base) / SR)
      + 0.5 * np.sin(2 * np.pi * np.cumsum(base * 2.1) / SR)
      + 0.3 * np.sin(2 * np.pi * np.cumsum(base * 3.4) / SR))
w("groan", gr * env(n, 0.12, 0.8, 1.2) * (1 + 0.3 * np.sin(2 * np.pi * 7 * t(0.8))))

n = int(SR * 0.42)
rl = np.zeros(n)
for off, ln in ((0.0, 0.05), (0.16, 0.06), (0.3, 0.05)):
    s = int(SR * off); ln_n = int(SR * ln)
    rl[s:s + ln_n] += lp(noise(ln_n), 0.6) * env(ln_n, 0.001, ln, 3.0)
w("reload", rl)

n = int(SR * 0.05)
w("click", hp(noise(n), 0.6) * env(n, 0.001, 0.05, 4.0), 0.6)

n = int(SR * 0.6)
lv = np.zeros(n)
for i, fr in enumerate((440, 587, 740, 880)):
    s = int(SR * 0.1 * i); ln = int(SR * 0.25)
    seg = np.sin(2 * np.pi * fr * t(0.25)) * env(ln, 0.005, 0.25, 2.0)
    lv[s:s + ln] += seg[:len(lv[s:s + ln])]
w("levelup", lv)

n = int(SR * 0.35)
w("hurt", np.sin(2 * np.pi * np.linspace(200, 70, n) * t(0.35)) * env(n, 0.002, 0.35, 1.8)
   + lp(noise(n), 0.3) * env(n, 0.001, 0.35, 3.0) * 0.6)

n = int(SR * 0.3)
w("build", lp(noise(n), 0.2) * env(n, 0.001, 0.3, 2.2)
   + np.sin(2 * np.pi * 320 * t(0.3)) * env(n, 0.001, 0.3, 3.4) * 0.5)

n = int(SR * 0.5)
saw = np.sign(np.sin(2 * np.pi * 62 * t(0.5))) * 0.5 + hp(noise(n), 0.4) * 0.5
w("saw", saw * env(n, 0.02, 0.5, 0.6))
print(sorted(os.listdir(OUT)))


# ============================ extra pack ============================
def sat(x, g=3.0):
    return np.tanh(x * g)

# boss roar: growling formants sweeping down
n = int(SR * 1.5)
tt = t(1.5)
base = np.linspace(105, 58, n)
gr = np.sin(2 * np.pi * np.cumsum(base) / SR)
gr += 0.6 * np.sin(2 * np.pi * np.cumsum(base * 1.5) / SR)
gr += 0.35 * np.sin(2 * np.pi * np.cumsum(base * 2.51) / SR)
growl = 1.0 + 0.45 * np.sin(2 * np.pi * 24 * tt)
body = sat(gr * growl, 2.2) * env(n, 0.06, 1.5, 1.1)
air = lp(noise(n), 0.08) * env(n, 0.1, 1.5, 1.4) * 0.5
w("roar", body + air)

# wave siren
n = int(SR * 1.8)
tt = t(1.8)
swp = 520 + 240 * np.sin(2 * np.pi * 0.9 * tt)
sir = np.sin(2 * np.pi * np.cumsum(swp) / SR)
sir += 0.4 * np.sin(2 * np.pi * np.cumsum(swp * 2.0) / SR)
amp = np.clip(np.sin(np.pi * tt / 1.8) * 1.4, 0, 1)
w("siren", sat(sir, 1.6) * amp)

# crate opening: wood crack + rattle
n = int(SR * 0.45)
crack = hp(noise(n), 0.55) * env(n, 0.001, 0.45, 3.2)
wood = np.sin(2 * np.pi * 220 * t(0.45)) * env(n, 0.001, 0.2, 4.0) * 0.6
w("crate", crack + wood)

# ui blip
n = int(SR * 0.07)
w("ui", np.sin(2 * np.pi * 880 * t(0.07)) * env(n, 0.001, 0.07, 3.0) * 0.7
   + np.sin(2 * np.pi * 1320 * t(0.07)) * env(n, 0.001, 0.05, 4.0) * 0.3)

# dry fire click
n = int(SR * 0.08)
w("empty", hp(noise(n), 0.7) * env(n, 0.0005, 0.08, 6.0)
   + np.sin(2 * np.pi * 320 * t(0.08)) * env(n, 0.001, 0.03, 6.0) * 0.4)

# heal chime
n = int(SR * 0.5)
tt = t(0.5)
ch = np.zeros(n)
for i, f in enumerate([523.0, 659.0, 784.0]):
    ch += np.sin(2 * np.pi * f * tt) * env(n, 0.01 + i * 0.05, 0.5, 2.0) / 3.0
w("heal", ch)

# coin
n = int(SR * 0.3)
tt = t(0.3)
co = np.sin(2 * np.pi * 1180 * tt) * env(n, 0.001, 0.1, 4.0)
co += np.sin(2 * np.pi * 1760 * tt) * env(n, 0.03, 0.3, 3.0) * 0.7
w("coin", co)

# dash whoosh
n = int(SR * 0.3)
w("dash", lp(hp(noise(n), 0.25), 0.35) * np.clip(np.sin(np.pi * t(0.3) / 0.3) ** 2, 0, 1) * 1.2)

# structure thud
n = int(SR * 0.28)
w("thud", np.sin(2 * np.pi * np.linspace(150, 60, n) * t(0.28)) * env(n, 0.001, 0.28, 2.2)
   + lp(noise(n), 0.2) * env(n, 0.001, 0.12, 3.0) * 0.6)

# headshot crunch
n = int(SR * 0.26)
w("headshot", lp(noise(n), 0.35) * env(n, 0.001, 0.26, 2.6) * 1.1
   + np.sin(2 * np.pi * np.linspace(420, 90, n) * t(0.26)) * env(n, 0.001, 0.2, 3.0) * 0.8)

# melee whoosh
n = int(SR * 0.22)
w("whoosh", lp(hp(noise(n), 0.3), 0.5) * env(n, 0.02, 0.22, 2.0))

# powerup / airdrop horn
n = int(SR * 1.1)
tt = t(1.1)
hn = sat(np.sin(2 * np.pi * 116 * tt) + 0.7 * np.sin(2 * np.pi * 174 * tt), 2.4)
w("horn", hn * np.clip(np.sin(np.pi * tt / 1.1) * 1.5, 0, 1))
print("sfx extra ok")
