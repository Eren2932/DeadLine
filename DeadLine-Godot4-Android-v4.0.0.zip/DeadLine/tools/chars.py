"""Character sprite generator.

v3.0 rig overhaul
=================
Two things were wrong before and both are fixed here.

1. WEAPON HOLDING.  The old rig baked the arms into the body sheet and only
   exported one hand point, so the gun could never really line up: it floated,
   it jittered between frames and it fought the aim angle.  Now the player
   sheets are drawn WITHOUT arms and every frame exports its shoulder pivot.
   The arms are separate limb sprites that the engine rigs with two bone IK
   straight onto the grip and foregrip of the weapon, so the gun is welded to
   the hands at any aim angle, during recoil, while reloading and while it is
   lowered.

2. ZOMBIE WALK.  The shamble is a real gait now: a long stance phase with the
   foot pinned to the road, a dragged leg that scuffs along the ground instead
   of stepping, hip drop on the bad side, torso list, a forward lurch once per
   stride and a lolling head.  No more moonwalking.
"""
import math, random
from core import *

CW, CH = 26, 38          # cell for normal humans
FEET = 36

# ---- rig proportions (pixels)
THIGH = 7.4
SHIN = 7.4
UPPER_ARM = 5.2
FOREARM = 5.6
STRIDE = 8.8             # full step length
DUTY = 0.66              # share of the cycle a foot spends on the ground


def pal(skin, shirt, pants, hair, boots=(40, 34, 40), gear=None, blood=(150, 18, 22),
        bare_arms=False, glove=None, hand=None):
    skin = tuple(list(skin)[:3] + [255])
    return {"skin": skin, "shirt": shirt, "pants": pants, "hair": hair,
            "boots": boots, "gear": gear or dark(shirt, 0.35), "blood": blood,
            "bare_arms": bare_arms, "glove": glove or (46, 42, 44, 255),
            "hand": hand or dark(skin, 0.25)}


# ------------------------------------------------------------------ math
def _ik(ax, ay, bx, by, l1, l2, flip=1.0):
    """Two bone IK. Returns the joint position between (ax,ay) and (bx,by)."""
    dx, dy = bx - ax, by - ay
    d = math.hypot(dx, dy)
    if d < 0.0001:
        d = 0.0001
        dx, dy = 0.0001, 0.0
    d = min(d, l1 + l2 - 0.02)
    d = max(d, abs(l1 - l2) + 0.02)
    ux, uy = dx / max(d, 0.0001), dy / max(d, 0.0001)
    a = (l1 * l1 - l2 * l2 + d * d) / (2.0 * d)
    h = math.sqrt(max(0.0, l1 * l1 - a * a))
    mx, my = ax + ux * a, ay + uy * a
    return mx + flip * (-uy) * h, my + flip * ux * h


def _foot(phase, stride, lift, ground, drag=0.0):
    """Gait cycle for one foot. Returns (x offset from hip, y, planted).

    drag = 0  -> a clean step: the foot lifts, arcs forward and re-plants.
    drag = 1  -> a scuff: the toe never leaves the road, it is shoved forward
                 in a slow, uneven slide (this is what makes a shamble read as
                 a shamble instead of a dance move).
    """
    p = phase % 1.0
    duty = DUTY + 0.14 * drag
    if p < duty:
        t = p / duty
        return stride * 0.5 - stride * t, ground, True
    t = (p - duty) / (1.0 - duty)
    if drag > 0.5:
        # scuff: ease-in only, stays on the ground, tiny hop at the very end
        ease = t * t
        lift_now = math.sin(math.pi * t) * lift * 0.25
        return -stride * 0.5 + stride * ease, ground - lift_now, t > 0.9
    ease = t * t * (3.0 - 2.0 * t)
    return -stride * 0.5 + stride * ease, ground - math.sin(math.pi * t) * lift, False


# ------------------------------------------------------------------ drawing
def draw_char(P, phase=0.0, hunch=0.0, cw=CW, ch=CH, feet=FEET, walk=1.0,
              helmet=False, vest=False, torn=0.0, gore=0.0, arm_reach=1.0,
              fat=0.0, rnd=None, backpack=False,
              arms=True, limp=0.0, lean=0.0, attack=0.0, breathe=0.0,
              shamble=0.0):
    """Side-view character facing right.

    Returns (image, info) where info holds the rigging anchors of this frame:
        {"hand": (x, y), "shoulder": (x, y)}
    With arms=False the arms are left out of the sheet entirely (the engine
    rigs them live) - that is the mode every player suit is generated in.
    """
    rnd = rnd or random.Random(7)
    im = new(cw, ch)
    a = phase * math.tau

    # ---- root motion -------------------------------------------------
    bob = (-math.cos(2.0 * a) * 0.5 + 0.5) * 1.5 * walk
    bob += math.sin(a * 2.0 + 1.1) * 0.25 * breathe
    # a shambler drops the hip on the bad side once per stride
    bob += max(0.0, math.sin(a)) * 1.1 * shamble * walk
    sway = math.sin(a) * 0.5 * walk
    # forward lurch: the upper body is thrown ahead every other step
    lurch = math.sin(a - 0.6) * 1.5 * shamble * walk
    lean_px = (lean + walk * 0.9) * 1.4 + hunch * 2.2 + attack * 2.0 + lurch

    hip_x = cw * 0.5 + sway * 0.4
    hip_y = feet - 14 + bob
    sh_x = hip_x + lean_px
    sh_y = hip_y - 9.0 + hunch * 1.6
    sh_x += math.sin(a + math.pi) * 0.6 * walk
    # head lolls on a slack neck when shambling
    hd_x = sh_x + 0.6 + hunch * 1.6 + attack * 1.2 + math.sin(a * 0.5) * 1.1 * shamble
    hd_y = sh_y - 4.6 - fat * 0.5 + math.sin(2.0 * a + 0.6) * 0.35 * walk \
        + abs(math.sin(a * 0.5)) * 0.5 * shamble
    head_r = 3.4 + fat * 0.7

    skin, skin_d = P["skin"], dark(P["skin"], 0.28)
    pants, pants_d = P["pants"], dark(P["pants"], 0.30)
    shirt = P["shirt"]
    ground = float(feet)

    # ---- legs ---------------------------------------------------------
    def leg(leg_phase, col, w, drag=0.0, boot=None):
        stride = STRIDE * walk * (1.0 - 0.42 * drag)
        lift = (3.2 * walk + 0.3) * (1.0 - 0.75 * drag)
        fx_off, fy, planted = _foot(leg_phase, stride, lift, ground, drag)
        fx = cw * 0.5 + fx_off
        kx, ky = _ik(hip_x, hip_y, fx, fy, THIGH, SHIN, -1.0)
        if drag > 0.4:
            # the bad knee never straightens and turns out sideways
            kx += 1.1 * drag
            ky -= 0.6 * drag
        limb(im, hip_x, hip_y, kx, ky, w, col)
        limb(im, kx, ky, fx, fy, max(2, w - 1), col)
        toe = 0 if planted else -1
        bcol = boot if boot is not None else P["boots"]
        rect(im, fx - 2, fy - 1, fx + 2, fy, bcol)
        rect(im, fx - 1 + toe, fy - 2, fx + 2, fy - 2, dark(bcol, 0.15))
        return fx, fy

    lw = 4 + int(fat)
    # back leg is a bit more than half a cycle behind for shamblers: the limp
    # makes the rhythm uneven, which is exactly what a dragging body looks like
    back_phase = phase + 0.5 + 0.06 * shamble
    leg(back_phase, dark(P["pants"], 0.48), lw, drag=limp,
        boot=dark(P["boots"], 0.35))

    # ---- arms ---------------------------------------------------------
    bare = P.get("bare_arms", False)
    fore_back = dark(P["skin"], 0.42) if bare else dark(shirt, 0.5)
    fore_front = P["skin"] if bare else P.get("glove", dark(shirt, 0.25))

    def arm_to(tx, ty, upper_col, fore_col, w, flip=1.0, shoulder_dy=1.0):
        ax, ay = sh_x, sh_y + shoulder_dy
        ex, ey = _ik(ax, ay, tx, ty, UPPER_ARM, FOREARM, flip)
        limb(im, ax, ay, ex, ey, w, upper_col)
        limb(im, ex, ey, tx, ty, max(2, w - 1), fore_col)
        disc(im, tx, ty, 1.3, P.get("hand", skin_d))
        return tx, ty

    def hand_target(swing_phase, reach):
        s = math.sin(swing_phase * math.tau)
        base_x = sh_x + 2.2 + reach * 3.2 + fat * 1.0
        return (base_x + s * 3.4 * walk + attack * 4.5,
                sh_y + 7.2 - reach * 3.0 - abs(s) * 0.8 * walk - attack * 2.0)

    aw = 3 + int(fat)
    hx, hy = sh_x + 6.6, sh_y + 2.4
    if arms:
        back_hand = arm_to(*hand_target(phase + 0.5, arm_reach * 0.92),
                           upper_col=dark(shirt, 0.45), fore_col=fore_back,
                           w=aw, flip=1.0, shoulder_dy=1.2)
        hx, hy = back_hand

    # ---- torso ---------------------------------------------------------
    top_w = 4 + fat * 2 + (0.25 if breathe > 0 and math.sin(a) > 0 else 0.0)
    bot_w = 3.5 + fat * 2
    steps = 16
    for i in range(steps + 1):
        t = i / steps
        x = sh_x + (hip_x - sh_x) * t
        y = sh_y + (hip_y - sh_y) * t
        w = top_w + (bot_w - top_w) * t
        col = shirt if t < 0.72 else pants
        rect(im, x - w, y, x + w - 1, y, col)
    rect(im, sh_x - top_w, sh_y + 1, sh_x + top_w - 1, sh_y + 1, light(shirt, 0.18))
    rect(im, hip_x - bot_w, hip_y - 3, hip_x + bot_w - 1, hip_y - 3, dark(P["boots"], 0.0))
    px(im, hip_x + 1, hip_y - 3, (214, 178, 66, 255))
    if vest:
        rect(im, sh_x - top_w + 1, sh_y + 2, sh_x + top_w - 2, sh_y + 7, P["gear"])
        rect(im, sh_x - 1, sh_y + 3, sh_x, sh_y + 4, dark(P["gear"], 0.4))
        rect(im, sh_x + 1, sh_y + 5, sh_x + 2, sh_y + 6, dark(P["gear"], 0.4))
        rect(im, sh_x - top_w + 1, sh_y + 3, sh_x - top_w + 1, sh_y + 6, light(P["gear"], 0.2))
    if backpack:
        rect(im, sh_x - top_w - 2, sh_y + 2, sh_x - top_w, sh_y + 8, P["gear"])
        rect(im, sh_x - top_w - 2, sh_y + 4, sh_x - top_w, sh_y + 4, dark(P["gear"], 0.3))
    if torn > 0:
        for _ in range(int(10 * torn)):
            x = rnd.randint(int(sh_x - top_w), int(sh_x + top_w))
            y = rnd.randint(int(sh_y + 2), int(hip_y - 1))
            px(im, x, y, skin_d if rnd.random() < 0.6 else (0, 0, 0, 0))

    # ---- front leg (over the torso) ------------------------------------
    leg(phase, light(P["pants"], 0.10), lw)

    # ---- neck + head ----------------------------------------------------
    rect(im, hd_x - 1, hd_y + 2, hd_x + 1, sh_y + 1, dark(skin, 0.2))
    disc(im, hd_x, hd_y, head_r, skin)
    rect(im, hd_x - head_r + 0.5, hd_y + 2, hd_x + head_r - 1.5, hd_y + 3, skin)
    px(im, hd_x + 2, hd_y - 1, (24, 18, 22, 255))
    px(im, hd_x + 1, hd_y - 1, (238, 238, 230, 255))
    rect(im, hd_x - 1, hd_y + 2, hd_x + 1, hd_y + 2, dark(skin, 0.35))
    if helmet:
        for x in range(int(hd_x - head_r - 0.5), int(hd_x + head_r + 0.5)):
            rect(im, x, hd_y - head_r - 1.6, x, hd_y - 2 - abs(x - hd_x) * 0.2, P["gear"])
        rect(im, hd_x - 4, hd_y - 2, hd_x + 3, hd_y - 2, dark(P["gear"], 0.25))
        rect(im, hd_x - 4, hd_y - 5, hd_x + 3, hd_y - 5, light(P["gear"], 0.25))
    else:
        for x in range(int(hd_x - head_r - 0.5), int(hd_x + head_r - 0.5)):
            rect(im, x, hd_y - head_r - 0.6, x, hd_y - 1 - abs(x - hd_x) * 0.35, P["hair"])
        rect(im, hd_x - 4, hd_y - 3, hd_x - 4, hd_y + 1, P["hair"])

    # ---- front arm (drawn last, in front of everything) -----------------
    if arms:
        hx, hy = arm_to(*hand_target(phase, arm_reach),
                        upper_col=shirt, fore_col=fore_front,
                        w=aw, flip=1.0, shoulder_dy=1.0)

    if gore > 0:
        b = P["blood"]
        for _ in range(int(16 * gore)):
            x = rnd.randint(2, cw - 3); y = rnd.randint(int(sh_y - 4), feet - 1)
            if get(im, x, y)[3] != 0:
                px(im, x, y, b if rnd.random() < 0.7 else dark(b, 0.35))

    volumize(im)
    outline(im)
    return im, {"hand": (hx, hy), "shoulder": (sh_x, sh_y + 1.0)}


# ------------------------------------------------------------------ limbs
def limb_sprites(P, w=3, up_len=UPPER_ARM, fore_len=FOREARM):
    """The four arm pieces the engine rigs live, drawn pointing right.

    Every piece has its pivot on the LEFT edge, vertically centred, so the
    engine can simply rotate it around that point:
        upper arm : shoulder -> elbow
        forearm   : elbow -> hand (the hand blob is baked on the far end)
    Front pieces are lit, back pieces are shaded, which keeps the depth
    reading right when the gun sits between them.
    """
    bare = P.get("bare_arms", False)
    out = {}
    specs = {
        "upper_front": (up_len, P["shirt"], w),
        "upper_back": (up_len, dark(P["shirt"], 0.45), w),
        "fore_front": (fore_len, P["skin"] if bare else P.get("glove"), max(2, w - 1)),
        "fore_back": (fore_len, dark(P["skin"], 0.42) if bare else dark(P["shirt"], 0.5),
                      max(2, w - 1)),
    }
    for key, (length, col, thick) in specs.items():
        pad = 3
        iw = int(math.ceil(length)) + pad * 2
        ih = thick + 4
        im = new(iw, ih)
        cy = ih / 2.0 - 0.5
        limb(im, pad, cy, pad + length, cy, thick, col)
        if key.startswith("fore"):
            hand_col = P.get("hand") if not key.endswith("back") else dark(P.get("hand"), 0.25)
            disc(im, pad + length, cy, 1.4, hand_col)
        volumize(im, 0.22, 0.24)
        outline(im)
        out[key] = {"img": im, "pivot": (pad, cy), "len": length}
    return out


# ------------------------------------------------------------------ strips
def anim(P, frames, **kw):
    """Returns (frames, hands, shoulders)."""
    out, hands, shoulders = [], [], []
    for i in range(frames):
        im, info = draw_char(P, phase=i / float(frames), **kw)
        out.append(im)
        hands.append(info["hand"])
        shoulders.append(info["shoulder"])
    return out, hands, shoulders


def attack_frames(P, n=5, reach=1.3, **kw):
    """Wind up, lunge, swipe, recover. Reads as a real attack, not a pose."""
    out, hands, shoulders = [], [], []
    curve = [-0.35, -0.55, 0.9, 1.0, 0.35]
    while len(curve) < n:
        curve.append(curve[-1])
    for i in range(n):
        k = curve[int(i * len(curve) / n)]
        im, info = draw_char(P, phase=0.0, walk=0.12,
                             arm_reach=reach + k * 0.55,
                             attack=max(0.0, k),
                             lean=k * 0.8, **kw)
        out.append(im)
        hands.append(info["hand"])
        shoulders.append(info["shoulder"])
    return out, hands, shoulders


def death_frames(P, n=6, **kw):
    """Staggers back, buckles, then folds into a bloody heap."""
    out = []
    cw = kw.get("cw", CW)
    feet = kw.get("feet", FEET)
    for i in range(n):
        t = i / float(n - 1)
        im = new(cw, kw.get("ch", CH))
        stagger = math.sin(min(1.0, t * 3.0) * math.pi) * 0.5
        base, _info = draw_char(P, phase=0.0, walk=0.0, lean=-1.6 * stagger, **kw)
        ang = -(t ** 1.35) * 86.0
        r = base.rotate(ang, resample=Image.NEAREST, center=(base.width / 2, feet))
        im.alpha_composite(r)
        if t > 0.3:
            b = P["blood"]
            rnd = random.Random(int(t * 100))
            for _ in range(int(t * 30)):
                x = rnd.randint(1, im.width - 2)
                y = feet - rnd.randint(0, 3)
                px(im, x, y, b if rnd.random() < 0.6 else dark(b, 0.4))
        out.append(im)
    return out
