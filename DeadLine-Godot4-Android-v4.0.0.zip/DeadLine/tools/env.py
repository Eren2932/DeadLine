"""DeadLine environment baker - 4 themes x 11 seamless layers.

Every layer is TILEABLE horizontally (drawn with wrapping plot functions), so
Game._layer can repeat it forever without a seam, and every layer carries a
fixed WORLD anchor Y that comes straight out of World.gd:

    HORIZON_Y = -34   fence base, far edge of the world
    BELT_TOP  = -22   depth 0.0, the far curb  (drawn, not invisible)
    BELT_BOT  =  72   depth 1.0, the near curb (drawn, not invisible)

Run:  python3 tools/env.py            -> art/env/<theme>/*.png + index.json
      python3 tools/env.py --preview  -> also art/env/preview_<theme>.png
      python3 tools/env.py --gif      -> also art/env/preview_<theme>.gif
"""
import os, sys, math, json, random

from PIL import Image

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, "art", "env")

TILE_W = 320          # every layer is this wide and wraps seamlessly

# ------------------------------------------------------------------ geometry
# Kept 1:1 with scripts/World.gd - tools/check.py verifies it.
HORIZON_Y = -34
CURB_H = 12
BELT_TOP = -22
BELT_BOT = 72
BELT_H = BELT_BOT - BELT_TOP        # 94

# layer name -> (height, world y of the image's TOP row, parallax factor, z)
LAYERS = {
    "sky":        (350, -160, 0.00, -60),
    "far":        ( 80, -110, 0.20, -50),
    "mid":        ( 66,  -92, 0.40, -46),
    "near":       ( 48,  -72, 0.66, -42),
    "fence":      ( 32,  -60, 0.80, -38),
    "fog":        ( 34,  -52, 0.86, -34),
    "curb_far":   ( 14,  -35, 1.00, -30),
    "road":       (100,  -22, 1.00, -28),
    "curb_near":  ( 28,   72, 1.00, 120),
    "props_near": (150,   50, 1.00, 122),
}
MOON = (96, 96, 0.04, -58)          # single sprite, never tiled


# ------------------------------------------------------------------ colour utils
def hx(h):
    h = h.lstrip("#")
    return (int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16))


def mix(a, b, t):
    t = max(0.0, min(1.0, t))
    return (int(a[0] + (b[0] - a[0]) * t),
            int(a[1] + (b[1] - a[1]) * t),
            int(a[2] + (b[2] - a[2]) * t))


def shade(c, t):
    """t > 0 lighter, t < 0 darker - stays in the theme's own hue."""
    if t >= 0:
        return mix(c, (255, 248, 230), t)
    return mix(c, (8, 6, 12), -t)


def rgba(c, a=255):
    return (c[0], c[1], c[2], int(a))


BAYER = [
    [0, 8, 2, 10], [12, 4, 14, 6],
    [3, 11, 1, 9], [15, 7, 13, 5],
]


def dither(x, y, v):
    """Ordered 4x4 dither of a 0..1 value -> bool. Kills gradient banding."""
    return v * 16.0 > BAYER[y & 3][x & 3] + 0.5


# ------------------------------------------------------------------ raster utils
class Layer:
    """RGBA canvas with wrapping (tileable) drawing."""

    def __init__(self, w, h):
        self.w, self.h = w, h
        self.im = Image.new("RGBA", (w, h), (0, 0, 0, 0))
        self.px = self.im.load()

    def put(self, x, y, c):
        y = int(y)
        if y < 0 or y >= self.h:
            return
        self.px[int(x) % self.w, y] = c

    def blend(self, x, y, c, a):
        """a in 0..1 over whatever is already there."""
        y = int(y)
        if y < 0 or y >= self.h or a <= 0.0:
            return
        x = int(x) % self.w
        o = self.px[x, y]
        if o[3] == 0:
            self.px[x, y] = (c[0], c[1], c[2], int(255 * a))
            return
        na = a + (o[3] / 255.0) * (1.0 - a)
        self.px[x, y] = (
            int(c[0] * a + o[0] * (1 - a)),
            int(c[1] * a + o[1] * (1 - a)),
            int(c[2] * a + o[2] * (1 - a)),
            int(min(255, na * 255)))

    def rect(self, x, y, w, h, c):
        for yy in range(int(y), int(y + h)):
            for xx in range(int(x), int(x + w)):
                self.put(xx, yy, c)

    def hline(self, x, y, w, c):
        self.rect(x, y, w, 1, c)

    def vline(self, x, y, h, c):
        self.rect(x, y, 1, h, c)

    def save(self, path):
        self.im.save(path)


def frnd(r, a, b):
    return a + (b - a) * r.random()


# ------------------------------------------------------------------ layers
def bake_sky(t, seed):
    """Banded dithered gradient + baked faint stars. No mush, no banding."""
    L = Layer(TILE_W, LAYERS["sky"][0])
    top_y = LAYERS["sky"][1]
    sky = [hx(c) for c in t["sky"]]
    horizon_row = HORIZON_Y - top_y            # image row of the horizon
    n = len(sky) - 1
    for y in range(L.h):
        f = max(0.0, min(1.0, y / float(max(1, horizon_row))))
        i = min(n - 1, int(f * n))
        lf = f * n - i
        a, b = sky[i], sky[i + 1]
        c0 = mix(a, b, math.floor(lf * 8) / 8.0)
        c1 = mix(a, b, math.ceil(lf * 8) / 8.0)
        frac = (lf * 8) % 1.0
        for x in range(L.w):
            L.put(x, y, rgba(c1 if dither(x, y, frac) else c0))
    r = random.Random(seed)
    star_bottom = int(horizon_row * 0.72)
    for _ in range(t["stars"]):
        x = r.randrange(L.w)
        y = r.randrange(0, max(2, star_bottom))
        b = frnd(r, 0.25, 0.75)
        L.blend(x, y, (255, 255, 255), b)
        if r.random() > 0.9:
            L.blend(x + 1, y, (255, 255, 255), b * 0.5)
    return L


def bake_moon(t, seed):
    """Disc + craters + a halo built from a few SOLID rings. The dithered halo
    of the first pass read as a checkerboard patch stuck to the sky."""
    w, h = MOON[0], MOON[1]
    L = Layer(w, h)
    r = random.Random(seed + 5)
    cx, cy = w // 2, h // 2
    rad = int(t["moon_r"])
    body = hx(t["moon"])
    glow = hx(t["moon_glow"])
    rings = [(rad + 2, 66), (rad + 4, 52), (rad + 6, 41), (rad + 9, 31),
             (rad + 12, 23), (rad + 16, 16), (rad + 21, 11), (rad + 27, 7),
             (rad + 34, 4)]
    for rr, a in reversed(rings):
        for y in range(cy - rr, cy + rr + 1):
            for x in range(cx - rr, cx + rr + 1):
                if 0 <= x < w and 0 <= y < h and math.hypot(x - cx, y - cy) <= rr:
                    L.px[x, y] = rgba(glow, a)
    for y in range(cy - rad - 1, cy + rad + 2):
        for x in range(cx - rad - 1, cx + rad + 2):
            d = math.hypot(x - cx, y - cy)
            if d > rad or not (0 <= x < w and 0 <= y < h):
                continue
            # two-tone body, terminator broken by a single dither pass only
            v = 1.0 - (d / float(rad)) ** 2 * 0.5 - (x - cx) / float(rad) * 0.14
            L.px[x, y] = rgba(body if v > 0.55 else shade(body, -0.14))
    for _ in range(max(3, rad // 3)):
        crx = cx + int(frnd(r, -rad * 0.6, rad * 0.6))
        cry = cy + int(frnd(r, -rad * 0.6, rad * 0.6))
        cr = max(1, int(frnd(r, 1, rad * 0.24)))
        for y in range(cry - cr, cry + cr + 1):
            for x in range(crx - cr, crx + cr + 1):
                if math.hypot(x - crx, y - cry) <= cr and math.hypot(x - cx, y - cy) < rad - 1:
                    if 0 <= x < w and 0 <= y < h:
                        L.px[x, y] = rgba(mix(body, glow, 0.34))
    return L


def bake_skyline(t, key, seed):
    """Tileable building band. No centre dip: a travelling dark blob reads as a
    bug once the layer scrolls. Detail is kept low and even instead."""
    cfg = t[key]
    hgt, top_y, _, _ = LAYERS[key]
    L = Layer(TILE_W, hgt)
    r = random.Random(seed)
    base_row = cfg["base"] - top_y             # image row of the ground line
    body = hx(cfg["body"])
    rim = hx(cfg["rim"]) if cfg.get("rim") else None
    win = hx(cfg["win"]) if cfg.get("win") else None
    win2 = hx(cfg["win2"]) if cfg.get("win2") else None

    spans = []
    x = 0
    while x < TILE_W:
        bw = int(frnd(r, cfg["minw"], cfg["maxw"]))
        if TILE_W - (x + bw) < cfg["minw"]:
            bw = TILE_W - x
        spans.append((x, bw, r.random()))
        x += bw
    for bx, bw, s in spans:
        bh = int(frnd(r, cfg["minh"], cfg["maxh"]))
        y0 = max(0, base_row - bh)
        L.rect(bx, y0, bw, base_row - y0 + 1, rgba(body))
        # vertical tone break so a wide block is not one flat slab
        if bw > 10:
            L.rect(bx + bw - 3, y0, 2, base_row - y0 + 1, rgba(shade(body, -0.12)))
        if rim:
            L.hline(bx, y0, bw, rgba(rim))
        if s > 0.70 and bw > 8:
            ax = bx + bw // 2
            L.vline(ax, y0 - int(4 + s * 6), int(4 + s * 6), rgba(body))
            if cfg.get("beacon") and s > 0.88:
                L.put(ax, y0 - int(4 + s * 6), rgba(hx(cfg["beacon"])))
        elif s < 0.22 and bw > 12:
            L.rect(bx + 2, y0 - 3, bw - 5, 3, rgba(body))
        if win:
            gap, sz = cfg["wingap"], cfg["winsz"]
            wy = y0 + 3
            while wy < base_row - 2:
                wx = bx + 2
                while wx < bx + bw - 2:
                    if r.random() < cfg["windens"]:
                        c = win2 if (win2 and r.random() > 0.85) else win
                        a = frnd(r, 0.40, 0.95)
                        for dy in range(sz):
                            for dx in range(sz):
                                L.blend(wx + dx, wy + dy, c, a)
                    wx += gap + sz
                wy += gap + sz
        if cfg.get("neon") and s > 0.84 and bw > 14:
            ny = y0 + 6
            for dx in range(bw - 6):
                L.blend(bx + 3 + dx, ny, hx(cfg["neon"]), 0.85)
                L.blend(bx + 3 + dx, ny + 1, hx(cfg["neon"]), 0.55)
    return L


def bake_fence(t, seed):
    """See-through chain-link, 14 px tall. Pass one was a solid wall that ate
    the whole city; the mesh is now a single sparse diagonal at low alpha."""
    hgt, top_y, _, _ = LAYERS["fence"]
    L = Layer(TILE_W, hgt)
    r = random.Random(seed + 11)
    base = HORIZON_Y - top_y
    post = hx(t["fence_post"])
    mesh = hx(t["fence_mesh"])
    conc = hx(t["fence_base"])
    top = base - 14
    L.rect(0, base, TILE_W, min(4, hgt - base), rgba(conc))
    for x in range(TILE_W):
        if r.random() < 0.18:
            L.put(x, base, rgba(shade(conc, 0.20)))
    for x in range(TILE_W):
        for y in range(top, base):
            if (x + y) % 6 == 0:
                L.blend(x, y, mesh, 0.16)
    for ry in (top, base - 1):
        for x in range(TILE_W):
            L.blend(x, ry, mesh, 0.34)
    for x in range(0, TILE_W, 24):
        L.vline(x, top - 2, base - top + 2, rgba(shade(post, 0.10)))
        if r.random() > 0.6:
            L.blend(x + 4, top - 2, mesh, 0.35)
    return L


def bake_fog(t, seed):
    """Ground haze that sits exactly on the fence foundation."""
    hgt, top_y, _, _ = LAYERS["fog"]
    L = Layer(TILE_W, hgt)
    c = hx(t["fog"])
    r = random.Random(seed + 13)
    for y in range(hgt):
        f = y / float(hgt - 1)
        a = math.sin(f * math.pi) ** 1.4 * 0.34
        for x in range(TILE_W):
            n = 0.75 + 0.25 * math.sin(x * 0.11 + y * 0.4 + r.random() * 0.2)
            if dither(x, y, a * n * 2.4):
                L.blend(x, y, c, min(0.5, a * n * 1.6))
    return L


def _asphalt(L, x0, y0, w, h, base, r, spec):
    """Calm asphalt: flat base, wide soft blotches, a few bright chips. The
    per-pixel dither of the first pass read as a moire carpet in motion."""
    L.rect(x0, y0, w, h, rgba(base))
    for _ in range(spec // 3):
        cx = r.randrange(int(x0), int(x0 + w))
        cy = int(frnd(r, y0, y0 + h - 1))
        rx, ry = r.randrange(4, 16), r.randrange(2, 5)
        tone = shade(base, frnd(r, -0.07, 0.09))
        for y in range(cy - ry, cy + ry + 1):
            for x in range(cx - rx, cx + rx + 1):
                d = ((x - cx) / float(rx)) ** 2 + ((y - cy) / float(ry)) ** 2
                if d <= 1.0 and dither(x, y, 1.0 - d * 0.7):
                    L.put(x, y, rgba(tone))
    for _ in range(spec):
        x = r.randrange(int(x0), int(x0 + w))
        y = int(frnd(r, y0, y0 + h - 1))
        L.blend(x, y, shade(base, 0.26), frnd(r, 0.20, 0.45))


def bake_road(t, seed):
    """The belt itself. Row BELT_TOP is the far curb, row BELT_BOT the near one,
    so the player's clamp lands on drawn geometry instead of on air."""
    hgt, top_y, _, _ = LAYERS["road"]
    L = Layer(TILE_W, hgt)
    r = random.Random(seed + 17)
    road = hx(t["road"])
    _asphalt(L, 0, 0, TILE_W, hgt, road, r, 260)
    # lane separators at 1/3 and 2/3 of the belt (faint, worn)
    for f in (0.34, 0.68):
        y = int(BELT_H * f)
        for x in range(TILE_W):
            if r.random() < 0.55:
                L.blend(x, y, hx(t["lane"]), frnd(r, 0.05, 0.13))
    # centre dashes, baked in: they must NOT slide under the player's feet
    y = int(BELT_H * 0.5)
    for sx in range(0, TILE_W, 32):
        for dx in range(14):
            for dy in range(2):
                L.blend(sx + dx, y + dy, hx(t["dash"]), 0.62 if dy else 0.78)
    # cracks
    for _ in range(22):
        x = r.randrange(TILE_W)
        y = r.randrange(4, hgt - 4)
        ln = r.randrange(2, 9)
        dy = 0
        for i in range(ln):
            L.blend(x + i, y + dy, hx(t["crack"]), frnd(r, 0.35, 0.7))
            if r.random() > 0.72:
                dy += 1 if r.random() > 0.5 else -1
    # oil / water patches - they read as depth on a flat surface
    for _ in range(7):
        cx = r.randrange(TILE_W)
        cy = r.randrange(6, hgt - 8)
        rx, ry = r.randrange(7, 22), r.randrange(2, 5)
        for y in range(cy - ry, cy + ry + 1):
            for x in range(cx - rx, cx + rx + 1):
                d = ((x - cx) / rx) ** 2 + ((y - cy) / ry) ** 2
                if d <= 1.0:
                    L.blend(x, y, hx(t["wet"]), 0.22 * (1.0 - d) + 0.06)
    # manhole
    cx = r.randrange(TILE_W)
    cy = int(BELT_H * 0.72)
    for y in range(cy - 3, cy + 4):
        for x in range(cx - 6, cx + 7):
            if ((x - cx) / 6.0) ** 2 + ((y - cy) / 3.0) ** 2 <= 1.0:
                L.put(x, y, rgba(shade(road, -0.22)))
    # below BELT_BOT the asphalt keeps going a little, then it is the near curb
    return L


def bake_curb_far(t, seed):
    """Far sidewalk + the curb line that IS depth 0."""
    hgt, top_y, _, _ = LAYERS["curb_far"]
    L = Layer(TILE_W, hgt)
    r = random.Random(seed + 19)
    walk = hx(t["walk"])
    curb = hx(t["curb"])
    L.rect(0, 0, TILE_W, hgt, rgba(shade(walk, -0.10)))
    for x in range(TILE_W):
        if r.random() < 0.22:
            L.put(x, r.randrange(0, hgt - 3), rgba(shade(walk, -0.22)))
    for x in range(0, TILE_W, 7):               # slab joints
        L.vline(x, 0, hgt - 3, rgba(shade(walk, -0.18)))
    curb_row = BELT_TOP - top_y                 # 13 -> last row
    L.hline(0, curb_row - 2, TILE_W, rgba(shade(curb, 0.04)))
    L.hline(0, curb_row - 1, TILE_W, rgba(curb))
    L.hline(0, curb_row, TILE_W, rgba(shade(curb, -0.30)))
    return L


def bake_curb_near(t, seed):
    """Near curb + sidewalk: the drawn floor of depth 1.0."""
    hgt, top_y, _, _ = LAYERS["curb_near"]
    L = Layer(TILE_W, hgt)
    r = random.Random(seed + 23)
    walk = hx(t["walk"])
    curb = hx(t["curb"])
    L.hline(0, 0, TILE_W, rgba(shade(curb, 0.10)))
    L.hline(0, 1, TILE_W, rgba(shade(curb, -0.06)))
    L.hline(0, 2, TILE_W, rgba(shade(curb, -0.40)))
    L.rect(0, 3, TILE_W, hgt - 3, rgba(walk))
    for x in range(0, TILE_W, 11):
        L.vline(x, 3, hgt - 3, rgba(shade(walk, -0.20)))
    for _ in range(90):
        L.blend(r.randrange(TILE_W), r.randrange(3, hgt), shade(walk, -0.25), 0.4)
    return L


CARS = ["sedan", "van", "pickup", "wreck"]


def _car(L, x, base, kind, col, r):
    """One abandoned car silhouette, drawn upward from its wheel line."""
    body = col
    dk = shade(body, -0.34)
    lt = shade(body, 0.16)
    glass = hx("#1b2233")
    if kind == "sedan":
        w, h, roof = 46, 12, 7
    elif kind == "van":
        w, h, roof = 44, 18, 15
    elif kind == "pickup":
        w, h, roof = 50, 12, 8
    else:
        w, h, roof = 42, 11, 5
    y0 = base - h
    L.rect(x, y0 + (h - 7), w, 7, rgba(body))          # lower body
    L.hline(x, y0 + (h - 7), w, rgba(lt))
    if kind == "pickup":
        L.rect(x + 2, y0, 20, roof, rgba(body))        # cab only
        L.rect(x + 4, y0 + 1, 15, max(2, roof - 4), rgba(glass))
        L.rect(x + 24, y0 + roof - 3, w - 26, 3, rgba(dk))
    elif kind == "wreck":
        L.rect(x + 6, y0 + 2, w - 16, roof, rgba(dk))  # burnt, caved in
        for i in range(0, w - 16, 3):
            L.put(x + 6 + i, y0 + 2, rgba(shade(dk, 0.2)))
    else:
        L.rect(x + 5, y0, w - 12, roof, rgba(body))
        L.rect(x + 7, y0 + 2, w - 17, max(2, roof - 3), rgba(glass))
        if r.random() > 0.5:                            # shattered windscreen
            for i in range(6):
                L.put(x + 8 + r.randrange(w - 18), y0 + 2 + r.randrange(max(1, roof - 3)),
                      rgba(shade(glass, 0.5)))
    for wx in (x + 6, x + w - 10):                      # wheels
        L.rect(wx, base - 3, 5, 3, rgba(hx("#0d0b12")))
    L.hline(x + 1, base, w - 2, rgba((0, 0, 0)))        # contact shadow
    if kind != "wreck" and r.random() > 0.45:           # one headlight still on
        L.blend(x + w - 1, base - 6, hx("#ffe9a8"), 0.55)
        L.blend(x + w, base - 6, hx("#ffe9a8"), 0.25)


def bake_props_near(t, seed):
    """Foreground: parked wrecks, bins, then a dark apron down to the screen
    edge (this is the black hole from the first pass, now filled)."""
    hgt, top_y, _, _ = LAYERS["props_near"]
    L = Layer(TILE_W, hgt)
    r = random.Random(seed + 29)
    walk_row = 96 - top_y                       # cars stand on the near sidewalk
    apron = hx(t["apron"])
    L.rect(0, walk_row, TILE_W, hgt - walk_row, rgba(apron))
    for y in range(walk_row, hgt):
        f = (y - walk_row) / float(hgt - walk_row)
        for x in range(TILE_W):
            if dither(x, y, f * 0.55):
                L.put(x, y, rgba(shade(apron, -0.16)))
    for _ in range(200):
        L.blend(r.randrange(TILE_W), r.randrange(walk_row, hgt), shade(apron, 0.30), 0.22)
    # ragged spacing on purpose: an even rhythm read as wallpaper
    x = r.randrange(20)
    guard = 0
    while x < TILE_W - 40 and guard < 40:
        guard += 1
        kind = CARS[r.randrange(len(CARS))]
        col = hx(t["cars"][r.randrange(len(t["cars"]))])
        _car(L, x, walk_row, kind, col, r)
        x += int(frnd(r, 58, 128))
    for _ in range(4):                          # bins / crates
        bx = r.randrange(TILE_W)
        bh = r.randrange(7, 12)
        c = hx(t["prop"])
        L.rect(bx, walk_row - bh, 9, bh, rgba(c))
        L.hline(bx, walk_row - bh, 9, rgba(shade(c, 0.22)))
        L.hline(bx, walk_row, 9, rgba((0, 0, 0)))
    return L


# ------------------------------------------------------------------ themes
def T(**kw):
    return kw


THEMES = {
    "neon": T(
        name="NEON DECAY", stars=70,
        sky=["#07040f", "#0d0719", "#1a0c28", "#2c1038", "#4a1442"],
        moon="#efe6ff", moon_glow="#7a4fd0", moon_r=16, moon_ax=0.18, moon_y=-86,
        far=dict(body="#150c26", rim="#26154a", base=-30, minh=26, maxh=62, minw=14, maxw=34,
                 win="#4a2b7a", winsz=1, wingap=3, windens=0.09),
        mid=dict(body="#1d1036", rim="#3a1f63", base=-28, minh=20, maxh=50, minw=18, maxw=40,
                 win="#b06bd8", win2="#ff5fa2", winsz=2, wingap=3, windens=0.12,
                 neon="#ff3d8b", beacon="#ff4d4d"),
        near=dict(body="#0a0616", base=-26, minh=12, maxh=34, minw=22, maxw=48,
                  win="#ff5fa2", winsz=2, wingap=5, windens=0.05),
        fence_post="#160f28", fence_mesh="#5b4a86", fence_base="#241a3c",
        fog="#3a1550",
        road="#221a38", lane="#7d6fa0", dash="#d8bf3f", crack="#120d20", wet="#6a5fd0",
        walk="#241b3c", curb="#42335f", apron="#171029",
        cars=["#2a1f42", "#3a2338", "#1e2440", "#402a2a"], prop="#2b2140",
        particle="rain", pcolor="#8f7ad8", beams=False,
    ),
    "blood": T(
        name="BLOOD MOON", stars=28,
        sky=["#0a0407", "#1a060b", "#320a11", "#54121a", "#7d1f1e"],
        moon="#ff6a4a", moon_glow="#c02a1e", moon_r=26, moon_ax=0.72, moon_y=-80,
        far=dict(body="#1a0810", base=-30, minh=28, maxh=64, minw=16, maxw=36,
                 win="#7a2a1a", winsz=1, wingap=4, windens=0.05),
        mid=dict(body="#120509", rim="#3d1013", base=-28, minh=20, maxh=50, minw=20, maxw=42,
                 win="#ffb347", winsz=1, wingap=4, windens=0.06, beacon="#ff3b30"),
        near=dict(body="#060203", base=-26, minh=12, maxh=34, minw=24, maxw=52,
                  win="#e08a3c", winsz=2, wingap=6, windens=0.03),
        fence_post="#150708", fence_mesh="#6b3a34", fence_base="#2a1213",
        fog="#6b1a1c",
        road="#241a1e", lane="#8a6a62", dash="#c8a83a", crack="#120a0c", wet="#7a3028",
        walk="#241416", curb="#472628", apron="#1a1114",
        cars=["#3a1c1c", "#2a1416", "#402424", "#1c1214"], prop="#2e1a18",
        particle="ash", pcolor="#ffb99a", beams=False,
    ),
    "toxic": T(
        name="TOXIC HAZE", stars=14,
        sky=["#07110c", "#0f2317", "#1d3a24", "#395d2e", "#7d9a3e"],
        moon="#e6f58a", moon_glow="#96b03a", moon_r=17, moon_ax=0.30, moon_y=-84,
        far=dict(body="#16281a", base=-30, minh=26, maxh=60, minw=12, maxw=30,
                 win="#3f6b32", winsz=1, wingap=3, windens=0.07),
        mid=dict(body="#0f1d13", rim="#2c4a26", base=-28, minh=20, maxh=52, minw=10, maxw=26,
                 win="#9dff6b", winsz=1, wingap=3, windens=0.09, beacon="#ff4d4d"),
        near=dict(body="#06100a", base=-26, minh=12, maxh=34, minw=26, maxw=54,
                  win="#7fe04a", winsz=2, wingap=6, windens=0.04),
        fence_post="#0b1a0f", fence_mesh="#5a7a48", fence_base="#1d3020",
        fog="#4a7a2e",
        road="#212a1e", lane="#8fa079", dash="#c9cf4a", crack="#0f1610", wet="#6fa040",
        walk="#1f2a1c", curb="#3c5232", apron="#141c14",
        cars=["#25361f", "#1c2a26", "#3a3a20", "#202a30"], prop="#26361f",
        particle="spore", pcolor="#c6ff7a", beams=False,
    ),
    "cold": T(
        name="DEAD COLD", stars=60,
        sky=["#05070d", "#0a1019", "#111d2e", "#1d3049", "#33506e"],
        moon="#dbeaff", moon_glow="#3f6a9e", moon_r=13, moon_ax=0.80, moon_y=-90,
        far=dict(body="#101a28", rim="#1e3450", base=-30, minh=28, maxh=62, minw=14, maxw=32,
                 win="#2f5d85", winsz=1, wingap=3, windens=0.08),
        mid=dict(body="#0b1320", rim="#1b2f47", base=-28, minh=24, maxh=92, minw=18, maxw=40,
                 win="#8fd8ff", win2="#ffd27a", winsz=1, wingap=3, windens=0.10, beacon="#ff5b5b"),
        near=dict(body="#050810", base=-26, minh=12, maxh=34, minw=24, maxw=50,
                  win="#7ab8e0", winsz=2, wingap=6, windens=0.04),
        fence_post="#0a1018", fence_mesh="#6f88a4", fence_base="#20303e",
        fog="#2a4a6e",
        road="#232a36", lane="#93a8bd", dash="#c9b25a", crack="#101724", wet="#5f7fa8",
        walk="#c8d6e4", curb="#8fa4b8", apron="#171e26",
        cars=["#233043", "#2c2c38", "#38424e", "#1e2836"], prop="#2a3644",
        particle="snow", pcolor="#ffffff", beams=True,
    ),
}

BAKERS = {
    "sky": bake_sky, "moon": bake_moon, "fence": bake_fence, "fog": bake_fog,
    "road": bake_road, "curb_far": bake_curb_far, "curb_near": bake_curb_near,
    "props_near": bake_props_near,
}


def bake_theme(key, seed):
    t = THEMES[key]
    d = os.path.join(OUT, key)
    os.makedirs(d, exist_ok=True)
    out = {}
    for name in ("sky", "far", "mid", "near", "fence", "fog",
                 "curb_far", "road", "curb_near", "props_near", "moon"):
        if name in ("far", "mid", "near"):
            L = bake_skyline(t, name, seed + hash(name) % 1000)
        else:
            L = BAKERS[name](t, seed)
        L.save(os.path.join(d, name + ".png"))
        out[name] = [L.w, L.h]
    return out


def main():
    seed = 1337
    os.makedirs(OUT, exist_ok=True)
    index = {"tile_w": TILE_W, "belt": {"horizon": HORIZON_Y, "curb_h": CURB_H,
                                        "top": BELT_TOP, "bot": BELT_BOT, "h": BELT_H},
             "layers": {k: {"h": v[0], "y": v[1], "factor": v[2], "z": v[3]}
                        for k, v in LAYERS.items()},
             "moon": {"w": MOON[0], "h": MOON[1], "factor": MOON[2], "z": MOON[3]},
             "themes": {}}
    for i, key in enumerate(THEMES):
        sizes = bake_theme(key, seed + i * 911)
        index["themes"][key] = {
            "name": THEMES[key]["name"],
            "particle": THEMES[key]["particle"],
            "pcolor": THEMES[key]["pcolor"],
            "beams": THEMES[key]["beams"],
            "moon_ax": THEMES[key]["moon_ax"],
            "moon_y": THEMES[key]["moon_y"],
            "sizes": sizes,
        }
        print("baked", key, THEMES[key]["name"])
    with open(os.path.join(OUT, "index.json"), "w") as f:
        json.dump(index, f, indent=1, sort_keys=True)
    total = 0
    for root, _, files in os.walk(OUT):
        for fn in files:
            total += os.path.getsize(os.path.join(root, fn))
    print("art/env total: %.0f KB" % (total / 1024.0))


if __name__ == "__main__":
    main()
