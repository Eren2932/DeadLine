"""Procedural soundtrack generator for Dead Line.
Renders three seamless looping tracks (menu / battle / boss) as 22050 Hz mono WAV.
Run:  python3 tools/music.py      (output -> <project>/music/*.wav)
"""
import numpy as np, wave, os, math
from scipy import signal

SR = 22050
OUT = os.environ.get("MUSIC_OUT", os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "music"))
os.makedirs(OUT, exist_ok=True)
rng = np.random.default_rng(1337)

# ------------------------------------------------------------------ helpers
def n_of(sec):
    return int(round(SR * sec))

def zeros(sec):
    return np.zeros(n_of(sec))

def add(buf, pos_sec, data, gain=1.0):
    i = int(round(pos_sec * SR))
    if i < 0:
        data = data[-i:]
        i = 0
    if i >= len(buf):
        return
    end = min(len(buf), i + len(data))
    buf[i:end] += data[:end - i] * gain

def env_ad(n, a=0.002, p=2.0, hold=0.0):
    e = np.ones(n)
    at = max(1, int(n * a)) if a < 1 else int(a)
    at = min(at, n - 1) if n > 1 else 1
    e[:at] = np.linspace(0.0, 1.0, at)
    h = int(hold * n)
    dec_len = n - at - h
    if dec_len > 0:
        e[at + h:] = np.linspace(1.0, 0.0, dec_len) ** p
    return e

def noise(n):
    return rng.normal(0.0, 1.0, n)

def lp(x, cut, order=2):
    cut = min(cut, SR * 0.45)
    b, a = signal.butter(order, cut / (SR * 0.5), btype="low")
    return signal.lfilter(b, a, x)

def hp(x, cut, order=2):
    b, a = signal.butter(order, max(20.0, cut) / (SR * 0.5), btype="high")
    return signal.lfilter(b, a, x)

def bp(x, lo, hi, order=2):
    b, a = signal.butter(order, [max(20.0, lo) / (SR * 0.5), min(hi, SR * 0.45) / (SR * 0.5)],
                         btype="band")
    return signal.lfilter(b, a, x)

def saw(freq, n, phase=0.0):
    ph = (np.arange(n) * freq / SR + phase) % 1.0
    return 2.0 * ph - 1.0

def square(freq, n, duty=0.5, phase=0.0):
    ph = (np.arange(n) * freq / SR + phase) % 1.0
    return np.where(ph < duty, 1.0, -1.0)

def sine(freq, n, phase=0.0):
    return np.sin(2.0 * np.pi * (np.arange(n) * freq / SR + phase))

def dist(x, drive=8.0):
    return np.tanh(x * drive)

def note(semi, base=82.41):
    """Frequency of a note given in semitones above E2 (drop-E metal root)."""
    return base * (2.0 ** (semi / 12.0))

# ------------------------------------------------------------------ instruments
def kick(dur=0.30, f0=150.0, f1=44.0, punch=1.0):
    n = n_of(dur)
    f = np.linspace(f0, f1, n)
    body = np.sin(2.0 * np.pi * np.cumsum(f) / SR) * env_ad(n, 0.0008, 2.2)
    click = hp(noise(n), 2200) * env_ad(n, 0.0005, 9.0) * 0.35 * punch
    return dist(body * 1.4, 1.6) * 0.9 + click

def snare(dur=0.22, bright=1.0):
    n = n_of(dur)
    body = (sine(190, n) + 0.7 * sine(268, n)) * env_ad(n, 0.001, 4.0) * 0.5
    rattle = bp(noise(n), 900, 6500 * bright) * env_ad(n, 0.001, 2.4)
    return dist(body + rattle * 1.2, 1.4)

def hat(dur=0.07, open_=False):
    n = n_of(dur if not open_ else dur * 4)
    return hp(noise(n), 6500) * env_ad(n, 0.0004, 5.0 if not open_ else 1.6) * 0.5

def crash(dur=1.6):
    n = n_of(dur)
    c = hp(noise(n), 3200) * env_ad(n, 0.001, 1.3)
    c += bp(noise(n), 1200, 4200) * env_ad(n, 0.002, 1.0) * 0.6
    return c * 0.55

def tom(f=120.0, dur=0.25):
    n = n_of(dur)
    return np.sin(2.0 * np.pi * np.cumsum(np.linspace(f, f * 0.7, n)) / SR) * env_ad(n, 0.001, 2.4)

def guitar(semi, dur, mute=False, power=True, drive=11.0, detune=0.008):
    """Palm-muted / ringing distorted power chord."""
    n = n_of(dur)
    f = note(semi)
    voices = [f, f * (1.0 + detune), f * 0.5]
    if power:
        voices += [f * 1.4983, f * 1.4983 * (1.0 - detune), f * 2.0]
    x = np.zeros(n)
    for i, vf in enumerate(voices):
        x += saw(vf, n, phase=rng.random()) * (1.0 / (1.0 + i * 0.35))
    e = env_ad(n, 0.0015, 6.0 if mute else 1.5, 0.0 if mute else 0.25)
    x = dist(x * e * 1.4, drive)
    x = lp(x, 3600)
    x = hp(x, 95)
    # speaker cabinet bump
    x += lp(x, 240) * 0.5
    return x * e

def bass(semi, dur, drive=5.0):
    n = n_of(dur)
    f = note(semi) * 0.5
    x = saw(f, n) * 0.8 + sine(f, n) * 0.9 + square(f * 2.0, n, 0.35) * 0.18
    x = dist(x, drive)
    x = lp(x, 900)
    return x * env_ad(n, 0.004, 2.0, 0.55)

def lead(semi, dur, kind="square"):
    n = n_of(dur)
    f = note(semi) * 2.0
    vib = 1.0 + 0.012 * np.sin(2.0 * np.pi * 5.5 * np.arange(n) / SR)
    ph = np.cumsum(f * vib) / SR
    x = (2.0 * ((ph % 1.0)) - 1.0) if kind == "saw" else np.where((ph % 1.0) < 0.5, 1.0, -1.0)
    x = dist(x * 0.7, 4.0)
    x = lp(x, 5200)
    return x * env_ad(n, 0.01, 1.6, 0.35) * 0.5

def pad(semi, dur, voices=5):
    n = n_of(dur)
    f = note(semi)
    x = np.zeros(n)
    for i in range(voices):
        det = 1.0 + (i - voices * 0.5) * 0.004
        x += saw(f * det, n, rng.random()) * 0.5
        x += saw(f * 2.0 * det, n, rng.random()) * 0.18
    x = lp(x, 1400)
    e = np.minimum(1.0, np.linspace(0, 3, n)) * np.minimum(1.0, np.linspace(3, 0, n))
    return x * e * 0.4

def bell(semi, dur=2.4):
    n = n_of(dur)
    f = note(semi) * 2.0
    x = np.zeros(n)
    for k, g in [(1.0, 1.0), (2.01, 0.5), (2.98, 0.3), (4.2, 0.16), (5.4, 0.1)]:
        x += sine(f * k, n) * g * env_ad(n, 0.001, 1.6 + k * 0.4)
    return x * 0.4

def wind(dur):
    n = n_of(dur)
    x = lp(noise(n), 420) * 1.4
    mod = 0.5 + 0.5 * np.sin(2.0 * np.pi * 0.08 * np.arange(n) / SR + rng.random() * 6.0)
    return x * mod * 0.25

def reverb(x, decay=0.32, mix=0.28):
    out = np.copy(x)
    for d, g in [(0.031, 0.7), (0.047, 0.6), (0.071, 0.5), (0.113, 0.42)]:
        di = n_of(d)
        tail = np.zeros(len(x))
        tail[di:] = x[:-di] * g * decay
        out += tail * mix
    return out

def master(buf, tail_sec, gain=0.92, loud=1.0):
    """Fold the reverb tail back to the head so the loop is seamless, then limit."""
    tail_n = n_of(tail_sec)
    if tail_n > 0 and len(buf) > tail_n * 2:
        buf[:tail_n] += buf[-tail_n:]
        buf = buf[:-tail_n]
    buf = dist(buf * loud, 1.05)
    m = np.max(np.abs(buf)) or 1.0
    return buf / m * gain

def write(name, data):
    """Writes a temp WAV then encodes to OGG Vorbis (small, loops cleanly in Godot)."""
    pcm = (np.clip(data, -1.0, 1.0) * 32000).astype("<i2")
    wav_path = os.path.join(OUT, name + ".wav")
    f = wave.open(wav_path, "wb")
    f.setnchannels(1)
    f.setsampwidth(2)
    f.setframerate(SR)
    f.writeframes(pcm.tobytes())
    f.close()
    ogg_path = os.path.join(OUT, name + ".ogg")
    rc = os.system('ffmpeg -y -loglevel error -i "%s" -c:a libvorbis -q:a 3 -ar %d -ac 1 "%s"'
                   % (wav_path, SR, ogg_path))
    if rc == 0 and os.path.exists(ogg_path):
        os.remove(wav_path)
        size = os.path.getsize(ogg_path) / 1024.0
        print("  %-12s %5.1f s  %6.1f KB (ogg)" % (name, len(data) / SR, size))
    else:
        print("  %-12s %5.1f s  WAV fallback (ffmpeg missing)" % (name, len(data) / SR))

# ------------------------------------------------------------------ BATTLE
# ============================================================ extra voices (v1.2)
def choir(semi, dur, voices=6):
    """Breathy dead-choir pad: filtered saws + formant-ish bandpassed noise."""
    n = n_of(dur)
    f = note(semi)
    x = np.zeros(n)
    for i in range(voices):
        det = 1.0 + (i - voices * 0.5) * 0.0035
        x += saw(f * det, n, rng.random()) * 0.35
        x += sine(f * 2.0 * det, n, rng.random()) * 0.22
    breath = bp(noise(n), f * 2.0, f * 5.0) * 0.25
    x = lp(x + breath, 2200)
    swell = np.minimum(1.0, np.linspace(0, 2.2, n)) * np.minimum(1.0, np.linspace(2.6, 0, n))
    trem = 0.88 + 0.12 * np.sin(2.0 * np.pi * 4.4 * np.arange(n) / SR)
    return x * swell * trem * 0.34


def anvil(dur=0.5, f=210.0):
    """Industrial metal hit: inharmonic partials over a noise burst."""
    n = n_of(dur)
    x = np.zeros(n)
    for k, g in [(1.0, 1.0), (1.73, 0.55), (2.41, 0.4), (3.77, 0.22), (5.19, 0.12)]:
        x += sine(f * k, n) * g * env_ad(n, 0.0005, 2.2 + k * 0.5)
    x += bp(noise(n), 1800, 6500) * env_ad(n, 0.0004, 9.0) * 0.7
    return x * 0.5


def sub_drop(dur=1.2, f0=70.0, f1=26.0):
    n = n_of(dur)
    ph = np.cumsum(np.linspace(f0, f1, n)) / SR
    return np.sin(2.0 * np.pi * ph) * env_ad(n, 0.004, 1.5, 0.25) * 0.9


def siren(dur, lo=380.0, hi=900.0, rate=0.5):
    n = n_of(dur)
    t = np.arange(n) / SR
    f = lo + (hi - lo) * (0.5 - 0.5 * np.cos(2.0 * np.pi * rate * t))
    x = np.where((np.cumsum(f) / SR % 1.0) < 0.5, 1.0, -1.0)
    return lp(x, 2600) * 0.16


# ============================================================ battle theme
def build_battle():
    """DEAD LINE main combat theme - drop-D industrial thrash, 152 BPM, 16 bars."""
    bpm = 152.0
    beat = 60.0 / bpm
    bar = beat * 4.0
    bars = 16
    tail = 2.2
    buf = zeros(bar * bars + tail)

    # drop-D root, natural minor colours
    riff_a = [-2, -2, -2, 3, -2, -2, 5, -2]        # gallop around the root
    riff_b = [-2, -2, 10, 8, -2, -2, 7, 5]
    chords = [-2, 5, 3, 7]                          # D  G  F  A
    melody = [17, 15, 14, 12, 14, 15, 17, 19, 17, 15, 14, 10]

    def drums(pos, style="main"):
        sixteenth = beat * 0.25
        add(buf, pos + 0.0, kick(0.30, 165.0, 46.0, 1.15), 1.05)
        add(buf, pos + beat * 0.75, kick(0.26, 150.0, 44.0), 0.75)
        add(buf, pos + beat * 1.0, snare(0.24, 1.0), 0.92)
        add(buf, pos + beat * 2.0, kick(0.30, 165.0, 46.0, 1.15), 1.0)
        add(buf, pos + beat * 2.5, kick(0.24, 150.0, 44.0), 0.7)
        add(buf, pos + beat * 3.0, snare(0.24, 1.05), 0.95)
        if style == "fill":
            for i in range(4):
                add(buf, pos + beat * 3.0 + sixteenth * i, tom(190.0 - i * 26.0, 0.22), 0.72)
        for i in range(8):
            open_ = (style == "main" and i == 7)
            add(buf, pos + beat * 0.5 * i, hat(0.10 if open_ else 0.06, open_), 0.30)

    for b in range(bars):
        pos = bar * b
        section = b // 4
        drums(pos, "fill" if (b % 4) == 3 else "main")

        # ---- rhythm guitar + bass, 8th note engine
        pattern = riff_a if section in (0, 2) else riff_b
        for i, semi in enumerate(pattern):
            t = pos + beat * 0.5 * i
            mute = (i % 4) != 2
            add(buf, t, guitar(semi, beat * 0.5, mute=mute, drive=12.0), 0.42)
            add(buf, t, bass(semi, beat * 0.5), 0.50)

        # ---- sustained power chord on the down beat from section 1 onward
        if section >= 1:
            add(buf, pos, guitar(chords[b % 4], bar * 0.55, mute=False, drive=9.0), 0.26)

        # ---- lead line over the third section
        if section == 2:
            for i in range(3):
                idx = ((b % 4) * 3 + i) % len(melody)
                add(buf, pos + beat * 1.3333 * i, lead(melody[idx], beat * 1.25, "saw"), 0.34)

        # ---- last section: half-time breakdown, choir and factory hits
        if section == 3:
            add(buf, pos, choir(chords[b % 4] + 12, bar * 1.05), 0.42)
            add(buf, pos + beat * 1.0, anvil(0.55, 232.0), 0.40)
            add(buf, pos + beat * 3.0, anvil(0.45, 186.0), 0.34)

        if b == 0:
            add(buf, pos, crash(1.7), 0.45)
        if b == 12:
            add(buf, pos, crash(1.9), 0.50)
            add(buf, pos, sub_drop(1.4), 0.55)

    buf += wind(len(buf) / SR) * 0.10
    buf = reverb(buf, 0.30, 0.22)
    return master(buf, tail, 0.93, 1.05)


# ============================================================ boss theme
def build_boss():
    """Boss encounter - slow doom crawl with sirens and a dead choir, 92 BPM."""
    bpm = 92.0
    beat = 60.0 / bpm
    bar = beat * 4.0
    bars = 8
    tail = 2.6
    buf = zeros(bar * bars + tail)

    prog = [-2, -2, 1, -2, -4, -4, -5, 3]
    for b in range(bars):
        pos = bar * b
        root = prog[b]

        add(buf, pos, kick(0.42, 180.0, 38.0, 1.3), 1.15)
        add(buf, pos + beat * 1.5, kick(0.32, 160.0, 40.0), 0.8)
        add(buf, pos + beat * 2.0, snare(0.30, 0.9), 0.9)
        add(buf, pos + beat * 3.5, kick(0.30, 160.0, 40.0), 0.7)
        for i in range(4):
            add(buf, pos + beat * i, tom(96.0 + (i % 2) * 22.0, 0.30), 0.30)

        # crushing chords, four to the bar
        for i in range(4):
            add(buf, pos + beat * i, guitar(root, beat * 0.95, mute=(i % 2 == 1), drive=14.0), 0.44)
            add(buf, pos + beat * i, bass(root, beat * 0.95, 6.0), 0.52)

        add(buf, pos, choir(root + 12, bar * 1.1), 0.50)
        add(buf, pos + beat * 2.0, anvil(0.7, 168.0), 0.42)
        if b % 2 == 1:
            add(buf, pos + beat * 3.0, bell(root + 24, 2.2), 0.30)
        if b == 0 or b == 4:
            add(buf, pos, crash(2.2), 0.48)
            add(buf, pos, sub_drop(1.8, 84.0, 24.0), 0.62)

    buf += siren(len(buf) / SR, 300.0, 780.0, 0.11) * 0.9
    buf += wind(len(buf) / SR) * 0.18
    buf = reverb(buf, 0.42, 0.34)
    return master(buf, tail, 0.94, 1.0)


# ============================================================ menu theme
def build_menu():
    """Main menu - cold post-apocalyptic ambience with a distant heartbeat."""
    bpm = 68.0
    beat = 60.0 / bpm
    bar = beat * 4.0
    bars = 8
    tail = 3.2
    buf = zeros(bar * bars + tail)

    prog = [-2, 3, -4, 5, -2, 3, -7, -5]
    phrase = [10, 12, 15, 14, 12, 10, 8, 7]

    for b in range(bars):
        pos = bar * b
        root = prog[b]
        add(buf, pos, pad(root, bar * 1.25, 6), 0.55)
        add(buf, pos, choir(root + 12, bar * 1.15), 0.30)
        add(buf, pos + beat * 0.5, bass(root, beat * 2.4, 2.5), 0.30)

        # heartbeat
        add(buf, pos, kick(0.40, 120.0, 40.0, 0.9), 0.55)
        add(buf, pos + beat * 0.42, kick(0.34, 110.0, 38.0, 0.7), 0.34)

        # lonely bell phrase, second half of the loop only
        if b >= 3:
            add(buf, pos + beat * 1.0, bell(phrase[b % len(phrase)] + 12, 2.6), 0.34)
        if b == 4:
            add(buf, pos, anvil(0.9, 148.0), 0.26)
        if b == 7:
            add(buf, pos + beat * 2.0, anvil(0.8, 196.0), 0.22)

    buf += wind(len(buf) / SR) * 0.55
    buf += siren(len(buf) / SR, 220.0, 420.0, 0.05) * 0.35
    buf = reverb(buf, 0.5, 0.42)
    return master(buf, tail, 0.85, 0.9)


if __name__ == "__main__":
    print("Dead Line soundtrack v1.2 -> %s" % OUT)
    write("battle", build_battle())
    write("boss", build_boss())
    write("menu", build_menu())
    print("done.")
