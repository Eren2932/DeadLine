# Dead Line 2.0 - "Balance & Bugfix" pass

Everything below is live in the code, not a plan.

## Fixed bugs
- **Map edges losing their textures.** The parallax bands were positioned from
  `cam.global_position`, which is the *unclamped* follow target. At the ends of
  the arena the camera is pinned by its limits, so every band drifted off and
  half the screen went bare. All layers now wrap around
  `cam.get_screen_center_position()` (the real, clamped centre).
- **Shop / build menu disappearing after a few waves.** `overlay_dim` could stay
  on after an upgrade or pause panel, and the prep card was hidden while it was
  visible. The HUD now self-heals: if no panel is actually shown, the dim layer
  is forced off every frame.
- **Build bar closing on its own.** The wave used to start while the bar was
  open. The intermission clock is now frozen while the shop or the build bar is
  open, and says so on screen.
- **No time in the shop.** Same fix: the timer stops when you walk in, and the
  remaining time is printed at the top ("TIMER PAUSED - NEXT WAVE IN 24s").
- **Walking out of the arena.** Player, spawns, building and the camera are all
  clamped to the same road strip (`GameData.play_left()/play_right()`).

## Wave flow
- 20 s before wave 1, **30 s between waves**, plus a "START NOW" button.
- Structures repair 20 % and age one wave at the end of each wave.
- Free upgrade pick every 3rd wave and a grenade resupply every wave.

## Balance
- **Weapons**: all damage re-tuned, every gun has an **armour-penetration**
  stat, and damage scales with survivor level (`player_power`, +4.2 %/level).
  Late guns (railgun, gauss, minigun, RPG) now need a **player level**, not just
  a wave number.
- **Zombies**: growth curve flattened (x13.8 HP at wave 66 instead of runaway),
  body count capped at 70, speed capped at x1.5.
- **Armour** is two-layered: percentage + flat, and **never** blocks more than
  88 % of a hit. Weapon AP eats into both.
- **Bosses** run on their own curve (`boss_hp_mul`, `boss_dmg_mul`,
  `boss_armor`), so a boss is always far above the trash of the same wave -
  wave 66 boss ~66k HP vs ~500 for a walker.
- **XP** is polynomial: level 66 costs ~2.1k XP instead of tens of millions.
- **Economy**: kill money, combo cap (x1.5) and wave rewards all trimmed;
  ammo and structures cost real money.

## Structures (the big nerf)
| | price | HP | life | limit |
|---|---|---|---|---|
| Barricade | 150 | 900 | 6 waves | 8 |
| Sandbags | 95 | 520 | 5 | 8 |
| Spikes | 170 | 260 | 4 | 6 |
| Mine | 120 | indestructible | 8 | 8 |
| Sentry | 900 | 150 | 3 | 3 |
| Tesla Coil | 1100 | 120 | 3 | 2 |

- Global cap of 22 structures on the field.
- Sentry: range 210 -> 132, rate 4.5 -> 2.2, damage 15 -> 9, knockback 30 -> 6.
- Barricades are much tougher, turrets and coils are made of paper.
- **Damage-type resistances**: walls take 65 % less acid, 35 % less blast, so
  ranged zombies no longer delete the defence line.
- The horde now **aggros structures** properly, and ranged zombies shell them.
- Mines cannot be destroyed and hit for 260 in a 78 px blast.
- Live **placement ghost**: footprint, spacing ring, attack radius, red/green
  validity and the blocked rings of everything already built. Drag on the ground
  to move it, release to place.
- The build bar shows what is selected in big letters, the price, how many are
  left of that kind and how many waves it will live.

## Drops & ammo
- Drop chance scales with the wave (7.5 % -> 17 %), bosses always drop.
- New **ammo pickup** (tops every gun up by 35 % of its reserve) and a grenade
  pickup. Medkits heal 35 % of max HP.
- Scavenger upgrade: +50 % drop rate.

## Combat feel
- Dash is longer and faster (0.24 s / 355 u), cooldown floor 0.55 s, i-frames
  cover the whole dash plus 0.18 s, and it dashes in the direction you *move*.
- Grenades: damage scales with level, bigger blast, 0.5 AP, and they are lobbed
  at the **densest cluster** in range (`best_cluster`) instead of the nearest
  scrub at the edge of the screen.
- Turrets, allies and auto-aim use `best_target`, which weighs threat (bosses
  and elites) against distance.

## Performance
- Distance based **level of detail**: bodies off screen think at half rate and
  skip all effects.
- Grid-based target lookups instead of O(n) scans per shot.
- HUD refreshes at 20 Hz during a fight instead of every frame.
- Structure aggro is cached (recomputed 3x/s, not every frame).

## New upgrades
Cooling Fins (structure fire rate), Field Repairs (+1 wave of structure life),
Demolition (grenades), Scavenger (drops) - plus a tier system: strong cards from
level 4, rare cards from level 9, and 4 cards offered from level 12.
